<div class="secondary">
    <div class="container">
        <div id="secondary_wrap" class="row">
            <div class="col-md-3">
            <h5 class="address_title"><strong>ADDRESS</strong></h5>
                <address>
                    <strong>College of Engineering Poonjar</strong>
                    <br>Engineering College Road
                    <br>Post Thekkekkara
                    <br>Poonjar
                    <br>Kottayam
                    <br>Kerala
                    <br>686582
                    <br>
                    <br>
                    <div><span class="glyphicon glyphicon-phone-alt"></span><a href="#">0481-25xxxx</a></div>
                    <div><span class="glyphicon glyphicon-earphone"></span><a href="#">+918547924342</a></div>
                <div>  <span class="glyphicon glyphicon-envelope"></span>  <a href="mailto:jithurjacob@gmail.com">jiturjacob@gmail.com</a></div>
                </address>
            </div>
            <div class="col-md-3">
                <ul>
                    <li>
                        <a href="">Vision and Mission</a>
                    </li>
                    <li>
                        <a href="">M.Tech &amp; B.Tech</a>
                    </li>
                    <li>
                        <a href="">College Calendar</a>
                    </li>
                    <li>
                        <a href="">Location</a>
                    </li>
                    <li>
                        <a href="">P T A</a>
                    </li>
                    <li>
                        <a href="">Hostel</a>
                    </li>
                    <li>
                        <a href="">IEEE Chapter</a>
                    </li>
                    <li>
                        <a href="">ISTE Chapter</a>
                    </li>
                    <li>
                        <a href="">ACM Chapter</a>
                    </li>
                </ul>
            </div>
            <div class="col-md-3">

                <ul>
                    <li>
                        <a href="">Vision and Mission</a>
                    </li>
                    <li>
                        <a href="">M.Tech &amp; B.Tech</a>
                    </li>
                    <li>
                        <a href="">College Calendar</a>
                    </li>
                    <li>
                        <a href="">Location</a>
                    </li>
                    <li>
                        <a href="">P T A</a>
                    </li>
                    <li>
                        <a href="">Hostel</a>
                    </li>
                    <li>
                        <a href="">IEEE Chapter</a>
                    </li>
                    <li>
                        <a href="">ISTE Chapter</a>
                    </li>
                    <li>
                        <a href="">ACM Chapter</a>
                    </li>
                </ul>
            </div>
            <div class="col-md-3">
                <ul>
                    <li>
                        <a href="">Vision and Mission</a>
                    </li>
                    <li>
                        <a href="">M.Tech &amp; B.Tech</a>
                    </li>
                    <li>
                        <a href="">College Calendar</a>
                    </li>
                    <li>
                        <a href="">Location</a>
                    </li>
                    <li>
                        <a href="">P T A</a>
                    </li>
                    <li>
                        <a href="">Hostel</a>
                    </li>
                    <li>
                        <a href="">IEEE Chapter</a>
                    </li>
                    <li>
                        <a href="">ISTE Chapter</a>
                    </li>
                    <li>
                        <a href="">ACM Chapter</a>
                    </li>
                </ul>
            </div>

        </div>
    </div>
</div>
