<?php $this->load->helper('url');?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <!-- Set the viewport so this responsive site displays correctly on mobile devices -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>College of Engineering Poonjar</title>
    <!-- Include bootstrap CSS -->
<!--<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>-->
    <!-- <link href="<?php //echo base_url();?>css/bootstrap.min.css" rel="stylesheet"> -->
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet">
    <script type="text/javascript">
    function cssLoaded(href) {
        var cssFound = false;

        for (var i = 0; i < document.styleSheets.length; i++) {
            var sheet = document.styleSheets[i];
            //alert(sheet['href']);
            if(sheet[href]!=null)
            if (sheet['href'].indexOf(href) >= 0 && sheet['cssRules'].length > 0) {
                cssFound = true;
            }
        };

        return cssFound;
    }

    if (!cssLoaded('bootstrap-combined.min.css')) {
        local_bootstrap = document.createElement('link');
        local_bootstrap.setAttribute("rel", "stylesheet");
        local_bootstrap.setAttribute("type", "text/css");
        local_bootstrap.setAttribute("href", "<?php echo base_url();?>css/bootstrap.min.css" );
        document.getElementsByTagName("head")[0].appendChild(local_bootstrap);
    }
</script>
<link href="<?php echo base_url();?>css/style_placement.css" rel="stylesheet">
<link href="<?php echo base_url();?>css/style_body_override.css" rel="stylesheet">



</head>

<body>


    <div class="header">
        <div class="container center-block">
            <div id="header_wrap" class="row center-block">

                <img src="<?php echo base_url();?>css/images/Logow_copy.png" class="img-responsive center-block inline logo">
                <!-- <h2 class="inline title">College of Engineering,Poonjar</h2> -->
            </div>
        </div>
    </div>
