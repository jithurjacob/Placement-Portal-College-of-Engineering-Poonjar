
<!DOCTYPE html>
<html lang="en">
<?php $this->load->helper('url'); ?>
<head>
    <meta charset="utf-8">
    <!-- Set the viewport so this responsive site displays correctly on mobile devices -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>College of Engineering Poonjar</title>
    <!-- Include bootstrap CSS -->
<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet">
    <!-- <link href="<?php // echo base_url();?>css/bootstrap.min.css" rel="stylesheet"> -->
    <link href="<?php echo base_url();?>css/style.css" rel="stylesheet">
    
</head>

<body>


    <div class="header">
        <div class="container center-block">
            <div id="header_wrap" class="row center-block">

                <img src="<?php echo base_url();?>css/images/logow.png" class="img-responsive center-block inline logo">
                <h2 class="inline title">College of Engineering,Poonjar</h2>
            </div>
        </div>
    </div>
