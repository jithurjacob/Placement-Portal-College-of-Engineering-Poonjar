<?php
$this->load->helper('url');
$this->load->helper('array');

?>
<div class="middle">
    <div class="container">

        <div class="row about">
            <div class="col-md-12" style="min-height:500px;">
               <div class="row">
                    <h2>Welcome, <?php echo element('name', $student_details[0]);
?></h2>
               </div>
               <br>
               <br>
               <div class="col-md-8" style="min-height:400px;">
               <div class="responsive-table">
<table class="table table-condensed text-left">
                        <tr>
                        <td>Username</td><td><?php echo element('username', $student_details[0]);
?></td>
                        </tr>
                        <tr>
                        <td>Email</td><td><?php echo element('email', $student_details[0]);
?></td>
                        </tr>
                        <tr>
                        <td>Admission Number</td><td><?php echo element('admnno', $student_details[0]);
?></td>
                        </tr>
                        <tr>
                        <td>Registration Number</td><td><?php echo element('regno', $student_details[0]);
?></td>
                        </tr>
                        </table>
               </div>
               </div>
               <div class="col-md-4" style="max-width:200px;">
                    <img src="<?php echo base_url();?>profile_pics/<?php echo element('pic', $student_details[0]);?>" style="max-height:200px;max-width:200px;"  class="margin_top_30">
               <?php $this->load->helper('form');
                echo form_open_multipart('placement/upload_profile_pic_student','accept="image/jpeg"');?>
<input type="file" name="userfile" />

<br /><br />
<?php if (isset($error)) if ($error !="" ) { ?>
                        <tr >
                        <td colspan="2">
                            <div class="alert   alert-danger  alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                <?php echo $error; ?>
                            </div>
                       </td> </tr>
                        <?php } ?>
                        <?php if (isset($upload_data)) if ($upload_data !="" ) { ?>
                        <tr >
                        <td colspan="2">
                            <div class="alert   alert-success  alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                <?php echo $upload_data; ?>
                            </div>
                       </td> </tr>
                        <?php } ?>
<input class="btn btn-lg btn-primary btn-block" type="submit" value="Upload" />
               </form>
               </div>
            </div>
             <!-- <div class="col-md-3">
                <div class="row">
                    <div class="col-md-12 events well text-justify home_steps" id="events">
<?php // $this->view('placement_events'); ?>
</div>
                </div>
                <div class="row">
                    <div class="col-md-12 login_sidebar events well text-justify home_steps" id="login_sidebar">
<?php //$this->view('placement_login_sidebar'); ?>
</div>
                </div>


            </div>  -->
        </div>


    </div>




</div>


