 <marquee direction="up" scrollamount="2" onmouseover="javascript: this.stop();" onmouseout="javascript: this.start();">
                            <ul>
                                <a href="http://" target="_blank">
                                    <li>Placement Training for Final year students:Phase 1-July 17th 718th, Phase 2-July 31,August 1st &amp; 2nd.

                                </a>
                                </li>
                                <li>Placement portal updated for 2012 Scheme Admissions..</li>
                            </ul>
                        </marquee>