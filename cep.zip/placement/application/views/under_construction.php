<img src="<?php echo base_url();?>css/images/under_construction.png" alt="Page under construction" class="img-responsive center-block inline ">
           