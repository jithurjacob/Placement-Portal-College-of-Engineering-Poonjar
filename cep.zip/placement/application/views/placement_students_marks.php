<div class="middle">
    <div class="container">

        <div class="row about">
            <div class="col-md-12">
                <div class="home_steps well text-justify noborder">
                    <h2>Marks</h2>
                    <br>
                    <br>
                    <?php $this->load->helper('array'); $mark_exists=FALSE;
                     if (isset($marks_details[0])) {
                     ?>

                    <h3>Semester I &amp; II</h3>
                    <div class="responsive-table">
                        <table id="students_table" class="table table-striped table-condense table-hover table-bordere text-left verify_table">
                            <thead>
                                <th>Subject Code</th>
                                <th>101</th>
                                <th>102</th>
                                <th>103</th>
                                <th>104</th>
                                <th>105</th>
                                <th>106</th>
                                <th>107</th>
                                <th>108</th>
                                <th>109</th>
                                <th>110</th>
                                <th>111</th>
                                <th>Total</th>
                            </thead>

                        </table>
                    </div>
                    <?php } ?>
                </div>
                <div class="home_steps well text-justify noborder">
                    <h2>Edit Marks</h2>
                    <br>
                    <br>
                </div>
                <div class="home_steps well text-justify noborder">
                    <h2>Add Marks</h2>
                    <br>
                    <br>
                </div>
            </div>

        </div>


    </div>




</div>
