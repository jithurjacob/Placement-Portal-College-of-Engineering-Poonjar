<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-08-13 09:26:14 --> Config Class Initialized
DEBUG - 2014-08-13 09:26:14 --> Hooks Class Initialized
DEBUG - 2014-08-13 09:26:14 --> Utf8 Class Initialized
DEBUG - 2014-08-13 09:26:14 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 09:26:14 --> URI Class Initialized
DEBUG - 2014-08-13 09:26:14 --> Router Class Initialized
DEBUG - 2014-08-13 09:26:14 --> No URI present. Default controller set.
DEBUG - 2014-08-13 09:26:14 --> Output Class Initialized
DEBUG - 2014-08-13 09:26:14 --> Security Class Initialized
DEBUG - 2014-08-13 09:26:14 --> Input Class Initialized
DEBUG - 2014-08-13 09:26:14 --> XSS Filtering completed
DEBUG - 2014-08-13 09:26:14 --> XSS Filtering completed
DEBUG - 2014-08-13 09:26:14 --> XSS Filtering completed
DEBUG - 2014-08-13 09:26:14 --> XSS Filtering completed
DEBUG - 2014-08-13 09:26:14 --> CRSF cookie Set
DEBUG - 2014-08-13 09:26:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 09:26:14 --> Language Class Initialized
DEBUG - 2014-08-13 09:26:14 --> Loader Class Initialized
DEBUG - 2014-08-13 09:26:14 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 09:26:14 --> Helper loaded: url_helper
DEBUG - 2014-08-13 09:26:14 --> Database Driver Class Initialized
ERROR - 2014-08-13 09:26:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 09:26:14 --> Session Class Initialized
DEBUG - 2014-08-13 09:26:14 --> Helper loaded: string_helper
DEBUG - 2014-08-13 09:26:14 --> A session cookie was not found.
DEBUG - 2014-08-13 09:26:14 --> Session routines successfully run
DEBUG - 2014-08-13 09:26:14 --> Controller Class Initialized
DEBUG - 2014-08-13 09:26:14 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 09:26:14 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 09:26:14 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 09:26:14 --> Helper loaded: form_helper
DEBUG - 2014-08-13 09:26:14 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 09:26:14 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 09:26:14 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 09:26:14 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 09:26:14 --> Final output sent to browser
DEBUG - 2014-08-13 09:26:14 --> Total execution time: 0.0673
DEBUG - 2014-08-13 09:26:25 --> Config Class Initialized
DEBUG - 2014-08-13 09:26:25 --> Hooks Class Initialized
DEBUG - 2014-08-13 09:26:25 --> Utf8 Class Initialized
DEBUG - 2014-08-13 09:26:25 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 09:26:25 --> URI Class Initialized
DEBUG - 2014-08-13 09:26:25 --> Router Class Initialized
DEBUG - 2014-08-13 09:26:25 --> No URI present. Default controller set.
DEBUG - 2014-08-13 09:26:25 --> Output Class Initialized
DEBUG - 2014-08-13 09:26:25 --> Security Class Initialized
DEBUG - 2014-08-13 09:26:25 --> Input Class Initialized
DEBUG - 2014-08-13 09:26:25 --> XSS Filtering completed
DEBUG - 2014-08-13 09:26:25 --> XSS Filtering completed
DEBUG - 2014-08-13 09:26:25 --> XSS Filtering completed
DEBUG - 2014-08-13 09:26:25 --> XSS Filtering completed
DEBUG - 2014-08-13 09:26:25 --> XSS Filtering completed
DEBUG - 2014-08-13 09:26:25 --> XSS Filtering completed
DEBUG - 2014-08-13 09:26:25 --> CRSF cookie Set
DEBUG - 2014-08-13 09:26:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 09:26:25 --> Language Class Initialized
DEBUG - 2014-08-13 09:26:25 --> Loader Class Initialized
DEBUG - 2014-08-13 09:26:25 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 09:26:25 --> Helper loaded: url_helper
DEBUG - 2014-08-13 09:26:25 --> Database Driver Class Initialized
ERROR - 2014-08-13 09:26:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 09:26:25 --> Session Class Initialized
DEBUG - 2014-08-13 09:26:25 --> Helper loaded: string_helper
DEBUG - 2014-08-13 09:26:25 --> Session routines successfully run
DEBUG - 2014-08-13 09:26:25 --> Controller Class Initialized
DEBUG - 2014-08-13 09:26:25 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 09:26:25 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 09:26:25 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 09:26:25 --> Helper loaded: form_helper
DEBUG - 2014-08-13 09:26:25 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 09:26:25 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 09:26:25 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 09:26:25 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 09:26:25 --> Final output sent to browser
DEBUG - 2014-08-13 09:26:25 --> Total execution time: 0.1092
DEBUG - 2014-08-13 09:26:39 --> Config Class Initialized
DEBUG - 2014-08-13 09:26:39 --> Hooks Class Initialized
DEBUG - 2014-08-13 09:26:39 --> Utf8 Class Initialized
DEBUG - 2014-08-13 09:26:39 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 09:26:39 --> URI Class Initialized
DEBUG - 2014-08-13 09:26:39 --> Router Class Initialized
DEBUG - 2014-08-13 09:26:39 --> Output Class Initialized
DEBUG - 2014-08-13 09:26:39 --> Security Class Initialized
DEBUG - 2014-08-13 09:26:39 --> Input Class Initialized
DEBUG - 2014-08-13 09:26:39 --> XSS Filtering completed
DEBUG - 2014-08-13 09:26:39 --> XSS Filtering completed
DEBUG - 2014-08-13 09:26:39 --> XSS Filtering completed
DEBUG - 2014-08-13 09:26:39 --> XSS Filtering completed
DEBUG - 2014-08-13 09:26:39 --> XSS Filtering completed
DEBUG - 2014-08-13 09:26:39 --> XSS Filtering completed
DEBUG - 2014-08-13 09:26:39 --> CRSF cookie Set
DEBUG - 2014-08-13 09:26:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 09:26:39 --> Language Class Initialized
DEBUG - 2014-08-13 09:26:39 --> Loader Class Initialized
DEBUG - 2014-08-13 09:26:39 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 09:26:39 --> Helper loaded: url_helper
DEBUG - 2014-08-13 09:26:39 --> Database Driver Class Initialized
ERROR - 2014-08-13 09:26:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 09:26:39 --> Session Class Initialized
DEBUG - 2014-08-13 09:26:39 --> Helper loaded: string_helper
DEBUG - 2014-08-13 09:26:39 --> Session routines successfully run
DEBUG - 2014-08-13 09:26:39 --> Controller Class Initialized
DEBUG - 2014-08-13 09:26:39 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 09:26:39 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 09:26:39 --> Helper loaded: form_helper
DEBUG - 2014-08-13 09:26:39 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 09:26:39 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 09:26:39 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 09:26:39 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 09:26:39 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 09:26:39 --> Final output sent to browser
DEBUG - 2014-08-13 09:26:39 --> Total execution time: 0.0483
DEBUG - 2014-08-13 09:27:06 --> Config Class Initialized
DEBUG - 2014-08-13 09:27:06 --> Hooks Class Initialized
DEBUG - 2014-08-13 09:27:06 --> Utf8 Class Initialized
DEBUG - 2014-08-13 09:27:06 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 09:27:06 --> URI Class Initialized
DEBUG - 2014-08-13 09:27:06 --> Router Class Initialized
DEBUG - 2014-08-13 09:27:06 --> Output Class Initialized
DEBUG - 2014-08-13 09:27:06 --> Security Class Initialized
DEBUG - 2014-08-13 09:27:06 --> Input Class Initialized
DEBUG - 2014-08-13 09:27:06 --> XSS Filtering completed
DEBUG - 2014-08-13 09:27:06 --> XSS Filtering completed
DEBUG - 2014-08-13 09:27:06 --> XSS Filtering completed
DEBUG - 2014-08-13 09:27:06 --> XSS Filtering completed
DEBUG - 2014-08-13 09:27:06 --> XSS Filtering completed
DEBUG - 2014-08-13 09:27:06 --> XSS Filtering completed
DEBUG - 2014-08-13 09:27:06 --> XSS Filtering completed
DEBUG - 2014-08-13 09:27:06 --> XSS Filtering completed
DEBUG - 2014-08-13 09:27:06 --> XSS Filtering completed
DEBUG - 2014-08-13 09:27:06 --> XSS Filtering completed
DEBUG - 2014-08-13 09:27:06 --> XSS Filtering completed
DEBUG - 2014-08-13 09:27:06 --> XSS Filtering completed
DEBUG - 2014-08-13 09:27:06 --> XSS Filtering completed
DEBUG - 2014-08-13 09:27:06 --> XSS Filtering completed
DEBUG - 2014-08-13 09:27:06 --> XSS Filtering completed
DEBUG - 2014-08-13 09:27:06 --> CRSF cookie Set
DEBUG - 2014-08-13 09:27:06 --> CSRF token verified
DEBUG - 2014-08-13 09:27:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 09:27:06 --> Language Class Initialized
DEBUG - 2014-08-13 09:27:06 --> Loader Class Initialized
DEBUG - 2014-08-13 09:27:06 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 09:27:06 --> Helper loaded: url_helper
DEBUG - 2014-08-13 09:27:06 --> Database Driver Class Initialized
ERROR - 2014-08-13 09:27:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 09:27:06 --> Session Class Initialized
DEBUG - 2014-08-13 09:27:06 --> Helper loaded: string_helper
DEBUG - 2014-08-13 09:27:06 --> Session routines successfully run
DEBUG - 2014-08-13 09:27:06 --> Controller Class Initialized
DEBUG - 2014-08-13 09:27:06 --> Helper loaded: form_helper
DEBUG - 2014-08-13 09:27:06 --> Form Validation Class Initialized
DEBUG - 2014-08-13 09:27:06 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2014-08-13 09:27:06 --> Severity: Notice  --> Undefined property: MY_Form_validation::$form_validation C:\wamp\www\cep\placement\application\libraries\MY_Form_validation.php 50
DEBUG - 2014-08-13 09:30:10 --> Config Class Initialized
DEBUG - 2014-08-13 09:30:10 --> Hooks Class Initialized
DEBUG - 2014-08-13 09:30:10 --> Utf8 Class Initialized
DEBUG - 2014-08-13 09:30:10 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 09:30:10 --> URI Class Initialized
DEBUG - 2014-08-13 09:30:10 --> Router Class Initialized
DEBUG - 2014-08-13 09:30:10 --> Output Class Initialized
DEBUG - 2014-08-13 09:30:10 --> Security Class Initialized
DEBUG - 2014-08-13 09:30:10 --> Input Class Initialized
DEBUG - 2014-08-13 09:30:10 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:10 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:10 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:10 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:10 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:10 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:10 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:10 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:10 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:10 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:10 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:10 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:10 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:10 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:10 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:10 --> CRSF cookie Set
DEBUG - 2014-08-13 09:30:10 --> CSRF token verified
DEBUG - 2014-08-13 09:30:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 09:30:10 --> Language Class Initialized
DEBUG - 2014-08-13 09:30:10 --> Loader Class Initialized
DEBUG - 2014-08-13 09:30:10 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 09:30:10 --> Helper loaded: url_helper
DEBUG - 2014-08-13 09:30:10 --> Database Driver Class Initialized
ERROR - 2014-08-13 09:30:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 09:30:10 --> Session Class Initialized
DEBUG - 2014-08-13 09:30:10 --> Helper loaded: string_helper
DEBUG - 2014-08-13 09:30:10 --> Session routines successfully run
DEBUG - 2014-08-13 09:30:10 --> Controller Class Initialized
DEBUG - 2014-08-13 09:30:10 --> Helper loaded: form_helper
DEBUG - 2014-08-13 09:30:10 --> Form Validation Class Initialized
DEBUG - 2014-08-13 09:30:10 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 09:30:10 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:10 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:10 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:10 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 09:30:10 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 09:30:10 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 09:30:10 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 09:30:10 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 09:30:10 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 09:30:10 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 09:30:10 --> Final output sent to browser
DEBUG - 2014-08-13 09:30:10 --> Total execution time: 0.1987
DEBUG - 2014-08-13 09:30:37 --> Config Class Initialized
DEBUG - 2014-08-13 09:30:37 --> Hooks Class Initialized
DEBUG - 2014-08-13 09:30:37 --> Utf8 Class Initialized
DEBUG - 2014-08-13 09:30:37 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 09:30:37 --> URI Class Initialized
DEBUG - 2014-08-13 09:30:37 --> Router Class Initialized
DEBUG - 2014-08-13 09:30:37 --> Output Class Initialized
DEBUG - 2014-08-13 09:30:37 --> Security Class Initialized
DEBUG - 2014-08-13 09:30:37 --> Input Class Initialized
DEBUG - 2014-08-13 09:30:37 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:37 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:37 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:37 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:37 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:37 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:37 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:37 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:37 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:37 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:37 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:37 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:37 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:37 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:37 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:37 --> CRSF cookie Set
DEBUG - 2014-08-13 09:30:37 --> CSRF token verified
DEBUG - 2014-08-13 09:30:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 09:30:37 --> Language Class Initialized
DEBUG - 2014-08-13 09:30:37 --> Loader Class Initialized
DEBUG - 2014-08-13 09:30:37 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 09:30:37 --> Helper loaded: url_helper
DEBUG - 2014-08-13 09:30:37 --> Database Driver Class Initialized
ERROR - 2014-08-13 09:30:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 09:30:37 --> Session Class Initialized
DEBUG - 2014-08-13 09:30:37 --> Helper loaded: string_helper
DEBUG - 2014-08-13 09:30:37 --> Session routines successfully run
DEBUG - 2014-08-13 09:30:37 --> Controller Class Initialized
DEBUG - 2014-08-13 09:30:37 --> Helper loaded: form_helper
DEBUG - 2014-08-13 09:30:37 --> Form Validation Class Initialized
DEBUG - 2014-08-13 09:30:37 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 09:30:37 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:37 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:37 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:37 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 09:30:37 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 09:30:37 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 09:30:37 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 09:30:37 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 09:30:37 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 09:30:37 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 09:30:37 --> Final output sent to browser
DEBUG - 2014-08-13 09:30:37 --> Total execution time: 0.0829
DEBUG - 2014-08-13 09:30:42 --> Config Class Initialized
DEBUG - 2014-08-13 09:30:42 --> Hooks Class Initialized
DEBUG - 2014-08-13 09:30:42 --> Utf8 Class Initialized
DEBUG - 2014-08-13 09:30:42 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 09:30:42 --> URI Class Initialized
DEBUG - 2014-08-13 09:30:42 --> Router Class Initialized
DEBUG - 2014-08-13 09:30:42 --> Output Class Initialized
DEBUG - 2014-08-13 09:30:42 --> Security Class Initialized
DEBUG - 2014-08-13 09:30:42 --> Input Class Initialized
DEBUG - 2014-08-13 09:30:42 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:42 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:42 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:42 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:42 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:42 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:42 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:42 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:42 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:42 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:42 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:42 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:42 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:42 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:42 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:42 --> CRSF cookie Set
DEBUG - 2014-08-13 09:30:42 --> CSRF token verified
DEBUG - 2014-08-13 09:30:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 09:30:42 --> Language Class Initialized
DEBUG - 2014-08-13 09:30:42 --> Loader Class Initialized
DEBUG - 2014-08-13 09:30:42 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 09:30:42 --> Helper loaded: url_helper
DEBUG - 2014-08-13 09:30:42 --> Database Driver Class Initialized
ERROR - 2014-08-13 09:30:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 09:30:42 --> Session Class Initialized
DEBUG - 2014-08-13 09:30:42 --> Helper loaded: string_helper
DEBUG - 2014-08-13 09:30:42 --> Session routines successfully run
DEBUG - 2014-08-13 09:30:42 --> Controller Class Initialized
DEBUG - 2014-08-13 09:30:42 --> Helper loaded: form_helper
DEBUG - 2014-08-13 09:30:42 --> Form Validation Class Initialized
DEBUG - 2014-08-13 09:30:42 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 09:30:42 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:42 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:42 --> XSS Filtering completed
DEBUG - 2014-08-13 09:30:42 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 09:30:42 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 09:30:42 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 09:30:42 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 09:30:42 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 09:30:42 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 09:30:42 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 09:30:42 --> Final output sent to browser
DEBUG - 2014-08-13 09:30:42 --> Total execution time: 0.0734
DEBUG - 2014-08-13 09:34:22 --> Config Class Initialized
DEBUG - 2014-08-13 09:34:22 --> Hooks Class Initialized
DEBUG - 2014-08-13 09:34:22 --> Utf8 Class Initialized
DEBUG - 2014-08-13 09:34:22 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 09:34:22 --> URI Class Initialized
DEBUG - 2014-08-13 09:34:22 --> Router Class Initialized
DEBUG - 2014-08-13 09:34:22 --> Output Class Initialized
DEBUG - 2014-08-13 09:34:22 --> Security Class Initialized
DEBUG - 2014-08-13 09:34:22 --> Input Class Initialized
DEBUG - 2014-08-13 09:34:22 --> XSS Filtering completed
DEBUG - 2014-08-13 09:34:22 --> XSS Filtering completed
DEBUG - 2014-08-13 09:34:22 --> XSS Filtering completed
DEBUG - 2014-08-13 09:34:22 --> XSS Filtering completed
DEBUG - 2014-08-13 09:34:22 --> XSS Filtering completed
DEBUG - 2014-08-13 09:34:22 --> XSS Filtering completed
DEBUG - 2014-08-13 09:34:22 --> CRSF cookie Set
DEBUG - 2014-08-13 09:34:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 09:34:22 --> Language Class Initialized
DEBUG - 2014-08-13 09:34:22 --> Loader Class Initialized
DEBUG - 2014-08-13 09:34:22 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 09:34:22 --> Helper loaded: url_helper
DEBUG - 2014-08-13 09:34:22 --> Database Driver Class Initialized
ERROR - 2014-08-13 09:34:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 09:34:22 --> Session Class Initialized
DEBUG - 2014-08-13 09:34:22 --> Helper loaded: string_helper
DEBUG - 2014-08-13 09:34:22 --> Session routines successfully run
DEBUG - 2014-08-13 09:34:22 --> Controller Class Initialized
DEBUG - 2014-08-13 09:34:22 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 09:34:22 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 09:34:22 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 09:34:22 --> Helper loaded: form_helper
DEBUG - 2014-08-13 09:34:22 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 09:34:22 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 09:34:22 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 09:34:22 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 09:34:22 --> Final output sent to browser
DEBUG - 2014-08-13 09:34:22 --> Total execution time: 0.0495
DEBUG - 2014-08-13 09:34:40 --> Config Class Initialized
DEBUG - 2014-08-13 09:34:40 --> Hooks Class Initialized
DEBUG - 2014-08-13 09:34:40 --> Utf8 Class Initialized
DEBUG - 2014-08-13 09:34:40 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 09:34:40 --> URI Class Initialized
DEBUG - 2014-08-13 09:34:40 --> Router Class Initialized
DEBUG - 2014-08-13 09:34:40 --> Output Class Initialized
DEBUG - 2014-08-13 09:34:40 --> Security Class Initialized
DEBUG - 2014-08-13 09:34:40 --> Input Class Initialized
DEBUG - 2014-08-13 09:34:40 --> XSS Filtering completed
DEBUG - 2014-08-13 09:34:40 --> XSS Filtering completed
DEBUG - 2014-08-13 09:34:40 --> XSS Filtering completed
DEBUG - 2014-08-13 09:34:40 --> XSS Filtering completed
DEBUG - 2014-08-13 09:34:40 --> XSS Filtering completed
DEBUG - 2014-08-13 09:34:40 --> XSS Filtering completed
DEBUG - 2014-08-13 09:34:40 --> XSS Filtering completed
DEBUG - 2014-08-13 09:34:40 --> XSS Filtering completed
DEBUG - 2014-08-13 09:34:40 --> XSS Filtering completed
DEBUG - 2014-08-13 09:34:40 --> XSS Filtering completed
DEBUG - 2014-08-13 09:34:40 --> XSS Filtering completed
DEBUG - 2014-08-13 09:34:40 --> XSS Filtering completed
DEBUG - 2014-08-13 09:34:40 --> XSS Filtering completed
DEBUG - 2014-08-13 09:34:40 --> XSS Filtering completed
DEBUG - 2014-08-13 09:34:40 --> XSS Filtering completed
DEBUG - 2014-08-13 09:34:40 --> CRSF cookie Set
DEBUG - 2014-08-13 09:34:40 --> CSRF token verified
DEBUG - 2014-08-13 09:34:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 09:34:40 --> Language Class Initialized
DEBUG - 2014-08-13 09:34:40 --> Loader Class Initialized
DEBUG - 2014-08-13 09:34:40 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 09:34:40 --> Helper loaded: url_helper
DEBUG - 2014-08-13 09:34:40 --> Database Driver Class Initialized
ERROR - 2014-08-13 09:34:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 09:34:40 --> Session Class Initialized
DEBUG - 2014-08-13 09:34:40 --> Helper loaded: string_helper
DEBUG - 2014-08-13 09:34:40 --> Session routines successfully run
DEBUG - 2014-08-13 09:34:40 --> Controller Class Initialized
DEBUG - 2014-08-13 09:34:40 --> Helper loaded: form_helper
DEBUG - 2014-08-13 09:34:40 --> Form Validation Class Initialized
DEBUG - 2014-08-13 09:34:40 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 09:34:40 --> XSS Filtering completed
DEBUG - 2014-08-13 09:34:40 --> XSS Filtering completed
DEBUG - 2014-08-13 09:34:40 --> XSS Filtering completed
DEBUG - 2014-08-13 09:34:40 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 09:34:40 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 09:34:40 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 09:34:40 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 09:34:40 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 09:34:40 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 09:34:40 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 09:34:40 --> Final output sent to browser
DEBUG - 2014-08-13 09:34:40 --> Total execution time: 0.0856
DEBUG - 2014-08-13 09:34:56 --> Config Class Initialized
DEBUG - 2014-08-13 09:34:56 --> Hooks Class Initialized
DEBUG - 2014-08-13 09:34:56 --> Utf8 Class Initialized
DEBUG - 2014-08-13 09:34:56 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 09:34:56 --> URI Class Initialized
DEBUG - 2014-08-13 09:34:56 --> Router Class Initialized
DEBUG - 2014-08-13 09:34:56 --> Output Class Initialized
DEBUG - 2014-08-13 09:34:56 --> Security Class Initialized
DEBUG - 2014-08-13 09:34:56 --> Input Class Initialized
DEBUG - 2014-08-13 09:34:56 --> XSS Filtering completed
DEBUG - 2014-08-13 09:34:56 --> XSS Filtering completed
DEBUG - 2014-08-13 09:34:56 --> XSS Filtering completed
DEBUG - 2014-08-13 09:34:56 --> XSS Filtering completed
DEBUG - 2014-08-13 09:34:56 --> XSS Filtering completed
DEBUG - 2014-08-13 09:34:56 --> XSS Filtering completed
DEBUG - 2014-08-13 09:34:56 --> XSS Filtering completed
DEBUG - 2014-08-13 09:34:56 --> XSS Filtering completed
DEBUG - 2014-08-13 09:34:56 --> XSS Filtering completed
DEBUG - 2014-08-13 09:34:56 --> XSS Filtering completed
DEBUG - 2014-08-13 09:34:56 --> XSS Filtering completed
DEBUG - 2014-08-13 09:34:56 --> XSS Filtering completed
DEBUG - 2014-08-13 09:34:56 --> XSS Filtering completed
DEBUG - 2014-08-13 09:34:56 --> XSS Filtering completed
DEBUG - 2014-08-13 09:34:56 --> XSS Filtering completed
DEBUG - 2014-08-13 09:34:56 --> CRSF cookie Set
DEBUG - 2014-08-13 09:34:56 --> CSRF token verified
DEBUG - 2014-08-13 09:34:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 09:34:56 --> Language Class Initialized
DEBUG - 2014-08-13 09:34:56 --> Loader Class Initialized
DEBUG - 2014-08-13 09:34:56 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 09:34:56 --> Helper loaded: url_helper
DEBUG - 2014-08-13 09:34:56 --> Database Driver Class Initialized
ERROR - 2014-08-13 09:34:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 09:34:56 --> Session Class Initialized
DEBUG - 2014-08-13 09:34:56 --> Helper loaded: string_helper
DEBUG - 2014-08-13 09:34:56 --> Session routines successfully run
DEBUG - 2014-08-13 09:34:56 --> Controller Class Initialized
DEBUG - 2014-08-13 09:34:56 --> Helper loaded: form_helper
DEBUG - 2014-08-13 09:34:56 --> Form Validation Class Initialized
DEBUG - 2014-08-13 09:34:56 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 09:34:56 --> XSS Filtering completed
DEBUG - 2014-08-13 09:34:56 --> XSS Filtering completed
DEBUG - 2014-08-13 09:34:56 --> XSS Filtering completed
DEBUG - 2014-08-13 09:34:56 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 09:34:56 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 09:34:56 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 09:34:56 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 09:34:56 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 09:34:56 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 09:34:56 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 09:34:56 --> Final output sent to browser
DEBUG - 2014-08-13 09:34:56 --> Total execution time: 0.0853
DEBUG - 2014-08-13 09:35:01 --> Config Class Initialized
DEBUG - 2014-08-13 09:35:01 --> Hooks Class Initialized
DEBUG - 2014-08-13 09:35:01 --> Utf8 Class Initialized
DEBUG - 2014-08-13 09:35:01 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 09:35:01 --> URI Class Initialized
DEBUG - 2014-08-13 09:35:01 --> Router Class Initialized
DEBUG - 2014-08-13 09:35:01 --> Output Class Initialized
DEBUG - 2014-08-13 09:35:01 --> Security Class Initialized
DEBUG - 2014-08-13 09:35:01 --> Input Class Initialized
DEBUG - 2014-08-13 09:35:01 --> XSS Filtering completed
DEBUG - 2014-08-13 09:35:01 --> XSS Filtering completed
DEBUG - 2014-08-13 09:35:01 --> XSS Filtering completed
DEBUG - 2014-08-13 09:35:01 --> XSS Filtering completed
DEBUG - 2014-08-13 09:35:01 --> XSS Filtering completed
DEBUG - 2014-08-13 09:35:01 --> XSS Filtering completed
DEBUG - 2014-08-13 09:35:01 --> XSS Filtering completed
DEBUG - 2014-08-13 09:35:01 --> XSS Filtering completed
DEBUG - 2014-08-13 09:35:01 --> XSS Filtering completed
DEBUG - 2014-08-13 09:35:01 --> XSS Filtering completed
DEBUG - 2014-08-13 09:35:01 --> XSS Filtering completed
DEBUG - 2014-08-13 09:35:01 --> XSS Filtering completed
DEBUG - 2014-08-13 09:35:01 --> XSS Filtering completed
DEBUG - 2014-08-13 09:35:01 --> XSS Filtering completed
DEBUG - 2014-08-13 09:35:01 --> XSS Filtering completed
DEBUG - 2014-08-13 09:35:01 --> CRSF cookie Set
DEBUG - 2014-08-13 09:35:01 --> CSRF token verified
DEBUG - 2014-08-13 09:35:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 09:35:01 --> Language Class Initialized
DEBUG - 2014-08-13 09:35:01 --> Loader Class Initialized
DEBUG - 2014-08-13 09:35:01 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 09:35:01 --> Helper loaded: url_helper
DEBUG - 2014-08-13 09:35:01 --> Database Driver Class Initialized
ERROR - 2014-08-13 09:35:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 09:35:01 --> Session Class Initialized
DEBUG - 2014-08-13 09:35:01 --> Helper loaded: string_helper
DEBUG - 2014-08-13 09:35:01 --> Session routines successfully run
DEBUG - 2014-08-13 09:35:01 --> Controller Class Initialized
DEBUG - 2014-08-13 09:35:01 --> Helper loaded: form_helper
DEBUG - 2014-08-13 09:35:01 --> Form Validation Class Initialized
DEBUG - 2014-08-13 09:35:01 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 09:35:01 --> XSS Filtering completed
DEBUG - 2014-08-13 09:35:01 --> XSS Filtering completed
DEBUG - 2014-08-13 09:35:01 --> XSS Filtering completed
DEBUG - 2014-08-13 09:35:01 --> Model Class Initialized
DEBUG - 2014-08-13 09:35:01 --> Model Class Initialized
DEBUG - 2014-08-13 09:35:01 --> Encrypt Class Initialized
DEBUG - 2014-08-13 09:35:01 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 09:35:01 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 09:35:01 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 09:35:01 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 09:35:01 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 09:35:01 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 09:35:01 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 09:35:01 --> Final output sent to browser
DEBUG - 2014-08-13 09:35:01 --> Total execution time: 0.0813
DEBUG - 2014-08-13 09:38:43 --> Config Class Initialized
DEBUG - 2014-08-13 09:38:43 --> Hooks Class Initialized
DEBUG - 2014-08-13 09:38:43 --> Utf8 Class Initialized
DEBUG - 2014-08-13 09:38:43 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 09:38:43 --> URI Class Initialized
DEBUG - 2014-08-13 09:38:43 --> Router Class Initialized
DEBUG - 2014-08-13 09:38:43 --> Output Class Initialized
DEBUG - 2014-08-13 09:38:43 --> Security Class Initialized
DEBUG - 2014-08-13 09:38:43 --> Input Class Initialized
DEBUG - 2014-08-13 09:38:43 --> XSS Filtering completed
DEBUG - 2014-08-13 09:38:43 --> XSS Filtering completed
DEBUG - 2014-08-13 09:38:43 --> XSS Filtering completed
DEBUG - 2014-08-13 09:38:43 --> XSS Filtering completed
DEBUG - 2014-08-13 09:38:43 --> XSS Filtering completed
DEBUG - 2014-08-13 09:38:43 --> XSS Filtering completed
DEBUG - 2014-08-13 09:38:43 --> XSS Filtering completed
DEBUG - 2014-08-13 09:38:43 --> XSS Filtering completed
DEBUG - 2014-08-13 09:38:43 --> XSS Filtering completed
DEBUG - 2014-08-13 09:38:43 --> XSS Filtering completed
DEBUG - 2014-08-13 09:38:43 --> XSS Filtering completed
DEBUG - 2014-08-13 09:38:43 --> XSS Filtering completed
DEBUG - 2014-08-13 09:38:43 --> XSS Filtering completed
DEBUG - 2014-08-13 09:38:43 --> XSS Filtering completed
DEBUG - 2014-08-13 09:38:43 --> XSS Filtering completed
DEBUG - 2014-08-13 09:38:43 --> CRSF cookie Set
DEBUG - 2014-08-13 09:38:43 --> CSRF token verified
DEBUG - 2014-08-13 09:38:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 09:38:43 --> Language Class Initialized
DEBUG - 2014-08-13 09:38:43 --> Loader Class Initialized
DEBUG - 2014-08-13 09:38:43 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 09:38:43 --> Helper loaded: url_helper
DEBUG - 2014-08-13 09:38:43 --> Database Driver Class Initialized
ERROR - 2014-08-13 09:38:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 09:38:43 --> Session Class Initialized
DEBUG - 2014-08-13 09:38:43 --> Helper loaded: string_helper
DEBUG - 2014-08-13 09:38:43 --> Session routines successfully run
DEBUG - 2014-08-13 09:38:43 --> Controller Class Initialized
DEBUG - 2014-08-13 09:38:43 --> Helper loaded: form_helper
DEBUG - 2014-08-13 09:38:43 --> Form Validation Class Initialized
DEBUG - 2014-08-13 09:38:59 --> Config Class Initialized
DEBUG - 2014-08-13 09:38:59 --> Hooks Class Initialized
DEBUG - 2014-08-13 09:38:59 --> Utf8 Class Initialized
DEBUG - 2014-08-13 09:38:59 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 09:38:59 --> URI Class Initialized
DEBUG - 2014-08-13 09:38:59 --> Router Class Initialized
DEBUG - 2014-08-13 09:38:59 --> Output Class Initialized
DEBUG - 2014-08-13 09:38:59 --> Security Class Initialized
DEBUG - 2014-08-13 09:38:59 --> Input Class Initialized
DEBUG - 2014-08-13 09:38:59 --> XSS Filtering completed
DEBUG - 2014-08-13 09:38:59 --> XSS Filtering completed
DEBUG - 2014-08-13 09:38:59 --> XSS Filtering completed
DEBUG - 2014-08-13 09:38:59 --> XSS Filtering completed
DEBUG - 2014-08-13 09:38:59 --> XSS Filtering completed
DEBUG - 2014-08-13 09:38:59 --> XSS Filtering completed
DEBUG - 2014-08-13 09:38:59 --> XSS Filtering completed
DEBUG - 2014-08-13 09:38:59 --> XSS Filtering completed
DEBUG - 2014-08-13 09:38:59 --> XSS Filtering completed
DEBUG - 2014-08-13 09:38:59 --> XSS Filtering completed
DEBUG - 2014-08-13 09:38:59 --> XSS Filtering completed
DEBUG - 2014-08-13 09:38:59 --> XSS Filtering completed
DEBUG - 2014-08-13 09:38:59 --> XSS Filtering completed
DEBUG - 2014-08-13 09:38:59 --> XSS Filtering completed
DEBUG - 2014-08-13 09:38:59 --> XSS Filtering completed
DEBUG - 2014-08-13 09:38:59 --> CRSF cookie Set
DEBUG - 2014-08-13 09:38:59 --> CSRF token verified
DEBUG - 2014-08-13 09:38:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 09:38:59 --> Language Class Initialized
DEBUG - 2014-08-13 09:38:59 --> Loader Class Initialized
DEBUG - 2014-08-13 09:38:59 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 09:38:59 --> Helper loaded: url_helper
DEBUG - 2014-08-13 09:38:59 --> Database Driver Class Initialized
ERROR - 2014-08-13 09:38:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 09:38:59 --> Session Class Initialized
DEBUG - 2014-08-13 09:38:59 --> Helper loaded: string_helper
DEBUG - 2014-08-13 09:38:59 --> Session routines successfully run
DEBUG - 2014-08-13 09:38:59 --> Controller Class Initialized
DEBUG - 2014-08-13 09:38:59 --> Helper loaded: form_helper
DEBUG - 2014-08-13 09:38:59 --> Form Validation Class Initialized
DEBUG - 2014-08-13 09:38:59 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 09:38:59 --> XSS Filtering completed
DEBUG - 2014-08-13 09:38:59 --> XSS Filtering completed
DEBUG - 2014-08-13 09:38:59 --> XSS Filtering completed
DEBUG - 2014-08-13 09:38:59 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 09:38:59 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 09:38:59 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 09:38:59 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 09:38:59 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 09:38:59 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 09:38:59 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 09:38:59 --> Final output sent to browser
DEBUG - 2014-08-13 09:38:59 --> Total execution time: 0.0911
DEBUG - 2014-08-13 13:48:00 --> Config Class Initialized
DEBUG - 2014-08-13 13:48:00 --> Hooks Class Initialized
DEBUG - 2014-08-13 13:48:00 --> Utf8 Class Initialized
DEBUG - 2014-08-13 13:48:00 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 13:48:00 --> URI Class Initialized
DEBUG - 2014-08-13 13:48:00 --> Router Class Initialized
DEBUG - 2014-08-13 13:48:00 --> Output Class Initialized
DEBUG - 2014-08-13 13:48:00 --> Security Class Initialized
DEBUG - 2014-08-13 13:48:00 --> Input Class Initialized
DEBUG - 2014-08-13 13:48:00 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:00 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:00 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:00 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:00 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:00 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:00 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:00 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:00 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:00 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:00 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:00 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:00 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:00 --> Config Class Initialized
DEBUG - 2014-08-13 13:48:00 --> Hooks Class Initialized
DEBUG - 2014-08-13 13:48:00 --> Utf8 Class Initialized
DEBUG - 2014-08-13 13:48:00 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 13:48:00 --> URI Class Initialized
DEBUG - 2014-08-13 13:48:00 --> Router Class Initialized
DEBUG - 2014-08-13 13:48:00 --> Output Class Initialized
DEBUG - 2014-08-13 13:48:00 --> Security Class Initialized
DEBUG - 2014-08-13 13:48:00 --> Input Class Initialized
DEBUG - 2014-08-13 13:48:00 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:00 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:00 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:00 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:00 --> CRSF cookie Set
DEBUG - 2014-08-13 13:48:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 13:48:00 --> Language Class Initialized
DEBUG - 2014-08-13 13:48:00 --> Loader Class Initialized
DEBUG - 2014-08-13 13:48:00 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 13:48:00 --> Helper loaded: url_helper
DEBUG - 2014-08-13 13:48:00 --> Database Driver Class Initialized
ERROR - 2014-08-13 13:48:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 13:48:00 --> Session Class Initialized
DEBUG - 2014-08-13 13:48:00 --> Helper loaded: string_helper
DEBUG - 2014-08-13 13:48:00 --> Session routines successfully run
DEBUG - 2014-08-13 13:48:00 --> Controller Class Initialized
DEBUG - 2014-08-13 13:48:00 --> Helper loaded: form_helper
DEBUG - 2014-08-13 13:48:00 --> Form Validation Class Initialized
DEBUG - 2014-08-13 13:48:00 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 13:48:00 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 13:48:00 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 13:48:00 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 13:48:00 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 13:48:00 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 13:48:00 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 13:48:00 --> Final output sent to browser
DEBUG - 2014-08-13 13:48:00 --> Total execution time: 0.1601
DEBUG - 2014-08-13 13:48:26 --> Config Class Initialized
DEBUG - 2014-08-13 13:48:26 --> Hooks Class Initialized
DEBUG - 2014-08-13 13:48:26 --> Utf8 Class Initialized
DEBUG - 2014-08-13 13:48:26 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 13:48:26 --> URI Class Initialized
DEBUG - 2014-08-13 13:48:26 --> Router Class Initialized
DEBUG - 2014-08-13 13:48:26 --> Output Class Initialized
DEBUG - 2014-08-13 13:48:26 --> Security Class Initialized
DEBUG - 2014-08-13 13:48:26 --> Input Class Initialized
DEBUG - 2014-08-13 13:48:26 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:26 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:26 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:26 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:26 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:26 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:26 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:26 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:26 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:26 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:26 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:26 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:26 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:26 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:26 --> CRSF cookie Set
DEBUG - 2014-08-13 13:48:26 --> CSRF token verified
DEBUG - 2014-08-13 13:48:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 13:48:26 --> Language Class Initialized
DEBUG - 2014-08-13 13:48:26 --> Loader Class Initialized
DEBUG - 2014-08-13 13:48:26 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 13:48:26 --> Helper loaded: url_helper
DEBUG - 2014-08-13 13:48:26 --> Database Driver Class Initialized
ERROR - 2014-08-13 13:48:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 13:48:26 --> Session Class Initialized
DEBUG - 2014-08-13 13:48:26 --> Helper loaded: string_helper
DEBUG - 2014-08-13 13:48:26 --> Session routines successfully run
DEBUG - 2014-08-13 13:48:26 --> Controller Class Initialized
DEBUG - 2014-08-13 13:48:26 --> Helper loaded: form_helper
DEBUG - 2014-08-13 13:48:26 --> Form Validation Class Initialized
DEBUG - 2014-08-13 13:48:26 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 13:48:26 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:26 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:26 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:26 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 13:48:26 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 13:48:26 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 13:48:26 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 13:48:26 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 13:48:26 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 13:48:26 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 13:48:26 --> Final output sent to browser
DEBUG - 2014-08-13 13:48:26 --> Total execution time: 0.0882
DEBUG - 2014-08-13 13:48:33 --> Config Class Initialized
DEBUG - 2014-08-13 13:48:33 --> Hooks Class Initialized
DEBUG - 2014-08-13 13:48:33 --> Utf8 Class Initialized
DEBUG - 2014-08-13 13:48:33 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 13:48:33 --> URI Class Initialized
DEBUG - 2014-08-13 13:48:33 --> Router Class Initialized
DEBUG - 2014-08-13 13:48:33 --> Output Class Initialized
DEBUG - 2014-08-13 13:48:33 --> Security Class Initialized
DEBUG - 2014-08-13 13:48:33 --> Input Class Initialized
DEBUG - 2014-08-13 13:48:33 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:33 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:33 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:33 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:33 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:33 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:33 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:33 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:33 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:33 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:33 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:33 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:33 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:33 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:33 --> CRSF cookie Set
DEBUG - 2014-08-13 13:48:33 --> CSRF token verified
DEBUG - 2014-08-13 13:48:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 13:48:33 --> Language Class Initialized
DEBUG - 2014-08-13 13:48:33 --> Loader Class Initialized
DEBUG - 2014-08-13 13:48:33 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 13:48:33 --> Helper loaded: url_helper
DEBUG - 2014-08-13 13:48:33 --> Database Driver Class Initialized
ERROR - 2014-08-13 13:48:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 13:48:33 --> Session Class Initialized
DEBUG - 2014-08-13 13:48:33 --> Helper loaded: string_helper
DEBUG - 2014-08-13 13:48:33 --> Session routines successfully run
DEBUG - 2014-08-13 13:48:33 --> Controller Class Initialized
DEBUG - 2014-08-13 13:48:33 --> Helper loaded: form_helper
DEBUG - 2014-08-13 13:48:33 --> Form Validation Class Initialized
DEBUG - 2014-08-13 13:48:33 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 13:48:33 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:33 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:33 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:33 --> XSS Filtering completed
DEBUG - 2014-08-13 13:48:33 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 13:48:33 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 13:48:33 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 13:48:33 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 13:48:33 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 13:48:33 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 13:48:33 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 13:48:33 --> Final output sent to browser
DEBUG - 2014-08-13 13:48:33 --> Total execution time: 0.0731
DEBUG - 2014-08-13 13:49:15 --> Config Class Initialized
DEBUG - 2014-08-13 13:49:15 --> Hooks Class Initialized
DEBUG - 2014-08-13 13:49:15 --> Utf8 Class Initialized
DEBUG - 2014-08-13 13:49:15 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 13:49:15 --> URI Class Initialized
DEBUG - 2014-08-13 13:49:15 --> Router Class Initialized
DEBUG - 2014-08-13 13:49:15 --> Output Class Initialized
DEBUG - 2014-08-13 13:49:15 --> Security Class Initialized
DEBUG - 2014-08-13 13:49:15 --> Input Class Initialized
DEBUG - 2014-08-13 13:49:15 --> XSS Filtering completed
DEBUG - 2014-08-13 13:49:15 --> XSS Filtering completed
DEBUG - 2014-08-13 13:49:15 --> XSS Filtering completed
DEBUG - 2014-08-13 13:49:15 --> XSS Filtering completed
DEBUG - 2014-08-13 13:49:15 --> XSS Filtering completed
DEBUG - 2014-08-13 13:49:15 --> XSS Filtering completed
DEBUG - 2014-08-13 13:49:15 --> XSS Filtering completed
DEBUG - 2014-08-13 13:49:15 --> XSS Filtering completed
DEBUG - 2014-08-13 13:49:15 --> XSS Filtering completed
DEBUG - 2014-08-13 13:49:15 --> XSS Filtering completed
DEBUG - 2014-08-13 13:49:15 --> XSS Filtering completed
DEBUG - 2014-08-13 13:49:15 --> XSS Filtering completed
DEBUG - 2014-08-13 13:49:15 --> XSS Filtering completed
DEBUG - 2014-08-13 13:49:15 --> XSS Filtering completed
DEBUG - 2014-08-13 13:49:15 --> CRSF cookie Set
DEBUG - 2014-08-13 13:49:15 --> CSRF token verified
DEBUG - 2014-08-13 13:49:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 13:49:15 --> Language Class Initialized
DEBUG - 2014-08-13 13:49:15 --> Loader Class Initialized
DEBUG - 2014-08-13 13:49:15 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 13:49:15 --> Helper loaded: url_helper
DEBUG - 2014-08-13 13:49:15 --> Database Driver Class Initialized
ERROR - 2014-08-13 13:49:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 13:49:15 --> Session Class Initialized
DEBUG - 2014-08-13 13:49:15 --> Helper loaded: string_helper
DEBUG - 2014-08-13 13:49:15 --> Session routines successfully run
DEBUG - 2014-08-13 13:49:15 --> Controller Class Initialized
DEBUG - 2014-08-13 13:49:15 --> Helper loaded: form_helper
DEBUG - 2014-08-13 13:49:15 --> Form Validation Class Initialized
DEBUG - 2014-08-13 13:49:15 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 13:49:15 --> XSS Filtering completed
DEBUG - 2014-08-13 13:49:15 --> XSS Filtering completed
DEBUG - 2014-08-13 13:49:15 --> XSS Filtering completed
DEBUG - 2014-08-13 13:49:15 --> XSS Filtering completed
DEBUG - 2014-08-13 13:49:15 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 13:49:15 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 13:49:15 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 13:49:15 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 13:49:15 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 13:49:15 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 13:49:15 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 13:49:15 --> Final output sent to browser
DEBUG - 2014-08-13 13:49:15 --> Total execution time: 0.0753
DEBUG - 2014-08-13 13:51:36 --> Config Class Initialized
DEBUG - 2014-08-13 13:51:36 --> Hooks Class Initialized
DEBUG - 2014-08-13 13:51:36 --> Utf8 Class Initialized
DEBUG - 2014-08-13 13:51:36 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 13:51:36 --> URI Class Initialized
DEBUG - 2014-08-13 13:51:36 --> Router Class Initialized
DEBUG - 2014-08-13 13:51:36 --> Output Class Initialized
DEBUG - 2014-08-13 13:51:36 --> Security Class Initialized
DEBUG - 2014-08-13 13:51:36 --> Input Class Initialized
DEBUG - 2014-08-13 13:51:36 --> XSS Filtering completed
DEBUG - 2014-08-13 13:51:36 --> XSS Filtering completed
DEBUG - 2014-08-13 13:51:36 --> XSS Filtering completed
DEBUG - 2014-08-13 13:51:36 --> XSS Filtering completed
DEBUG - 2014-08-13 13:51:36 --> XSS Filtering completed
DEBUG - 2014-08-13 13:51:36 --> XSS Filtering completed
DEBUG - 2014-08-13 13:51:36 --> XSS Filtering completed
DEBUG - 2014-08-13 13:51:36 --> XSS Filtering completed
DEBUG - 2014-08-13 13:51:36 --> XSS Filtering completed
DEBUG - 2014-08-13 13:51:36 --> XSS Filtering completed
DEBUG - 2014-08-13 13:51:36 --> XSS Filtering completed
DEBUG - 2014-08-13 13:51:36 --> XSS Filtering completed
DEBUG - 2014-08-13 13:51:36 --> XSS Filtering completed
DEBUG - 2014-08-13 13:51:36 --> XSS Filtering completed
DEBUG - 2014-08-13 13:51:36 --> CRSF cookie Set
DEBUG - 2014-08-13 13:51:36 --> CSRF token verified
DEBUG - 2014-08-13 13:51:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 13:51:36 --> Language Class Initialized
DEBUG - 2014-08-13 13:51:36 --> Loader Class Initialized
DEBUG - 2014-08-13 13:51:36 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 13:51:36 --> Helper loaded: url_helper
DEBUG - 2014-08-13 13:51:36 --> Database Driver Class Initialized
ERROR - 2014-08-13 13:51:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 13:51:36 --> Session Class Initialized
DEBUG - 2014-08-13 13:51:36 --> Helper loaded: string_helper
DEBUG - 2014-08-13 13:51:36 --> Session routines successfully run
DEBUG - 2014-08-13 13:51:36 --> Controller Class Initialized
DEBUG - 2014-08-13 13:51:36 --> Helper loaded: form_helper
DEBUG - 2014-08-13 13:51:36 --> Form Validation Class Initialized
DEBUG - 2014-08-13 13:51:36 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 13:51:36 --> XSS Filtering completed
DEBUG - 2014-08-13 13:51:36 --> XSS Filtering completed
DEBUG - 2014-08-13 13:51:36 --> XSS Filtering completed
DEBUG - 2014-08-13 13:51:36 --> XSS Filtering completed
DEBUG - 2014-08-13 13:51:36 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 13:51:36 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 13:51:36 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 13:51:36 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 13:51:36 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 13:51:36 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 13:51:36 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 13:51:36 --> Final output sent to browser
DEBUG - 2014-08-13 13:51:36 --> Total execution time: 0.0743
DEBUG - 2014-08-13 13:51:45 --> Config Class Initialized
DEBUG - 2014-08-13 13:51:45 --> Hooks Class Initialized
DEBUG - 2014-08-13 13:51:45 --> Utf8 Class Initialized
DEBUG - 2014-08-13 13:51:45 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 13:51:45 --> URI Class Initialized
DEBUG - 2014-08-13 13:51:45 --> Router Class Initialized
DEBUG - 2014-08-13 13:51:45 --> Output Class Initialized
DEBUG - 2014-08-13 13:51:45 --> Security Class Initialized
DEBUG - 2014-08-13 13:51:45 --> Input Class Initialized
DEBUG - 2014-08-13 13:51:45 --> XSS Filtering completed
DEBUG - 2014-08-13 13:51:45 --> XSS Filtering completed
DEBUG - 2014-08-13 13:51:45 --> XSS Filtering completed
DEBUG - 2014-08-13 13:51:45 --> XSS Filtering completed
DEBUG - 2014-08-13 13:51:45 --> XSS Filtering completed
DEBUG - 2014-08-13 13:51:45 --> XSS Filtering completed
DEBUG - 2014-08-13 13:51:45 --> XSS Filtering completed
DEBUG - 2014-08-13 13:51:45 --> XSS Filtering completed
DEBUG - 2014-08-13 13:51:45 --> XSS Filtering completed
DEBUG - 2014-08-13 13:51:45 --> XSS Filtering completed
DEBUG - 2014-08-13 13:51:45 --> XSS Filtering completed
DEBUG - 2014-08-13 13:51:45 --> XSS Filtering completed
DEBUG - 2014-08-13 13:51:45 --> XSS Filtering completed
DEBUG - 2014-08-13 13:51:45 --> XSS Filtering completed
DEBUG - 2014-08-13 13:51:45 --> CRSF cookie Set
DEBUG - 2014-08-13 13:51:45 --> CSRF token verified
DEBUG - 2014-08-13 13:51:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 13:51:45 --> Language Class Initialized
DEBUG - 2014-08-13 13:51:45 --> Loader Class Initialized
DEBUG - 2014-08-13 13:51:45 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 13:51:45 --> Helper loaded: url_helper
DEBUG - 2014-08-13 13:51:45 --> Database Driver Class Initialized
ERROR - 2014-08-13 13:51:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 13:51:45 --> Session Class Initialized
DEBUG - 2014-08-13 13:51:45 --> Helper loaded: string_helper
DEBUG - 2014-08-13 13:51:45 --> Session routines successfully run
DEBUG - 2014-08-13 13:51:45 --> Controller Class Initialized
DEBUG - 2014-08-13 13:51:45 --> Helper loaded: form_helper
DEBUG - 2014-08-13 13:51:45 --> Form Validation Class Initialized
DEBUG - 2014-08-13 13:51:45 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 13:51:45 --> XSS Filtering completed
DEBUG - 2014-08-13 13:51:45 --> XSS Filtering completed
DEBUG - 2014-08-13 13:51:45 --> XSS Filtering completed
DEBUG - 2014-08-13 13:51:45 --> XSS Filtering completed
DEBUG - 2014-08-13 13:51:45 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 13:51:45 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 13:51:45 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 13:51:45 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 13:51:45 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 13:51:45 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 13:51:45 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 13:51:45 --> Final output sent to browser
DEBUG - 2014-08-13 13:51:45 --> Total execution time: 0.0719
DEBUG - 2014-08-13 13:52:48 --> Config Class Initialized
DEBUG - 2014-08-13 13:52:48 --> Hooks Class Initialized
DEBUG - 2014-08-13 13:52:48 --> Utf8 Class Initialized
DEBUG - 2014-08-13 13:52:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 13:52:48 --> URI Class Initialized
DEBUG - 2014-08-13 13:52:48 --> Router Class Initialized
DEBUG - 2014-08-13 13:52:48 --> Output Class Initialized
DEBUG - 2014-08-13 13:52:48 --> Security Class Initialized
DEBUG - 2014-08-13 13:52:48 --> Input Class Initialized
DEBUG - 2014-08-13 13:52:48 --> XSS Filtering completed
DEBUG - 2014-08-13 13:52:48 --> XSS Filtering completed
DEBUG - 2014-08-13 13:52:48 --> XSS Filtering completed
DEBUG - 2014-08-13 13:52:48 --> XSS Filtering completed
DEBUG - 2014-08-13 13:52:48 --> XSS Filtering completed
DEBUG - 2014-08-13 13:52:48 --> XSS Filtering completed
DEBUG - 2014-08-13 13:52:48 --> XSS Filtering completed
DEBUG - 2014-08-13 13:52:48 --> XSS Filtering completed
DEBUG - 2014-08-13 13:52:48 --> XSS Filtering completed
DEBUG - 2014-08-13 13:52:48 --> XSS Filtering completed
DEBUG - 2014-08-13 13:52:48 --> XSS Filtering completed
DEBUG - 2014-08-13 13:52:48 --> XSS Filtering completed
DEBUG - 2014-08-13 13:52:48 --> XSS Filtering completed
DEBUG - 2014-08-13 13:52:48 --> XSS Filtering completed
DEBUG - 2014-08-13 13:52:48 --> CRSF cookie Set
DEBUG - 2014-08-13 13:52:48 --> CSRF token verified
DEBUG - 2014-08-13 13:52:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 13:52:48 --> Language Class Initialized
DEBUG - 2014-08-13 13:52:48 --> Loader Class Initialized
DEBUG - 2014-08-13 13:52:48 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 13:52:48 --> Helper loaded: url_helper
DEBUG - 2014-08-13 13:52:48 --> Database Driver Class Initialized
ERROR - 2014-08-13 13:52:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 13:52:48 --> Session Class Initialized
DEBUG - 2014-08-13 13:52:48 --> Helper loaded: string_helper
DEBUG - 2014-08-13 13:52:48 --> Session routines successfully run
DEBUG - 2014-08-13 13:52:48 --> Controller Class Initialized
DEBUG - 2014-08-13 13:52:48 --> Helper loaded: form_helper
DEBUG - 2014-08-13 13:52:48 --> Form Validation Class Initialized
DEBUG - 2014-08-13 13:52:48 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 13:52:48 --> XSS Filtering completed
DEBUG - 2014-08-13 13:52:48 --> XSS Filtering completed
DEBUG - 2014-08-13 13:52:48 --> XSS Filtering completed
DEBUG - 2014-08-13 13:52:48 --> XSS Filtering completed
DEBUG - 2014-08-13 13:52:48 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 13:52:48 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 13:52:48 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 13:52:48 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 13:52:48 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 13:52:48 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 13:52:48 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 13:52:48 --> Final output sent to browser
DEBUG - 2014-08-13 13:52:48 --> Total execution time: 0.0770
DEBUG - 2014-08-13 13:53:44 --> Config Class Initialized
DEBUG - 2014-08-13 13:53:44 --> Hooks Class Initialized
DEBUG - 2014-08-13 13:53:44 --> Utf8 Class Initialized
DEBUG - 2014-08-13 13:53:44 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 13:53:44 --> URI Class Initialized
DEBUG - 2014-08-13 13:53:44 --> Router Class Initialized
DEBUG - 2014-08-13 13:53:44 --> Output Class Initialized
DEBUG - 2014-08-13 13:53:44 --> Security Class Initialized
DEBUG - 2014-08-13 13:53:44 --> Input Class Initialized
DEBUG - 2014-08-13 13:53:44 --> XSS Filtering completed
DEBUG - 2014-08-13 13:53:44 --> XSS Filtering completed
DEBUG - 2014-08-13 13:53:44 --> XSS Filtering completed
DEBUG - 2014-08-13 13:53:44 --> XSS Filtering completed
DEBUG - 2014-08-13 13:53:44 --> XSS Filtering completed
DEBUG - 2014-08-13 13:53:44 --> XSS Filtering completed
DEBUG - 2014-08-13 13:53:44 --> XSS Filtering completed
DEBUG - 2014-08-13 13:53:44 --> XSS Filtering completed
DEBUG - 2014-08-13 13:53:44 --> XSS Filtering completed
DEBUG - 2014-08-13 13:53:44 --> XSS Filtering completed
DEBUG - 2014-08-13 13:53:44 --> XSS Filtering completed
DEBUG - 2014-08-13 13:53:44 --> XSS Filtering completed
DEBUG - 2014-08-13 13:53:44 --> XSS Filtering completed
DEBUG - 2014-08-13 13:53:44 --> XSS Filtering completed
DEBUG - 2014-08-13 13:53:44 --> CRSF cookie Set
DEBUG - 2014-08-13 13:53:44 --> CSRF token verified
DEBUG - 2014-08-13 13:53:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 13:53:44 --> Language Class Initialized
DEBUG - 2014-08-13 13:53:44 --> Loader Class Initialized
DEBUG - 2014-08-13 13:53:44 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 13:53:44 --> Helper loaded: url_helper
DEBUG - 2014-08-13 13:53:44 --> Database Driver Class Initialized
ERROR - 2014-08-13 13:53:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 13:53:44 --> Session Class Initialized
DEBUG - 2014-08-13 13:53:44 --> Helper loaded: string_helper
DEBUG - 2014-08-13 13:53:44 --> Session routines successfully run
DEBUG - 2014-08-13 13:53:44 --> Controller Class Initialized
DEBUG - 2014-08-13 13:53:44 --> Helper loaded: form_helper
DEBUG - 2014-08-13 13:53:44 --> Form Validation Class Initialized
DEBUG - 2014-08-13 13:53:44 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 13:53:44 --> XSS Filtering completed
DEBUG - 2014-08-13 13:53:44 --> XSS Filtering completed
DEBUG - 2014-08-13 13:53:44 --> XSS Filtering completed
DEBUG - 2014-08-13 13:53:44 --> XSS Filtering completed
DEBUG - 2014-08-13 13:53:44 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 13:53:44 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 13:53:44 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 13:53:44 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 13:53:44 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 13:53:44 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 13:53:44 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 13:53:44 --> Final output sent to browser
DEBUG - 2014-08-13 13:53:44 --> Total execution time: 0.0760
DEBUG - 2014-08-13 13:54:20 --> Config Class Initialized
DEBUG - 2014-08-13 13:54:20 --> Hooks Class Initialized
DEBUG - 2014-08-13 13:54:20 --> Utf8 Class Initialized
DEBUG - 2014-08-13 13:54:20 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 13:54:20 --> URI Class Initialized
DEBUG - 2014-08-13 13:54:20 --> Router Class Initialized
DEBUG - 2014-08-13 13:54:20 --> Output Class Initialized
DEBUG - 2014-08-13 13:54:20 --> Security Class Initialized
DEBUG - 2014-08-13 13:54:20 --> Input Class Initialized
DEBUG - 2014-08-13 13:54:20 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:20 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:20 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:20 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:20 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:20 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:20 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:20 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:20 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:20 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:20 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:20 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:20 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:20 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:20 --> CRSF cookie Set
DEBUG - 2014-08-13 13:54:20 --> CSRF token verified
DEBUG - 2014-08-13 13:54:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 13:54:20 --> Language Class Initialized
DEBUG - 2014-08-13 13:54:20 --> Loader Class Initialized
DEBUG - 2014-08-13 13:54:20 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 13:54:20 --> Helper loaded: url_helper
DEBUG - 2014-08-13 13:54:20 --> Database Driver Class Initialized
ERROR - 2014-08-13 13:54:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 13:54:20 --> Session Class Initialized
DEBUG - 2014-08-13 13:54:20 --> Helper loaded: string_helper
DEBUG - 2014-08-13 13:54:20 --> Session routines successfully run
DEBUG - 2014-08-13 13:54:20 --> Controller Class Initialized
DEBUG - 2014-08-13 13:54:20 --> Helper loaded: form_helper
DEBUG - 2014-08-13 13:54:20 --> Form Validation Class Initialized
DEBUG - 2014-08-13 13:54:20 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 13:54:20 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:20 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:20 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:20 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:20 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 13:54:20 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 13:54:20 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 13:54:20 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 13:54:20 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 13:54:20 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 13:54:20 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 13:54:20 --> Final output sent to browser
DEBUG - 2014-08-13 13:54:20 --> Total execution time: 0.0851
DEBUG - 2014-08-13 13:54:40 --> Config Class Initialized
DEBUG - 2014-08-13 13:54:40 --> Hooks Class Initialized
DEBUG - 2014-08-13 13:54:40 --> Utf8 Class Initialized
DEBUG - 2014-08-13 13:54:40 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 13:54:40 --> URI Class Initialized
DEBUG - 2014-08-13 13:54:40 --> Router Class Initialized
DEBUG - 2014-08-13 13:54:40 --> Output Class Initialized
DEBUG - 2014-08-13 13:54:40 --> Security Class Initialized
DEBUG - 2014-08-13 13:54:40 --> Input Class Initialized
DEBUG - 2014-08-13 13:54:40 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:40 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:40 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:40 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:40 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:40 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:40 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:40 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:40 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:40 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:40 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:40 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:40 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:40 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:40 --> CRSF cookie Set
DEBUG - 2014-08-13 13:54:40 --> CSRF token verified
DEBUG - 2014-08-13 13:54:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 13:54:40 --> Language Class Initialized
DEBUG - 2014-08-13 13:54:40 --> Loader Class Initialized
DEBUG - 2014-08-13 13:54:40 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 13:54:40 --> Helper loaded: url_helper
DEBUG - 2014-08-13 13:54:40 --> Database Driver Class Initialized
ERROR - 2014-08-13 13:54:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 13:54:40 --> Session Class Initialized
DEBUG - 2014-08-13 13:54:40 --> Helper loaded: string_helper
DEBUG - 2014-08-13 13:54:40 --> Session routines successfully run
DEBUG - 2014-08-13 13:54:40 --> Controller Class Initialized
DEBUG - 2014-08-13 13:54:40 --> Helper loaded: form_helper
DEBUG - 2014-08-13 13:54:40 --> Form Validation Class Initialized
DEBUG - 2014-08-13 13:54:40 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 13:54:40 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:40 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:40 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:40 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:40 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 13:54:40 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 13:54:40 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 13:54:40 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 13:54:40 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 13:54:40 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 13:54:40 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 13:54:40 --> Final output sent to browser
DEBUG - 2014-08-13 13:54:40 --> Total execution time: 0.0759
DEBUG - 2014-08-13 13:54:46 --> Config Class Initialized
DEBUG - 2014-08-13 13:54:46 --> Hooks Class Initialized
DEBUG - 2014-08-13 13:54:46 --> Utf8 Class Initialized
DEBUG - 2014-08-13 13:54:46 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 13:54:46 --> URI Class Initialized
DEBUG - 2014-08-13 13:54:46 --> Router Class Initialized
DEBUG - 2014-08-13 13:54:46 --> Output Class Initialized
DEBUG - 2014-08-13 13:54:46 --> Security Class Initialized
DEBUG - 2014-08-13 13:54:46 --> Input Class Initialized
DEBUG - 2014-08-13 13:54:46 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:46 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:46 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:46 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:46 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:46 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:46 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:46 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:46 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:46 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:46 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:46 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:46 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:46 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:46 --> CRSF cookie Set
DEBUG - 2014-08-13 13:54:46 --> CSRF token verified
DEBUG - 2014-08-13 13:54:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 13:54:46 --> Language Class Initialized
DEBUG - 2014-08-13 13:54:46 --> Loader Class Initialized
DEBUG - 2014-08-13 13:54:46 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 13:54:46 --> Helper loaded: url_helper
DEBUG - 2014-08-13 13:54:46 --> Database Driver Class Initialized
ERROR - 2014-08-13 13:54:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 13:54:46 --> Session Class Initialized
DEBUG - 2014-08-13 13:54:46 --> Helper loaded: string_helper
DEBUG - 2014-08-13 13:54:46 --> Session routines successfully run
DEBUG - 2014-08-13 13:54:46 --> Controller Class Initialized
DEBUG - 2014-08-13 13:54:46 --> Helper loaded: form_helper
DEBUG - 2014-08-13 13:54:46 --> Form Validation Class Initialized
DEBUG - 2014-08-13 13:54:46 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 13:54:46 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:46 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:46 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:46 --> XSS Filtering completed
DEBUG - 2014-08-13 13:54:46 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 13:54:46 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 13:54:46 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 13:54:46 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 13:54:46 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 13:54:46 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 13:54:46 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 13:54:46 --> Final output sent to browser
DEBUG - 2014-08-13 13:54:46 --> Total execution time: 0.0768
DEBUG - 2014-08-13 13:55:39 --> Config Class Initialized
DEBUG - 2014-08-13 13:55:39 --> Hooks Class Initialized
DEBUG - 2014-08-13 13:55:39 --> Utf8 Class Initialized
DEBUG - 2014-08-13 13:55:39 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 13:55:39 --> URI Class Initialized
DEBUG - 2014-08-13 13:55:39 --> Router Class Initialized
DEBUG - 2014-08-13 13:55:39 --> Output Class Initialized
DEBUG - 2014-08-13 13:55:39 --> Security Class Initialized
DEBUG - 2014-08-13 13:55:39 --> Input Class Initialized
DEBUG - 2014-08-13 13:55:39 --> XSS Filtering completed
DEBUG - 2014-08-13 13:55:39 --> XSS Filtering completed
DEBUG - 2014-08-13 13:55:39 --> XSS Filtering completed
DEBUG - 2014-08-13 13:55:39 --> XSS Filtering completed
DEBUG - 2014-08-13 13:55:39 --> XSS Filtering completed
DEBUG - 2014-08-13 13:55:39 --> XSS Filtering completed
DEBUG - 2014-08-13 13:55:39 --> XSS Filtering completed
DEBUG - 2014-08-13 13:55:39 --> XSS Filtering completed
DEBUG - 2014-08-13 13:55:39 --> XSS Filtering completed
DEBUG - 2014-08-13 13:55:39 --> XSS Filtering completed
DEBUG - 2014-08-13 13:55:39 --> XSS Filtering completed
DEBUG - 2014-08-13 13:55:39 --> XSS Filtering completed
DEBUG - 2014-08-13 13:55:39 --> XSS Filtering completed
DEBUG - 2014-08-13 13:55:39 --> XSS Filtering completed
DEBUG - 2014-08-13 13:55:39 --> CRSF cookie Set
DEBUG - 2014-08-13 13:55:39 --> CSRF token verified
DEBUG - 2014-08-13 13:55:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 13:55:39 --> Language Class Initialized
DEBUG - 2014-08-13 13:55:39 --> Loader Class Initialized
DEBUG - 2014-08-13 13:55:39 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 13:55:39 --> Helper loaded: url_helper
DEBUG - 2014-08-13 13:55:39 --> Database Driver Class Initialized
ERROR - 2014-08-13 13:55:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 13:55:39 --> Session Class Initialized
DEBUG - 2014-08-13 13:55:39 --> Helper loaded: string_helper
DEBUG - 2014-08-13 13:55:39 --> Session routines successfully run
DEBUG - 2014-08-13 13:55:39 --> Controller Class Initialized
DEBUG - 2014-08-13 13:55:40 --> Helper loaded: form_helper
DEBUG - 2014-08-13 13:55:40 --> Form Validation Class Initialized
DEBUG - 2014-08-13 13:55:40 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 13:55:40 --> XSS Filtering completed
DEBUG - 2014-08-13 13:55:40 --> XSS Filtering completed
DEBUG - 2014-08-13 13:55:40 --> XSS Filtering completed
DEBUG - 2014-08-13 13:55:40 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 13:55:40 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 13:55:40 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 13:55:40 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 13:55:40 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 13:55:40 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 13:55:40 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 13:55:40 --> Final output sent to browser
DEBUG - 2014-08-13 13:55:40 --> Total execution time: 0.0746
DEBUG - 2014-08-13 13:55:45 --> Config Class Initialized
DEBUG - 2014-08-13 13:55:45 --> Hooks Class Initialized
DEBUG - 2014-08-13 13:55:45 --> Utf8 Class Initialized
DEBUG - 2014-08-13 13:55:45 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 13:55:45 --> URI Class Initialized
DEBUG - 2014-08-13 13:55:45 --> Router Class Initialized
DEBUG - 2014-08-13 13:55:45 --> Output Class Initialized
DEBUG - 2014-08-13 13:55:45 --> Security Class Initialized
DEBUG - 2014-08-13 13:55:45 --> Input Class Initialized
DEBUG - 2014-08-13 13:55:45 --> XSS Filtering completed
DEBUG - 2014-08-13 13:55:45 --> XSS Filtering completed
DEBUG - 2014-08-13 13:55:45 --> XSS Filtering completed
DEBUG - 2014-08-13 13:55:45 --> XSS Filtering completed
DEBUG - 2014-08-13 13:55:45 --> XSS Filtering completed
DEBUG - 2014-08-13 13:55:45 --> XSS Filtering completed
DEBUG - 2014-08-13 13:55:45 --> XSS Filtering completed
DEBUG - 2014-08-13 13:55:45 --> XSS Filtering completed
DEBUG - 2014-08-13 13:55:45 --> XSS Filtering completed
DEBUG - 2014-08-13 13:55:45 --> XSS Filtering completed
DEBUG - 2014-08-13 13:55:45 --> XSS Filtering completed
DEBUG - 2014-08-13 13:55:45 --> XSS Filtering completed
DEBUG - 2014-08-13 13:55:45 --> XSS Filtering completed
DEBUG - 2014-08-13 13:55:45 --> XSS Filtering completed
DEBUG - 2014-08-13 13:55:45 --> CRSF cookie Set
DEBUG - 2014-08-13 13:55:45 --> CSRF token verified
DEBUG - 2014-08-13 13:55:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 13:55:45 --> Language Class Initialized
DEBUG - 2014-08-13 13:55:45 --> Loader Class Initialized
DEBUG - 2014-08-13 13:55:45 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 13:55:45 --> Helper loaded: url_helper
DEBUG - 2014-08-13 13:55:45 --> Database Driver Class Initialized
ERROR - 2014-08-13 13:55:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 13:55:45 --> Session Class Initialized
DEBUG - 2014-08-13 13:55:45 --> Helper loaded: string_helper
DEBUG - 2014-08-13 13:55:45 --> Session routines successfully run
DEBUG - 2014-08-13 13:55:45 --> Controller Class Initialized
DEBUG - 2014-08-13 13:55:45 --> Helper loaded: form_helper
DEBUG - 2014-08-13 13:55:45 --> Form Validation Class Initialized
DEBUG - 2014-08-13 13:55:45 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 13:55:45 --> XSS Filtering completed
DEBUG - 2014-08-13 13:55:45 --> XSS Filtering completed
DEBUG - 2014-08-13 13:55:45 --> XSS Filtering completed
DEBUG - 2014-08-13 13:55:45 --> XSS Filtering completed
DEBUG - 2014-08-13 13:55:45 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 13:55:45 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 13:55:45 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 13:55:45 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 13:55:45 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 13:55:45 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 13:55:45 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 13:55:45 --> Final output sent to browser
DEBUG - 2014-08-13 13:55:45 --> Total execution time: 0.0786
DEBUG - 2014-08-13 13:56:04 --> Config Class Initialized
DEBUG - 2014-08-13 13:56:04 --> Hooks Class Initialized
DEBUG - 2014-08-13 13:56:04 --> Utf8 Class Initialized
DEBUG - 2014-08-13 13:56:04 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 13:56:04 --> URI Class Initialized
DEBUG - 2014-08-13 13:56:04 --> Router Class Initialized
DEBUG - 2014-08-13 13:56:04 --> Output Class Initialized
DEBUG - 2014-08-13 13:56:04 --> Security Class Initialized
DEBUG - 2014-08-13 13:56:04 --> Input Class Initialized
DEBUG - 2014-08-13 13:56:04 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:04 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:04 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:04 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:04 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:04 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:04 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:04 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:04 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:04 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:04 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:04 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:04 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:04 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:04 --> CRSF cookie Set
DEBUG - 2014-08-13 13:56:04 --> CSRF token verified
DEBUG - 2014-08-13 13:56:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 13:56:04 --> Language Class Initialized
DEBUG - 2014-08-13 13:56:04 --> Loader Class Initialized
DEBUG - 2014-08-13 13:56:04 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 13:56:04 --> Helper loaded: url_helper
DEBUG - 2014-08-13 13:56:04 --> Database Driver Class Initialized
ERROR - 2014-08-13 13:56:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 13:56:04 --> Session Class Initialized
DEBUG - 2014-08-13 13:56:04 --> Helper loaded: string_helper
DEBUG - 2014-08-13 13:56:04 --> Session routines successfully run
DEBUG - 2014-08-13 13:56:04 --> Controller Class Initialized
DEBUG - 2014-08-13 13:56:04 --> Helper loaded: form_helper
DEBUG - 2014-08-13 13:56:04 --> Form Validation Class Initialized
DEBUG - 2014-08-13 13:56:04 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 13:56:04 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:04 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:05 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:05 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 13:56:05 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 13:56:05 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 13:56:05 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 13:56:05 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 13:56:05 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 13:56:05 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 13:56:05 --> Final output sent to browser
DEBUG - 2014-08-13 13:56:05 --> Total execution time: 0.0821
DEBUG - 2014-08-13 13:56:23 --> Config Class Initialized
DEBUG - 2014-08-13 13:56:23 --> Hooks Class Initialized
DEBUG - 2014-08-13 13:56:23 --> Utf8 Class Initialized
DEBUG - 2014-08-13 13:56:23 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 13:56:23 --> URI Class Initialized
DEBUG - 2014-08-13 13:56:23 --> Router Class Initialized
DEBUG - 2014-08-13 13:56:23 --> Output Class Initialized
DEBUG - 2014-08-13 13:56:23 --> Security Class Initialized
DEBUG - 2014-08-13 13:56:23 --> Input Class Initialized
DEBUG - 2014-08-13 13:56:23 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:23 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:23 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:23 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:23 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:23 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:23 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:23 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:23 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:23 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:23 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:23 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:23 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:23 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:23 --> CRSF cookie Set
DEBUG - 2014-08-13 13:56:23 --> CSRF token verified
DEBUG - 2014-08-13 13:56:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 13:56:23 --> Language Class Initialized
DEBUG - 2014-08-13 13:56:23 --> Loader Class Initialized
DEBUG - 2014-08-13 13:56:23 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 13:56:23 --> Helper loaded: url_helper
DEBUG - 2014-08-13 13:56:23 --> Database Driver Class Initialized
ERROR - 2014-08-13 13:56:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 13:56:23 --> Session Class Initialized
DEBUG - 2014-08-13 13:56:23 --> Helper loaded: string_helper
DEBUG - 2014-08-13 13:56:23 --> Session routines successfully run
DEBUG - 2014-08-13 13:56:23 --> Controller Class Initialized
DEBUG - 2014-08-13 13:56:23 --> Helper loaded: form_helper
DEBUG - 2014-08-13 13:56:23 --> Form Validation Class Initialized
DEBUG - 2014-08-13 13:56:23 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 13:56:23 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:23 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:23 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:23 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 13:56:23 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 13:56:23 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 13:56:23 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 13:56:23 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 13:56:23 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 13:56:23 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 13:56:23 --> Final output sent to browser
DEBUG - 2014-08-13 13:56:23 --> Total execution time: 0.0743
DEBUG - 2014-08-13 13:56:29 --> Config Class Initialized
DEBUG - 2014-08-13 13:56:29 --> Hooks Class Initialized
DEBUG - 2014-08-13 13:56:29 --> Utf8 Class Initialized
DEBUG - 2014-08-13 13:56:29 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 13:56:29 --> URI Class Initialized
DEBUG - 2014-08-13 13:56:29 --> Router Class Initialized
DEBUG - 2014-08-13 13:56:29 --> Output Class Initialized
DEBUG - 2014-08-13 13:56:29 --> Security Class Initialized
DEBUG - 2014-08-13 13:56:29 --> Input Class Initialized
DEBUG - 2014-08-13 13:56:29 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:29 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:29 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:29 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:29 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:29 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:29 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:29 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:29 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:29 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:29 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:29 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:29 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:29 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:29 --> CRSF cookie Set
DEBUG - 2014-08-13 13:56:29 --> CSRF token verified
DEBUG - 2014-08-13 13:56:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 13:56:29 --> Language Class Initialized
DEBUG - 2014-08-13 13:56:29 --> Loader Class Initialized
DEBUG - 2014-08-13 13:56:29 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 13:56:29 --> Helper loaded: url_helper
DEBUG - 2014-08-13 13:56:29 --> Database Driver Class Initialized
ERROR - 2014-08-13 13:56:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 13:56:29 --> Session Class Initialized
DEBUG - 2014-08-13 13:56:29 --> Helper loaded: string_helper
DEBUG - 2014-08-13 13:56:29 --> Session routines successfully run
DEBUG - 2014-08-13 13:56:29 --> Controller Class Initialized
DEBUG - 2014-08-13 13:56:29 --> Helper loaded: form_helper
DEBUG - 2014-08-13 13:56:29 --> Form Validation Class Initialized
DEBUG - 2014-08-13 13:56:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 13:56:29 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:29 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:29 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:29 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 13:56:29 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 13:56:29 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 13:56:29 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 13:56:29 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 13:56:29 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 13:56:29 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 13:56:29 --> Final output sent to browser
DEBUG - 2014-08-13 13:56:29 --> Total execution time: 0.0752
DEBUG - 2014-08-13 13:56:35 --> Config Class Initialized
DEBUG - 2014-08-13 13:56:35 --> Hooks Class Initialized
DEBUG - 2014-08-13 13:56:35 --> Utf8 Class Initialized
DEBUG - 2014-08-13 13:56:35 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 13:56:35 --> URI Class Initialized
DEBUG - 2014-08-13 13:56:35 --> Router Class Initialized
DEBUG - 2014-08-13 13:56:35 --> Output Class Initialized
DEBUG - 2014-08-13 13:56:35 --> Security Class Initialized
DEBUG - 2014-08-13 13:56:35 --> Input Class Initialized
DEBUG - 2014-08-13 13:56:35 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:35 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:35 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:35 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:35 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:35 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:35 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:35 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:35 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:35 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:35 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:35 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:35 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:35 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:35 --> CRSF cookie Set
DEBUG - 2014-08-13 13:56:35 --> CSRF token verified
DEBUG - 2014-08-13 13:56:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 13:56:35 --> Language Class Initialized
DEBUG - 2014-08-13 13:56:35 --> Loader Class Initialized
DEBUG - 2014-08-13 13:56:35 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 13:56:35 --> Helper loaded: url_helper
DEBUG - 2014-08-13 13:56:35 --> Database Driver Class Initialized
ERROR - 2014-08-13 13:56:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 13:56:35 --> Session Class Initialized
DEBUG - 2014-08-13 13:56:35 --> Helper loaded: string_helper
DEBUG - 2014-08-13 13:56:35 --> Session routines successfully run
DEBUG - 2014-08-13 13:56:35 --> Controller Class Initialized
DEBUG - 2014-08-13 13:56:35 --> Helper loaded: form_helper
DEBUG - 2014-08-13 13:56:35 --> Form Validation Class Initialized
DEBUG - 2014-08-13 13:56:35 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 13:56:35 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:35 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:35 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:35 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:35 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 13:56:35 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 13:56:35 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 13:56:35 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 13:56:35 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 13:56:35 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 13:56:35 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 13:56:35 --> Final output sent to browser
DEBUG - 2014-08-13 13:56:35 --> Total execution time: 0.0766
DEBUG - 2014-08-13 13:56:43 --> Config Class Initialized
DEBUG - 2014-08-13 13:56:43 --> Hooks Class Initialized
DEBUG - 2014-08-13 13:56:43 --> Utf8 Class Initialized
DEBUG - 2014-08-13 13:56:43 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 13:56:43 --> URI Class Initialized
DEBUG - 2014-08-13 13:56:43 --> Router Class Initialized
DEBUG - 2014-08-13 13:56:43 --> Output Class Initialized
DEBUG - 2014-08-13 13:56:43 --> Security Class Initialized
DEBUG - 2014-08-13 13:56:43 --> Input Class Initialized
DEBUG - 2014-08-13 13:56:43 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:43 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:43 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:43 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:43 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:43 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:43 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:43 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:43 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:43 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:43 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:43 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:43 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:43 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:43 --> CRSF cookie Set
DEBUG - 2014-08-13 13:56:43 --> CSRF token verified
DEBUG - 2014-08-13 13:56:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 13:56:43 --> Language Class Initialized
DEBUG - 2014-08-13 13:56:43 --> Loader Class Initialized
DEBUG - 2014-08-13 13:56:43 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 13:56:43 --> Helper loaded: url_helper
DEBUG - 2014-08-13 13:56:43 --> Database Driver Class Initialized
ERROR - 2014-08-13 13:56:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 13:56:43 --> Session Class Initialized
DEBUG - 2014-08-13 13:56:43 --> Helper loaded: string_helper
DEBUG - 2014-08-13 13:56:43 --> Session routines successfully run
DEBUG - 2014-08-13 13:56:43 --> Controller Class Initialized
DEBUG - 2014-08-13 13:56:43 --> Helper loaded: form_helper
DEBUG - 2014-08-13 13:56:43 --> Form Validation Class Initialized
DEBUG - 2014-08-13 13:56:43 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 13:56:43 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:43 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:43 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:43 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:43 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 13:56:43 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 13:56:43 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 13:56:43 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 13:56:43 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 13:56:43 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 13:56:43 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 13:56:43 --> Final output sent to browser
DEBUG - 2014-08-13 13:56:43 --> Total execution time: 0.0798
DEBUG - 2014-08-13 13:56:55 --> Config Class Initialized
DEBUG - 2014-08-13 13:56:55 --> Hooks Class Initialized
DEBUG - 2014-08-13 13:56:55 --> Utf8 Class Initialized
DEBUG - 2014-08-13 13:56:55 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 13:56:55 --> URI Class Initialized
DEBUG - 2014-08-13 13:56:55 --> Router Class Initialized
DEBUG - 2014-08-13 13:56:55 --> Output Class Initialized
DEBUG - 2014-08-13 13:56:55 --> Security Class Initialized
DEBUG - 2014-08-13 13:56:55 --> Input Class Initialized
DEBUG - 2014-08-13 13:56:55 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:55 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:55 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:55 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:55 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:55 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:55 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:55 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:55 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:55 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:55 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:55 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:55 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:55 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:55 --> CRSF cookie Set
DEBUG - 2014-08-13 13:56:55 --> CSRF token verified
DEBUG - 2014-08-13 13:56:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 13:56:55 --> Language Class Initialized
DEBUG - 2014-08-13 13:56:55 --> Loader Class Initialized
DEBUG - 2014-08-13 13:56:55 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 13:56:55 --> Helper loaded: url_helper
DEBUG - 2014-08-13 13:56:55 --> Database Driver Class Initialized
ERROR - 2014-08-13 13:56:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 13:56:55 --> Session Class Initialized
DEBUG - 2014-08-13 13:56:55 --> Helper loaded: string_helper
DEBUG - 2014-08-13 13:56:55 --> Session routines successfully run
DEBUG - 2014-08-13 13:56:55 --> Controller Class Initialized
DEBUG - 2014-08-13 13:56:55 --> Helper loaded: form_helper
DEBUG - 2014-08-13 13:56:55 --> Form Validation Class Initialized
DEBUG - 2014-08-13 13:56:55 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 13:56:55 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:55 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:55 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:55 --> XSS Filtering completed
DEBUG - 2014-08-13 13:56:55 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 13:56:55 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 13:56:55 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 13:56:55 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 13:56:55 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 13:56:55 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 13:56:55 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 13:56:55 --> Final output sent to browser
DEBUG - 2014-08-13 13:56:55 --> Total execution time: 0.0781
DEBUG - 2014-08-13 13:57:58 --> Config Class Initialized
DEBUG - 2014-08-13 13:57:58 --> Hooks Class Initialized
DEBUG - 2014-08-13 13:57:58 --> Utf8 Class Initialized
DEBUG - 2014-08-13 13:57:58 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 13:57:58 --> URI Class Initialized
DEBUG - 2014-08-13 13:57:58 --> Router Class Initialized
DEBUG - 2014-08-13 13:57:58 --> Output Class Initialized
DEBUG - 2014-08-13 13:57:58 --> Security Class Initialized
DEBUG - 2014-08-13 13:57:58 --> Input Class Initialized
DEBUG - 2014-08-13 13:57:58 --> XSS Filtering completed
DEBUG - 2014-08-13 13:57:58 --> XSS Filtering completed
DEBUG - 2014-08-13 13:57:58 --> XSS Filtering completed
DEBUG - 2014-08-13 13:57:58 --> XSS Filtering completed
DEBUG - 2014-08-13 13:57:58 --> XSS Filtering completed
DEBUG - 2014-08-13 13:57:58 --> XSS Filtering completed
DEBUG - 2014-08-13 13:57:58 --> XSS Filtering completed
DEBUG - 2014-08-13 13:57:58 --> XSS Filtering completed
DEBUG - 2014-08-13 13:57:58 --> XSS Filtering completed
DEBUG - 2014-08-13 13:57:58 --> XSS Filtering completed
DEBUG - 2014-08-13 13:57:58 --> XSS Filtering completed
DEBUG - 2014-08-13 13:57:58 --> XSS Filtering completed
DEBUG - 2014-08-13 13:57:58 --> XSS Filtering completed
DEBUG - 2014-08-13 13:57:58 --> XSS Filtering completed
DEBUG - 2014-08-13 13:57:58 --> CRSF cookie Set
DEBUG - 2014-08-13 13:57:58 --> CSRF token verified
DEBUG - 2014-08-13 13:57:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 13:57:58 --> Language Class Initialized
DEBUG - 2014-08-13 13:57:58 --> Loader Class Initialized
DEBUG - 2014-08-13 13:57:58 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 13:57:58 --> Helper loaded: url_helper
DEBUG - 2014-08-13 13:57:58 --> Database Driver Class Initialized
ERROR - 2014-08-13 13:57:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 13:57:58 --> Session Class Initialized
DEBUG - 2014-08-13 13:57:58 --> Helper loaded: string_helper
DEBUG - 2014-08-13 13:57:58 --> Session routines successfully run
DEBUG - 2014-08-13 13:57:58 --> Controller Class Initialized
DEBUG - 2014-08-13 13:57:58 --> Helper loaded: form_helper
DEBUG - 2014-08-13 13:57:58 --> Form Validation Class Initialized
DEBUG - 2014-08-13 13:57:58 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 13:57:58 --> XSS Filtering completed
DEBUG - 2014-08-13 13:57:58 --> XSS Filtering completed
DEBUG - 2014-08-13 13:57:58 --> XSS Filtering completed
DEBUG - 2014-08-13 13:57:58 --> XSS Filtering completed
DEBUG - 2014-08-13 13:57:58 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 13:57:58 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 13:57:58 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 13:57:58 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 13:57:58 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 13:57:58 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 13:57:58 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 13:57:58 --> Final output sent to browser
DEBUG - 2014-08-13 13:57:58 --> Total execution time: 0.0761
DEBUG - 2014-08-13 13:59:49 --> Config Class Initialized
DEBUG - 2014-08-13 13:59:49 --> Hooks Class Initialized
DEBUG - 2014-08-13 13:59:49 --> Utf8 Class Initialized
DEBUG - 2014-08-13 13:59:49 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 13:59:49 --> URI Class Initialized
DEBUG - 2014-08-13 13:59:49 --> Router Class Initialized
DEBUG - 2014-08-13 13:59:49 --> Output Class Initialized
DEBUG - 2014-08-13 13:59:49 --> Security Class Initialized
DEBUG - 2014-08-13 13:59:49 --> Input Class Initialized
DEBUG - 2014-08-13 13:59:49 --> XSS Filtering completed
DEBUG - 2014-08-13 13:59:49 --> XSS Filtering completed
DEBUG - 2014-08-13 13:59:49 --> XSS Filtering completed
DEBUG - 2014-08-13 13:59:49 --> XSS Filtering completed
DEBUG - 2014-08-13 13:59:49 --> XSS Filtering completed
DEBUG - 2014-08-13 13:59:49 --> XSS Filtering completed
DEBUG - 2014-08-13 13:59:49 --> XSS Filtering completed
DEBUG - 2014-08-13 13:59:49 --> XSS Filtering completed
DEBUG - 2014-08-13 13:59:49 --> XSS Filtering completed
DEBUG - 2014-08-13 13:59:49 --> XSS Filtering completed
DEBUG - 2014-08-13 13:59:49 --> XSS Filtering completed
DEBUG - 2014-08-13 13:59:49 --> XSS Filtering completed
DEBUG - 2014-08-13 13:59:49 --> XSS Filtering completed
DEBUG - 2014-08-13 13:59:49 --> XSS Filtering completed
DEBUG - 2014-08-13 13:59:49 --> CRSF cookie Set
DEBUG - 2014-08-13 13:59:49 --> CSRF token verified
DEBUG - 2014-08-13 13:59:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 13:59:49 --> Language Class Initialized
DEBUG - 2014-08-13 13:59:49 --> Loader Class Initialized
DEBUG - 2014-08-13 13:59:49 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 13:59:49 --> Helper loaded: url_helper
DEBUG - 2014-08-13 13:59:49 --> Database Driver Class Initialized
ERROR - 2014-08-13 13:59:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 13:59:49 --> Session Class Initialized
DEBUG - 2014-08-13 13:59:49 --> Helper loaded: string_helper
DEBUG - 2014-08-13 13:59:49 --> Session routines successfully run
DEBUG - 2014-08-13 13:59:49 --> Controller Class Initialized
DEBUG - 2014-08-13 13:59:49 --> Helper loaded: form_helper
DEBUG - 2014-08-13 13:59:49 --> Form Validation Class Initialized
DEBUG - 2014-08-13 13:59:49 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 13:59:49 --> XSS Filtering completed
DEBUG - 2014-08-13 13:59:49 --> XSS Filtering completed
DEBUG - 2014-08-13 13:59:49 --> XSS Filtering completed
DEBUG - 2014-08-13 13:59:49 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 13:59:49 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 13:59:49 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 13:59:49 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 13:59:49 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 13:59:49 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 13:59:49 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 13:59:49 --> Final output sent to browser
DEBUG - 2014-08-13 13:59:49 --> Total execution time: 0.0735
DEBUG - 2014-08-13 14:01:21 --> Config Class Initialized
DEBUG - 2014-08-13 14:01:21 --> Hooks Class Initialized
DEBUG - 2014-08-13 14:01:21 --> Utf8 Class Initialized
DEBUG - 2014-08-13 14:01:21 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 14:01:21 --> URI Class Initialized
DEBUG - 2014-08-13 14:01:21 --> Router Class Initialized
DEBUG - 2014-08-13 14:01:21 --> Output Class Initialized
DEBUG - 2014-08-13 14:01:21 --> Security Class Initialized
DEBUG - 2014-08-13 14:01:21 --> Input Class Initialized
DEBUG - 2014-08-13 14:01:21 --> XSS Filtering completed
DEBUG - 2014-08-13 14:01:21 --> XSS Filtering completed
DEBUG - 2014-08-13 14:01:21 --> XSS Filtering completed
DEBUG - 2014-08-13 14:01:21 --> XSS Filtering completed
DEBUG - 2014-08-13 14:01:21 --> XSS Filtering completed
DEBUG - 2014-08-13 14:01:21 --> XSS Filtering completed
DEBUG - 2014-08-13 14:01:21 --> XSS Filtering completed
DEBUG - 2014-08-13 14:01:21 --> XSS Filtering completed
DEBUG - 2014-08-13 14:01:21 --> XSS Filtering completed
DEBUG - 2014-08-13 14:01:21 --> XSS Filtering completed
DEBUG - 2014-08-13 14:01:21 --> XSS Filtering completed
DEBUG - 2014-08-13 14:01:21 --> XSS Filtering completed
DEBUG - 2014-08-13 14:01:21 --> XSS Filtering completed
DEBUG - 2014-08-13 14:01:21 --> XSS Filtering completed
DEBUG - 2014-08-13 14:01:21 --> CRSF cookie Set
DEBUG - 2014-08-13 14:01:21 --> CSRF token verified
DEBUG - 2014-08-13 14:01:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 14:01:21 --> Language Class Initialized
DEBUG - 2014-08-13 14:01:21 --> Loader Class Initialized
DEBUG - 2014-08-13 14:01:21 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 14:01:21 --> Helper loaded: url_helper
DEBUG - 2014-08-13 14:01:21 --> Database Driver Class Initialized
ERROR - 2014-08-13 14:01:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 14:01:21 --> Session Class Initialized
DEBUG - 2014-08-13 14:01:21 --> Helper loaded: string_helper
DEBUG - 2014-08-13 14:01:21 --> Session routines successfully run
DEBUG - 2014-08-13 14:01:21 --> Controller Class Initialized
DEBUG - 2014-08-13 14:01:21 --> Helper loaded: form_helper
DEBUG - 2014-08-13 14:01:21 --> Form Validation Class Initialized
DEBUG - 2014-08-13 14:01:21 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 14:01:21 --> XSS Filtering completed
DEBUG - 2014-08-13 14:01:21 --> XSS Filtering completed
DEBUG - 2014-08-13 14:01:21 --> XSS Filtering completed
DEBUG - 2014-08-13 14:01:21 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 14:01:21 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 14:01:21 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 14:01:21 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 14:01:21 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 14:01:21 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 14:01:21 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 14:01:21 --> Final output sent to browser
DEBUG - 2014-08-13 14:01:21 --> Total execution time: 0.0724
DEBUG - 2014-08-13 14:02:37 --> Config Class Initialized
DEBUG - 2014-08-13 14:02:37 --> Hooks Class Initialized
DEBUG - 2014-08-13 14:02:37 --> Utf8 Class Initialized
DEBUG - 2014-08-13 14:02:37 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 14:02:37 --> URI Class Initialized
DEBUG - 2014-08-13 14:02:37 --> Router Class Initialized
DEBUG - 2014-08-13 14:02:37 --> Output Class Initialized
DEBUG - 2014-08-13 14:02:37 --> Security Class Initialized
DEBUG - 2014-08-13 14:02:37 --> Input Class Initialized
DEBUG - 2014-08-13 14:02:37 --> XSS Filtering completed
DEBUG - 2014-08-13 14:02:37 --> XSS Filtering completed
DEBUG - 2014-08-13 14:02:37 --> XSS Filtering completed
DEBUG - 2014-08-13 14:02:37 --> XSS Filtering completed
DEBUG - 2014-08-13 14:02:37 --> XSS Filtering completed
DEBUG - 2014-08-13 14:02:37 --> XSS Filtering completed
DEBUG - 2014-08-13 14:02:37 --> XSS Filtering completed
DEBUG - 2014-08-13 14:02:37 --> XSS Filtering completed
DEBUG - 2014-08-13 14:02:37 --> XSS Filtering completed
DEBUG - 2014-08-13 14:02:37 --> XSS Filtering completed
DEBUG - 2014-08-13 14:02:37 --> XSS Filtering completed
DEBUG - 2014-08-13 14:02:37 --> XSS Filtering completed
DEBUG - 2014-08-13 14:02:37 --> XSS Filtering completed
DEBUG - 2014-08-13 14:02:37 --> XSS Filtering completed
DEBUG - 2014-08-13 14:02:37 --> CRSF cookie Set
DEBUG - 2014-08-13 14:02:37 --> CSRF token verified
DEBUG - 2014-08-13 14:02:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 14:02:37 --> Language Class Initialized
DEBUG - 2014-08-13 14:02:37 --> Loader Class Initialized
DEBUG - 2014-08-13 14:02:37 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 14:02:37 --> Helper loaded: url_helper
DEBUG - 2014-08-13 14:02:37 --> Database Driver Class Initialized
ERROR - 2014-08-13 14:02:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 14:02:37 --> Session Class Initialized
DEBUG - 2014-08-13 14:02:37 --> Helper loaded: string_helper
DEBUG - 2014-08-13 14:02:37 --> Session routines successfully run
DEBUG - 2014-08-13 14:02:37 --> Controller Class Initialized
DEBUG - 2014-08-13 14:02:37 --> Helper loaded: form_helper
DEBUG - 2014-08-13 14:02:37 --> Form Validation Class Initialized
DEBUG - 2014-08-13 14:02:37 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2014-08-13 14:02:37 --> Could not find the language line "is_unique"
ERROR - 2014-08-13 14:02:37 --> Could not find the language line "is_unique"
DEBUG - 2014-08-13 14:02:37 --> XSS Filtering completed
DEBUG - 2014-08-13 14:02:37 --> XSS Filtering completed
DEBUG - 2014-08-13 14:02:37 --> XSS Filtering completed
DEBUG - 2014-08-13 14:02:37 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 14:02:37 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 14:02:37 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 14:02:37 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 14:02:37 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 14:02:37 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 14:02:37 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 14:02:37 --> Final output sent to browser
DEBUG - 2014-08-13 14:02:37 --> Total execution time: 0.0744
DEBUG - 2014-08-13 14:05:46 --> Config Class Initialized
DEBUG - 2014-08-13 14:05:46 --> Hooks Class Initialized
DEBUG - 2014-08-13 14:05:46 --> Utf8 Class Initialized
DEBUG - 2014-08-13 14:05:46 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 14:05:46 --> URI Class Initialized
DEBUG - 2014-08-13 14:05:46 --> Router Class Initialized
DEBUG - 2014-08-13 14:05:46 --> Output Class Initialized
DEBUG - 2014-08-13 14:05:46 --> Security Class Initialized
DEBUG - 2014-08-13 14:05:46 --> Input Class Initialized
DEBUG - 2014-08-13 14:05:46 --> XSS Filtering completed
DEBUG - 2014-08-13 14:05:46 --> XSS Filtering completed
DEBUG - 2014-08-13 14:05:46 --> XSS Filtering completed
DEBUG - 2014-08-13 14:05:46 --> XSS Filtering completed
DEBUG - 2014-08-13 14:05:46 --> XSS Filtering completed
DEBUG - 2014-08-13 14:05:46 --> XSS Filtering completed
DEBUG - 2014-08-13 14:05:46 --> XSS Filtering completed
DEBUG - 2014-08-13 14:05:46 --> XSS Filtering completed
DEBUG - 2014-08-13 14:05:46 --> XSS Filtering completed
DEBUG - 2014-08-13 14:05:46 --> XSS Filtering completed
DEBUG - 2014-08-13 14:05:46 --> XSS Filtering completed
DEBUG - 2014-08-13 14:05:46 --> XSS Filtering completed
DEBUG - 2014-08-13 14:05:46 --> XSS Filtering completed
DEBUG - 2014-08-13 14:05:46 --> XSS Filtering completed
DEBUG - 2014-08-13 14:05:46 --> CRSF cookie Set
DEBUG - 2014-08-13 14:05:46 --> CSRF token verified
DEBUG - 2014-08-13 14:05:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 14:05:46 --> Language Class Initialized
DEBUG - 2014-08-13 14:05:46 --> Loader Class Initialized
DEBUG - 2014-08-13 14:05:46 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 14:05:46 --> Helper loaded: url_helper
DEBUG - 2014-08-13 14:05:46 --> Database Driver Class Initialized
ERROR - 2014-08-13 14:05:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 14:05:46 --> Session Class Initialized
DEBUG - 2014-08-13 14:05:46 --> Helper loaded: string_helper
DEBUG - 2014-08-13 14:05:46 --> Session routines successfully run
DEBUG - 2014-08-13 14:05:46 --> Controller Class Initialized
DEBUG - 2014-08-13 14:05:46 --> Helper loaded: form_helper
DEBUG - 2014-08-13 14:05:46 --> Form Validation Class Initialized
DEBUG - 2014-08-13 14:05:46 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2014-08-13 14:05:46 --> Could not find the language line "is_unique"
ERROR - 2014-08-13 14:05:46 --> Could not find the language line "is_unique"
DEBUG - 2014-08-13 14:05:46 --> XSS Filtering completed
DEBUG - 2014-08-13 14:05:46 --> XSS Filtering completed
DEBUG - 2014-08-13 14:05:46 --> XSS Filtering completed
DEBUG - 2014-08-13 14:05:46 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 14:05:46 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 14:05:46 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 14:05:46 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 14:05:46 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 14:05:46 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 14:05:46 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 14:05:46 --> Final output sent to browser
DEBUG - 2014-08-13 14:05:46 --> Total execution time: 0.0727
DEBUG - 2014-08-13 14:10:04 --> Config Class Initialized
DEBUG - 2014-08-13 14:10:04 --> Hooks Class Initialized
DEBUG - 2014-08-13 14:10:04 --> Utf8 Class Initialized
DEBUG - 2014-08-13 14:10:04 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 14:10:04 --> URI Class Initialized
DEBUG - 2014-08-13 14:10:04 --> Router Class Initialized
DEBUG - 2014-08-13 14:10:04 --> Output Class Initialized
DEBUG - 2014-08-13 14:10:04 --> Security Class Initialized
DEBUG - 2014-08-13 14:10:04 --> Input Class Initialized
DEBUG - 2014-08-13 14:10:04 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:04 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:04 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:04 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:04 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:04 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:04 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:04 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:04 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:04 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:04 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:04 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:04 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:04 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:04 --> CRSF cookie Set
DEBUG - 2014-08-13 14:10:04 --> CSRF token verified
DEBUG - 2014-08-13 14:10:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 14:10:04 --> Language Class Initialized
DEBUG - 2014-08-13 14:10:04 --> Loader Class Initialized
DEBUG - 2014-08-13 14:10:04 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 14:10:04 --> Helper loaded: url_helper
DEBUG - 2014-08-13 14:10:04 --> Database Driver Class Initialized
ERROR - 2014-08-13 14:10:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 14:10:04 --> Session Class Initialized
DEBUG - 2014-08-13 14:10:04 --> Helper loaded: string_helper
DEBUG - 2014-08-13 14:10:04 --> Session routines successfully run
DEBUG - 2014-08-13 14:10:04 --> Controller Class Initialized
DEBUG - 2014-08-13 14:10:04 --> Helper loaded: form_helper
DEBUG - 2014-08-13 14:10:04 --> Form Validation Class Initialized
DEBUG - 2014-08-13 14:10:04 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2014-08-13 14:10:04 --> Could not find the language line "is_unique"
ERROR - 2014-08-13 14:10:04 --> Could not find the language line "is_unique"
DEBUG - 2014-08-13 14:10:04 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:04 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:04 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:04 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 14:10:04 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 14:10:04 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 14:10:04 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 14:10:04 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 14:10:04 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 14:10:04 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 14:10:04 --> Final output sent to browser
DEBUG - 2014-08-13 14:10:04 --> Total execution time: 0.0758
DEBUG - 2014-08-13 14:10:33 --> Config Class Initialized
DEBUG - 2014-08-13 14:10:33 --> Hooks Class Initialized
DEBUG - 2014-08-13 14:10:33 --> Utf8 Class Initialized
DEBUG - 2014-08-13 14:10:33 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 14:10:33 --> URI Class Initialized
DEBUG - 2014-08-13 14:10:33 --> Router Class Initialized
DEBUG - 2014-08-13 14:10:33 --> Output Class Initialized
DEBUG - 2014-08-13 14:10:33 --> Security Class Initialized
DEBUG - 2014-08-13 14:10:33 --> Input Class Initialized
DEBUG - 2014-08-13 14:10:33 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:33 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:33 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:33 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:33 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:33 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:33 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:33 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:33 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:33 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:33 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:33 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:33 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:33 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:33 --> CRSF cookie Set
DEBUG - 2014-08-13 14:10:33 --> CSRF token verified
DEBUG - 2014-08-13 14:10:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 14:10:33 --> Language Class Initialized
DEBUG - 2014-08-13 14:10:33 --> Loader Class Initialized
DEBUG - 2014-08-13 14:10:33 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 14:10:33 --> Helper loaded: url_helper
DEBUG - 2014-08-13 14:10:33 --> Database Driver Class Initialized
ERROR - 2014-08-13 14:10:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 14:10:33 --> Session Class Initialized
DEBUG - 2014-08-13 14:10:33 --> Helper loaded: string_helper
DEBUG - 2014-08-13 14:10:33 --> Session routines successfully run
DEBUG - 2014-08-13 14:10:33 --> Controller Class Initialized
DEBUG - 2014-08-13 14:10:33 --> Helper loaded: form_helper
DEBUG - 2014-08-13 14:10:33 --> Form Validation Class Initialized
DEBUG - 2014-08-13 14:10:33 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2014-08-13 14:10:33 --> Could not find the language line "is_unique"
ERROR - 2014-08-13 14:10:33 --> Could not find the language line "is_unique"
DEBUG - 2014-08-13 14:10:33 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:33 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:33 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:33 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 14:10:33 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 14:10:33 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 14:10:33 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 14:10:33 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 14:10:33 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 14:10:33 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 14:10:33 --> Final output sent to browser
DEBUG - 2014-08-13 14:10:33 --> Total execution time: 0.0722
DEBUG - 2014-08-13 14:10:39 --> Config Class Initialized
DEBUG - 2014-08-13 14:10:39 --> Hooks Class Initialized
DEBUG - 2014-08-13 14:10:39 --> Utf8 Class Initialized
DEBUG - 2014-08-13 14:10:39 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 14:10:39 --> URI Class Initialized
DEBUG - 2014-08-13 14:10:39 --> Router Class Initialized
DEBUG - 2014-08-13 14:10:39 --> Output Class Initialized
DEBUG - 2014-08-13 14:10:39 --> Security Class Initialized
DEBUG - 2014-08-13 14:10:39 --> Input Class Initialized
DEBUG - 2014-08-13 14:10:39 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:39 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:39 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:39 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:39 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:39 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:39 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:39 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:39 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:39 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:39 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:39 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:39 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:39 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:39 --> CRSF cookie Set
DEBUG - 2014-08-13 14:10:39 --> CSRF token verified
DEBUG - 2014-08-13 14:10:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 14:10:39 --> Language Class Initialized
DEBUG - 2014-08-13 14:10:39 --> Loader Class Initialized
DEBUG - 2014-08-13 14:10:39 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 14:10:39 --> Helper loaded: url_helper
DEBUG - 2014-08-13 14:10:39 --> Database Driver Class Initialized
ERROR - 2014-08-13 14:10:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 14:10:39 --> Session Class Initialized
DEBUG - 2014-08-13 14:10:39 --> Helper loaded: string_helper
DEBUG - 2014-08-13 14:10:39 --> Session routines successfully run
DEBUG - 2014-08-13 14:10:39 --> Controller Class Initialized
DEBUG - 2014-08-13 14:10:39 --> Helper loaded: form_helper
DEBUG - 2014-08-13 14:10:39 --> Form Validation Class Initialized
DEBUG - 2014-08-13 14:10:39 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2014-08-13 14:10:39 --> Could not find the language line "is_unique"
DEBUG - 2014-08-13 14:10:39 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:39 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:39 --> XSS Filtering completed
DEBUG - 2014-08-13 14:10:39 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 14:10:39 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 14:10:39 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 14:10:39 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 14:10:39 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 14:10:39 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 14:10:39 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 14:10:39 --> Final output sent to browser
DEBUG - 2014-08-13 14:10:39 --> Total execution time: 0.0734
DEBUG - 2014-08-13 14:11:42 --> Config Class Initialized
DEBUG - 2014-08-13 14:11:42 --> Hooks Class Initialized
DEBUG - 2014-08-13 14:11:42 --> Utf8 Class Initialized
DEBUG - 2014-08-13 14:11:42 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 14:11:42 --> URI Class Initialized
DEBUG - 2014-08-13 14:11:42 --> Router Class Initialized
DEBUG - 2014-08-13 14:11:42 --> Output Class Initialized
DEBUG - 2014-08-13 14:11:42 --> Security Class Initialized
DEBUG - 2014-08-13 14:11:42 --> Input Class Initialized
DEBUG - 2014-08-13 14:11:42 --> XSS Filtering completed
DEBUG - 2014-08-13 14:11:42 --> XSS Filtering completed
DEBUG - 2014-08-13 14:11:42 --> XSS Filtering completed
DEBUG - 2014-08-13 14:11:42 --> XSS Filtering completed
DEBUG - 2014-08-13 14:11:42 --> XSS Filtering completed
DEBUG - 2014-08-13 14:11:42 --> XSS Filtering completed
DEBUG - 2014-08-13 14:11:42 --> XSS Filtering completed
DEBUG - 2014-08-13 14:11:42 --> XSS Filtering completed
DEBUG - 2014-08-13 14:11:42 --> XSS Filtering completed
DEBUG - 2014-08-13 14:11:42 --> XSS Filtering completed
DEBUG - 2014-08-13 14:11:42 --> XSS Filtering completed
DEBUG - 2014-08-13 14:11:42 --> XSS Filtering completed
DEBUG - 2014-08-13 14:11:42 --> XSS Filtering completed
DEBUG - 2014-08-13 14:11:42 --> XSS Filtering completed
DEBUG - 2014-08-13 14:11:42 --> CRSF cookie Set
DEBUG - 2014-08-13 14:11:42 --> CSRF token verified
DEBUG - 2014-08-13 14:11:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 14:11:42 --> Language Class Initialized
DEBUG - 2014-08-13 14:11:42 --> Loader Class Initialized
DEBUG - 2014-08-13 14:11:42 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 14:11:42 --> Helper loaded: url_helper
DEBUG - 2014-08-13 14:11:42 --> Database Driver Class Initialized
ERROR - 2014-08-13 14:11:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 14:11:42 --> Session Class Initialized
DEBUG - 2014-08-13 14:11:42 --> Helper loaded: string_helper
DEBUG - 2014-08-13 14:11:42 --> Session routines successfully run
DEBUG - 2014-08-13 14:11:42 --> Controller Class Initialized
DEBUG - 2014-08-13 14:11:42 --> Helper loaded: form_helper
DEBUG - 2014-08-13 14:11:42 --> Form Validation Class Initialized
DEBUG - 2014-08-13 14:11:42 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2014-08-13 14:11:42 --> Could not find the language line "is_unique"
DEBUG - 2014-08-13 14:11:42 --> XSS Filtering completed
DEBUG - 2014-08-13 14:11:42 --> XSS Filtering completed
DEBUG - 2014-08-13 14:11:42 --> XSS Filtering completed
DEBUG - 2014-08-13 14:11:42 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 14:11:42 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 14:11:42 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 14:11:42 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 14:11:42 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 14:11:42 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 14:11:42 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 14:11:42 --> Final output sent to browser
DEBUG - 2014-08-13 14:11:42 --> Total execution time: 0.0744
DEBUG - 2014-08-13 14:23:38 --> Config Class Initialized
DEBUG - 2014-08-13 14:23:38 --> Hooks Class Initialized
DEBUG - 2014-08-13 14:23:38 --> Utf8 Class Initialized
DEBUG - 2014-08-13 14:23:38 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 14:23:38 --> URI Class Initialized
DEBUG - 2014-08-13 14:23:38 --> Router Class Initialized
DEBUG - 2014-08-13 14:23:38 --> Output Class Initialized
DEBUG - 2014-08-13 14:23:38 --> Security Class Initialized
DEBUG - 2014-08-13 14:23:38 --> Input Class Initialized
DEBUG - 2014-08-13 14:23:38 --> XSS Filtering completed
DEBUG - 2014-08-13 14:23:38 --> XSS Filtering completed
DEBUG - 2014-08-13 14:23:38 --> XSS Filtering completed
DEBUG - 2014-08-13 14:23:38 --> XSS Filtering completed
DEBUG - 2014-08-13 14:23:38 --> XSS Filtering completed
DEBUG - 2014-08-13 14:23:38 --> XSS Filtering completed
DEBUG - 2014-08-13 14:23:38 --> XSS Filtering completed
DEBUG - 2014-08-13 14:23:38 --> XSS Filtering completed
DEBUG - 2014-08-13 14:23:38 --> XSS Filtering completed
DEBUG - 2014-08-13 14:23:38 --> XSS Filtering completed
DEBUG - 2014-08-13 14:23:38 --> XSS Filtering completed
DEBUG - 2014-08-13 14:23:38 --> XSS Filtering completed
DEBUG - 2014-08-13 14:23:38 --> XSS Filtering completed
DEBUG - 2014-08-13 14:23:38 --> XSS Filtering completed
DEBUG - 2014-08-13 14:23:38 --> CRSF cookie Set
DEBUG - 2014-08-13 14:23:38 --> CSRF token verified
DEBUG - 2014-08-13 14:23:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 14:23:38 --> Language Class Initialized
DEBUG - 2014-08-13 14:23:38 --> Loader Class Initialized
DEBUG - 2014-08-13 14:23:38 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 14:23:38 --> Helper loaded: url_helper
DEBUG - 2014-08-13 14:23:38 --> Database Driver Class Initialized
ERROR - 2014-08-13 14:23:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 14:23:38 --> Session Class Initialized
DEBUG - 2014-08-13 14:23:38 --> Helper loaded: string_helper
DEBUG - 2014-08-13 14:23:38 --> Session routines successfully run
DEBUG - 2014-08-13 14:23:38 --> Controller Class Initialized
DEBUG - 2014-08-13 14:23:38 --> Helper loaded: form_helper
DEBUG - 2014-08-13 14:23:38 --> Form Validation Class Initialized
DEBUG - 2014-08-13 14:23:38 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2014-08-13 14:23:38 --> Could not find the language line "is_unique"
DEBUG - 2014-08-13 14:23:38 --> XSS Filtering completed
DEBUG - 2014-08-13 14:23:38 --> XSS Filtering completed
DEBUG - 2014-08-13 14:23:38 --> XSS Filtering completed
DEBUG - 2014-08-13 14:23:38 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 14:23:38 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 14:23:38 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 14:23:38 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 14:23:38 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 14:23:38 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 14:23:38 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 14:23:38 --> Final output sent to browser
DEBUG - 2014-08-13 14:23:38 --> Total execution time: 0.0770
DEBUG - 2014-08-13 14:30:50 --> Config Class Initialized
DEBUG - 2014-08-13 14:30:50 --> Hooks Class Initialized
DEBUG - 2014-08-13 14:30:50 --> Utf8 Class Initialized
DEBUG - 2014-08-13 14:30:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 14:30:50 --> URI Class Initialized
DEBUG - 2014-08-13 14:30:50 --> Router Class Initialized
DEBUG - 2014-08-13 14:30:50 --> Output Class Initialized
DEBUG - 2014-08-13 14:30:50 --> Security Class Initialized
DEBUG - 2014-08-13 14:30:50 --> Input Class Initialized
DEBUG - 2014-08-13 14:30:50 --> XSS Filtering completed
DEBUG - 2014-08-13 14:30:50 --> XSS Filtering completed
DEBUG - 2014-08-13 14:30:50 --> XSS Filtering completed
DEBUG - 2014-08-13 14:30:50 --> XSS Filtering completed
DEBUG - 2014-08-13 14:30:50 --> XSS Filtering completed
DEBUG - 2014-08-13 14:30:50 --> XSS Filtering completed
DEBUG - 2014-08-13 14:30:50 --> XSS Filtering completed
DEBUG - 2014-08-13 14:30:50 --> XSS Filtering completed
DEBUG - 2014-08-13 14:30:50 --> XSS Filtering completed
DEBUG - 2014-08-13 14:30:50 --> XSS Filtering completed
DEBUG - 2014-08-13 14:30:50 --> XSS Filtering completed
DEBUG - 2014-08-13 14:30:50 --> XSS Filtering completed
DEBUG - 2014-08-13 14:30:50 --> XSS Filtering completed
DEBUG - 2014-08-13 14:30:50 --> XSS Filtering completed
DEBUG - 2014-08-13 14:30:50 --> CRSF cookie Set
DEBUG - 2014-08-13 14:30:50 --> CSRF token verified
DEBUG - 2014-08-13 14:30:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 14:30:50 --> Language Class Initialized
DEBUG - 2014-08-13 14:30:50 --> Loader Class Initialized
DEBUG - 2014-08-13 14:30:50 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 14:30:50 --> Helper loaded: url_helper
DEBUG - 2014-08-13 14:30:50 --> Database Driver Class Initialized
ERROR - 2014-08-13 14:30:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 14:30:50 --> Session Class Initialized
DEBUG - 2014-08-13 14:30:50 --> Helper loaded: string_helper
DEBUG - 2014-08-13 14:30:50 --> Session routines successfully run
DEBUG - 2014-08-13 14:30:50 --> Controller Class Initialized
DEBUG - 2014-08-13 14:30:50 --> Helper loaded: form_helper
DEBUG - 2014-08-13 14:30:50 --> Form Validation Class Initialized
DEBUG - 2014-08-13 14:30:50 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2014-08-13 14:30:50 --> Could not find the language line "is_unique"
DEBUG - 2014-08-13 14:30:50 --> XSS Filtering completed
DEBUG - 2014-08-13 14:30:50 --> XSS Filtering completed
DEBUG - 2014-08-13 14:30:50 --> XSS Filtering completed
DEBUG - 2014-08-13 14:30:50 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 14:30:50 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 14:30:50 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 14:30:50 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 14:30:50 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 14:30:50 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 14:30:50 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 14:30:50 --> Final output sent to browser
DEBUG - 2014-08-13 14:30:50 --> Total execution time: 0.0768
DEBUG - 2014-08-13 14:31:17 --> Config Class Initialized
DEBUG - 2014-08-13 14:31:17 --> Hooks Class Initialized
DEBUG - 2014-08-13 14:31:17 --> Utf8 Class Initialized
DEBUG - 2014-08-13 14:31:17 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 14:31:17 --> URI Class Initialized
DEBUG - 2014-08-13 14:31:17 --> Router Class Initialized
DEBUG - 2014-08-13 14:31:17 --> Output Class Initialized
DEBUG - 2014-08-13 14:31:17 --> Security Class Initialized
DEBUG - 2014-08-13 14:31:17 --> Input Class Initialized
DEBUG - 2014-08-13 14:31:17 --> XSS Filtering completed
DEBUG - 2014-08-13 14:31:17 --> XSS Filtering completed
DEBUG - 2014-08-13 14:31:17 --> XSS Filtering completed
DEBUG - 2014-08-13 14:31:17 --> XSS Filtering completed
DEBUG - 2014-08-13 14:31:17 --> XSS Filtering completed
DEBUG - 2014-08-13 14:31:17 --> XSS Filtering completed
DEBUG - 2014-08-13 14:31:17 --> XSS Filtering completed
DEBUG - 2014-08-13 14:31:17 --> XSS Filtering completed
DEBUG - 2014-08-13 14:31:17 --> XSS Filtering completed
DEBUG - 2014-08-13 14:31:17 --> XSS Filtering completed
DEBUG - 2014-08-13 14:31:17 --> XSS Filtering completed
DEBUG - 2014-08-13 14:31:17 --> XSS Filtering completed
DEBUG - 2014-08-13 14:31:17 --> XSS Filtering completed
DEBUG - 2014-08-13 14:31:17 --> XSS Filtering completed
DEBUG - 2014-08-13 14:31:17 --> CRSF cookie Set
DEBUG - 2014-08-13 14:31:17 --> CSRF token verified
DEBUG - 2014-08-13 14:31:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 14:31:17 --> Language Class Initialized
DEBUG - 2014-08-13 14:31:17 --> Loader Class Initialized
DEBUG - 2014-08-13 14:31:17 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 14:31:17 --> Helper loaded: url_helper
DEBUG - 2014-08-13 14:31:17 --> Database Driver Class Initialized
ERROR - 2014-08-13 14:31:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 14:31:17 --> Session Class Initialized
DEBUG - 2014-08-13 14:31:17 --> Helper loaded: string_helper
DEBUG - 2014-08-13 14:31:17 --> Session routines successfully run
DEBUG - 2014-08-13 14:31:17 --> Controller Class Initialized
DEBUG - 2014-08-13 14:31:17 --> Helper loaded: form_helper
DEBUG - 2014-08-13 14:31:17 --> Form Validation Class Initialized
DEBUG - 2014-08-13 14:31:17 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2014-08-13 14:31:17 --> Could not find the language line "is_unique"
DEBUG - 2014-08-13 14:31:17 --> XSS Filtering completed
DEBUG - 2014-08-13 14:31:17 --> XSS Filtering completed
DEBUG - 2014-08-13 14:31:17 --> XSS Filtering completed
DEBUG - 2014-08-13 14:31:17 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 14:31:17 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 14:31:17 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 14:31:17 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 14:31:17 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 14:31:17 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 14:31:17 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 14:31:17 --> Final output sent to browser
DEBUG - 2014-08-13 14:31:17 --> Total execution time: 0.0765
DEBUG - 2014-08-13 14:32:29 --> Config Class Initialized
DEBUG - 2014-08-13 14:32:29 --> Hooks Class Initialized
DEBUG - 2014-08-13 14:32:29 --> Utf8 Class Initialized
DEBUG - 2014-08-13 14:32:29 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 14:32:29 --> URI Class Initialized
DEBUG - 2014-08-13 14:32:29 --> Router Class Initialized
DEBUG - 2014-08-13 14:32:29 --> Output Class Initialized
DEBUG - 2014-08-13 14:32:29 --> Security Class Initialized
DEBUG - 2014-08-13 14:32:29 --> Input Class Initialized
DEBUG - 2014-08-13 14:32:29 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:29 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:29 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:29 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:29 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:29 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:29 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:29 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:29 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:29 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:29 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:29 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:29 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:29 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:29 --> CRSF cookie Set
DEBUG - 2014-08-13 14:32:29 --> CSRF token verified
DEBUG - 2014-08-13 14:32:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 14:32:29 --> Language Class Initialized
DEBUG - 2014-08-13 14:32:29 --> Loader Class Initialized
DEBUG - 2014-08-13 14:32:29 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 14:32:29 --> Helper loaded: url_helper
DEBUG - 2014-08-13 14:32:29 --> Database Driver Class Initialized
ERROR - 2014-08-13 14:32:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 14:32:29 --> Session Class Initialized
DEBUG - 2014-08-13 14:32:29 --> Helper loaded: string_helper
DEBUG - 2014-08-13 14:32:29 --> Session routines successfully run
DEBUG - 2014-08-13 14:32:29 --> Controller Class Initialized
DEBUG - 2014-08-13 14:32:29 --> Helper loaded: form_helper
DEBUG - 2014-08-13 14:32:29 --> Form Validation Class Initialized
DEBUG - 2014-08-13 14:32:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 14:32:29 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:29 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:29 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:29 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 14:32:29 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 14:32:29 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 14:32:29 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 14:32:29 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 14:32:29 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 14:32:29 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 14:32:29 --> Final output sent to browser
DEBUG - 2014-08-13 14:32:29 --> Total execution time: 0.0736
DEBUG - 2014-08-13 14:32:43 --> Config Class Initialized
DEBUG - 2014-08-13 14:32:43 --> Hooks Class Initialized
DEBUG - 2014-08-13 14:32:43 --> Utf8 Class Initialized
DEBUG - 2014-08-13 14:32:43 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 14:32:43 --> URI Class Initialized
DEBUG - 2014-08-13 14:32:43 --> Router Class Initialized
DEBUG - 2014-08-13 14:32:43 --> Output Class Initialized
DEBUG - 2014-08-13 14:32:43 --> Security Class Initialized
DEBUG - 2014-08-13 14:32:43 --> Input Class Initialized
DEBUG - 2014-08-13 14:32:43 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:43 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:43 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:43 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:43 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:43 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:43 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:43 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:43 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:43 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:43 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:43 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:43 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:43 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:43 --> CRSF cookie Set
DEBUG - 2014-08-13 14:32:43 --> CSRF token verified
DEBUG - 2014-08-13 14:32:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 14:32:43 --> Language Class Initialized
DEBUG - 2014-08-13 14:32:43 --> Loader Class Initialized
DEBUG - 2014-08-13 14:32:43 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 14:32:43 --> Helper loaded: url_helper
DEBUG - 2014-08-13 14:32:43 --> Database Driver Class Initialized
ERROR - 2014-08-13 14:32:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 14:32:43 --> Session Class Initialized
DEBUG - 2014-08-13 14:32:43 --> Helper loaded: string_helper
DEBUG - 2014-08-13 14:32:43 --> Session routines successfully run
DEBUG - 2014-08-13 14:32:43 --> Controller Class Initialized
DEBUG - 2014-08-13 14:32:43 --> Helper loaded: form_helper
DEBUG - 2014-08-13 14:32:43 --> Form Validation Class Initialized
DEBUG - 2014-08-13 14:32:43 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 14:32:43 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:43 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:43 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:43 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 14:32:43 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 14:32:43 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 14:32:43 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 14:32:43 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 14:32:43 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 14:32:43 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 14:32:43 --> Final output sent to browser
DEBUG - 2014-08-13 14:32:43 --> Total execution time: 0.0905
DEBUG - 2014-08-13 14:32:49 --> Config Class Initialized
DEBUG - 2014-08-13 14:32:49 --> Hooks Class Initialized
DEBUG - 2014-08-13 14:32:49 --> Utf8 Class Initialized
DEBUG - 2014-08-13 14:32:49 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 14:32:49 --> URI Class Initialized
DEBUG - 2014-08-13 14:32:49 --> Router Class Initialized
DEBUG - 2014-08-13 14:32:49 --> Output Class Initialized
DEBUG - 2014-08-13 14:32:49 --> Security Class Initialized
DEBUG - 2014-08-13 14:32:49 --> Input Class Initialized
DEBUG - 2014-08-13 14:32:49 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:49 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:49 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:49 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:49 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:49 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:49 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:49 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:49 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:49 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:49 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:49 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:49 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:49 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:49 --> CRSF cookie Set
DEBUG - 2014-08-13 14:32:49 --> CSRF token verified
DEBUG - 2014-08-13 14:32:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 14:32:49 --> Language Class Initialized
DEBUG - 2014-08-13 14:32:49 --> Loader Class Initialized
DEBUG - 2014-08-13 14:32:49 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 14:32:49 --> Helper loaded: url_helper
DEBUG - 2014-08-13 14:32:49 --> Database Driver Class Initialized
ERROR - 2014-08-13 14:32:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 14:32:49 --> Session Class Initialized
DEBUG - 2014-08-13 14:32:49 --> Helper loaded: string_helper
DEBUG - 2014-08-13 14:32:49 --> Session routines successfully run
DEBUG - 2014-08-13 14:32:49 --> Controller Class Initialized
DEBUG - 2014-08-13 14:32:49 --> Helper loaded: form_helper
DEBUG - 2014-08-13 14:32:49 --> Form Validation Class Initialized
DEBUG - 2014-08-13 14:32:49 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 14:32:49 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:49 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:49 --> XSS Filtering completed
DEBUG - 2014-08-13 14:32:49 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 14:32:49 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 14:32:49 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 14:32:49 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 14:32:49 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 14:32:49 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 14:32:49 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 14:32:49 --> Final output sent to browser
DEBUG - 2014-08-13 14:32:49 --> Total execution time: 0.1169
DEBUG - 2014-08-13 14:34:56 --> Config Class Initialized
DEBUG - 2014-08-13 14:34:56 --> Hooks Class Initialized
DEBUG - 2014-08-13 14:34:56 --> Utf8 Class Initialized
DEBUG - 2014-08-13 14:34:56 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 14:34:56 --> URI Class Initialized
DEBUG - 2014-08-13 14:34:56 --> Router Class Initialized
DEBUG - 2014-08-13 14:34:56 --> Output Class Initialized
DEBUG - 2014-08-13 14:34:56 --> Security Class Initialized
DEBUG - 2014-08-13 14:34:56 --> Input Class Initialized
DEBUG - 2014-08-13 14:34:56 --> XSS Filtering completed
DEBUG - 2014-08-13 14:34:56 --> XSS Filtering completed
DEBUG - 2014-08-13 14:34:56 --> XSS Filtering completed
DEBUG - 2014-08-13 14:34:56 --> XSS Filtering completed
DEBUG - 2014-08-13 14:34:56 --> XSS Filtering completed
DEBUG - 2014-08-13 14:34:56 --> XSS Filtering completed
DEBUG - 2014-08-13 14:34:56 --> XSS Filtering completed
DEBUG - 2014-08-13 14:34:56 --> XSS Filtering completed
DEBUG - 2014-08-13 14:34:56 --> XSS Filtering completed
DEBUG - 2014-08-13 14:34:56 --> XSS Filtering completed
DEBUG - 2014-08-13 14:34:56 --> XSS Filtering completed
DEBUG - 2014-08-13 14:34:56 --> XSS Filtering completed
DEBUG - 2014-08-13 14:34:56 --> XSS Filtering completed
DEBUG - 2014-08-13 14:34:56 --> XSS Filtering completed
DEBUG - 2014-08-13 14:34:56 --> CRSF cookie Set
DEBUG - 2014-08-13 14:34:56 --> CSRF token verified
DEBUG - 2014-08-13 14:34:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 14:34:56 --> Language Class Initialized
DEBUG - 2014-08-13 14:34:56 --> Loader Class Initialized
DEBUG - 2014-08-13 14:34:56 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 14:34:56 --> Helper loaded: url_helper
DEBUG - 2014-08-13 14:34:56 --> Database Driver Class Initialized
ERROR - 2014-08-13 14:34:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 14:34:56 --> Session Class Initialized
DEBUG - 2014-08-13 14:34:56 --> Helper loaded: string_helper
DEBUG - 2014-08-13 14:34:56 --> Session routines successfully run
DEBUG - 2014-08-13 14:34:56 --> Controller Class Initialized
DEBUG - 2014-08-13 14:34:56 --> Helper loaded: form_helper
DEBUG - 2014-08-13 14:34:56 --> Form Validation Class Initialized
DEBUG - 2014-08-13 14:34:56 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 14:34:56 --> XSS Filtering completed
DEBUG - 2014-08-13 14:34:56 --> XSS Filtering completed
DEBUG - 2014-08-13 14:34:56 --> XSS Filtering completed
DEBUG - 2014-08-13 14:34:56 --> XSS Filtering completed
DEBUG - 2014-08-13 14:34:56 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 14:34:56 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 14:34:56 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 14:34:56 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 14:34:56 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 14:34:56 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 14:34:56 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 14:34:56 --> Final output sent to browser
DEBUG - 2014-08-13 14:34:56 --> Total execution time: 0.0758
DEBUG - 2014-08-13 14:36:43 --> Config Class Initialized
DEBUG - 2014-08-13 14:36:43 --> Hooks Class Initialized
DEBUG - 2014-08-13 14:36:43 --> Utf8 Class Initialized
DEBUG - 2014-08-13 14:36:43 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 14:36:43 --> URI Class Initialized
DEBUG - 2014-08-13 14:36:43 --> Router Class Initialized
DEBUG - 2014-08-13 14:36:43 --> Output Class Initialized
DEBUG - 2014-08-13 14:36:43 --> Security Class Initialized
DEBUG - 2014-08-13 14:36:43 --> Input Class Initialized
DEBUG - 2014-08-13 14:36:43 --> XSS Filtering completed
DEBUG - 2014-08-13 14:36:43 --> XSS Filtering completed
DEBUG - 2014-08-13 14:36:43 --> XSS Filtering completed
DEBUG - 2014-08-13 14:36:43 --> XSS Filtering completed
DEBUG - 2014-08-13 14:36:43 --> XSS Filtering completed
DEBUG - 2014-08-13 14:36:43 --> XSS Filtering completed
DEBUG - 2014-08-13 14:36:43 --> XSS Filtering completed
DEBUG - 2014-08-13 14:36:43 --> XSS Filtering completed
DEBUG - 2014-08-13 14:36:43 --> XSS Filtering completed
DEBUG - 2014-08-13 14:36:43 --> XSS Filtering completed
DEBUG - 2014-08-13 14:36:43 --> XSS Filtering completed
DEBUG - 2014-08-13 14:36:43 --> XSS Filtering completed
DEBUG - 2014-08-13 14:36:43 --> XSS Filtering completed
DEBUG - 2014-08-13 14:36:43 --> XSS Filtering completed
DEBUG - 2014-08-13 14:36:43 --> CRSF cookie Set
DEBUG - 2014-08-13 14:36:43 --> CSRF token verified
DEBUG - 2014-08-13 14:36:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 14:36:43 --> Language Class Initialized
DEBUG - 2014-08-13 14:36:43 --> Loader Class Initialized
DEBUG - 2014-08-13 14:36:43 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 14:36:43 --> Helper loaded: url_helper
DEBUG - 2014-08-13 14:36:43 --> Database Driver Class Initialized
ERROR - 2014-08-13 14:36:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 14:36:43 --> Session Class Initialized
DEBUG - 2014-08-13 14:36:43 --> Helper loaded: string_helper
DEBUG - 2014-08-13 14:36:43 --> Session routines successfully run
DEBUG - 2014-08-13 14:36:43 --> Controller Class Initialized
DEBUG - 2014-08-13 14:36:43 --> Helper loaded: form_helper
DEBUG - 2014-08-13 14:36:43 --> Form Validation Class Initialized
DEBUG - 2014-08-13 14:36:43 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 14:36:43 --> XSS Filtering completed
DEBUG - 2014-08-13 14:36:43 --> XSS Filtering completed
DEBUG - 2014-08-13 14:36:43 --> XSS Filtering completed
DEBUG - 2014-08-13 14:36:43 --> XSS Filtering completed
DEBUG - 2014-08-13 14:36:43 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 14:36:43 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 14:36:43 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 14:36:43 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 14:36:43 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 14:36:43 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 14:36:43 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 14:36:43 --> Final output sent to browser
DEBUG - 2014-08-13 14:36:43 --> Total execution time: 0.0749
DEBUG - 2014-08-13 14:50:03 --> Config Class Initialized
DEBUG - 2014-08-13 14:50:03 --> Hooks Class Initialized
DEBUG - 2014-08-13 14:50:03 --> Utf8 Class Initialized
DEBUG - 2014-08-13 14:50:03 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 14:50:03 --> URI Class Initialized
DEBUG - 2014-08-13 14:50:03 --> Router Class Initialized
DEBUG - 2014-08-13 14:50:03 --> Output Class Initialized
DEBUG - 2014-08-13 14:50:03 --> Security Class Initialized
DEBUG - 2014-08-13 14:50:03 --> Input Class Initialized
DEBUG - 2014-08-13 14:50:03 --> XSS Filtering completed
DEBUG - 2014-08-13 14:50:03 --> XSS Filtering completed
DEBUG - 2014-08-13 14:50:03 --> XSS Filtering completed
DEBUG - 2014-08-13 14:50:03 --> XSS Filtering completed
DEBUG - 2014-08-13 14:50:03 --> XSS Filtering completed
DEBUG - 2014-08-13 14:50:03 --> XSS Filtering completed
DEBUG - 2014-08-13 14:50:03 --> XSS Filtering completed
DEBUG - 2014-08-13 14:50:03 --> XSS Filtering completed
DEBUG - 2014-08-13 14:50:03 --> XSS Filtering completed
DEBUG - 2014-08-13 14:50:03 --> XSS Filtering completed
DEBUG - 2014-08-13 14:50:03 --> XSS Filtering completed
DEBUG - 2014-08-13 14:50:03 --> XSS Filtering completed
DEBUG - 2014-08-13 14:50:03 --> XSS Filtering completed
DEBUG - 2014-08-13 14:50:03 --> XSS Filtering completed
DEBUG - 2014-08-13 14:50:03 --> CRSF cookie Set
DEBUG - 2014-08-13 14:50:03 --> CSRF token verified
DEBUG - 2014-08-13 14:50:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 14:50:03 --> Language Class Initialized
DEBUG - 2014-08-13 14:50:03 --> Loader Class Initialized
DEBUG - 2014-08-13 14:50:03 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 14:50:03 --> Helper loaded: url_helper
DEBUG - 2014-08-13 14:50:03 --> Database Driver Class Initialized
ERROR - 2014-08-13 14:50:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 14:50:03 --> Session Class Initialized
DEBUG - 2014-08-13 14:50:03 --> Helper loaded: string_helper
DEBUG - 2014-08-13 14:50:03 --> Session routines successfully run
DEBUG - 2014-08-13 14:50:03 --> Controller Class Initialized
DEBUG - 2014-08-13 14:50:03 --> Helper loaded: form_helper
DEBUG - 2014-08-13 14:50:03 --> Form Validation Class Initialized
DEBUG - 2014-08-13 14:50:03 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 14:50:03 --> XSS Filtering completed
DEBUG - 2014-08-13 14:50:03 --> XSS Filtering completed
DEBUG - 2014-08-13 14:50:03 --> XSS Filtering completed
DEBUG - 2014-08-13 14:50:03 --> XSS Filtering completed
DEBUG - 2014-08-13 14:50:03 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 14:50:03 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 14:50:03 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 14:50:03 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 14:50:03 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 14:50:03 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 14:50:03 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 14:50:03 --> Final output sent to browser
DEBUG - 2014-08-13 14:50:03 --> Total execution time: 0.0757
DEBUG - 2014-08-13 14:50:29 --> Config Class Initialized
DEBUG - 2014-08-13 14:50:29 --> Hooks Class Initialized
DEBUG - 2014-08-13 14:50:29 --> Utf8 Class Initialized
DEBUG - 2014-08-13 14:50:29 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 14:50:29 --> URI Class Initialized
DEBUG - 2014-08-13 14:50:29 --> Router Class Initialized
DEBUG - 2014-08-13 14:50:29 --> Output Class Initialized
DEBUG - 2014-08-13 14:50:29 --> Security Class Initialized
DEBUG - 2014-08-13 14:50:29 --> Input Class Initialized
DEBUG - 2014-08-13 14:50:29 --> XSS Filtering completed
DEBUG - 2014-08-13 14:50:29 --> XSS Filtering completed
DEBUG - 2014-08-13 14:50:29 --> XSS Filtering completed
DEBUG - 2014-08-13 14:50:29 --> XSS Filtering completed
DEBUG - 2014-08-13 14:50:29 --> XSS Filtering completed
DEBUG - 2014-08-13 14:50:29 --> XSS Filtering completed
DEBUG - 2014-08-13 14:50:29 --> XSS Filtering completed
DEBUG - 2014-08-13 14:50:29 --> XSS Filtering completed
DEBUG - 2014-08-13 14:50:29 --> XSS Filtering completed
DEBUG - 2014-08-13 14:50:29 --> XSS Filtering completed
DEBUG - 2014-08-13 14:50:29 --> XSS Filtering completed
DEBUG - 2014-08-13 14:50:29 --> XSS Filtering completed
DEBUG - 2014-08-13 14:50:29 --> XSS Filtering completed
DEBUG - 2014-08-13 14:50:29 --> XSS Filtering completed
DEBUG - 2014-08-13 14:50:29 --> CRSF cookie Set
DEBUG - 2014-08-13 14:50:29 --> CSRF token verified
DEBUG - 2014-08-13 14:50:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 14:50:29 --> Language Class Initialized
DEBUG - 2014-08-13 14:50:29 --> Loader Class Initialized
DEBUG - 2014-08-13 14:50:29 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 14:50:29 --> Helper loaded: url_helper
DEBUG - 2014-08-13 14:50:29 --> Database Driver Class Initialized
ERROR - 2014-08-13 14:50:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 14:50:29 --> Session Class Initialized
DEBUG - 2014-08-13 14:50:29 --> Helper loaded: string_helper
DEBUG - 2014-08-13 14:50:29 --> Session routines successfully run
DEBUG - 2014-08-13 14:50:29 --> Controller Class Initialized
DEBUG - 2014-08-13 14:50:29 --> Helper loaded: form_helper
DEBUG - 2014-08-13 14:50:29 --> Form Validation Class Initialized
DEBUG - 2014-08-13 14:50:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 14:50:29 --> XSS Filtering completed
DEBUG - 2014-08-13 14:50:29 --> XSS Filtering completed
DEBUG - 2014-08-13 14:50:29 --> XSS Filtering completed
DEBUG - 2014-08-13 14:50:29 --> XSS Filtering completed
DEBUG - 2014-08-13 14:50:29 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 14:50:29 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 14:50:29 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 14:50:29 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 14:50:29 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 14:50:29 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 14:50:29 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 14:50:29 --> Final output sent to browser
DEBUG - 2014-08-13 14:50:29 --> Total execution time: 0.0752
DEBUG - 2014-08-13 14:52:27 --> Config Class Initialized
DEBUG - 2014-08-13 14:52:27 --> Hooks Class Initialized
DEBUG - 2014-08-13 14:52:27 --> Utf8 Class Initialized
DEBUG - 2014-08-13 14:52:27 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 14:52:27 --> URI Class Initialized
DEBUG - 2014-08-13 14:52:27 --> Router Class Initialized
DEBUG - 2014-08-13 14:52:27 --> Output Class Initialized
DEBUG - 2014-08-13 14:52:27 --> Security Class Initialized
DEBUG - 2014-08-13 14:52:27 --> Input Class Initialized
DEBUG - 2014-08-13 14:52:27 --> XSS Filtering completed
DEBUG - 2014-08-13 14:52:27 --> XSS Filtering completed
DEBUG - 2014-08-13 14:52:27 --> XSS Filtering completed
DEBUG - 2014-08-13 14:52:27 --> XSS Filtering completed
DEBUG - 2014-08-13 14:52:27 --> XSS Filtering completed
DEBUG - 2014-08-13 14:52:27 --> XSS Filtering completed
DEBUG - 2014-08-13 14:52:27 --> XSS Filtering completed
DEBUG - 2014-08-13 14:52:27 --> XSS Filtering completed
DEBUG - 2014-08-13 14:52:27 --> XSS Filtering completed
DEBUG - 2014-08-13 14:52:27 --> XSS Filtering completed
DEBUG - 2014-08-13 14:52:27 --> XSS Filtering completed
DEBUG - 2014-08-13 14:52:27 --> XSS Filtering completed
DEBUG - 2014-08-13 14:52:27 --> XSS Filtering completed
DEBUG - 2014-08-13 14:52:27 --> XSS Filtering completed
DEBUG - 2014-08-13 14:52:27 --> CRSF cookie Set
DEBUG - 2014-08-13 14:52:27 --> CSRF token verified
DEBUG - 2014-08-13 14:52:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 14:52:27 --> Language Class Initialized
DEBUG - 2014-08-13 14:52:27 --> Loader Class Initialized
DEBUG - 2014-08-13 14:52:27 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 14:52:27 --> Helper loaded: url_helper
DEBUG - 2014-08-13 14:52:27 --> Database Driver Class Initialized
ERROR - 2014-08-13 14:52:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 14:52:27 --> Session Class Initialized
DEBUG - 2014-08-13 14:52:27 --> Helper loaded: string_helper
DEBUG - 2014-08-13 14:52:27 --> Session routines successfully run
DEBUG - 2014-08-13 14:52:27 --> Controller Class Initialized
DEBUG - 2014-08-13 14:53:09 --> Config Class Initialized
DEBUG - 2014-08-13 14:53:09 --> Hooks Class Initialized
DEBUG - 2014-08-13 14:53:09 --> Utf8 Class Initialized
DEBUG - 2014-08-13 14:53:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 14:53:09 --> URI Class Initialized
DEBUG - 2014-08-13 14:53:09 --> Router Class Initialized
DEBUG - 2014-08-13 14:53:09 --> Output Class Initialized
DEBUG - 2014-08-13 14:53:09 --> Security Class Initialized
DEBUG - 2014-08-13 14:53:09 --> Input Class Initialized
DEBUG - 2014-08-13 14:53:09 --> XSS Filtering completed
DEBUG - 2014-08-13 14:53:09 --> XSS Filtering completed
DEBUG - 2014-08-13 14:53:09 --> XSS Filtering completed
DEBUG - 2014-08-13 14:53:09 --> XSS Filtering completed
DEBUG - 2014-08-13 14:53:09 --> XSS Filtering completed
DEBUG - 2014-08-13 14:53:09 --> XSS Filtering completed
DEBUG - 2014-08-13 14:53:09 --> XSS Filtering completed
DEBUG - 2014-08-13 14:53:09 --> XSS Filtering completed
DEBUG - 2014-08-13 14:53:09 --> XSS Filtering completed
DEBUG - 2014-08-13 14:53:09 --> XSS Filtering completed
DEBUG - 2014-08-13 14:53:09 --> XSS Filtering completed
DEBUG - 2014-08-13 14:53:09 --> XSS Filtering completed
DEBUG - 2014-08-13 14:53:09 --> XSS Filtering completed
DEBUG - 2014-08-13 14:53:09 --> XSS Filtering completed
DEBUG - 2014-08-13 14:53:09 --> CRSF cookie Set
DEBUG - 2014-08-13 14:53:09 --> CSRF token verified
DEBUG - 2014-08-13 14:53:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 14:53:09 --> Language Class Initialized
DEBUG - 2014-08-13 14:53:09 --> Loader Class Initialized
DEBUG - 2014-08-13 14:53:09 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 14:53:09 --> Helper loaded: url_helper
DEBUG - 2014-08-13 14:53:09 --> Database Driver Class Initialized
ERROR - 2014-08-13 14:53:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 14:53:09 --> Session Class Initialized
DEBUG - 2014-08-13 14:53:09 --> Helper loaded: string_helper
DEBUG - 2014-08-13 14:53:09 --> Session routines successfully run
DEBUG - 2014-08-13 14:53:09 --> Controller Class Initialized
DEBUG - 2014-08-13 14:53:09 --> Helper loaded: form_helper
DEBUG - 2014-08-13 14:53:09 --> Form Validation Class Initialized
DEBUG - 2014-08-13 14:53:09 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 14:53:09 --> XSS Filtering completed
DEBUG - 2014-08-13 14:53:09 --> XSS Filtering completed
DEBUG - 2014-08-13 14:53:09 --> XSS Filtering completed
DEBUG - 2014-08-13 14:53:09 --> XSS Filtering completed
DEBUG - 2014-08-13 14:53:09 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 14:53:09 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 14:53:09 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 14:53:09 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 14:53:09 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 14:53:09 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 14:53:09 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 14:53:09 --> Final output sent to browser
DEBUG - 2014-08-13 14:53:09 --> Total execution time: 0.1177
DEBUG - 2014-08-13 14:53:13 --> Config Class Initialized
DEBUG - 2014-08-13 14:53:13 --> Hooks Class Initialized
DEBUG - 2014-08-13 14:53:13 --> Utf8 Class Initialized
DEBUG - 2014-08-13 14:53:13 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 14:53:13 --> URI Class Initialized
DEBUG - 2014-08-13 14:53:13 --> Router Class Initialized
DEBUG - 2014-08-13 14:53:13 --> Output Class Initialized
DEBUG - 2014-08-13 14:53:13 --> Security Class Initialized
DEBUG - 2014-08-13 14:53:13 --> Input Class Initialized
DEBUG - 2014-08-13 14:53:13 --> XSS Filtering completed
DEBUG - 2014-08-13 14:53:13 --> XSS Filtering completed
DEBUG - 2014-08-13 14:53:13 --> XSS Filtering completed
DEBUG - 2014-08-13 14:53:13 --> XSS Filtering completed
DEBUG - 2014-08-13 14:53:13 --> XSS Filtering completed
DEBUG - 2014-08-13 14:53:13 --> XSS Filtering completed
DEBUG - 2014-08-13 14:53:13 --> XSS Filtering completed
DEBUG - 2014-08-13 14:53:13 --> XSS Filtering completed
DEBUG - 2014-08-13 14:53:13 --> XSS Filtering completed
DEBUG - 2014-08-13 14:53:13 --> XSS Filtering completed
DEBUG - 2014-08-13 14:53:13 --> XSS Filtering completed
DEBUG - 2014-08-13 14:53:13 --> XSS Filtering completed
DEBUG - 2014-08-13 14:53:13 --> XSS Filtering completed
DEBUG - 2014-08-13 14:53:13 --> XSS Filtering completed
DEBUG - 2014-08-13 14:53:13 --> CRSF cookie Set
DEBUG - 2014-08-13 14:53:13 --> CSRF token verified
DEBUG - 2014-08-13 14:53:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 14:53:13 --> Language Class Initialized
DEBUG - 2014-08-13 14:53:13 --> Loader Class Initialized
DEBUG - 2014-08-13 14:53:13 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 14:53:13 --> Helper loaded: url_helper
DEBUG - 2014-08-13 14:53:13 --> Database Driver Class Initialized
ERROR - 2014-08-13 14:53:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 14:53:13 --> Session Class Initialized
DEBUG - 2014-08-13 14:53:13 --> Helper loaded: string_helper
DEBUG - 2014-08-13 14:53:13 --> Session routines successfully run
DEBUG - 2014-08-13 14:53:13 --> Controller Class Initialized
DEBUG - 2014-08-13 14:53:13 --> Helper loaded: form_helper
DEBUG - 2014-08-13 14:53:13 --> Form Validation Class Initialized
DEBUG - 2014-08-13 14:53:13 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 14:53:13 --> XSS Filtering completed
DEBUG - 2014-08-13 14:53:13 --> XSS Filtering completed
DEBUG - 2014-08-13 14:53:13 --> XSS Filtering completed
DEBUG - 2014-08-13 14:53:13 --> XSS Filtering completed
DEBUG - 2014-08-13 14:53:13 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 14:53:13 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 14:53:13 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 14:53:13 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 14:53:13 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 14:53:13 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 14:53:13 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 14:53:13 --> Final output sent to browser
DEBUG - 2014-08-13 14:53:13 --> Total execution time: 0.1030
DEBUG - 2014-08-13 14:54:16 --> Config Class Initialized
DEBUG - 2014-08-13 14:54:16 --> Hooks Class Initialized
DEBUG - 2014-08-13 14:54:16 --> Utf8 Class Initialized
DEBUG - 2014-08-13 14:54:16 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 14:54:16 --> URI Class Initialized
DEBUG - 2014-08-13 14:54:16 --> Router Class Initialized
DEBUG - 2014-08-13 14:54:16 --> Output Class Initialized
DEBUG - 2014-08-13 14:54:16 --> Security Class Initialized
DEBUG - 2014-08-13 14:54:16 --> Input Class Initialized
DEBUG - 2014-08-13 14:54:16 --> XSS Filtering completed
DEBUG - 2014-08-13 14:54:16 --> XSS Filtering completed
DEBUG - 2014-08-13 14:54:16 --> XSS Filtering completed
DEBUG - 2014-08-13 14:54:16 --> XSS Filtering completed
DEBUG - 2014-08-13 14:54:16 --> XSS Filtering completed
DEBUG - 2014-08-13 14:54:16 --> XSS Filtering completed
DEBUG - 2014-08-13 14:54:16 --> XSS Filtering completed
DEBUG - 2014-08-13 14:54:16 --> XSS Filtering completed
DEBUG - 2014-08-13 14:54:16 --> XSS Filtering completed
DEBUG - 2014-08-13 14:54:16 --> XSS Filtering completed
DEBUG - 2014-08-13 14:54:16 --> XSS Filtering completed
DEBUG - 2014-08-13 14:54:16 --> XSS Filtering completed
DEBUG - 2014-08-13 14:54:16 --> XSS Filtering completed
DEBUG - 2014-08-13 14:54:16 --> XSS Filtering completed
DEBUG - 2014-08-13 14:54:16 --> CRSF cookie Set
DEBUG - 2014-08-13 14:54:16 --> CSRF token verified
DEBUG - 2014-08-13 14:54:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 14:54:16 --> Language Class Initialized
DEBUG - 2014-08-13 14:54:16 --> Loader Class Initialized
DEBUG - 2014-08-13 14:54:16 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 14:54:16 --> Helper loaded: url_helper
DEBUG - 2014-08-13 14:54:16 --> Database Driver Class Initialized
ERROR - 2014-08-13 14:54:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 14:54:16 --> Session Class Initialized
DEBUG - 2014-08-13 14:54:16 --> Helper loaded: string_helper
DEBUG - 2014-08-13 14:54:16 --> Session routines successfully run
DEBUG - 2014-08-13 14:54:16 --> Controller Class Initialized
DEBUG - 2014-08-13 14:54:16 --> Helper loaded: form_helper
DEBUG - 2014-08-13 14:54:16 --> Form Validation Class Initialized
DEBUG - 2014-08-13 14:54:16 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 14:54:16 --> XSS Filtering completed
DEBUG - 2014-08-13 14:54:16 --> XSS Filtering completed
DEBUG - 2014-08-13 14:54:16 --> XSS Filtering completed
DEBUG - 2014-08-13 14:54:16 --> XSS Filtering completed
DEBUG - 2014-08-13 14:54:16 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 14:54:16 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 14:54:16 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 14:54:16 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 14:54:16 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 14:54:16 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 14:54:16 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 14:54:16 --> Final output sent to browser
DEBUG - 2014-08-13 14:54:16 --> Total execution time: 0.0732
DEBUG - 2014-08-13 14:55:22 --> Config Class Initialized
DEBUG - 2014-08-13 14:55:22 --> Hooks Class Initialized
DEBUG - 2014-08-13 14:55:22 --> Utf8 Class Initialized
DEBUG - 2014-08-13 14:55:22 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 14:55:22 --> URI Class Initialized
DEBUG - 2014-08-13 14:55:22 --> Router Class Initialized
DEBUG - 2014-08-13 14:55:22 --> Output Class Initialized
DEBUG - 2014-08-13 14:55:22 --> Security Class Initialized
DEBUG - 2014-08-13 14:55:22 --> Input Class Initialized
DEBUG - 2014-08-13 14:55:22 --> XSS Filtering completed
DEBUG - 2014-08-13 14:55:22 --> XSS Filtering completed
DEBUG - 2014-08-13 14:55:22 --> XSS Filtering completed
DEBUG - 2014-08-13 14:55:22 --> XSS Filtering completed
DEBUG - 2014-08-13 14:55:22 --> XSS Filtering completed
DEBUG - 2014-08-13 14:55:22 --> XSS Filtering completed
DEBUG - 2014-08-13 14:55:22 --> XSS Filtering completed
DEBUG - 2014-08-13 14:55:22 --> XSS Filtering completed
DEBUG - 2014-08-13 14:55:22 --> XSS Filtering completed
DEBUG - 2014-08-13 14:55:22 --> XSS Filtering completed
DEBUG - 2014-08-13 14:55:22 --> XSS Filtering completed
DEBUG - 2014-08-13 14:55:22 --> XSS Filtering completed
DEBUG - 2014-08-13 14:55:22 --> XSS Filtering completed
DEBUG - 2014-08-13 14:55:22 --> XSS Filtering completed
DEBUG - 2014-08-13 14:55:22 --> CRSF cookie Set
DEBUG - 2014-08-13 14:55:22 --> CSRF token verified
DEBUG - 2014-08-13 14:55:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 14:55:22 --> Language Class Initialized
DEBUG - 2014-08-13 14:55:22 --> Loader Class Initialized
DEBUG - 2014-08-13 14:55:22 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 14:55:22 --> Helper loaded: url_helper
DEBUG - 2014-08-13 14:55:22 --> Database Driver Class Initialized
ERROR - 2014-08-13 14:55:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 14:55:22 --> Session Class Initialized
DEBUG - 2014-08-13 14:55:22 --> Helper loaded: string_helper
DEBUG - 2014-08-13 14:55:22 --> Session routines successfully run
DEBUG - 2014-08-13 14:55:22 --> Controller Class Initialized
DEBUG - 2014-08-13 14:55:22 --> Helper loaded: form_helper
DEBUG - 2014-08-13 14:55:22 --> Form Validation Class Initialized
DEBUG - 2014-08-13 14:55:22 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 14:55:22 --> XSS Filtering completed
DEBUG - 2014-08-13 14:55:22 --> XSS Filtering completed
DEBUG - 2014-08-13 14:55:22 --> XSS Filtering completed
DEBUG - 2014-08-13 14:55:22 --> XSS Filtering completed
DEBUG - 2014-08-13 14:55:22 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 14:55:22 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 14:55:22 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 14:55:22 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 14:55:22 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 14:55:22 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 14:55:22 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 14:55:22 --> Final output sent to browser
DEBUG - 2014-08-13 14:55:22 --> Total execution time: 0.0749
DEBUG - 2014-08-13 14:57:44 --> Config Class Initialized
DEBUG - 2014-08-13 14:57:44 --> Hooks Class Initialized
DEBUG - 2014-08-13 14:57:44 --> Utf8 Class Initialized
DEBUG - 2014-08-13 14:57:44 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 14:57:44 --> URI Class Initialized
DEBUG - 2014-08-13 14:57:44 --> Router Class Initialized
DEBUG - 2014-08-13 14:57:44 --> Output Class Initialized
DEBUG - 2014-08-13 14:57:44 --> Security Class Initialized
DEBUG - 2014-08-13 14:57:44 --> Input Class Initialized
DEBUG - 2014-08-13 14:57:44 --> XSS Filtering completed
DEBUG - 2014-08-13 14:57:44 --> XSS Filtering completed
DEBUG - 2014-08-13 14:57:44 --> XSS Filtering completed
DEBUG - 2014-08-13 14:57:44 --> XSS Filtering completed
DEBUG - 2014-08-13 14:57:44 --> XSS Filtering completed
DEBUG - 2014-08-13 14:57:44 --> XSS Filtering completed
DEBUG - 2014-08-13 14:57:44 --> XSS Filtering completed
DEBUG - 2014-08-13 14:57:44 --> XSS Filtering completed
DEBUG - 2014-08-13 14:57:44 --> XSS Filtering completed
DEBUG - 2014-08-13 14:57:44 --> XSS Filtering completed
DEBUG - 2014-08-13 14:57:44 --> XSS Filtering completed
DEBUG - 2014-08-13 14:57:44 --> XSS Filtering completed
DEBUG - 2014-08-13 14:57:44 --> XSS Filtering completed
DEBUG - 2014-08-13 14:57:44 --> XSS Filtering completed
DEBUG - 2014-08-13 14:57:44 --> CRSF cookie Set
DEBUG - 2014-08-13 14:57:44 --> CSRF token verified
DEBUG - 2014-08-13 14:57:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 14:57:44 --> Language Class Initialized
DEBUG - 2014-08-13 14:57:44 --> Loader Class Initialized
DEBUG - 2014-08-13 14:57:44 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 14:57:44 --> Helper loaded: url_helper
DEBUG - 2014-08-13 14:57:44 --> Database Driver Class Initialized
ERROR - 2014-08-13 14:57:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 14:57:44 --> Session Class Initialized
DEBUG - 2014-08-13 14:57:44 --> Helper loaded: string_helper
DEBUG - 2014-08-13 14:57:44 --> Session routines successfully run
DEBUG - 2014-08-13 14:57:44 --> Controller Class Initialized
DEBUG - 2014-08-13 14:57:44 --> Helper loaded: form_helper
DEBUG - 2014-08-13 14:57:44 --> Form Validation Class Initialized
DEBUG - 2014-08-13 14:57:44 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 14:57:44 --> XSS Filtering completed
DEBUG - 2014-08-13 14:57:44 --> XSS Filtering completed
DEBUG - 2014-08-13 14:57:44 --> XSS Filtering completed
DEBUG - 2014-08-13 14:57:44 --> XSS Filtering completed
DEBUG - 2014-08-13 14:57:44 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 14:57:44 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 14:57:44 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 14:57:44 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 14:57:44 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 14:57:44 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 14:57:44 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 14:57:44 --> Final output sent to browser
DEBUG - 2014-08-13 14:57:44 --> Total execution time: 0.0744
DEBUG - 2014-08-13 15:02:38 --> Config Class Initialized
DEBUG - 2014-08-13 15:02:38 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:02:38 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:02:38 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:02:38 --> URI Class Initialized
DEBUG - 2014-08-13 15:02:38 --> Router Class Initialized
DEBUG - 2014-08-13 15:02:38 --> Output Class Initialized
DEBUG - 2014-08-13 15:02:38 --> Security Class Initialized
DEBUG - 2014-08-13 15:02:38 --> Input Class Initialized
DEBUG - 2014-08-13 15:02:38 --> XSS Filtering completed
DEBUG - 2014-08-13 15:02:38 --> XSS Filtering completed
DEBUG - 2014-08-13 15:02:38 --> XSS Filtering completed
DEBUG - 2014-08-13 15:02:38 --> XSS Filtering completed
DEBUG - 2014-08-13 15:02:38 --> XSS Filtering completed
DEBUG - 2014-08-13 15:02:38 --> XSS Filtering completed
DEBUG - 2014-08-13 15:02:38 --> XSS Filtering completed
DEBUG - 2014-08-13 15:02:38 --> XSS Filtering completed
DEBUG - 2014-08-13 15:02:38 --> XSS Filtering completed
DEBUG - 2014-08-13 15:02:38 --> XSS Filtering completed
DEBUG - 2014-08-13 15:02:38 --> XSS Filtering completed
DEBUG - 2014-08-13 15:02:38 --> XSS Filtering completed
DEBUG - 2014-08-13 15:02:38 --> XSS Filtering completed
DEBUG - 2014-08-13 15:02:38 --> XSS Filtering completed
DEBUG - 2014-08-13 15:02:38 --> CRSF cookie Set
DEBUG - 2014-08-13 15:02:38 --> CSRF token verified
DEBUG - 2014-08-13 15:02:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:02:38 --> Language Class Initialized
DEBUG - 2014-08-13 15:02:38 --> Loader Class Initialized
DEBUG - 2014-08-13 15:02:38 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:02:38 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:02:38 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:02:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:02:38 --> Session Class Initialized
DEBUG - 2014-08-13 15:02:38 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:02:38 --> Session routines successfully run
DEBUG - 2014-08-13 15:02:38 --> Controller Class Initialized
DEBUG - 2014-08-13 15:02:38 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:02:38 --> Form Validation Class Initialized
DEBUG - 2014-08-13 15:02:38 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 15:02:38 --> XSS Filtering completed
DEBUG - 2014-08-13 15:02:38 --> XSS Filtering completed
DEBUG - 2014-08-13 15:02:38 --> XSS Filtering completed
DEBUG - 2014-08-13 15:02:38 --> XSS Filtering completed
DEBUG - 2014-08-13 15:02:38 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:02:38 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 15:02:38 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 15:02:38 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 15:02:38 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 15:02:38 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:02:38 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:02:38 --> Final output sent to browser
DEBUG - 2014-08-13 15:02:38 --> Total execution time: 0.0773
DEBUG - 2014-08-13 15:08:31 --> Config Class Initialized
DEBUG - 2014-08-13 15:08:31 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:08:31 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:08:31 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:08:31 --> URI Class Initialized
DEBUG - 2014-08-13 15:08:31 --> Router Class Initialized
DEBUG - 2014-08-13 15:08:31 --> Output Class Initialized
DEBUG - 2014-08-13 15:08:31 --> Security Class Initialized
DEBUG - 2014-08-13 15:08:31 --> Input Class Initialized
DEBUG - 2014-08-13 15:08:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:31 --> CRSF cookie Set
DEBUG - 2014-08-13 15:08:31 --> CSRF token verified
DEBUG - 2014-08-13 15:08:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:08:31 --> Language Class Initialized
DEBUG - 2014-08-13 15:08:31 --> Loader Class Initialized
DEBUG - 2014-08-13 15:08:31 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:08:31 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:08:31 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:08:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:08:31 --> Session Class Initialized
DEBUG - 2014-08-13 15:08:31 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:08:31 --> Session routines successfully run
DEBUG - 2014-08-13 15:08:31 --> Controller Class Initialized
DEBUG - 2014-08-13 15:08:31 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:08:31 --> Form Validation Class Initialized
DEBUG - 2014-08-13 15:08:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 15:08:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:31 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:08:31 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 15:08:31 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 15:08:31 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 15:08:31 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 15:08:31 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:08:31 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:08:31 --> Final output sent to browser
DEBUG - 2014-08-13 15:08:31 --> Total execution time: 0.1707
DEBUG - 2014-08-13 15:08:36 --> Config Class Initialized
DEBUG - 2014-08-13 15:08:36 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:08:36 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:08:36 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:08:36 --> URI Class Initialized
DEBUG - 2014-08-13 15:08:36 --> Router Class Initialized
DEBUG - 2014-08-13 15:08:36 --> Output Class Initialized
DEBUG - 2014-08-13 15:08:36 --> Security Class Initialized
DEBUG - 2014-08-13 15:08:36 --> Input Class Initialized
DEBUG - 2014-08-13 15:08:36 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:36 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:36 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:36 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:36 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:36 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:36 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:36 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:36 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:36 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:36 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:36 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:36 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:36 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:36 --> CRSF cookie Set
DEBUG - 2014-08-13 15:08:36 --> CSRF token verified
DEBUG - 2014-08-13 15:08:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:08:36 --> Language Class Initialized
DEBUG - 2014-08-13 15:08:36 --> Loader Class Initialized
DEBUG - 2014-08-13 15:08:36 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:08:36 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:08:36 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:08:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:08:36 --> Session Class Initialized
DEBUG - 2014-08-13 15:08:36 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:08:36 --> Session routines successfully run
DEBUG - 2014-08-13 15:08:36 --> Controller Class Initialized
DEBUG - 2014-08-13 15:08:36 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:08:36 --> Form Validation Class Initialized
DEBUG - 2014-08-13 15:08:36 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 15:08:36 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:36 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:36 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:36 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:36 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:36 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:08:36 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 15:08:36 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 15:08:36 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 15:08:36 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 15:08:36 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:08:36 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:08:36 --> Final output sent to browser
DEBUG - 2014-08-13 15:08:36 --> Total execution time: 0.1946
DEBUG - 2014-08-13 15:08:41 --> Config Class Initialized
DEBUG - 2014-08-13 15:08:41 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:08:41 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:08:41 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:08:41 --> URI Class Initialized
DEBUG - 2014-08-13 15:08:41 --> Router Class Initialized
DEBUG - 2014-08-13 15:08:41 --> Output Class Initialized
DEBUG - 2014-08-13 15:08:41 --> Security Class Initialized
DEBUG - 2014-08-13 15:08:41 --> Input Class Initialized
DEBUG - 2014-08-13 15:08:41 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:41 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:41 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:41 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:41 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:41 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:41 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:41 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:41 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:41 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:41 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:41 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:41 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:41 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:41 --> CRSF cookie Set
DEBUG - 2014-08-13 15:08:41 --> CSRF token verified
DEBUG - 2014-08-13 15:08:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:08:41 --> Language Class Initialized
DEBUG - 2014-08-13 15:08:41 --> Loader Class Initialized
DEBUG - 2014-08-13 15:08:41 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:08:41 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:08:41 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:08:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:08:41 --> Session Class Initialized
DEBUG - 2014-08-13 15:08:41 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:08:41 --> Session routines successfully run
DEBUG - 2014-08-13 15:08:41 --> Controller Class Initialized
DEBUG - 2014-08-13 15:08:41 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:08:41 --> Form Validation Class Initialized
DEBUG - 2014-08-13 15:08:41 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 15:08:41 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:41 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:41 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:41 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:41 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:41 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:41 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:08:41 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 15:08:41 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 15:08:41 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 15:08:41 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 15:08:41 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:08:41 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:08:41 --> Final output sent to browser
DEBUG - 2014-08-13 15:08:41 --> Total execution time: 0.1650
DEBUG - 2014-08-13 15:08:45 --> Config Class Initialized
DEBUG - 2014-08-13 15:08:45 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:08:45 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:08:45 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:08:45 --> URI Class Initialized
DEBUG - 2014-08-13 15:08:45 --> Router Class Initialized
DEBUG - 2014-08-13 15:08:45 --> Output Class Initialized
DEBUG - 2014-08-13 15:08:45 --> Security Class Initialized
DEBUG - 2014-08-13 15:08:45 --> Input Class Initialized
DEBUG - 2014-08-13 15:08:45 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:45 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:45 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:45 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:45 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:45 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:45 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:45 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:45 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:45 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:45 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:45 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:45 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:45 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:45 --> CRSF cookie Set
DEBUG - 2014-08-13 15:08:45 --> CSRF token verified
DEBUG - 2014-08-13 15:08:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:08:45 --> Language Class Initialized
DEBUG - 2014-08-13 15:08:45 --> Loader Class Initialized
DEBUG - 2014-08-13 15:08:45 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:08:45 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:08:45 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:08:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:08:45 --> Session Class Initialized
DEBUG - 2014-08-13 15:08:45 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:08:45 --> Session routines successfully run
DEBUG - 2014-08-13 15:08:45 --> Controller Class Initialized
DEBUG - 2014-08-13 15:08:45 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:08:45 --> Form Validation Class Initialized
DEBUG - 2014-08-13 15:08:45 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 15:08:45 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:45 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:45 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:45 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:45 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:45 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:45 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:45 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:08:45 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 15:08:45 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 15:08:45 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 15:08:45 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 15:08:45 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:08:45 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:08:45 --> Final output sent to browser
DEBUG - 2014-08-13 15:08:45 --> Total execution time: 0.1616
DEBUG - 2014-08-13 15:08:49 --> Config Class Initialized
DEBUG - 2014-08-13 15:08:49 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:08:49 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:08:49 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:08:49 --> URI Class Initialized
DEBUG - 2014-08-13 15:08:49 --> Router Class Initialized
DEBUG - 2014-08-13 15:08:49 --> Output Class Initialized
DEBUG - 2014-08-13 15:08:49 --> Security Class Initialized
DEBUG - 2014-08-13 15:08:49 --> Input Class Initialized
DEBUG - 2014-08-13 15:08:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:49 --> CRSF cookie Set
DEBUG - 2014-08-13 15:08:49 --> CSRF token verified
DEBUG - 2014-08-13 15:08:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:08:49 --> Language Class Initialized
DEBUG - 2014-08-13 15:08:49 --> Loader Class Initialized
DEBUG - 2014-08-13 15:08:49 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:08:49 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:08:49 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:08:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:08:49 --> Session Class Initialized
DEBUG - 2014-08-13 15:08:49 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:08:49 --> Session routines successfully run
DEBUG - 2014-08-13 15:08:49 --> Controller Class Initialized
DEBUG - 2014-08-13 15:08:49 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:08:49 --> Form Validation Class Initialized
DEBUG - 2014-08-13 15:08:49 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 15:08:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:08:49 --> Model Class Initialized
DEBUG - 2014-08-13 15:08:49 --> Model Class Initialized
DEBUG - 2014-08-13 15:08:49 --> Encrypt Class Initialized
DEBUG - 2014-08-13 15:08:49 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:08:49 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 15:08:49 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 15:08:49 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 15:08:49 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 15:08:49 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:08:49 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:08:49 --> Final output sent to browser
DEBUG - 2014-08-13 15:08:49 --> Total execution time: 0.2133
DEBUG - 2014-08-13 15:09:02 --> Config Class Initialized
DEBUG - 2014-08-13 15:09:02 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:09:02 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:09:02 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:09:02 --> URI Class Initialized
DEBUG - 2014-08-13 15:09:02 --> Router Class Initialized
DEBUG - 2014-08-13 15:09:02 --> Output Class Initialized
DEBUG - 2014-08-13 15:09:02 --> Security Class Initialized
DEBUG - 2014-08-13 15:09:02 --> Input Class Initialized
DEBUG - 2014-08-13 15:09:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:09:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:09:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:09:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:09:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:09:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:09:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:09:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:09:02 --> CRSF cookie Set
DEBUG - 2014-08-13 15:09:02 --> CSRF token verified
DEBUG - 2014-08-13 15:09:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:09:02 --> Language Class Initialized
DEBUG - 2014-08-13 15:09:02 --> Loader Class Initialized
DEBUG - 2014-08-13 15:09:02 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:09:02 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:09:02 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:09:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:09:02 --> Session Class Initialized
DEBUG - 2014-08-13 15:09:02 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:09:02 --> Session routines successfully run
DEBUG - 2014-08-13 15:09:02 --> Controller Class Initialized
DEBUG - 2014-08-13 15:09:02 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:09:02 --> Form Validation Class Initialized
DEBUG - 2014-08-13 15:09:02 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 15:09:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:09:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:09:02 --> Model Class Initialized
DEBUG - 2014-08-13 15:09:02 --> Model Class Initialized
DEBUG - 2014-08-13 15:09:02 --> Encrypt Class Initialized
DEBUG - 2014-08-13 15:09:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:09:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:09:02 --> Model Class Initialized
DEBUG - 2014-08-13 15:09:02 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 15:09:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:09:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:09:02 --> Config Class Initialized
DEBUG - 2014-08-13 15:09:02 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:09:02 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:09:02 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:09:02 --> URI Class Initialized
DEBUG - 2014-08-13 15:09:02 --> Router Class Initialized
DEBUG - 2014-08-13 15:09:02 --> Output Class Initialized
DEBUG - 2014-08-13 15:09:02 --> Security Class Initialized
DEBUG - 2014-08-13 15:09:02 --> Input Class Initialized
DEBUG - 2014-08-13 15:09:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:09:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:09:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:09:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:09:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:09:02 --> CRSF cookie Set
DEBUG - 2014-08-13 15:09:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:09:02 --> Language Class Initialized
DEBUG - 2014-08-13 15:09:02 --> Loader Class Initialized
DEBUG - 2014-08-13 15:09:02 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:09:02 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:09:03 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:09:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:09:03 --> Session Class Initialized
DEBUG - 2014-08-13 15:09:03 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:09:03 --> Session routines successfully run
DEBUG - 2014-08-13 15:09:03 --> Controller Class Initialized
DEBUG - 2014-08-13 15:09:03 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:09:03 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-13 15:09:03 --> Model Class Initialized
DEBUG - 2014-08-13 15:09:03 --> Model Class Initialized
DEBUG - 2014-08-13 15:09:03 --> Model Class Initialized
DEBUG - 2014-08-13 15:09:03 --> Model Class Initialized
DEBUG - 2014-08-13 15:09:03 --> Helper loaded: array_helper
DEBUG - 2014-08-13 15:09:03 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:09:03 --> File loaded: application/views/placement_students_home.php
DEBUG - 2014-08-13 15:09:03 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:09:03 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:09:03 --> Final output sent to browser
DEBUG - 2014-08-13 15:09:03 --> Total execution time: 0.1524
DEBUG - 2014-08-13 15:09:10 --> Config Class Initialized
DEBUG - 2014-08-13 15:09:10 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:09:10 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:09:10 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:09:10 --> URI Class Initialized
DEBUG - 2014-08-13 15:09:10 --> Router Class Initialized
DEBUG - 2014-08-13 15:09:10 --> Output Class Initialized
DEBUG - 2014-08-13 15:09:10 --> Security Class Initialized
DEBUG - 2014-08-13 15:09:10 --> Input Class Initialized
DEBUG - 2014-08-13 15:09:10 --> XSS Filtering completed
DEBUG - 2014-08-13 15:09:10 --> XSS Filtering completed
DEBUG - 2014-08-13 15:09:10 --> XSS Filtering completed
DEBUG - 2014-08-13 15:09:10 --> XSS Filtering completed
DEBUG - 2014-08-13 15:09:10 --> XSS Filtering completed
DEBUG - 2014-08-13 15:09:10 --> XSS Filtering completed
DEBUG - 2014-08-13 15:09:10 --> CRSF cookie Set
DEBUG - 2014-08-13 15:09:10 --> CSRF token verified
DEBUG - 2014-08-13 15:09:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:09:10 --> Language Class Initialized
DEBUG - 2014-08-13 15:09:10 --> Loader Class Initialized
DEBUG - 2014-08-13 15:09:10 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:09:10 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:09:10 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:09:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:09:10 --> Session Class Initialized
DEBUG - 2014-08-13 15:09:10 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:09:10 --> Session routines successfully run
DEBUG - 2014-08-13 15:09:10 --> Controller Class Initialized
DEBUG - 2014-08-13 15:09:10 --> Upload Class Initialized
DEBUG - 2014-08-13 15:09:10 --> Model Class Initialized
DEBUG - 2014-08-13 15:09:10 --> Model Class Initialized
DEBUG - 2014-08-13 15:09:10 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:09:10 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-13 15:09:10 --> Model Class Initialized
DEBUG - 2014-08-13 15:09:10 --> Model Class Initialized
DEBUG - 2014-08-13 15:09:10 --> Helper loaded: array_helper
DEBUG - 2014-08-13 15:09:10 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:09:10 --> File loaded: application/views/placement_students_home.php
DEBUG - 2014-08-13 15:09:10 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:09:10 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:09:10 --> Final output sent to browser
DEBUG - 2014-08-13 15:09:10 --> Total execution time: 0.1851
DEBUG - 2014-08-13 15:09:17 --> Config Class Initialized
DEBUG - 2014-08-13 15:09:17 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:09:17 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:09:17 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:09:17 --> URI Class Initialized
DEBUG - 2014-08-13 15:09:17 --> Router Class Initialized
DEBUG - 2014-08-13 15:09:17 --> Output Class Initialized
DEBUG - 2014-08-13 15:09:17 --> Security Class Initialized
DEBUG - 2014-08-13 15:09:17 --> Input Class Initialized
DEBUG - 2014-08-13 15:09:17 --> XSS Filtering completed
DEBUG - 2014-08-13 15:09:17 --> XSS Filtering completed
DEBUG - 2014-08-13 15:09:17 --> XSS Filtering completed
DEBUG - 2014-08-13 15:09:17 --> XSS Filtering completed
DEBUG - 2014-08-13 15:09:17 --> XSS Filtering completed
DEBUG - 2014-08-13 15:09:17 --> CRSF cookie Set
DEBUG - 2014-08-13 15:09:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:09:17 --> Language Class Initialized
DEBUG - 2014-08-13 15:09:17 --> Loader Class Initialized
DEBUG - 2014-08-13 15:09:17 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:09:17 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:09:17 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:09:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:09:17 --> Session Class Initialized
DEBUG - 2014-08-13 15:09:17 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:09:17 --> Session routines successfully run
DEBUG - 2014-08-13 15:09:17 --> Controller Class Initialized
DEBUG - 2014-08-13 15:09:17 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:09:17 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-13 15:09:17 --> Model Class Initialized
DEBUG - 2014-08-13 15:09:17 --> Model Class Initialized
DEBUG - 2014-08-13 15:09:17 --> Model Class Initialized
DEBUG - 2014-08-13 15:09:17 --> Model Class Initialized
DEBUG - 2014-08-13 15:09:17 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:09:17 --> Helper loaded: array_helper
DEBUG - 2014-08-13 15:09:17 --> File loaded: application/views/placement_students_update.php
DEBUG - 2014-08-13 15:09:17 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:09:18 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:09:18 --> Final output sent to browser
DEBUG - 2014-08-13 15:09:18 --> Total execution time: 0.1106
DEBUG - 2014-08-13 15:10:14 --> Config Class Initialized
DEBUG - 2014-08-13 15:10:14 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:10:14 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:10:14 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:10:14 --> URI Class Initialized
DEBUG - 2014-08-13 15:10:14 --> Router Class Initialized
DEBUG - 2014-08-13 15:10:14 --> Output Class Initialized
DEBUG - 2014-08-13 15:10:14 --> Security Class Initialized
DEBUG - 2014-08-13 15:10:14 --> Input Class Initialized
DEBUG - 2014-08-13 15:10:14 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:14 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:14 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:14 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:14 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:14 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:14 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:14 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:14 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:14 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:14 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:14 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:14 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:14 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:14 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:14 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:14 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:14 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:14 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:14 --> CRSF cookie Set
DEBUG - 2014-08-13 15:10:14 --> CSRF token verified
DEBUG - 2014-08-13 15:10:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:10:14 --> Language Class Initialized
DEBUG - 2014-08-13 15:10:14 --> Loader Class Initialized
DEBUG - 2014-08-13 15:10:14 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:10:14 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:10:14 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:10:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:10:14 --> Session Class Initialized
DEBUG - 2014-08-13 15:10:14 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:10:14 --> Session routines successfully run
DEBUG - 2014-08-13 15:10:14 --> Controller Class Initialized
DEBUG - 2014-08-13 15:10:14 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:10:14 --> Form Validation Class Initialized
ERROR - 2014-08-13 15:10:14 --> Severity: Notice  --> Undefined property: Placement::$register_form C:\wamp\www\cep\placement\application\controllers\placement.php 23
DEBUG - 2014-08-13 15:10:31 --> Config Class Initialized
DEBUG - 2014-08-13 15:10:31 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:10:31 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:10:31 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:10:31 --> URI Class Initialized
DEBUG - 2014-08-13 15:10:31 --> Router Class Initialized
DEBUG - 2014-08-13 15:10:31 --> Output Class Initialized
DEBUG - 2014-08-13 15:10:31 --> Security Class Initialized
DEBUG - 2014-08-13 15:10:31 --> Input Class Initialized
DEBUG - 2014-08-13 15:10:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:31 --> CRSF cookie Set
DEBUG - 2014-08-13 15:10:31 --> CSRF token verified
DEBUG - 2014-08-13 15:10:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:10:31 --> Language Class Initialized
DEBUG - 2014-08-13 15:10:31 --> Loader Class Initialized
DEBUG - 2014-08-13 15:10:31 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:10:31 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:10:31 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:10:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:10:31 --> Session Class Initialized
DEBUG - 2014-08-13 15:10:31 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:10:31 --> Session routines successfully run
DEBUG - 2014-08-13 15:10:31 --> Controller Class Initialized
DEBUG - 2014-08-13 15:10:31 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:10:31 --> Form Validation Class Initialized
DEBUG - 2014-08-13 15:10:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 15:10:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:10:31 --> Model Class Initialized
DEBUG - 2014-08-13 15:10:31 --> Model Class Initialized
ERROR - 2014-08-13 15:10:31 --> Severity: Notice  --> Array to string conversion C:\wamp\www\cep\placement\system\database\DB_active_rec.php 427
DEBUG - 2014-08-13 15:10:31 --> DB Transaction Failure
ERROR - 2014-08-13 15:10:31 --> Query error: Unknown column 'students' in 'where clause'
DEBUG - 2014-08-13 15:10:31 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-08-13 15:13:31 --> Config Class Initialized
DEBUG - 2014-08-13 15:13:31 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:13:31 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:13:31 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:13:31 --> URI Class Initialized
DEBUG - 2014-08-13 15:13:31 --> Router Class Initialized
DEBUG - 2014-08-13 15:13:31 --> Output Class Initialized
DEBUG - 2014-08-13 15:13:31 --> Security Class Initialized
DEBUG - 2014-08-13 15:13:31 --> Input Class Initialized
DEBUG - 2014-08-13 15:13:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:13:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:13:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:13:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:13:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:13:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:13:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:13:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:13:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:13:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:13:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:13:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:13:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:13:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:13:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:13:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:13:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:13:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:13:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:13:31 --> CRSF cookie Set
DEBUG - 2014-08-13 15:13:31 --> CSRF token verified
DEBUG - 2014-08-13 15:13:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:13:31 --> Language Class Initialized
DEBUG - 2014-08-13 15:13:31 --> Loader Class Initialized
DEBUG - 2014-08-13 15:13:31 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:13:31 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:13:31 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:13:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:13:31 --> Session Class Initialized
DEBUG - 2014-08-13 15:13:31 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:13:31 --> Session routines successfully run
DEBUG - 2014-08-13 15:13:31 --> Controller Class Initialized
DEBUG - 2014-08-13 15:13:31 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:13:31 --> Form Validation Class Initialized
DEBUG - 2014-08-13 15:13:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 15:13:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:13:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:13:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:13:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:13:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:13:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:13:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:13:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:13:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:13:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:13:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:13:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:13:31 --> Model Class Initialized
DEBUG - 2014-08-13 15:14:24 --> Config Class Initialized
DEBUG - 2014-08-13 15:14:24 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:14:24 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:14:24 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:14:24 --> URI Class Initialized
DEBUG - 2014-08-13 15:14:24 --> Router Class Initialized
DEBUG - 2014-08-13 15:14:24 --> Output Class Initialized
DEBUG - 2014-08-13 15:14:24 --> Security Class Initialized
DEBUG - 2014-08-13 15:14:24 --> Input Class Initialized
DEBUG - 2014-08-13 15:14:24 --> XSS Filtering completed
DEBUG - 2014-08-13 15:14:24 --> XSS Filtering completed
DEBUG - 2014-08-13 15:14:24 --> XSS Filtering completed
DEBUG - 2014-08-13 15:14:24 --> XSS Filtering completed
DEBUG - 2014-08-13 15:14:24 --> XSS Filtering completed
DEBUG - 2014-08-13 15:14:24 --> XSS Filtering completed
DEBUG - 2014-08-13 15:14:24 --> XSS Filtering completed
DEBUG - 2014-08-13 15:14:24 --> XSS Filtering completed
DEBUG - 2014-08-13 15:14:24 --> XSS Filtering completed
DEBUG - 2014-08-13 15:14:24 --> XSS Filtering completed
DEBUG - 2014-08-13 15:14:24 --> XSS Filtering completed
DEBUG - 2014-08-13 15:14:24 --> XSS Filtering completed
DEBUG - 2014-08-13 15:14:24 --> XSS Filtering completed
DEBUG - 2014-08-13 15:14:24 --> XSS Filtering completed
DEBUG - 2014-08-13 15:14:24 --> XSS Filtering completed
DEBUG - 2014-08-13 15:14:24 --> XSS Filtering completed
DEBUG - 2014-08-13 15:14:24 --> XSS Filtering completed
DEBUG - 2014-08-13 15:14:24 --> XSS Filtering completed
DEBUG - 2014-08-13 15:14:24 --> XSS Filtering completed
DEBUG - 2014-08-13 15:14:24 --> CRSF cookie Set
DEBUG - 2014-08-13 15:14:24 --> CSRF token verified
DEBUG - 2014-08-13 15:14:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:14:24 --> Language Class Initialized
DEBUG - 2014-08-13 15:14:24 --> Loader Class Initialized
DEBUG - 2014-08-13 15:14:24 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:14:24 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:14:24 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:14:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:14:24 --> Session Class Initialized
DEBUG - 2014-08-13 15:14:24 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:14:24 --> Session routines successfully run
DEBUG - 2014-08-13 15:14:24 --> Controller Class Initialized
DEBUG - 2014-08-13 15:14:24 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:14:24 --> Form Validation Class Initialized
DEBUG - 2014-08-13 15:14:24 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 15:14:24 --> XSS Filtering completed
DEBUG - 2014-08-13 15:14:24 --> XSS Filtering completed
DEBUG - 2014-08-13 15:14:24 --> XSS Filtering completed
DEBUG - 2014-08-13 15:14:24 --> XSS Filtering completed
DEBUG - 2014-08-13 15:14:24 --> XSS Filtering completed
DEBUG - 2014-08-13 15:14:24 --> XSS Filtering completed
DEBUG - 2014-08-13 15:14:24 --> XSS Filtering completed
DEBUG - 2014-08-13 15:14:24 --> XSS Filtering completed
DEBUG - 2014-08-13 15:14:24 --> XSS Filtering completed
DEBUG - 2014-08-13 15:14:24 --> XSS Filtering completed
DEBUG - 2014-08-13 15:14:24 --> XSS Filtering completed
DEBUG - 2014-08-13 15:14:24 --> XSS Filtering completed
DEBUG - 2014-08-13 15:14:24 --> Model Class Initialized
DEBUG - 2014-08-13 15:14:24 --> Model Class Initialized
DEBUG - 2014-08-13 15:14:24 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:14:24 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-13 15:14:24 --> Model Class Initialized
DEBUG - 2014-08-13 15:14:24 --> Model Class Initialized
DEBUG - 2014-08-13 15:14:24 --> Helper loaded: array_helper
DEBUG - 2014-08-13 15:14:24 --> File loaded: application/views/placement_students_update.php
DEBUG - 2014-08-13 15:14:24 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:14:24 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:14:24 --> Final output sent to browser
DEBUG - 2014-08-13 15:14:24 --> Total execution time: 0.2135
DEBUG - 2014-08-13 15:15:42 --> Config Class Initialized
DEBUG - 2014-08-13 15:15:42 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:15:42 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:15:42 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:15:42 --> URI Class Initialized
DEBUG - 2014-08-13 15:15:42 --> Router Class Initialized
DEBUG - 2014-08-13 15:15:42 --> Output Class Initialized
DEBUG - 2014-08-13 15:15:42 --> Security Class Initialized
DEBUG - 2014-08-13 15:15:42 --> Input Class Initialized
DEBUG - 2014-08-13 15:15:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:15:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:15:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:15:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:15:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:15:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:15:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:15:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:15:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:15:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:15:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:15:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:15:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:15:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:15:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:15:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:15:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:15:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:15:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:15:42 --> CRSF cookie Set
DEBUG - 2014-08-13 15:15:42 --> CSRF token verified
DEBUG - 2014-08-13 15:15:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:15:42 --> Language Class Initialized
DEBUG - 2014-08-13 15:15:42 --> Loader Class Initialized
DEBUG - 2014-08-13 15:15:42 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:15:42 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:15:42 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:15:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:15:42 --> Session Class Initialized
DEBUG - 2014-08-13 15:15:42 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:15:42 --> Session routines successfully run
DEBUG - 2014-08-13 15:15:42 --> Controller Class Initialized
DEBUG - 2014-08-13 15:15:42 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:15:42 --> Form Validation Class Initialized
DEBUG - 2014-08-13 15:15:42 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 15:15:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:15:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:15:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:15:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:15:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:15:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:15:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:15:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:15:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:15:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:15:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:15:42 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:15:42 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-13 15:15:42 --> Model Class Initialized
DEBUG - 2014-08-13 15:15:42 --> Model Class Initialized
DEBUG - 2014-08-13 15:15:42 --> Model Class Initialized
DEBUG - 2014-08-13 15:15:42 --> Model Class Initialized
DEBUG - 2014-08-13 15:15:43 --> Helper loaded: array_helper
DEBUG - 2014-08-13 15:15:43 --> File loaded: application/views/placement_students_update.php
DEBUG - 2014-08-13 15:15:43 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:15:43 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:15:43 --> Final output sent to browser
DEBUG - 2014-08-13 15:15:43 --> Total execution time: 0.2080
DEBUG - 2014-08-13 15:15:55 --> Config Class Initialized
DEBUG - 2014-08-13 15:15:55 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:15:55 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:15:55 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:15:55 --> URI Class Initialized
DEBUG - 2014-08-13 15:15:55 --> Router Class Initialized
DEBUG - 2014-08-13 15:15:55 --> Output Class Initialized
DEBUG - 2014-08-13 15:15:55 --> Security Class Initialized
DEBUG - 2014-08-13 15:15:55 --> Input Class Initialized
DEBUG - 2014-08-13 15:15:55 --> XSS Filtering completed
DEBUG - 2014-08-13 15:15:55 --> XSS Filtering completed
DEBUG - 2014-08-13 15:15:55 --> XSS Filtering completed
DEBUG - 2014-08-13 15:15:55 --> XSS Filtering completed
DEBUG - 2014-08-13 15:15:55 --> XSS Filtering completed
DEBUG - 2014-08-13 15:15:55 --> CRSF cookie Set
DEBUG - 2014-08-13 15:15:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:15:55 --> Language Class Initialized
DEBUG - 2014-08-13 15:15:55 --> Loader Class Initialized
DEBUG - 2014-08-13 15:15:55 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:15:55 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:15:55 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:15:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:15:55 --> Session Class Initialized
DEBUG - 2014-08-13 15:15:55 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:15:55 --> Session routines successfully run
DEBUG - 2014-08-13 15:15:55 --> Controller Class Initialized
DEBUG - 2014-08-13 15:15:55 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:15:55 --> Form Validation Class Initialized
DEBUG - 2014-08-13 15:15:55 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:15:55 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-13 15:15:55 --> Model Class Initialized
DEBUG - 2014-08-13 15:15:55 --> Model Class Initialized
DEBUG - 2014-08-13 15:15:55 --> Model Class Initialized
DEBUG - 2014-08-13 15:15:55 --> Model Class Initialized
DEBUG - 2014-08-13 15:15:55 --> Helper loaded: array_helper
DEBUG - 2014-08-13 15:15:55 --> File loaded: application/views/placement_students_update.php
DEBUG - 2014-08-13 15:15:55 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:15:55 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:15:55 --> Final output sent to browser
DEBUG - 2014-08-13 15:15:55 --> Total execution time: 0.1475
DEBUG - 2014-08-13 15:16:25 --> Config Class Initialized
DEBUG - 2014-08-13 15:16:25 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:16:25 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:16:25 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:16:25 --> URI Class Initialized
DEBUG - 2014-08-13 15:16:25 --> Router Class Initialized
DEBUG - 2014-08-13 15:16:25 --> Output Class Initialized
DEBUG - 2014-08-13 15:16:25 --> Security Class Initialized
DEBUG - 2014-08-13 15:16:25 --> Input Class Initialized
DEBUG - 2014-08-13 15:16:25 --> XSS Filtering completed
DEBUG - 2014-08-13 15:16:25 --> XSS Filtering completed
DEBUG - 2014-08-13 15:16:25 --> XSS Filtering completed
DEBUG - 2014-08-13 15:16:25 --> XSS Filtering completed
DEBUG - 2014-08-13 15:16:25 --> XSS Filtering completed
DEBUG - 2014-08-13 15:16:25 --> XSS Filtering completed
DEBUG - 2014-08-13 15:16:25 --> XSS Filtering completed
DEBUG - 2014-08-13 15:16:25 --> XSS Filtering completed
DEBUG - 2014-08-13 15:16:25 --> XSS Filtering completed
DEBUG - 2014-08-13 15:16:25 --> XSS Filtering completed
DEBUG - 2014-08-13 15:16:25 --> XSS Filtering completed
DEBUG - 2014-08-13 15:16:25 --> XSS Filtering completed
DEBUG - 2014-08-13 15:16:25 --> XSS Filtering completed
DEBUG - 2014-08-13 15:16:25 --> XSS Filtering completed
DEBUG - 2014-08-13 15:16:25 --> XSS Filtering completed
DEBUG - 2014-08-13 15:16:25 --> XSS Filtering completed
DEBUG - 2014-08-13 15:16:25 --> XSS Filtering completed
DEBUG - 2014-08-13 15:16:25 --> XSS Filtering completed
DEBUG - 2014-08-13 15:16:25 --> XSS Filtering completed
DEBUG - 2014-08-13 15:16:25 --> CRSF cookie Set
DEBUG - 2014-08-13 15:16:25 --> CSRF token verified
DEBUG - 2014-08-13 15:16:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:16:25 --> Language Class Initialized
DEBUG - 2014-08-13 15:16:25 --> Loader Class Initialized
DEBUG - 2014-08-13 15:16:25 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:16:25 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:16:25 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:16:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:16:25 --> Session Class Initialized
DEBUG - 2014-08-13 15:16:25 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:16:25 --> Session routines successfully run
DEBUG - 2014-08-13 15:16:25 --> Controller Class Initialized
DEBUG - 2014-08-13 15:16:25 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:16:25 --> Form Validation Class Initialized
DEBUG - 2014-08-13 15:16:25 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 15:16:25 --> XSS Filtering completed
DEBUG - 2014-08-13 15:16:25 --> XSS Filtering completed
DEBUG - 2014-08-13 15:16:25 --> XSS Filtering completed
DEBUG - 2014-08-13 15:16:25 --> XSS Filtering completed
DEBUG - 2014-08-13 15:16:25 --> XSS Filtering completed
DEBUG - 2014-08-13 15:16:25 --> XSS Filtering completed
DEBUG - 2014-08-13 15:16:25 --> XSS Filtering completed
DEBUG - 2014-08-13 15:16:25 --> XSS Filtering completed
DEBUG - 2014-08-13 15:16:25 --> XSS Filtering completed
DEBUG - 2014-08-13 15:16:25 --> XSS Filtering completed
DEBUG - 2014-08-13 15:16:25 --> XSS Filtering completed
DEBUG - 2014-08-13 15:16:25 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:16:25 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-13 15:16:25 --> Model Class Initialized
DEBUG - 2014-08-13 15:16:25 --> Model Class Initialized
DEBUG - 2014-08-13 15:16:25 --> Model Class Initialized
DEBUG - 2014-08-13 15:16:25 --> Model Class Initialized
DEBUG - 2014-08-13 15:16:25 --> Helper loaded: array_helper
DEBUG - 2014-08-13 15:16:25 --> File loaded: application/views/placement_students_update.php
DEBUG - 2014-08-13 15:16:25 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:16:25 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:16:25 --> Final output sent to browser
DEBUG - 2014-08-13 15:16:25 --> Total execution time: 0.1857
DEBUG - 2014-08-13 15:17:42 --> Config Class Initialized
DEBUG - 2014-08-13 15:17:42 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:17:42 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:17:42 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:17:42 --> URI Class Initialized
DEBUG - 2014-08-13 15:17:42 --> Router Class Initialized
DEBUG - 2014-08-13 15:17:42 --> Output Class Initialized
DEBUG - 2014-08-13 15:17:42 --> Security Class Initialized
DEBUG - 2014-08-13 15:17:42 --> Input Class Initialized
DEBUG - 2014-08-13 15:17:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:42 --> CRSF cookie Set
DEBUG - 2014-08-13 15:17:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:17:42 --> Language Class Initialized
DEBUG - 2014-08-13 15:17:42 --> Loader Class Initialized
DEBUG - 2014-08-13 15:17:42 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:17:42 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:17:42 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:17:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:17:42 --> Session Class Initialized
DEBUG - 2014-08-13 15:17:42 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:17:42 --> Session routines successfully run
DEBUG - 2014-08-13 15:17:42 --> Controller Class Initialized
DEBUG - 2014-08-13 15:17:42 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:17:42 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-13 15:17:42 --> Model Class Initialized
DEBUG - 2014-08-13 15:17:42 --> Model Class Initialized
DEBUG - 2014-08-13 15:17:42 --> Model Class Initialized
DEBUG - 2014-08-13 15:17:42 --> Model Class Initialized
DEBUG - 2014-08-13 15:17:42 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-13 15:17:42 --> File loaded: application/views/placement_under_construction_in.php
DEBUG - 2014-08-13 15:17:42 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:17:42 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:17:42 --> Final output sent to browser
DEBUG - 2014-08-13 15:17:42 --> Total execution time: 0.1089
DEBUG - 2014-08-13 15:17:43 --> Config Class Initialized
DEBUG - 2014-08-13 15:17:43 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:17:43 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:17:43 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:17:43 --> URI Class Initialized
DEBUG - 2014-08-13 15:17:43 --> Router Class Initialized
DEBUG - 2014-08-13 15:17:43 --> Output Class Initialized
DEBUG - 2014-08-13 15:17:43 --> Security Class Initialized
DEBUG - 2014-08-13 15:17:43 --> Input Class Initialized
DEBUG - 2014-08-13 15:17:43 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:43 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:43 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:43 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:43 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:43 --> CRSF cookie Set
DEBUG - 2014-08-13 15:17:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:17:43 --> Language Class Initialized
DEBUG - 2014-08-13 15:17:43 --> Loader Class Initialized
DEBUG - 2014-08-13 15:17:43 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:17:43 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:17:43 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:17:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:17:43 --> Session Class Initialized
DEBUG - 2014-08-13 15:17:43 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:17:43 --> Session routines successfully run
DEBUG - 2014-08-13 15:17:43 --> Controller Class Initialized
DEBUG - 2014-08-13 15:17:43 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:17:43 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-13 15:17:43 --> Model Class Initialized
DEBUG - 2014-08-13 15:17:43 --> Model Class Initialized
DEBUG - 2014-08-13 15:17:43 --> Model Class Initialized
DEBUG - 2014-08-13 15:17:43 --> Model Class Initialized
DEBUG - 2014-08-13 15:17:43 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-13 15:17:43 --> File loaded: application/views/placement_under_construction_in.php
DEBUG - 2014-08-13 15:17:43 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:17:43 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:17:43 --> Final output sent to browser
DEBUG - 2014-08-13 15:17:43 --> Total execution time: 0.1165
DEBUG - 2014-08-13 15:17:44 --> Config Class Initialized
DEBUG - 2014-08-13 15:17:44 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:17:44 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:17:44 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:17:44 --> URI Class Initialized
DEBUG - 2014-08-13 15:17:44 --> Router Class Initialized
DEBUG - 2014-08-13 15:17:44 --> Output Class Initialized
DEBUG - 2014-08-13 15:17:44 --> Security Class Initialized
DEBUG - 2014-08-13 15:17:44 --> Input Class Initialized
DEBUG - 2014-08-13 15:17:44 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:44 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:44 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:44 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:44 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:44 --> CRSF cookie Set
DEBUG - 2014-08-13 15:17:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:17:44 --> Language Class Initialized
DEBUG - 2014-08-13 15:17:44 --> Loader Class Initialized
DEBUG - 2014-08-13 15:17:44 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:17:44 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:17:44 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:17:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:17:44 --> Session Class Initialized
DEBUG - 2014-08-13 15:17:44 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:17:44 --> Session routines successfully run
DEBUG - 2014-08-13 15:17:44 --> Controller Class Initialized
DEBUG - 2014-08-13 15:17:44 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:17:44 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-13 15:17:44 --> Model Class Initialized
DEBUG - 2014-08-13 15:17:44 --> Model Class Initialized
DEBUG - 2014-08-13 15:17:44 --> Model Class Initialized
DEBUG - 2014-08-13 15:17:44 --> Model Class Initialized
DEBUG - 2014-08-13 15:17:44 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-13 15:17:44 --> File loaded: application/views/placement_under_construction_in.php
DEBUG - 2014-08-13 15:17:44 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:17:44 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:17:44 --> Final output sent to browser
DEBUG - 2014-08-13 15:17:44 --> Total execution time: 0.1119
DEBUG - 2014-08-13 15:17:45 --> Config Class Initialized
DEBUG - 2014-08-13 15:17:45 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:17:45 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:17:45 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:17:45 --> URI Class Initialized
DEBUG - 2014-08-13 15:17:45 --> Router Class Initialized
DEBUG - 2014-08-13 15:17:45 --> Output Class Initialized
DEBUG - 2014-08-13 15:17:45 --> Security Class Initialized
DEBUG - 2014-08-13 15:17:45 --> Input Class Initialized
DEBUG - 2014-08-13 15:17:45 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:45 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:45 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:45 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:45 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:45 --> CRSF cookie Set
DEBUG - 2014-08-13 15:17:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:17:45 --> Language Class Initialized
DEBUG - 2014-08-13 15:17:45 --> Loader Class Initialized
DEBUG - 2014-08-13 15:17:45 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:17:45 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:17:45 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:17:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:17:45 --> Session Class Initialized
DEBUG - 2014-08-13 15:17:45 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:17:45 --> Session routines successfully run
DEBUG - 2014-08-13 15:17:45 --> Controller Class Initialized
DEBUG - 2014-08-13 15:17:45 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:17:45 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-13 15:17:45 --> Model Class Initialized
DEBUG - 2014-08-13 15:17:45 --> Model Class Initialized
DEBUG - 2014-08-13 15:17:45 --> Model Class Initialized
DEBUG - 2014-08-13 15:17:45 --> Model Class Initialized
DEBUG - 2014-08-13 15:17:45 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-13 15:17:45 --> File loaded: application/views/placement_under_construction_in.php
DEBUG - 2014-08-13 15:17:45 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:17:45 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:17:45 --> Final output sent to browser
DEBUG - 2014-08-13 15:17:45 --> Total execution time: 0.1490
DEBUG - 2014-08-13 15:17:46 --> Config Class Initialized
DEBUG - 2014-08-13 15:17:46 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:17:46 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:17:46 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:17:46 --> URI Class Initialized
DEBUG - 2014-08-13 15:17:46 --> Router Class Initialized
DEBUG - 2014-08-13 15:17:46 --> Output Class Initialized
DEBUG - 2014-08-13 15:17:46 --> Security Class Initialized
DEBUG - 2014-08-13 15:17:46 --> Input Class Initialized
DEBUG - 2014-08-13 15:17:46 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:46 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:46 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:46 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:46 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:46 --> CRSF cookie Set
DEBUG - 2014-08-13 15:17:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:17:46 --> Language Class Initialized
DEBUG - 2014-08-13 15:17:46 --> Loader Class Initialized
DEBUG - 2014-08-13 15:17:46 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:17:46 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:17:46 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:17:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:17:46 --> Session Class Initialized
DEBUG - 2014-08-13 15:17:46 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:17:46 --> Session routines successfully run
DEBUG - 2014-08-13 15:17:46 --> Controller Class Initialized
DEBUG - 2014-08-13 15:17:46 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:17:46 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-13 15:17:46 --> Model Class Initialized
DEBUG - 2014-08-13 15:17:46 --> Model Class Initialized
DEBUG - 2014-08-13 15:17:46 --> Model Class Initialized
DEBUG - 2014-08-13 15:17:46 --> Model Class Initialized
DEBUG - 2014-08-13 15:17:46 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-13 15:17:46 --> File loaded: application/views/placement_under_construction_in.php
DEBUG - 2014-08-13 15:17:46 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:17:46 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:17:46 --> Final output sent to browser
DEBUG - 2014-08-13 15:17:46 --> Total execution time: 0.1119
DEBUG - 2014-08-13 15:17:47 --> Config Class Initialized
DEBUG - 2014-08-13 15:17:47 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:17:47 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:17:47 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:17:47 --> URI Class Initialized
DEBUG - 2014-08-13 15:17:47 --> Router Class Initialized
DEBUG - 2014-08-13 15:17:47 --> Output Class Initialized
DEBUG - 2014-08-13 15:17:47 --> Security Class Initialized
DEBUG - 2014-08-13 15:17:47 --> Input Class Initialized
DEBUG - 2014-08-13 15:17:47 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:47 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:47 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:47 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:47 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:47 --> CRSF cookie Set
DEBUG - 2014-08-13 15:17:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:17:47 --> Language Class Initialized
DEBUG - 2014-08-13 15:17:47 --> Loader Class Initialized
DEBUG - 2014-08-13 15:17:47 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:17:47 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:17:47 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:17:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:17:47 --> Session Class Initialized
DEBUG - 2014-08-13 15:17:47 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:17:47 --> Session routines successfully run
DEBUG - 2014-08-13 15:17:47 --> Controller Class Initialized
DEBUG - 2014-08-13 15:17:47 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:17:47 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-13 15:17:47 --> Model Class Initialized
DEBUG - 2014-08-13 15:17:47 --> Model Class Initialized
DEBUG - 2014-08-13 15:17:47 --> Model Class Initialized
DEBUG - 2014-08-13 15:17:47 --> Model Class Initialized
DEBUG - 2014-08-13 15:17:47 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-13 15:17:47 --> File loaded: application/views/placement_under_construction_in.php
DEBUG - 2014-08-13 15:17:47 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:17:47 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:17:47 --> Final output sent to browser
DEBUG - 2014-08-13 15:17:47 --> Total execution time: 0.1221
DEBUG - 2014-08-13 15:17:48 --> Config Class Initialized
DEBUG - 2014-08-13 15:17:48 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:17:48 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:17:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:17:48 --> URI Class Initialized
DEBUG - 2014-08-13 15:17:48 --> Router Class Initialized
DEBUG - 2014-08-13 15:17:48 --> Output Class Initialized
DEBUG - 2014-08-13 15:17:48 --> Security Class Initialized
DEBUG - 2014-08-13 15:17:48 --> Input Class Initialized
DEBUG - 2014-08-13 15:17:48 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:48 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:48 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:48 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:48 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:48 --> CRSF cookie Set
DEBUG - 2014-08-13 15:17:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:17:48 --> Language Class Initialized
DEBUG - 2014-08-13 15:17:48 --> Loader Class Initialized
DEBUG - 2014-08-13 15:17:48 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:17:48 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:17:48 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:17:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:17:48 --> Session Class Initialized
DEBUG - 2014-08-13 15:17:48 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:17:48 --> Session routines successfully run
DEBUG - 2014-08-13 15:17:48 --> Controller Class Initialized
DEBUG - 2014-08-13 15:17:48 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:17:48 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-13 15:17:48 --> Model Class Initialized
DEBUG - 2014-08-13 15:17:48 --> Model Class Initialized
DEBUG - 2014-08-13 15:17:48 --> Model Class Initialized
DEBUG - 2014-08-13 15:17:48 --> Model Class Initialized
DEBUG - 2014-08-13 15:17:48 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-13 15:17:48 --> File loaded: application/views/placement_under_construction_in.php
DEBUG - 2014-08-13 15:17:48 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:17:48 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:17:48 --> Final output sent to browser
DEBUG - 2014-08-13 15:17:48 --> Total execution time: 0.1081
DEBUG - 2014-08-13 15:17:49 --> Config Class Initialized
DEBUG - 2014-08-13 15:17:49 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:17:49 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:17:49 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:17:49 --> URI Class Initialized
DEBUG - 2014-08-13 15:17:49 --> Router Class Initialized
DEBUG - 2014-08-13 15:17:49 --> Output Class Initialized
DEBUG - 2014-08-13 15:17:49 --> Security Class Initialized
DEBUG - 2014-08-13 15:17:49 --> Input Class Initialized
DEBUG - 2014-08-13 15:17:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:49 --> CRSF cookie Set
DEBUG - 2014-08-13 15:17:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:17:49 --> Language Class Initialized
DEBUG - 2014-08-13 15:17:49 --> Loader Class Initialized
DEBUG - 2014-08-13 15:17:49 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:17:49 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:17:49 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:17:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:17:49 --> Session Class Initialized
DEBUG - 2014-08-13 15:17:49 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:17:49 --> Session routines successfully run
DEBUG - 2014-08-13 15:17:49 --> Controller Class Initialized
DEBUG - 2014-08-13 15:17:49 --> File loaded: application/views/logout.php
DEBUG - 2014-08-13 15:17:49 --> Final output sent to browser
DEBUG - 2014-08-13 15:17:49 --> Total execution time: 0.0916
DEBUG - 2014-08-13 15:17:49 --> Config Class Initialized
DEBUG - 2014-08-13 15:17:49 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:17:49 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:17:49 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:17:49 --> URI Class Initialized
DEBUG - 2014-08-13 15:17:49 --> Router Class Initialized
DEBUG - 2014-08-13 15:17:49 --> No URI present. Default controller set.
DEBUG - 2014-08-13 15:17:49 --> Output Class Initialized
DEBUG - 2014-08-13 15:17:49 --> Security Class Initialized
DEBUG - 2014-08-13 15:17:49 --> Input Class Initialized
DEBUG - 2014-08-13 15:17:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:17:49 --> CRSF cookie Set
DEBUG - 2014-08-13 15:17:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:17:49 --> Language Class Initialized
DEBUG - 2014-08-13 15:17:49 --> Loader Class Initialized
DEBUG - 2014-08-13 15:17:49 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:17:49 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:17:49 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:17:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:17:49 --> Session Class Initialized
DEBUG - 2014-08-13 15:17:49 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:17:49 --> A session cookie was not found.
DEBUG - 2014-08-13 15:17:49 --> Session routines successfully run
DEBUG - 2014-08-13 15:17:49 --> Controller Class Initialized
DEBUG - 2014-08-13 15:17:49 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:17:49 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 15:17:49 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 15:17:49 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:17:49 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 15:17:49 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 15:17:49 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:17:49 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:17:49 --> Final output sent to browser
DEBUG - 2014-08-13 15:17:49 --> Total execution time: 0.1284
DEBUG - 2014-08-13 15:19:21 --> Config Class Initialized
DEBUG - 2014-08-13 15:19:21 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:19:21 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:19:21 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:19:21 --> URI Class Initialized
DEBUG - 2014-08-13 15:19:21 --> Router Class Initialized
DEBUG - 2014-08-13 15:19:21 --> Output Class Initialized
DEBUG - 2014-08-13 15:19:21 --> Security Class Initialized
DEBUG - 2014-08-13 15:19:21 --> Input Class Initialized
DEBUG - 2014-08-13 15:19:21 --> XSS Filtering completed
DEBUG - 2014-08-13 15:19:22 --> XSS Filtering completed
DEBUG - 2014-08-13 15:19:22 --> XSS Filtering completed
DEBUG - 2014-08-13 15:19:22 --> XSS Filtering completed
DEBUG - 2014-08-13 15:19:22 --> XSS Filtering completed
DEBUG - 2014-08-13 15:19:22 --> XSS Filtering completed
DEBUG - 2014-08-13 15:19:22 --> XSS Filtering completed
DEBUG - 2014-08-13 15:19:22 --> XSS Filtering completed
DEBUG - 2014-08-13 15:19:22 --> CRSF cookie Set
DEBUG - 2014-08-13 15:19:22 --> CSRF token verified
DEBUG - 2014-08-13 15:19:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:19:22 --> Language Class Initialized
DEBUG - 2014-08-13 15:19:22 --> Loader Class Initialized
DEBUG - 2014-08-13 15:19:22 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:19:22 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:19:22 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:19:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:19:22 --> Session Class Initialized
DEBUG - 2014-08-13 15:19:22 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:19:22 --> Session routines successfully run
DEBUG - 2014-08-13 15:19:22 --> Controller Class Initialized
DEBUG - 2014-08-13 15:19:22 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:19:22 --> Form Validation Class Initialized
DEBUG - 2014-08-13 15:19:22 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 15:19:22 --> XSS Filtering completed
DEBUG - 2014-08-13 15:19:22 --> XSS Filtering completed
DEBUG - 2014-08-13 15:19:22 --> Model Class Initialized
DEBUG - 2014-08-13 15:19:22 --> Model Class Initialized
DEBUG - 2014-08-13 15:19:22 --> Encrypt Class Initialized
DEBUG - 2014-08-13 15:19:22 --> XSS Filtering completed
DEBUG - 2014-08-13 15:19:22 --> XSS Filtering completed
DEBUG - 2014-08-13 15:19:22 --> Config Class Initialized
DEBUG - 2014-08-13 15:19:22 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:19:22 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:19:22 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:19:22 --> URI Class Initialized
DEBUG - 2014-08-13 15:19:22 --> Router Class Initialized
DEBUG - 2014-08-13 15:19:22 --> Output Class Initialized
DEBUG - 2014-08-13 15:19:22 --> Security Class Initialized
DEBUG - 2014-08-13 15:19:22 --> Input Class Initialized
DEBUG - 2014-08-13 15:19:22 --> XSS Filtering completed
DEBUG - 2014-08-13 15:19:22 --> XSS Filtering completed
DEBUG - 2014-08-13 15:19:22 --> XSS Filtering completed
DEBUG - 2014-08-13 15:19:22 --> XSS Filtering completed
DEBUG - 2014-08-13 15:19:22 --> XSS Filtering completed
DEBUG - 2014-08-13 15:19:22 --> CRSF cookie Set
DEBUG - 2014-08-13 15:19:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:19:22 --> Language Class Initialized
DEBUG - 2014-08-13 15:19:22 --> Loader Class Initialized
DEBUG - 2014-08-13 15:19:22 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:19:22 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:19:22 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:19:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:19:22 --> Session Class Initialized
DEBUG - 2014-08-13 15:19:22 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:19:22 --> Session routines successfully run
DEBUG - 2014-08-13 15:19:22 --> Controller Class Initialized
DEBUG - 2014-08-13 15:19:22 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:19:22 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-13 15:19:22 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-13 15:19:22 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 15:19:22 --> File loaded: application/views/placement_admin_home.php
DEBUG - 2014-08-13 15:19:22 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:19:22 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:19:22 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-13 15:19:22 --> Final output sent to browser
DEBUG - 2014-08-13 15:19:22 --> Total execution time: 0.1259
DEBUG - 2014-08-13 15:19:26 --> Config Class Initialized
DEBUG - 2014-08-13 15:19:26 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:19:26 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:19:26 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:19:26 --> URI Class Initialized
DEBUG - 2014-08-13 15:19:26 --> Router Class Initialized
DEBUG - 2014-08-13 15:19:26 --> Output Class Initialized
DEBUG - 2014-08-13 15:19:26 --> Security Class Initialized
DEBUG - 2014-08-13 15:19:26 --> Input Class Initialized
DEBUG - 2014-08-13 15:19:26 --> XSS Filtering completed
DEBUG - 2014-08-13 15:19:26 --> XSS Filtering completed
DEBUG - 2014-08-13 15:19:26 --> XSS Filtering completed
DEBUG - 2014-08-13 15:19:26 --> XSS Filtering completed
DEBUG - 2014-08-13 15:19:26 --> XSS Filtering completed
DEBUG - 2014-08-13 15:19:26 --> CRSF cookie Set
DEBUG - 2014-08-13 15:19:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:19:26 --> Language Class Initialized
DEBUG - 2014-08-13 15:19:26 --> Loader Class Initialized
DEBUG - 2014-08-13 15:19:26 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:19:26 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:19:26 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:19:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:19:26 --> Session Class Initialized
DEBUG - 2014-08-13 15:19:26 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:19:26 --> Session routines successfully run
DEBUG - 2014-08-13 15:19:26 --> Controller Class Initialized
DEBUG - 2014-08-13 15:19:26 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:19:26 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-13 15:19:26 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-13 15:19:26 --> File loaded: application/views/placement_admin_history.php
DEBUG - 2014-08-13 15:19:26 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:19:26 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:19:26 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-13 15:19:26 --> Final output sent to browser
DEBUG - 2014-08-13 15:19:26 --> Total execution time: 0.0986
DEBUG - 2014-08-13 15:27:57 --> Config Class Initialized
DEBUG - 2014-08-13 15:27:57 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:27:57 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:27:57 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:27:57 --> URI Class Initialized
DEBUG - 2014-08-13 15:27:57 --> Router Class Initialized
DEBUG - 2014-08-13 15:27:57 --> Output Class Initialized
DEBUG - 2014-08-13 15:27:57 --> Security Class Initialized
DEBUG - 2014-08-13 15:27:57 --> Input Class Initialized
DEBUG - 2014-08-13 15:27:57 --> XSS Filtering completed
DEBUG - 2014-08-13 15:27:57 --> XSS Filtering completed
DEBUG - 2014-08-13 15:27:57 --> XSS Filtering completed
DEBUG - 2014-08-13 15:27:57 --> XSS Filtering completed
DEBUG - 2014-08-13 15:27:57 --> XSS Filtering completed
DEBUG - 2014-08-13 15:27:57 --> CRSF cookie Set
DEBUG - 2014-08-13 15:27:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:27:57 --> Language Class Initialized
DEBUG - 2014-08-13 15:27:57 --> Loader Class Initialized
DEBUG - 2014-08-13 15:27:57 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:27:57 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:27:57 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:27:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:27:57 --> Session Class Initialized
DEBUG - 2014-08-13 15:27:57 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:27:57 --> Session routines successfully run
DEBUG - 2014-08-13 15:27:57 --> Controller Class Initialized
DEBUG - 2014-08-13 15:27:57 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:27:57 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-13 15:27:57 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-13 15:27:57 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 15:27:57 --> File loaded: application/views/placement_admin_home.php
DEBUG - 2014-08-13 15:27:57 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:27:57 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:27:57 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-13 15:27:57 --> Final output sent to browser
DEBUG - 2014-08-13 15:27:57 --> Total execution time: 0.0970
DEBUG - 2014-08-13 15:28:03 --> Config Class Initialized
DEBUG - 2014-08-13 15:28:03 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:28:03 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:28:03 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:28:03 --> URI Class Initialized
DEBUG - 2014-08-13 15:28:03 --> Router Class Initialized
DEBUG - 2014-08-13 15:28:03 --> Output Class Initialized
DEBUG - 2014-08-13 15:28:03 --> Security Class Initialized
DEBUG - 2014-08-13 15:28:03 --> Input Class Initialized
DEBUG - 2014-08-13 15:28:03 --> XSS Filtering completed
DEBUG - 2014-08-13 15:28:03 --> XSS Filtering completed
DEBUG - 2014-08-13 15:28:03 --> XSS Filtering completed
DEBUG - 2014-08-13 15:28:03 --> XSS Filtering completed
DEBUG - 2014-08-13 15:28:03 --> XSS Filtering completed
DEBUG - 2014-08-13 15:28:03 --> CRSF cookie Set
DEBUG - 2014-08-13 15:28:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:28:03 --> Language Class Initialized
DEBUG - 2014-08-13 15:28:03 --> Loader Class Initialized
DEBUG - 2014-08-13 15:28:03 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:28:03 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:28:03 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:28:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:28:03 --> Session Class Initialized
DEBUG - 2014-08-13 15:28:03 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:28:03 --> Session routines successfully run
DEBUG - 2014-08-13 15:28:03 --> Controller Class Initialized
DEBUG - 2014-08-13 15:28:03 --> File loaded: application/views/logout.php
DEBUG - 2014-08-13 15:28:03 --> Final output sent to browser
DEBUG - 2014-08-13 15:28:03 --> Total execution time: 0.0806
DEBUG - 2014-08-13 15:28:03 --> Config Class Initialized
DEBUG - 2014-08-13 15:28:03 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:28:03 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:28:03 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:28:03 --> URI Class Initialized
DEBUG - 2014-08-13 15:28:03 --> Router Class Initialized
DEBUG - 2014-08-13 15:28:03 --> No URI present. Default controller set.
DEBUG - 2014-08-13 15:28:03 --> Output Class Initialized
DEBUG - 2014-08-13 15:28:03 --> Security Class Initialized
DEBUG - 2014-08-13 15:28:03 --> Input Class Initialized
DEBUG - 2014-08-13 15:28:03 --> XSS Filtering completed
DEBUG - 2014-08-13 15:28:03 --> XSS Filtering completed
DEBUG - 2014-08-13 15:28:03 --> XSS Filtering completed
DEBUG - 2014-08-13 15:28:03 --> XSS Filtering completed
DEBUG - 2014-08-13 15:28:03 --> CRSF cookie Set
DEBUG - 2014-08-13 15:28:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:28:03 --> Language Class Initialized
DEBUG - 2014-08-13 15:28:03 --> Loader Class Initialized
DEBUG - 2014-08-13 15:28:03 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:28:03 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:28:03 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:28:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:28:03 --> Session Class Initialized
DEBUG - 2014-08-13 15:28:03 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:28:03 --> A session cookie was not found.
DEBUG - 2014-08-13 15:28:03 --> Session routines successfully run
DEBUG - 2014-08-13 15:28:03 --> Controller Class Initialized
DEBUG - 2014-08-13 15:28:03 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:28:03 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 15:28:03 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 15:28:03 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:28:03 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 15:28:03 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 15:28:03 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:28:03 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:28:03 --> Final output sent to browser
DEBUG - 2014-08-13 15:28:03 --> Total execution time: 0.1226
DEBUG - 2014-08-13 15:28:09 --> Config Class Initialized
DEBUG - 2014-08-13 15:28:09 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:28:09 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:28:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:28:09 --> URI Class Initialized
DEBUG - 2014-08-13 15:28:09 --> Router Class Initialized
DEBUG - 2014-08-13 15:28:09 --> Output Class Initialized
DEBUG - 2014-08-13 15:28:09 --> Security Class Initialized
DEBUG - 2014-08-13 15:28:09 --> Input Class Initialized
DEBUG - 2014-08-13 15:28:09 --> XSS Filtering completed
DEBUG - 2014-08-13 15:28:09 --> XSS Filtering completed
DEBUG - 2014-08-13 15:28:09 --> XSS Filtering completed
DEBUG - 2014-08-13 15:28:09 --> XSS Filtering completed
DEBUG - 2014-08-13 15:28:09 --> XSS Filtering completed
DEBUG - 2014-08-13 15:28:09 --> CRSF cookie Set
DEBUG - 2014-08-13 15:28:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:28:09 --> Language Class Initialized
DEBUG - 2014-08-13 15:28:09 --> Loader Class Initialized
DEBUG - 2014-08-13 15:28:09 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:28:09 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:28:09 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:28:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:28:09 --> Session Class Initialized
DEBUG - 2014-08-13 15:28:09 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:28:09 --> Session routines successfully run
DEBUG - 2014-08-13 15:28:09 --> Controller Class Initialized
DEBUG - 2014-08-13 15:28:09 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:28:09 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 15:28:09 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-13 15:28:09 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 15:28:09 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:28:09 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 15:28:09 --> File loaded: application/views/placement_history.php
DEBUG - 2014-08-13 15:28:09 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:28:09 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:28:09 --> Final output sent to browser
DEBUG - 2014-08-13 15:28:09 --> Total execution time: 0.1062
DEBUG - 2014-08-13 15:28:12 --> Config Class Initialized
DEBUG - 2014-08-13 15:28:12 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:28:12 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:28:12 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:28:12 --> URI Class Initialized
DEBUG - 2014-08-13 15:28:12 --> Router Class Initialized
DEBUG - 2014-08-13 15:28:12 --> Output Class Initialized
DEBUG - 2014-08-13 15:28:12 --> Security Class Initialized
DEBUG - 2014-08-13 15:28:12 --> Input Class Initialized
DEBUG - 2014-08-13 15:28:12 --> XSS Filtering completed
DEBUG - 2014-08-13 15:28:12 --> XSS Filtering completed
DEBUG - 2014-08-13 15:28:12 --> XSS Filtering completed
DEBUG - 2014-08-13 15:28:12 --> XSS Filtering completed
DEBUG - 2014-08-13 15:28:12 --> XSS Filtering completed
DEBUG - 2014-08-13 15:28:12 --> CRSF cookie Set
DEBUG - 2014-08-13 15:28:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:28:12 --> Language Class Initialized
DEBUG - 2014-08-13 15:28:12 --> Loader Class Initialized
DEBUG - 2014-08-13 15:28:12 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:28:12 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:28:12 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:28:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:28:12 --> Session Class Initialized
DEBUG - 2014-08-13 15:28:12 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:28:12 --> Session routines successfully run
DEBUG - 2014-08-13 15:28:12 --> Controller Class Initialized
DEBUG - 2014-08-13 15:28:12 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:28:12 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 15:28:12 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 15:28:12 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:28:12 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 15:28:12 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 15:28:12 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:28:12 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:28:12 --> Final output sent to browser
DEBUG - 2014-08-13 15:28:12 --> Total execution time: 0.1082
DEBUG - 2014-08-13 15:28:48 --> Config Class Initialized
DEBUG - 2014-08-13 15:28:48 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:28:48 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:28:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:28:48 --> URI Class Initialized
DEBUG - 2014-08-13 15:28:48 --> Router Class Initialized
DEBUG - 2014-08-13 15:28:48 --> Output Class Initialized
DEBUG - 2014-08-13 15:28:48 --> Security Class Initialized
DEBUG - 2014-08-13 15:28:48 --> Input Class Initialized
DEBUG - 2014-08-13 15:28:48 --> XSS Filtering completed
DEBUG - 2014-08-13 15:28:48 --> XSS Filtering completed
DEBUG - 2014-08-13 15:28:48 --> XSS Filtering completed
DEBUG - 2014-08-13 15:28:48 --> XSS Filtering completed
DEBUG - 2014-08-13 15:28:48 --> XSS Filtering completed
DEBUG - 2014-08-13 15:28:48 --> CRSF cookie Set
DEBUG - 2014-08-13 15:28:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:28:48 --> Language Class Initialized
DEBUG - 2014-08-13 15:28:48 --> Loader Class Initialized
DEBUG - 2014-08-13 15:28:48 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:28:48 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:28:48 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:28:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:28:48 --> Session Class Initialized
DEBUG - 2014-08-13 15:28:48 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:28:48 --> Session routines successfully run
DEBUG - 2014-08-13 15:28:48 --> Controller Class Initialized
DEBUG - 2014-08-13 15:28:48 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:28:48 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 15:28:48 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 15:28:48 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:28:48 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 15:28:48 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 15:28:48 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:28:48 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:28:48 --> Final output sent to browser
DEBUG - 2014-08-13 15:28:48 --> Total execution time: 0.1589
DEBUG - 2014-08-13 15:30:28 --> Config Class Initialized
DEBUG - 2014-08-13 15:30:28 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:30:28 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:30:28 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:30:28 --> URI Class Initialized
DEBUG - 2014-08-13 15:30:28 --> Router Class Initialized
DEBUG - 2014-08-13 15:30:28 --> Output Class Initialized
DEBUG - 2014-08-13 15:30:28 --> Security Class Initialized
DEBUG - 2014-08-13 15:30:28 --> Input Class Initialized
DEBUG - 2014-08-13 15:30:28 --> XSS Filtering completed
DEBUG - 2014-08-13 15:30:28 --> XSS Filtering completed
DEBUG - 2014-08-13 15:30:28 --> XSS Filtering completed
DEBUG - 2014-08-13 15:30:28 --> XSS Filtering completed
DEBUG - 2014-08-13 15:30:28 --> XSS Filtering completed
DEBUG - 2014-08-13 15:30:28 --> CRSF cookie Set
DEBUG - 2014-08-13 15:30:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:30:28 --> Language Class Initialized
DEBUG - 2014-08-13 15:30:28 --> Loader Class Initialized
DEBUG - 2014-08-13 15:30:28 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:30:28 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:30:28 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:30:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:30:28 --> Session Class Initialized
DEBUG - 2014-08-13 15:30:28 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:30:28 --> Session routines successfully run
DEBUG - 2014-08-13 15:30:28 --> Controller Class Initialized
DEBUG - 2014-08-13 15:30:28 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:30:28 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 15:30:28 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 15:30:28 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:30:28 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 15:30:28 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 15:30:28 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:30:28 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:30:28 --> Final output sent to browser
DEBUG - 2014-08-13 15:30:28 --> Total execution time: 0.1046
DEBUG - 2014-08-13 15:32:36 --> Config Class Initialized
DEBUG - 2014-08-13 15:32:36 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:32:36 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:32:36 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:32:36 --> URI Class Initialized
DEBUG - 2014-08-13 15:32:36 --> Router Class Initialized
DEBUG - 2014-08-13 15:32:36 --> Output Class Initialized
DEBUG - 2014-08-13 15:32:36 --> Security Class Initialized
DEBUG - 2014-08-13 15:32:36 --> Input Class Initialized
DEBUG - 2014-08-13 15:32:36 --> XSS Filtering completed
DEBUG - 2014-08-13 15:32:36 --> XSS Filtering completed
DEBUG - 2014-08-13 15:32:36 --> XSS Filtering completed
DEBUG - 2014-08-13 15:32:36 --> XSS Filtering completed
DEBUG - 2014-08-13 15:32:36 --> XSS Filtering completed
DEBUG - 2014-08-13 15:32:36 --> CRSF cookie Set
DEBUG - 2014-08-13 15:32:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:32:36 --> Language Class Initialized
DEBUG - 2014-08-13 15:32:36 --> Loader Class Initialized
DEBUG - 2014-08-13 15:32:36 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:32:36 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:32:36 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:32:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:32:36 --> Session Class Initialized
DEBUG - 2014-08-13 15:32:36 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:32:36 --> Session routines successfully run
DEBUG - 2014-08-13 15:32:36 --> Controller Class Initialized
DEBUG - 2014-08-13 15:32:36 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:32:36 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 15:32:36 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 15:32:36 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:32:36 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 15:32:36 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 15:32:36 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:32:36 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:32:36 --> Final output sent to browser
DEBUG - 2014-08-13 15:32:36 --> Total execution time: 0.1150
DEBUG - 2014-08-13 15:33:00 --> Config Class Initialized
DEBUG - 2014-08-13 15:33:00 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:33:00 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:33:00 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:33:00 --> URI Class Initialized
DEBUG - 2014-08-13 15:33:00 --> Router Class Initialized
DEBUG - 2014-08-13 15:33:00 --> Output Class Initialized
DEBUG - 2014-08-13 15:33:00 --> Security Class Initialized
DEBUG - 2014-08-13 15:33:00 --> Input Class Initialized
DEBUG - 2014-08-13 15:33:00 --> XSS Filtering completed
DEBUG - 2014-08-13 15:33:00 --> XSS Filtering completed
DEBUG - 2014-08-13 15:33:00 --> XSS Filtering completed
DEBUG - 2014-08-13 15:33:00 --> XSS Filtering completed
DEBUG - 2014-08-13 15:33:00 --> XSS Filtering completed
DEBUG - 2014-08-13 15:33:00 --> XSS Filtering completed
DEBUG - 2014-08-13 15:33:00 --> XSS Filtering completed
DEBUG - 2014-08-13 15:33:00 --> XSS Filtering completed
DEBUG - 2014-08-13 15:33:00 --> CRSF cookie Set
DEBUG - 2014-08-13 15:33:00 --> CSRF token verified
DEBUG - 2014-08-13 15:33:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:33:00 --> Language Class Initialized
DEBUG - 2014-08-13 15:33:00 --> Loader Class Initialized
DEBUG - 2014-08-13 15:33:00 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:33:00 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:33:00 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:33:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:33:00 --> Session Class Initialized
DEBUG - 2014-08-13 15:33:00 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:33:00 --> Session routines successfully run
DEBUG - 2014-08-13 15:33:00 --> Controller Class Initialized
DEBUG - 2014-08-13 15:33:00 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:33:00 --> Form Validation Class Initialized
DEBUG - 2014-08-13 15:33:00 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 15:33:00 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:33:00 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 15:33:00 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 15:33:00 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 15:33:00 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 15:33:00 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:33:00 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:33:00 --> Final output sent to browser
DEBUG - 2014-08-13 15:33:00 --> Total execution time: 0.1186
DEBUG - 2014-08-13 15:33:09 --> Config Class Initialized
DEBUG - 2014-08-13 15:33:09 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:33:09 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:33:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:33:09 --> URI Class Initialized
DEBUG - 2014-08-13 15:33:09 --> Router Class Initialized
DEBUG - 2014-08-13 15:33:09 --> Output Class Initialized
DEBUG - 2014-08-13 15:33:09 --> Security Class Initialized
DEBUG - 2014-08-13 15:33:09 --> Input Class Initialized
DEBUG - 2014-08-13 15:33:09 --> XSS Filtering completed
DEBUG - 2014-08-13 15:33:09 --> XSS Filtering completed
DEBUG - 2014-08-13 15:33:09 --> XSS Filtering completed
DEBUG - 2014-08-13 15:33:09 --> XSS Filtering completed
DEBUG - 2014-08-13 15:33:09 --> XSS Filtering completed
DEBUG - 2014-08-13 15:33:10 --> CRSF cookie Set
DEBUG - 2014-08-13 15:33:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:33:10 --> Language Class Initialized
DEBUG - 2014-08-13 15:33:10 --> Loader Class Initialized
DEBUG - 2014-08-13 15:33:10 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:33:10 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:33:10 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:33:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:33:10 --> Session Class Initialized
DEBUG - 2014-08-13 15:33:10 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:33:10 --> Session routines successfully run
DEBUG - 2014-08-13 15:33:10 --> Controller Class Initialized
DEBUG - 2014-08-13 15:33:10 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:33:10 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 15:33:10 --> File loaded: application/views/404.php
DEBUG - 2014-08-13 15:33:10 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:33:10 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:33:10 --> Final output sent to browser
DEBUG - 2014-08-13 15:33:10 --> Total execution time: 0.0924
DEBUG - 2014-08-13 15:33:14 --> Config Class Initialized
DEBUG - 2014-08-13 15:33:14 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:33:14 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:33:14 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:33:14 --> URI Class Initialized
DEBUG - 2014-08-13 15:33:14 --> Router Class Initialized
DEBUG - 2014-08-13 15:33:14 --> Output Class Initialized
DEBUG - 2014-08-13 15:33:14 --> Security Class Initialized
DEBUG - 2014-08-13 15:33:14 --> Input Class Initialized
DEBUG - 2014-08-13 15:33:14 --> XSS Filtering completed
DEBUG - 2014-08-13 15:33:14 --> XSS Filtering completed
DEBUG - 2014-08-13 15:33:14 --> XSS Filtering completed
DEBUG - 2014-08-13 15:33:14 --> XSS Filtering completed
DEBUG - 2014-08-13 15:33:14 --> XSS Filtering completed
DEBUG - 2014-08-13 15:33:14 --> CRSF cookie Set
DEBUG - 2014-08-13 15:33:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:33:14 --> Language Class Initialized
DEBUG - 2014-08-13 15:33:14 --> Loader Class Initialized
DEBUG - 2014-08-13 15:33:14 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:33:14 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:33:14 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:33:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:33:14 --> Session Class Initialized
DEBUG - 2014-08-13 15:33:14 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:33:15 --> Session routines successfully run
DEBUG - 2014-08-13 15:33:15 --> Controller Class Initialized
DEBUG - 2014-08-13 15:33:15 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:33:15 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 15:33:15 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 15:33:15 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:33:15 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 15:33:15 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 15:33:15 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:33:15 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:33:15 --> Final output sent to browser
DEBUG - 2014-08-13 15:33:15 --> Total execution time: 0.0973
DEBUG - 2014-08-13 15:34:41 --> Config Class Initialized
DEBUG - 2014-08-13 15:34:41 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:34:41 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:34:41 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:34:41 --> URI Class Initialized
DEBUG - 2014-08-13 15:34:41 --> Router Class Initialized
DEBUG - 2014-08-13 15:34:41 --> Output Class Initialized
DEBUG - 2014-08-13 15:34:41 --> Security Class Initialized
DEBUG - 2014-08-13 15:34:41 --> Input Class Initialized
DEBUG - 2014-08-13 15:34:41 --> XSS Filtering completed
DEBUG - 2014-08-13 15:34:41 --> XSS Filtering completed
DEBUG - 2014-08-13 15:34:41 --> XSS Filtering completed
DEBUG - 2014-08-13 15:34:41 --> XSS Filtering completed
DEBUG - 2014-08-13 15:34:41 --> XSS Filtering completed
DEBUG - 2014-08-13 15:34:41 --> XSS Filtering completed
DEBUG - 2014-08-13 15:34:41 --> XSS Filtering completed
DEBUG - 2014-08-13 15:34:41 --> XSS Filtering completed
DEBUG - 2014-08-13 15:34:41 --> CRSF cookie Set
DEBUG - 2014-08-13 15:34:41 --> CSRF token verified
DEBUG - 2014-08-13 15:34:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:34:41 --> Language Class Initialized
DEBUG - 2014-08-13 15:34:41 --> Loader Class Initialized
DEBUG - 2014-08-13 15:34:41 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:34:41 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:34:41 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:34:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:34:41 --> Session Class Initialized
DEBUG - 2014-08-13 15:34:41 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:34:41 --> Session routines successfully run
DEBUG - 2014-08-13 15:34:41 --> Controller Class Initialized
DEBUG - 2014-08-13 15:34:41 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:34:41 --> Form Validation Class Initialized
DEBUG - 2014-08-13 15:34:41 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 15:34:41 --> XSS Filtering completed
DEBUG - 2014-08-13 15:34:41 --> XSS Filtering completed
DEBUG - 2014-08-13 15:34:41 --> Model Class Initialized
DEBUG - 2014-08-13 15:34:41 --> Model Class Initialized
DEBUG - 2014-08-13 15:34:41 --> Encrypt Class Initialized
DEBUG - 2014-08-13 15:34:41 --> XSS Filtering completed
DEBUG - 2014-08-13 15:34:41 --> XSS Filtering completed
DEBUG - 2014-08-13 15:34:41 --> Model Class Initialized
DEBUG - 2014-08-13 15:34:41 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 15:34:41 --> XSS Filtering completed
DEBUG - 2014-08-13 15:34:41 --> XSS Filtering completed
DEBUG - 2014-08-13 15:34:41 --> Model Class Initialized
DEBUG - 2014-08-13 15:34:41 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 15:34:41 --> XSS Filtering completed
DEBUG - 2014-08-13 15:34:41 --> XSS Filtering completed
DEBUG - 2014-08-13 15:34:41 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:34:41 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 15:34:41 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 15:34:41 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 15:34:41 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 15:34:41 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:34:41 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:34:41 --> Final output sent to browser
DEBUG - 2014-08-13 15:34:41 --> Total execution time: 0.1617
DEBUG - 2014-08-13 15:34:50 --> Config Class Initialized
DEBUG - 2014-08-13 15:34:50 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:34:50 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:34:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:34:50 --> URI Class Initialized
DEBUG - 2014-08-13 15:34:50 --> Router Class Initialized
DEBUG - 2014-08-13 15:34:50 --> Output Class Initialized
DEBUG - 2014-08-13 15:34:50 --> Security Class Initialized
DEBUG - 2014-08-13 15:34:50 --> Input Class Initialized
DEBUG - 2014-08-13 15:34:50 --> XSS Filtering completed
DEBUG - 2014-08-13 15:34:50 --> XSS Filtering completed
DEBUG - 2014-08-13 15:34:50 --> XSS Filtering completed
DEBUG - 2014-08-13 15:34:50 --> XSS Filtering completed
DEBUG - 2014-08-13 15:34:50 --> XSS Filtering completed
DEBUG - 2014-08-13 15:34:50 --> XSS Filtering completed
DEBUG - 2014-08-13 15:34:50 --> XSS Filtering completed
DEBUG - 2014-08-13 15:34:50 --> XSS Filtering completed
DEBUG - 2014-08-13 15:34:50 --> CRSF cookie Set
DEBUG - 2014-08-13 15:34:50 --> CSRF token verified
DEBUG - 2014-08-13 15:34:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:34:50 --> Language Class Initialized
DEBUG - 2014-08-13 15:34:50 --> Loader Class Initialized
DEBUG - 2014-08-13 15:34:50 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:34:50 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:34:50 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:34:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:34:50 --> Session Class Initialized
DEBUG - 2014-08-13 15:34:50 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:34:50 --> Session routines successfully run
DEBUG - 2014-08-13 15:34:50 --> Controller Class Initialized
DEBUG - 2014-08-13 15:34:50 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:34:50 --> Form Validation Class Initialized
DEBUG - 2014-08-13 15:34:50 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 15:34:50 --> XSS Filtering completed
DEBUG - 2014-08-13 15:34:50 --> XSS Filtering completed
DEBUG - 2014-08-13 15:34:50 --> Model Class Initialized
DEBUG - 2014-08-13 15:34:50 --> Model Class Initialized
DEBUG - 2014-08-13 15:34:50 --> Encrypt Class Initialized
DEBUG - 2014-08-13 15:34:50 --> XSS Filtering completed
DEBUG - 2014-08-13 15:34:50 --> XSS Filtering completed
DEBUG - 2014-08-13 15:34:50 --> Config Class Initialized
DEBUG - 2014-08-13 15:34:50 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:34:50 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:34:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:34:50 --> URI Class Initialized
DEBUG - 2014-08-13 15:34:50 --> Router Class Initialized
DEBUG - 2014-08-13 15:34:50 --> Output Class Initialized
DEBUG - 2014-08-13 15:34:50 --> Security Class Initialized
DEBUG - 2014-08-13 15:34:50 --> Input Class Initialized
DEBUG - 2014-08-13 15:34:50 --> XSS Filtering completed
DEBUG - 2014-08-13 15:34:50 --> XSS Filtering completed
DEBUG - 2014-08-13 15:34:50 --> XSS Filtering completed
DEBUG - 2014-08-13 15:34:50 --> XSS Filtering completed
DEBUG - 2014-08-13 15:34:50 --> XSS Filtering completed
DEBUG - 2014-08-13 15:34:50 --> CRSF cookie Set
DEBUG - 2014-08-13 15:34:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:34:50 --> Language Class Initialized
DEBUG - 2014-08-13 15:34:50 --> Loader Class Initialized
DEBUG - 2014-08-13 15:34:50 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:34:50 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:34:51 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:34:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:34:51 --> Session Class Initialized
DEBUG - 2014-08-13 15:34:51 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:34:51 --> Session routines successfully run
DEBUG - 2014-08-13 15:34:51 --> Controller Class Initialized
DEBUG - 2014-08-13 15:34:51 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:34:51 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-13 15:34:51 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-13 15:34:51 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 15:34:51 --> File loaded: application/views/placement_admin_home.php
DEBUG - 2014-08-13 15:34:51 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:34:51 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:34:51 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-13 15:34:51 --> Final output sent to browser
DEBUG - 2014-08-13 15:34:51 --> Total execution time: 0.1291
DEBUG - 2014-08-13 15:46:02 --> Config Class Initialized
DEBUG - 2014-08-13 15:46:02 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:46:02 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:46:02 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:46:02 --> URI Class Initialized
DEBUG - 2014-08-13 15:46:02 --> Router Class Initialized
DEBUG - 2014-08-13 15:46:02 --> Output Class Initialized
DEBUG - 2014-08-13 15:46:02 --> Security Class Initialized
DEBUG - 2014-08-13 15:46:02 --> Input Class Initialized
DEBUG - 2014-08-13 15:46:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:46:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:46:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:46:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:46:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:46:02 --> CRSF cookie Set
DEBUG - 2014-08-13 15:46:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:46:02 --> Language Class Initialized
DEBUG - 2014-08-13 15:46:02 --> Loader Class Initialized
DEBUG - 2014-08-13 15:46:02 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:46:02 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:46:02 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:46:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:46:02 --> Session Class Initialized
DEBUG - 2014-08-13 15:46:02 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:46:02 --> Session routines successfully run
DEBUG - 2014-08-13 15:46:02 --> Controller Class Initialized
DEBUG - 2014-08-13 15:46:02 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:46:02 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-13 15:46:02 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-13 15:46:02 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 15:46:02 --> File loaded: application/views/placement_admin_home.php
DEBUG - 2014-08-13 15:46:02 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:46:02 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:46:02 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-13 15:46:02 --> Final output sent to browser
DEBUG - 2014-08-13 15:46:02 --> Total execution time: 0.0966
DEBUG - 2014-08-13 15:46:05 --> Config Class Initialized
DEBUG - 2014-08-13 15:46:05 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:46:05 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:46:05 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:46:05 --> URI Class Initialized
DEBUG - 2014-08-13 15:46:05 --> Router Class Initialized
DEBUG - 2014-08-13 15:46:05 --> Output Class Initialized
DEBUG - 2014-08-13 15:46:05 --> Security Class Initialized
DEBUG - 2014-08-13 15:46:05 --> Input Class Initialized
DEBUG - 2014-08-13 15:46:05 --> XSS Filtering completed
DEBUG - 2014-08-13 15:46:05 --> XSS Filtering completed
DEBUG - 2014-08-13 15:46:05 --> XSS Filtering completed
DEBUG - 2014-08-13 15:46:05 --> XSS Filtering completed
DEBUG - 2014-08-13 15:46:05 --> XSS Filtering completed
DEBUG - 2014-08-13 15:46:05 --> CRSF cookie Set
DEBUG - 2014-08-13 15:46:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:46:05 --> Language Class Initialized
DEBUG - 2014-08-13 15:46:05 --> Loader Class Initialized
DEBUG - 2014-08-13 15:46:05 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:46:05 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:46:05 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:46:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:46:05 --> Session Class Initialized
DEBUG - 2014-08-13 15:46:05 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:46:05 --> Session routines successfully run
DEBUG - 2014-08-13 15:46:05 --> Controller Class Initialized
DEBUG - 2014-08-13 15:46:05 --> File loaded: application/views/logout.php
DEBUG - 2014-08-13 15:46:05 --> Final output sent to browser
DEBUG - 2014-08-13 15:46:05 --> Total execution time: 0.0991
DEBUG - 2014-08-13 15:46:05 --> Config Class Initialized
DEBUG - 2014-08-13 15:46:05 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:46:05 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:46:05 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:46:05 --> URI Class Initialized
DEBUG - 2014-08-13 15:46:05 --> Router Class Initialized
DEBUG - 2014-08-13 15:46:05 --> No URI present. Default controller set.
DEBUG - 2014-08-13 15:46:05 --> Output Class Initialized
DEBUG - 2014-08-13 15:46:05 --> Security Class Initialized
DEBUG - 2014-08-13 15:46:05 --> Input Class Initialized
DEBUG - 2014-08-13 15:46:05 --> XSS Filtering completed
DEBUG - 2014-08-13 15:46:05 --> XSS Filtering completed
DEBUG - 2014-08-13 15:46:05 --> XSS Filtering completed
DEBUG - 2014-08-13 15:46:05 --> XSS Filtering completed
DEBUG - 2014-08-13 15:46:05 --> CRSF cookie Set
DEBUG - 2014-08-13 15:46:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:46:05 --> Language Class Initialized
DEBUG - 2014-08-13 15:46:05 --> Loader Class Initialized
DEBUG - 2014-08-13 15:46:05 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:46:05 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:46:06 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:46:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:46:06 --> Session Class Initialized
DEBUG - 2014-08-13 15:46:06 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:46:06 --> A session cookie was not found.
DEBUG - 2014-08-13 15:46:06 --> Session routines successfully run
DEBUG - 2014-08-13 15:46:06 --> Controller Class Initialized
DEBUG - 2014-08-13 15:46:06 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:46:06 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 15:46:06 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 15:46:06 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:46:06 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 15:46:06 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 15:46:06 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:46:06 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:46:06 --> Final output sent to browser
DEBUG - 2014-08-13 15:46:06 --> Total execution time: 0.1256
DEBUG - 2014-08-13 15:46:11 --> Config Class Initialized
DEBUG - 2014-08-13 15:46:11 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:46:11 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:46:11 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:46:11 --> URI Class Initialized
DEBUG - 2014-08-13 15:46:11 --> Router Class Initialized
DEBUG - 2014-08-13 15:46:12 --> Output Class Initialized
DEBUG - 2014-08-13 15:46:12 --> Security Class Initialized
DEBUG - 2014-08-13 15:46:12 --> Input Class Initialized
DEBUG - 2014-08-13 15:46:12 --> XSS Filtering completed
DEBUG - 2014-08-13 15:46:12 --> XSS Filtering completed
DEBUG - 2014-08-13 15:46:12 --> XSS Filtering completed
DEBUG - 2014-08-13 15:46:12 --> XSS Filtering completed
DEBUG - 2014-08-13 15:46:12 --> XSS Filtering completed
DEBUG - 2014-08-13 15:46:12 --> XSS Filtering completed
DEBUG - 2014-08-13 15:46:12 --> XSS Filtering completed
DEBUG - 2014-08-13 15:46:12 --> XSS Filtering completed
DEBUG - 2014-08-13 15:46:12 --> CRSF cookie Set
DEBUG - 2014-08-13 15:46:12 --> CSRF token verified
DEBUG - 2014-08-13 15:46:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:46:12 --> Language Class Initialized
DEBUG - 2014-08-13 15:46:12 --> Loader Class Initialized
DEBUG - 2014-08-13 15:46:12 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:46:12 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:46:12 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:46:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:46:12 --> Session Class Initialized
DEBUG - 2014-08-13 15:46:12 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:46:12 --> Session routines successfully run
DEBUG - 2014-08-13 15:46:12 --> Controller Class Initialized
DEBUG - 2014-08-13 15:46:12 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:46:12 --> Form Validation Class Initialized
DEBUG - 2014-08-13 15:46:12 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 15:46:12 --> XSS Filtering completed
DEBUG - 2014-08-13 15:46:12 --> XSS Filtering completed
DEBUG - 2014-08-13 15:46:12 --> Model Class Initialized
DEBUG - 2014-08-13 15:46:12 --> Model Class Initialized
DEBUG - 2014-08-13 15:46:12 --> Encrypt Class Initialized
DEBUG - 2014-08-13 15:46:12 --> XSS Filtering completed
DEBUG - 2014-08-13 15:46:12 --> XSS Filtering completed
DEBUG - 2014-08-13 15:46:12 --> Model Class Initialized
DEBUG - 2014-08-13 15:46:12 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 15:46:12 --> XSS Filtering completed
DEBUG - 2014-08-13 15:46:12 --> XSS Filtering completed
DEBUG - 2014-08-13 15:46:12 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:46:12 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 15:46:12 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 15:46:12 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 15:46:12 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 15:46:12 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:46:12 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:46:12 --> Final output sent to browser
DEBUG - 2014-08-13 15:46:12 --> Total execution time: 0.1531
DEBUG - 2014-08-13 15:46:49 --> Config Class Initialized
DEBUG - 2014-08-13 15:46:49 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:46:49 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:46:49 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:46:49 --> URI Class Initialized
DEBUG - 2014-08-13 15:46:49 --> Router Class Initialized
DEBUG - 2014-08-13 15:46:49 --> Output Class Initialized
DEBUG - 2014-08-13 15:46:49 --> Security Class Initialized
DEBUG - 2014-08-13 15:46:49 --> Input Class Initialized
DEBUG - 2014-08-13 15:46:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:46:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:46:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:46:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:46:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:46:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:46:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:46:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:46:49 --> CRSF cookie Set
DEBUG - 2014-08-13 15:46:49 --> CSRF token verified
DEBUG - 2014-08-13 15:46:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:46:49 --> Language Class Initialized
DEBUG - 2014-08-13 15:46:49 --> Loader Class Initialized
DEBUG - 2014-08-13 15:46:49 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:46:49 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:46:49 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:46:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:46:49 --> Session Class Initialized
DEBUG - 2014-08-13 15:46:49 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:46:49 --> Session routines successfully run
DEBUG - 2014-08-13 15:46:49 --> Controller Class Initialized
DEBUG - 2014-08-13 15:46:49 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:46:49 --> Form Validation Class Initialized
DEBUG - 2014-08-13 15:46:49 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 15:46:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:46:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:46:49 --> Model Class Initialized
DEBUG - 2014-08-13 15:46:49 --> Model Class Initialized
DEBUG - 2014-08-13 15:46:49 --> Encrypt Class Initialized
DEBUG - 2014-08-13 15:46:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:46:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:46:49 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:46:49 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 15:46:49 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 15:46:49 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 15:46:49 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 15:46:49 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:46:49 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:46:49 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:46:49 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 15:46:49 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 15:46:49 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 15:46:49 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 15:46:49 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:46:49 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:46:49 --> Final output sent to browser
DEBUG - 2014-08-13 15:46:49 --> Total execution time: 0.1517
DEBUG - 2014-08-13 15:47:53 --> Config Class Initialized
DEBUG - 2014-08-13 15:47:53 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:47:53 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:47:53 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:47:53 --> URI Class Initialized
DEBUG - 2014-08-13 15:47:53 --> Router Class Initialized
DEBUG - 2014-08-13 15:47:53 --> Output Class Initialized
DEBUG - 2014-08-13 15:47:53 --> Security Class Initialized
DEBUG - 2014-08-13 15:47:53 --> Input Class Initialized
DEBUG - 2014-08-13 15:47:53 --> XSS Filtering completed
DEBUG - 2014-08-13 15:47:53 --> XSS Filtering completed
DEBUG - 2014-08-13 15:47:53 --> XSS Filtering completed
DEBUG - 2014-08-13 15:47:53 --> XSS Filtering completed
DEBUG - 2014-08-13 15:47:53 --> XSS Filtering completed
DEBUG - 2014-08-13 15:47:53 --> XSS Filtering completed
DEBUG - 2014-08-13 15:47:53 --> XSS Filtering completed
DEBUG - 2014-08-13 15:47:53 --> XSS Filtering completed
DEBUG - 2014-08-13 15:47:53 --> CRSF cookie Set
DEBUG - 2014-08-13 15:47:53 --> CSRF token verified
DEBUG - 2014-08-13 15:47:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:47:53 --> Language Class Initialized
DEBUG - 2014-08-13 15:47:53 --> Loader Class Initialized
DEBUG - 2014-08-13 15:47:53 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:47:53 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:47:53 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:47:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:47:53 --> Session Class Initialized
DEBUG - 2014-08-13 15:47:53 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:47:53 --> Session routines successfully run
DEBUG - 2014-08-13 15:47:53 --> Controller Class Initialized
DEBUG - 2014-08-13 15:47:53 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:47:53 --> Form Validation Class Initialized
DEBUG - 2014-08-13 15:47:53 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 15:47:53 --> XSS Filtering completed
DEBUG - 2014-08-13 15:47:53 --> XSS Filtering completed
DEBUG - 2014-08-13 15:47:53 --> Model Class Initialized
DEBUG - 2014-08-13 15:47:53 --> Model Class Initialized
DEBUG - 2014-08-13 15:47:53 --> Encrypt Class Initialized
DEBUG - 2014-08-13 15:47:53 --> XSS Filtering completed
DEBUG - 2014-08-13 15:47:53 --> XSS Filtering completed
DEBUG - 2014-08-13 15:47:53 --> Config Class Initialized
DEBUG - 2014-08-13 15:47:53 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:47:53 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:47:53 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:47:53 --> URI Class Initialized
DEBUG - 2014-08-13 15:47:53 --> Router Class Initialized
DEBUG - 2014-08-13 15:47:53 --> Output Class Initialized
DEBUG - 2014-08-13 15:47:53 --> Security Class Initialized
DEBUG - 2014-08-13 15:47:53 --> Input Class Initialized
DEBUG - 2014-08-13 15:47:53 --> XSS Filtering completed
DEBUG - 2014-08-13 15:47:53 --> XSS Filtering completed
DEBUG - 2014-08-13 15:47:53 --> XSS Filtering completed
DEBUG - 2014-08-13 15:47:53 --> XSS Filtering completed
DEBUG - 2014-08-13 15:47:53 --> XSS Filtering completed
DEBUG - 2014-08-13 15:47:53 --> CRSF cookie Set
DEBUG - 2014-08-13 15:47:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:47:53 --> Language Class Initialized
DEBUG - 2014-08-13 15:47:53 --> Loader Class Initialized
DEBUG - 2014-08-13 15:47:53 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:47:53 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:47:54 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:47:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:47:54 --> Session Class Initialized
DEBUG - 2014-08-13 15:47:54 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:47:54 --> Session routines successfully run
DEBUG - 2014-08-13 15:47:54 --> Controller Class Initialized
DEBUG - 2014-08-13 15:47:54 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:47:54 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-13 15:47:54 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-13 15:47:54 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 15:47:54 --> File loaded: application/views/placement_admin_home.php
DEBUG - 2014-08-13 15:47:54 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:47:54 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:47:54 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-13 15:47:54 --> Final output sent to browser
DEBUG - 2014-08-13 15:47:54 --> Total execution time: 0.1183
DEBUG - 2014-08-13 15:47:56 --> Config Class Initialized
DEBUG - 2014-08-13 15:47:56 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:47:56 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:47:56 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:47:56 --> URI Class Initialized
DEBUG - 2014-08-13 15:47:56 --> Router Class Initialized
DEBUG - 2014-08-13 15:47:56 --> Output Class Initialized
DEBUG - 2014-08-13 15:47:56 --> Security Class Initialized
DEBUG - 2014-08-13 15:47:56 --> Input Class Initialized
DEBUG - 2014-08-13 15:47:56 --> XSS Filtering completed
DEBUG - 2014-08-13 15:47:56 --> XSS Filtering completed
DEBUG - 2014-08-13 15:47:56 --> XSS Filtering completed
DEBUG - 2014-08-13 15:47:56 --> XSS Filtering completed
DEBUG - 2014-08-13 15:47:56 --> XSS Filtering completed
DEBUG - 2014-08-13 15:47:56 --> CRSF cookie Set
DEBUG - 2014-08-13 15:47:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:47:56 --> Language Class Initialized
DEBUG - 2014-08-13 15:47:56 --> Loader Class Initialized
DEBUG - 2014-08-13 15:47:56 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:47:56 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:47:56 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:47:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:47:56 --> Session Class Initialized
DEBUG - 2014-08-13 15:47:56 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:47:56 --> Session routines successfully run
DEBUG - 2014-08-13 15:47:56 --> Controller Class Initialized
DEBUG - 2014-08-13 15:47:56 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:47:56 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-13 15:47:56 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-13 15:47:56 --> File loaded: application/views/placement_admin_history.php
DEBUG - 2014-08-13 15:47:56 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:47:56 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:47:56 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-13 15:47:56 --> Final output sent to browser
DEBUG - 2014-08-13 15:47:56 --> Total execution time: 0.1009
DEBUG - 2014-08-13 15:47:58 --> Config Class Initialized
DEBUG - 2014-08-13 15:47:58 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:47:58 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:47:58 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:47:58 --> URI Class Initialized
DEBUG - 2014-08-13 15:47:58 --> Router Class Initialized
DEBUG - 2014-08-13 15:47:58 --> Output Class Initialized
DEBUG - 2014-08-13 15:47:58 --> Security Class Initialized
DEBUG - 2014-08-13 15:47:58 --> Input Class Initialized
DEBUG - 2014-08-13 15:47:58 --> XSS Filtering completed
DEBUG - 2014-08-13 15:47:58 --> XSS Filtering completed
DEBUG - 2014-08-13 15:47:58 --> XSS Filtering completed
DEBUG - 2014-08-13 15:47:58 --> XSS Filtering completed
DEBUG - 2014-08-13 15:47:58 --> XSS Filtering completed
DEBUG - 2014-08-13 15:47:58 --> CRSF cookie Set
DEBUG - 2014-08-13 15:47:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:47:58 --> Language Class Initialized
DEBUG - 2014-08-13 15:47:58 --> Loader Class Initialized
DEBUG - 2014-08-13 15:47:58 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:47:58 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:47:58 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:47:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:47:58 --> Session Class Initialized
DEBUG - 2014-08-13 15:47:58 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:47:58 --> Session routines successfully run
DEBUG - 2014-08-13 15:47:58 --> Controller Class Initialized
DEBUG - 2014-08-13 15:47:58 --> File loaded: application/views/logout.php
DEBUG - 2014-08-13 15:47:58 --> Final output sent to browser
DEBUG - 2014-08-13 15:47:58 --> Total execution time: 0.0807
DEBUG - 2014-08-13 15:47:58 --> Config Class Initialized
DEBUG - 2014-08-13 15:47:58 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:47:58 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:47:58 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:47:58 --> URI Class Initialized
DEBUG - 2014-08-13 15:47:58 --> Router Class Initialized
DEBUG - 2014-08-13 15:47:58 --> No URI present. Default controller set.
DEBUG - 2014-08-13 15:47:58 --> Output Class Initialized
DEBUG - 2014-08-13 15:47:58 --> Security Class Initialized
DEBUG - 2014-08-13 15:47:58 --> Input Class Initialized
DEBUG - 2014-08-13 15:47:58 --> XSS Filtering completed
DEBUG - 2014-08-13 15:47:58 --> XSS Filtering completed
DEBUG - 2014-08-13 15:47:58 --> XSS Filtering completed
DEBUG - 2014-08-13 15:47:58 --> XSS Filtering completed
DEBUG - 2014-08-13 15:47:58 --> CRSF cookie Set
DEBUG - 2014-08-13 15:47:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:47:58 --> Language Class Initialized
DEBUG - 2014-08-13 15:47:58 --> Loader Class Initialized
DEBUG - 2014-08-13 15:47:58 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:47:58 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:47:58 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:47:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:47:58 --> Session Class Initialized
DEBUG - 2014-08-13 15:47:58 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:47:58 --> A session cookie was not found.
DEBUG - 2014-08-13 15:47:58 --> Session routines successfully run
DEBUG - 2014-08-13 15:47:58 --> Controller Class Initialized
DEBUG - 2014-08-13 15:47:58 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:47:58 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 15:47:58 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 15:47:58 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:47:58 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 15:47:58 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 15:47:58 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:47:58 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:47:58 --> Final output sent to browser
DEBUG - 2014-08-13 15:47:58 --> Total execution time: 0.1313
DEBUG - 2014-08-13 15:48:05 --> Config Class Initialized
DEBUG - 2014-08-13 15:48:05 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:48:05 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:48:05 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:48:05 --> URI Class Initialized
DEBUG - 2014-08-13 15:48:05 --> Router Class Initialized
DEBUG - 2014-08-13 15:48:05 --> Output Class Initialized
DEBUG - 2014-08-13 15:48:05 --> Security Class Initialized
DEBUG - 2014-08-13 15:48:05 --> Input Class Initialized
DEBUG - 2014-08-13 15:48:05 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:05 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:05 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:05 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:05 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:05 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:05 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:05 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:05 --> CRSF cookie Set
DEBUG - 2014-08-13 15:48:05 --> CSRF token verified
DEBUG - 2014-08-13 15:48:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:48:05 --> Language Class Initialized
DEBUG - 2014-08-13 15:48:05 --> Loader Class Initialized
DEBUG - 2014-08-13 15:48:05 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:48:05 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:48:05 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:48:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:48:05 --> Session Class Initialized
DEBUG - 2014-08-13 15:48:05 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:48:05 --> Session routines successfully run
DEBUG - 2014-08-13 15:48:05 --> Controller Class Initialized
DEBUG - 2014-08-13 15:48:05 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:48:05 --> Form Validation Class Initialized
DEBUG - 2014-08-13 15:48:05 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 15:48:05 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:05 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:05 --> Model Class Initialized
DEBUG - 2014-08-13 15:48:05 --> Model Class Initialized
DEBUG - 2014-08-13 15:48:05 --> Encrypt Class Initialized
DEBUG - 2014-08-13 15:48:05 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:05 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:05 --> Model Class Initialized
DEBUG - 2014-08-13 15:48:05 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 15:48:05 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:05 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:05 --> Config Class Initialized
DEBUG - 2014-08-13 15:48:05 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:48:05 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:48:05 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:48:05 --> URI Class Initialized
DEBUG - 2014-08-13 15:48:05 --> Router Class Initialized
DEBUG - 2014-08-13 15:48:05 --> Output Class Initialized
DEBUG - 2014-08-13 15:48:05 --> Security Class Initialized
DEBUG - 2014-08-13 15:48:05 --> Input Class Initialized
DEBUG - 2014-08-13 15:48:05 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:05 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:05 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:05 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:05 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:05 --> CRSF cookie Set
DEBUG - 2014-08-13 15:48:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:48:05 --> Language Class Initialized
DEBUG - 2014-08-13 15:48:05 --> Loader Class Initialized
DEBUG - 2014-08-13 15:48:05 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:48:05 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:48:05 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:48:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:48:05 --> Session Class Initialized
DEBUG - 2014-08-13 15:48:05 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:48:05 --> Session routines successfully run
DEBUG - 2014-08-13 15:48:05 --> Controller Class Initialized
DEBUG - 2014-08-13 15:48:05 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:48:05 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-13 15:48:05 --> Model Class Initialized
DEBUG - 2014-08-13 15:48:05 --> Model Class Initialized
DEBUG - 2014-08-13 15:48:05 --> Model Class Initialized
DEBUG - 2014-08-13 15:48:05 --> Model Class Initialized
DEBUG - 2014-08-13 15:48:05 --> Helper loaded: array_helper
DEBUG - 2014-08-13 15:48:05 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:48:05 --> File loaded: application/views/placement_students_home.php
DEBUG - 2014-08-13 15:48:05 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:48:05 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:48:05 --> Final output sent to browser
DEBUG - 2014-08-13 15:48:05 --> Total execution time: 0.1410
DEBUG - 2014-08-13 15:48:26 --> Config Class Initialized
DEBUG - 2014-08-13 15:48:26 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:48:26 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:48:26 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:48:26 --> URI Class Initialized
DEBUG - 2014-08-13 15:48:26 --> Router Class Initialized
DEBUG - 2014-08-13 15:48:26 --> Output Class Initialized
DEBUG - 2014-08-13 15:48:26 --> Security Class Initialized
DEBUG - 2014-08-13 15:48:26 --> Input Class Initialized
DEBUG - 2014-08-13 15:48:26 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:26 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:26 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:26 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:26 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:26 --> CRSF cookie Set
DEBUG - 2014-08-13 15:48:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:48:26 --> Language Class Initialized
DEBUG - 2014-08-13 15:48:26 --> Loader Class Initialized
DEBUG - 2014-08-13 15:48:26 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:48:26 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:48:26 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:48:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:48:26 --> Session Class Initialized
DEBUG - 2014-08-13 15:48:26 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:48:26 --> Session routines successfully run
DEBUG - 2014-08-13 15:48:26 --> Controller Class Initialized
DEBUG - 2014-08-13 15:48:26 --> File loaded: application/views/logout.php
DEBUG - 2014-08-13 15:48:26 --> Final output sent to browser
DEBUG - 2014-08-13 15:48:26 --> Total execution time: 0.0824
DEBUG - 2014-08-13 15:48:27 --> Config Class Initialized
DEBUG - 2014-08-13 15:48:27 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:48:27 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:48:27 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:48:27 --> URI Class Initialized
DEBUG - 2014-08-13 15:48:27 --> Router Class Initialized
DEBUG - 2014-08-13 15:48:27 --> No URI present. Default controller set.
DEBUG - 2014-08-13 15:48:27 --> Output Class Initialized
DEBUG - 2014-08-13 15:48:27 --> Security Class Initialized
DEBUG - 2014-08-13 15:48:27 --> Input Class Initialized
DEBUG - 2014-08-13 15:48:27 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:27 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:27 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:27 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:27 --> CRSF cookie Set
DEBUG - 2014-08-13 15:48:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:48:27 --> Language Class Initialized
DEBUG - 2014-08-13 15:48:27 --> Loader Class Initialized
DEBUG - 2014-08-13 15:48:27 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:48:27 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:48:27 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:48:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:48:27 --> Session Class Initialized
DEBUG - 2014-08-13 15:48:27 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:48:27 --> A session cookie was not found.
DEBUG - 2014-08-13 15:48:27 --> Session routines successfully run
DEBUG - 2014-08-13 15:48:27 --> Controller Class Initialized
DEBUG - 2014-08-13 15:48:27 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:48:27 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 15:48:27 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 15:48:27 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:48:27 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 15:48:27 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 15:48:27 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:48:27 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:48:27 --> Final output sent to browser
DEBUG - 2014-08-13 15:48:27 --> Total execution time: 0.1249
DEBUG - 2014-08-13 15:48:35 --> Config Class Initialized
DEBUG - 2014-08-13 15:48:35 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:48:35 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:48:35 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:48:35 --> URI Class Initialized
DEBUG - 2014-08-13 15:48:35 --> Router Class Initialized
DEBUG - 2014-08-13 15:48:35 --> Output Class Initialized
DEBUG - 2014-08-13 15:48:35 --> Security Class Initialized
DEBUG - 2014-08-13 15:48:35 --> Input Class Initialized
DEBUG - 2014-08-13 15:48:35 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:35 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:35 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:35 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:35 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:35 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:35 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:35 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:35 --> CRSF cookie Set
DEBUG - 2014-08-13 15:48:35 --> CSRF token verified
DEBUG - 2014-08-13 15:48:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:48:35 --> Language Class Initialized
DEBUG - 2014-08-13 15:48:35 --> Loader Class Initialized
DEBUG - 2014-08-13 15:48:35 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:48:35 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:48:35 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:48:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:48:35 --> Session Class Initialized
DEBUG - 2014-08-13 15:48:35 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:48:35 --> Session routines successfully run
DEBUG - 2014-08-13 15:48:35 --> Controller Class Initialized
DEBUG - 2014-08-13 15:48:35 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:48:35 --> Form Validation Class Initialized
DEBUG - 2014-08-13 15:48:35 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 15:48:35 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:35 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:35 --> Model Class Initialized
DEBUG - 2014-08-13 15:48:35 --> Model Class Initialized
DEBUG - 2014-08-13 15:48:35 --> Encrypt Class Initialized
DEBUG - 2014-08-13 15:48:35 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:35 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:35 --> Model Class Initialized
DEBUG - 2014-08-13 15:48:35 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 15:48:35 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:35 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:35 --> Model Class Initialized
DEBUG - 2014-08-13 15:48:35 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 15:48:35 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:35 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:35 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:48:35 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 15:48:35 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 15:48:35 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 15:48:35 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 15:48:35 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:48:35 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:48:35 --> Final output sent to browser
DEBUG - 2014-08-13 15:48:35 --> Total execution time: 0.1605
DEBUG - 2014-08-13 15:48:51 --> Config Class Initialized
DEBUG - 2014-08-13 15:48:51 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:48:51 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:48:51 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:48:51 --> URI Class Initialized
DEBUG - 2014-08-13 15:48:51 --> Router Class Initialized
DEBUG - 2014-08-13 15:48:51 --> Output Class Initialized
DEBUG - 2014-08-13 15:48:51 --> Security Class Initialized
DEBUG - 2014-08-13 15:48:51 --> Input Class Initialized
DEBUG - 2014-08-13 15:48:51 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:51 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:51 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:51 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:51 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:51 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:51 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:51 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:51 --> CRSF cookie Set
DEBUG - 2014-08-13 15:48:51 --> CSRF token verified
DEBUG - 2014-08-13 15:48:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:48:51 --> Language Class Initialized
DEBUG - 2014-08-13 15:48:51 --> Loader Class Initialized
DEBUG - 2014-08-13 15:48:51 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:48:51 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:48:51 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:48:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:48:51 --> Session Class Initialized
DEBUG - 2014-08-13 15:48:51 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:48:51 --> Session routines successfully run
DEBUG - 2014-08-13 15:48:51 --> Controller Class Initialized
DEBUG - 2014-08-13 15:48:51 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:48:51 --> Form Validation Class Initialized
DEBUG - 2014-08-13 15:48:51 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 15:48:51 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:51 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:51 --> Model Class Initialized
DEBUG - 2014-08-13 15:48:51 --> Model Class Initialized
DEBUG - 2014-08-13 15:48:51 --> Encrypt Class Initialized
DEBUG - 2014-08-13 15:48:51 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:51 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:51 --> Model Class Initialized
DEBUG - 2014-08-13 15:48:51 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 15:48:51 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:51 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:51 --> Config Class Initialized
DEBUG - 2014-08-13 15:48:51 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:48:51 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:48:51 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:48:51 --> URI Class Initialized
DEBUG - 2014-08-13 15:48:51 --> Router Class Initialized
DEBUG - 2014-08-13 15:48:51 --> Output Class Initialized
DEBUG - 2014-08-13 15:48:51 --> Security Class Initialized
DEBUG - 2014-08-13 15:48:51 --> Input Class Initialized
DEBUG - 2014-08-13 15:48:51 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:51 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:51 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:51 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:51 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:51 --> CRSF cookie Set
DEBUG - 2014-08-13 15:48:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:48:51 --> Language Class Initialized
DEBUG - 2014-08-13 15:48:51 --> Loader Class Initialized
DEBUG - 2014-08-13 15:48:51 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:48:51 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:48:51 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:48:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:48:51 --> Session Class Initialized
DEBUG - 2014-08-13 15:48:51 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:48:51 --> Session routines successfully run
DEBUG - 2014-08-13 15:48:51 --> Controller Class Initialized
DEBUG - 2014-08-13 15:48:51 --> File loaded: application/views/login_to_continue.php
DEBUG - 2014-08-13 15:48:51 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:48:51 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-13 15:48:51 --> Model Class Initialized
DEBUG - 2014-08-13 15:48:51 --> Model Class Initialized
DEBUG - 2014-08-13 15:48:51 --> Model Class Initialized
DEBUG - 2014-08-13 15:48:51 --> Model Class Initialized
DEBUG - 2014-08-13 15:48:51 --> Helper loaded: array_helper
DEBUG - 2014-08-13 15:48:51 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:48:51 --> File loaded: application/views/placement_students_home.php
DEBUG - 2014-08-13 15:48:51 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:48:51 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:48:51 --> Final output sent to browser
DEBUG - 2014-08-13 15:48:51 --> Total execution time: 0.1447
DEBUG - 2014-08-13 15:48:54 --> Config Class Initialized
DEBUG - 2014-08-13 15:48:54 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:48:54 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:48:54 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:48:54 --> URI Class Initialized
DEBUG - 2014-08-13 15:48:54 --> Router Class Initialized
DEBUG - 2014-08-13 15:48:54 --> No URI present. Default controller set.
DEBUG - 2014-08-13 15:48:54 --> Output Class Initialized
DEBUG - 2014-08-13 15:48:54 --> Security Class Initialized
DEBUG - 2014-08-13 15:48:54 --> Input Class Initialized
DEBUG - 2014-08-13 15:48:54 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:54 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:54 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:54 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:54 --> XSS Filtering completed
DEBUG - 2014-08-13 15:48:54 --> CRSF cookie Set
DEBUG - 2014-08-13 15:48:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:48:54 --> Language Class Initialized
DEBUG - 2014-08-13 15:48:54 --> Loader Class Initialized
DEBUG - 2014-08-13 15:48:54 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:48:54 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:48:54 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:48:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:48:54 --> Session Class Initialized
DEBUG - 2014-08-13 15:48:54 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:48:54 --> Session routines successfully run
DEBUG - 2014-08-13 15:48:54 --> Controller Class Initialized
DEBUG - 2014-08-13 15:48:54 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:48:54 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 15:48:54 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 15:48:54 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:48:54 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 15:48:54 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 15:48:54 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:48:54 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:48:54 --> Final output sent to browser
DEBUG - 2014-08-13 15:48:54 --> Total execution time: 0.0962
DEBUG - 2014-08-13 15:49:30 --> Config Class Initialized
DEBUG - 2014-08-13 15:49:30 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:49:30 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:49:30 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:49:30 --> URI Class Initialized
DEBUG - 2014-08-13 15:49:30 --> Router Class Initialized
DEBUG - 2014-08-13 15:49:30 --> Output Class Initialized
DEBUG - 2014-08-13 15:49:31 --> Security Class Initialized
DEBUG - 2014-08-13 15:49:31 --> Input Class Initialized
DEBUG - 2014-08-13 15:49:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:49:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:49:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:49:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:49:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:49:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:49:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:49:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:49:31 --> CRSF cookie Set
DEBUG - 2014-08-13 15:49:31 --> CSRF token verified
DEBUG - 2014-08-13 15:49:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:49:31 --> Language Class Initialized
DEBUG - 2014-08-13 15:49:31 --> Loader Class Initialized
DEBUG - 2014-08-13 15:49:31 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:49:31 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:49:31 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:49:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:49:31 --> Session Class Initialized
DEBUG - 2014-08-13 15:49:31 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:49:31 --> Session routines successfully run
DEBUG - 2014-08-13 15:49:31 --> Controller Class Initialized
DEBUG - 2014-08-13 15:49:31 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:49:31 --> Form Validation Class Initialized
DEBUG - 2014-08-13 15:49:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 15:49:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:49:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:49:31 --> Model Class Initialized
DEBUG - 2014-08-13 15:49:31 --> Model Class Initialized
DEBUG - 2014-08-13 15:49:31 --> Encrypt Class Initialized
DEBUG - 2014-08-13 15:49:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:49:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:49:31 --> Model Class Initialized
DEBUG - 2014-08-13 15:49:31 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 15:49:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:49:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:49:31 --> Config Class Initialized
DEBUG - 2014-08-13 15:49:31 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:49:31 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:49:31 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:49:31 --> URI Class Initialized
DEBUG - 2014-08-13 15:49:31 --> Router Class Initialized
DEBUG - 2014-08-13 15:49:31 --> Output Class Initialized
DEBUG - 2014-08-13 15:49:31 --> Security Class Initialized
DEBUG - 2014-08-13 15:49:31 --> Input Class Initialized
DEBUG - 2014-08-13 15:49:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:49:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:49:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:49:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:49:31 --> XSS Filtering completed
DEBUG - 2014-08-13 15:49:31 --> CRSF cookie Set
DEBUG - 2014-08-13 15:49:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:49:31 --> Language Class Initialized
DEBUG - 2014-08-13 15:49:31 --> Loader Class Initialized
DEBUG - 2014-08-13 15:49:31 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:49:31 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:49:31 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:49:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:49:31 --> Session Class Initialized
DEBUG - 2014-08-13 15:49:31 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:49:31 --> Session routines successfully run
DEBUG - 2014-08-13 15:49:31 --> Controller Class Initialized
DEBUG - 2014-08-13 15:49:31 --> File loaded: application/views/login_to_continue.php
DEBUG - 2014-08-13 15:49:31 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:49:31 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-13 15:49:31 --> Model Class Initialized
DEBUG - 2014-08-13 15:49:31 --> Model Class Initialized
DEBUG - 2014-08-13 15:49:31 --> Model Class Initialized
DEBUG - 2014-08-13 15:49:31 --> Model Class Initialized
DEBUG - 2014-08-13 15:49:31 --> Helper loaded: array_helper
DEBUG - 2014-08-13 15:49:31 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:49:31 --> File loaded: application/views/placement_students_home.php
DEBUG - 2014-08-13 15:49:31 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:49:31 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:49:31 --> Final output sent to browser
DEBUG - 2014-08-13 15:49:31 --> Total execution time: 0.1805
DEBUG - 2014-08-13 15:53:44 --> Config Class Initialized
DEBUG - 2014-08-13 15:53:44 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:53:44 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:53:44 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:53:44 --> URI Class Initialized
DEBUG - 2014-08-13 15:53:44 --> Router Class Initialized
DEBUG - 2014-08-13 15:53:44 --> No URI present. Default controller set.
DEBUG - 2014-08-13 15:53:44 --> Output Class Initialized
DEBUG - 2014-08-13 15:53:44 --> Security Class Initialized
DEBUG - 2014-08-13 15:53:44 --> Input Class Initialized
DEBUG - 2014-08-13 15:53:44 --> XSS Filtering completed
DEBUG - 2014-08-13 15:53:44 --> XSS Filtering completed
DEBUG - 2014-08-13 15:53:44 --> XSS Filtering completed
DEBUG - 2014-08-13 15:53:44 --> XSS Filtering completed
DEBUG - 2014-08-13 15:53:44 --> XSS Filtering completed
DEBUG - 2014-08-13 15:53:44 --> CRSF cookie Set
DEBUG - 2014-08-13 15:53:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:53:44 --> Language Class Initialized
DEBUG - 2014-08-13 15:53:44 --> Loader Class Initialized
DEBUG - 2014-08-13 15:53:44 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:53:44 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:53:44 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:53:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:53:44 --> Session Class Initialized
DEBUG - 2014-08-13 15:53:44 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:53:44 --> Session routines successfully run
DEBUG - 2014-08-13 15:53:44 --> Controller Class Initialized
DEBUG - 2014-08-13 15:53:44 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:53:44 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 15:53:44 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 15:53:44 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:53:44 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 15:53:44 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 15:53:44 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:53:44 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:53:44 --> Final output sent to browser
DEBUG - 2014-08-13 15:53:44 --> Total execution time: 0.1057
DEBUG - 2014-08-13 15:54:26 --> Config Class Initialized
DEBUG - 2014-08-13 15:54:26 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:54:26 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:54:26 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:54:26 --> URI Class Initialized
DEBUG - 2014-08-13 15:54:26 --> Router Class Initialized
DEBUG - 2014-08-13 15:54:26 --> Output Class Initialized
DEBUG - 2014-08-13 15:54:26 --> Security Class Initialized
DEBUG - 2014-08-13 15:54:26 --> Input Class Initialized
DEBUG - 2014-08-13 15:54:26 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:26 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:26 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:26 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:26 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:26 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:26 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:26 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:26 --> CRSF cookie Set
DEBUG - 2014-08-13 15:54:26 --> CSRF token verified
DEBUG - 2014-08-13 15:54:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:54:26 --> Language Class Initialized
DEBUG - 2014-08-13 15:54:26 --> Loader Class Initialized
DEBUG - 2014-08-13 15:54:26 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:54:26 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:54:26 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:54:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:54:26 --> Session Class Initialized
DEBUG - 2014-08-13 15:54:26 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:54:26 --> Session routines successfully run
DEBUG - 2014-08-13 15:54:26 --> Controller Class Initialized
DEBUG - 2014-08-13 15:54:26 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:54:26 --> Form Validation Class Initialized
DEBUG - 2014-08-13 15:54:26 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 15:54:26 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:26 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:26 --> Model Class Initialized
DEBUG - 2014-08-13 15:54:26 --> Model Class Initialized
DEBUG - 2014-08-13 15:54:26 --> Encrypt Class Initialized
DEBUG - 2014-08-13 15:54:26 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:26 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:26 --> Model Class Initialized
DEBUG - 2014-08-13 15:54:26 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 15:54:26 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:26 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:26 --> Config Class Initialized
DEBUG - 2014-08-13 15:54:26 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:54:26 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:54:26 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:54:26 --> URI Class Initialized
DEBUG - 2014-08-13 15:54:26 --> Router Class Initialized
DEBUG - 2014-08-13 15:54:26 --> Output Class Initialized
DEBUG - 2014-08-13 15:54:26 --> Security Class Initialized
DEBUG - 2014-08-13 15:54:26 --> Input Class Initialized
DEBUG - 2014-08-13 15:54:26 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:26 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:26 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:26 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:26 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:26 --> CRSF cookie Set
DEBUG - 2014-08-13 15:54:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:54:26 --> Language Class Initialized
DEBUG - 2014-08-13 15:54:26 --> Loader Class Initialized
DEBUG - 2014-08-13 15:54:26 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:54:26 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:54:26 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:54:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:54:26 --> Session Class Initialized
DEBUG - 2014-08-13 15:54:26 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:54:26 --> Session routines successfully run
DEBUG - 2014-08-13 15:54:26 --> Controller Class Initialized
DEBUG - 2014-08-13 15:54:26 --> File loaded: application/views/login_to_continue.php
DEBUG - 2014-08-13 15:54:26 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:54:26 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-13 15:54:26 --> Model Class Initialized
DEBUG - 2014-08-13 15:54:26 --> Model Class Initialized
DEBUG - 2014-08-13 15:54:26 --> Model Class Initialized
DEBUG - 2014-08-13 15:54:26 --> Model Class Initialized
DEBUG - 2014-08-13 15:54:26 --> Helper loaded: array_helper
DEBUG - 2014-08-13 15:54:26 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:54:26 --> File loaded: application/views/placement_students_home.php
DEBUG - 2014-08-13 15:54:26 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:54:26 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:54:26 --> Final output sent to browser
DEBUG - 2014-08-13 15:54:26 --> Total execution time: 0.1460
DEBUG - 2014-08-13 15:54:28 --> Config Class Initialized
DEBUG - 2014-08-13 15:54:28 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:54:28 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:54:28 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:54:28 --> URI Class Initialized
DEBUG - 2014-08-13 15:54:28 --> Router Class Initialized
DEBUG - 2014-08-13 15:54:28 --> No URI present. Default controller set.
DEBUG - 2014-08-13 15:54:28 --> Output Class Initialized
DEBUG - 2014-08-13 15:54:28 --> Security Class Initialized
DEBUG - 2014-08-13 15:54:28 --> Input Class Initialized
DEBUG - 2014-08-13 15:54:28 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:28 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:28 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:28 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:28 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:28 --> CRSF cookie Set
DEBUG - 2014-08-13 15:54:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:54:28 --> Language Class Initialized
DEBUG - 2014-08-13 15:54:28 --> Loader Class Initialized
DEBUG - 2014-08-13 15:54:28 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:54:28 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:54:28 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:54:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:54:28 --> Session Class Initialized
DEBUG - 2014-08-13 15:54:28 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:54:28 --> Session routines successfully run
DEBUG - 2014-08-13 15:54:28 --> Controller Class Initialized
DEBUG - 2014-08-13 15:54:28 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:54:28 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 15:54:28 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 15:54:28 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:54:28 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 15:54:28 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 15:54:28 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:54:28 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:54:28 --> Final output sent to browser
DEBUG - 2014-08-13 15:54:28 --> Total execution time: 0.0955
DEBUG - 2014-08-13 15:54:44 --> Config Class Initialized
DEBUG - 2014-08-13 15:54:44 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:54:44 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:54:44 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:54:44 --> URI Class Initialized
DEBUG - 2014-08-13 15:54:44 --> Router Class Initialized
DEBUG - 2014-08-13 15:54:44 --> Output Class Initialized
DEBUG - 2014-08-13 15:54:44 --> Security Class Initialized
DEBUG - 2014-08-13 15:54:44 --> Input Class Initialized
DEBUG - 2014-08-13 15:54:44 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:44 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:44 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:44 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:44 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:44 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:44 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:44 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:44 --> CRSF cookie Set
DEBUG - 2014-08-13 15:54:44 --> CSRF token verified
DEBUG - 2014-08-13 15:54:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:54:44 --> Language Class Initialized
DEBUG - 2014-08-13 15:54:44 --> Loader Class Initialized
DEBUG - 2014-08-13 15:54:44 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:54:44 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:54:44 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:54:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:54:44 --> Session Class Initialized
DEBUG - 2014-08-13 15:54:44 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:54:44 --> Session routines successfully run
DEBUG - 2014-08-13 15:54:44 --> Controller Class Initialized
DEBUG - 2014-08-13 15:54:45 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:54:45 --> Form Validation Class Initialized
DEBUG - 2014-08-13 15:54:45 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 15:54:45 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:45 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:45 --> Model Class Initialized
DEBUG - 2014-08-13 15:54:45 --> Model Class Initialized
DEBUG - 2014-08-13 15:54:45 --> Encrypt Class Initialized
DEBUG - 2014-08-13 15:54:45 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:45 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:45 --> Model Class Initialized
DEBUG - 2014-08-13 15:54:45 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 15:54:45 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:45 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:45 --> Config Class Initialized
DEBUG - 2014-08-13 15:54:45 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:54:45 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:54:45 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:54:45 --> URI Class Initialized
DEBUG - 2014-08-13 15:54:45 --> Router Class Initialized
DEBUG - 2014-08-13 15:54:45 --> Output Class Initialized
DEBUG - 2014-08-13 15:54:45 --> Security Class Initialized
DEBUG - 2014-08-13 15:54:45 --> Input Class Initialized
DEBUG - 2014-08-13 15:54:45 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:45 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:45 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:45 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:45 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:45 --> CRSF cookie Set
DEBUG - 2014-08-13 15:54:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:54:45 --> Language Class Initialized
DEBUG - 2014-08-13 15:54:45 --> Loader Class Initialized
DEBUG - 2014-08-13 15:54:45 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:54:45 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:54:45 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:54:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:54:45 --> Session Class Initialized
DEBUG - 2014-08-13 15:54:45 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:54:45 --> Session routines successfully run
DEBUG - 2014-08-13 15:54:45 --> Controller Class Initialized
DEBUG - 2014-08-13 15:54:45 --> File loaded: application/views/login_to_continue.php
DEBUG - 2014-08-13 15:54:45 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:54:45 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-13 15:54:45 --> Model Class Initialized
DEBUG - 2014-08-13 15:54:45 --> Model Class Initialized
DEBUG - 2014-08-13 15:54:45 --> Model Class Initialized
DEBUG - 2014-08-13 15:54:45 --> Model Class Initialized
DEBUG - 2014-08-13 15:54:45 --> Helper loaded: array_helper
DEBUG - 2014-08-13 15:54:45 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:54:45 --> File loaded: application/views/placement_students_home.php
DEBUG - 2014-08-13 15:54:45 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:54:45 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:54:45 --> Final output sent to browser
DEBUG - 2014-08-13 15:54:45 --> Total execution time: 0.1561
DEBUG - 2014-08-13 15:54:49 --> Config Class Initialized
DEBUG - 2014-08-13 15:54:49 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:54:49 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:54:49 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:54:49 --> URI Class Initialized
DEBUG - 2014-08-13 15:54:49 --> Router Class Initialized
DEBUG - 2014-08-13 15:54:49 --> No URI present. Default controller set.
DEBUG - 2014-08-13 15:54:49 --> Output Class Initialized
DEBUG - 2014-08-13 15:54:49 --> Security Class Initialized
DEBUG - 2014-08-13 15:54:49 --> Input Class Initialized
DEBUG - 2014-08-13 15:54:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:49 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:49 --> CRSF cookie Set
DEBUG - 2014-08-13 15:54:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:54:49 --> Language Class Initialized
DEBUG - 2014-08-13 15:54:49 --> Loader Class Initialized
DEBUG - 2014-08-13 15:54:49 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:54:49 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:54:49 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:54:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:54:49 --> Session Class Initialized
DEBUG - 2014-08-13 15:54:49 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:54:49 --> Session routines successfully run
DEBUG - 2014-08-13 15:54:49 --> Controller Class Initialized
DEBUG - 2014-08-13 15:54:49 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:54:49 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 15:54:49 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 15:54:49 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:54:49 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 15:54:49 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 15:54:49 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:54:49 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:54:49 --> Final output sent to browser
DEBUG - 2014-08-13 15:54:49 --> Total execution time: 0.0965
DEBUG - 2014-08-13 15:54:56 --> Config Class Initialized
DEBUG - 2014-08-13 15:54:56 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:54:56 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:54:56 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:54:56 --> URI Class Initialized
DEBUG - 2014-08-13 15:54:56 --> Router Class Initialized
DEBUG - 2014-08-13 15:54:56 --> Output Class Initialized
DEBUG - 2014-08-13 15:54:56 --> Security Class Initialized
DEBUG - 2014-08-13 15:54:56 --> Input Class Initialized
DEBUG - 2014-08-13 15:54:56 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:56 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:56 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:56 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:56 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:56 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:56 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:56 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:56 --> CRSF cookie Set
DEBUG - 2014-08-13 15:54:56 --> CSRF token verified
DEBUG - 2014-08-13 15:54:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:54:56 --> Language Class Initialized
DEBUG - 2014-08-13 15:54:56 --> Loader Class Initialized
DEBUG - 2014-08-13 15:54:56 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:54:56 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:54:56 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:54:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:54:56 --> Session Class Initialized
DEBUG - 2014-08-13 15:54:56 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:54:56 --> Session routines successfully run
DEBUG - 2014-08-13 15:54:56 --> Controller Class Initialized
DEBUG - 2014-08-13 15:54:56 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:54:56 --> Form Validation Class Initialized
DEBUG - 2014-08-13 15:54:56 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 15:54:56 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:56 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:56 --> Model Class Initialized
DEBUG - 2014-08-13 15:54:56 --> Model Class Initialized
DEBUG - 2014-08-13 15:54:56 --> Encrypt Class Initialized
DEBUG - 2014-08-13 15:54:56 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:56 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:56 --> Model Class Initialized
DEBUG - 2014-08-13 15:54:56 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 15:54:56 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:56 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:56 --> Config Class Initialized
DEBUG - 2014-08-13 15:54:56 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:54:56 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:54:56 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:54:56 --> URI Class Initialized
DEBUG - 2014-08-13 15:54:56 --> Router Class Initialized
DEBUG - 2014-08-13 15:54:56 --> Output Class Initialized
DEBUG - 2014-08-13 15:54:56 --> Security Class Initialized
DEBUG - 2014-08-13 15:54:56 --> Input Class Initialized
DEBUG - 2014-08-13 15:54:56 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:56 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:56 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:56 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:56 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:56 --> CRSF cookie Set
DEBUG - 2014-08-13 15:54:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:54:56 --> Language Class Initialized
DEBUG - 2014-08-13 15:54:56 --> Loader Class Initialized
DEBUG - 2014-08-13 15:54:56 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:54:56 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:54:56 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:54:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:54:56 --> Session Class Initialized
DEBUG - 2014-08-13 15:54:56 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:54:56 --> Session routines successfully run
DEBUG - 2014-08-13 15:54:56 --> Controller Class Initialized
DEBUG - 2014-08-13 15:54:56 --> File loaded: application/views/login_to_continue.php
DEBUG - 2014-08-13 15:54:56 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:54:56 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-13 15:54:56 --> Model Class Initialized
DEBUG - 2014-08-13 15:54:56 --> Model Class Initialized
DEBUG - 2014-08-13 15:54:56 --> Model Class Initialized
DEBUG - 2014-08-13 15:54:56 --> Model Class Initialized
DEBUG - 2014-08-13 15:54:56 --> Helper loaded: array_helper
DEBUG - 2014-08-13 15:54:56 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:54:56 --> File loaded: application/views/placement_students_home.php
DEBUG - 2014-08-13 15:54:56 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:54:56 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:54:56 --> Final output sent to browser
DEBUG - 2014-08-13 15:54:56 --> Total execution time: 0.1494
DEBUG - 2014-08-13 15:54:58 --> Config Class Initialized
DEBUG - 2014-08-13 15:54:58 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:54:58 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:54:58 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:54:58 --> URI Class Initialized
DEBUG - 2014-08-13 15:54:58 --> Router Class Initialized
DEBUG - 2014-08-13 15:54:58 --> No URI present. Default controller set.
DEBUG - 2014-08-13 15:54:58 --> Output Class Initialized
DEBUG - 2014-08-13 15:54:58 --> Security Class Initialized
DEBUG - 2014-08-13 15:54:58 --> Input Class Initialized
DEBUG - 2014-08-13 15:54:58 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:58 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:58 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:58 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:58 --> XSS Filtering completed
DEBUG - 2014-08-13 15:54:58 --> CRSF cookie Set
DEBUG - 2014-08-13 15:54:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:54:58 --> Language Class Initialized
DEBUG - 2014-08-13 15:54:58 --> Loader Class Initialized
DEBUG - 2014-08-13 15:54:58 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:54:58 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:54:58 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:54:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:54:58 --> Session Class Initialized
DEBUG - 2014-08-13 15:54:58 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:54:58 --> Session routines successfully run
DEBUG - 2014-08-13 15:54:58 --> Controller Class Initialized
DEBUG - 2014-08-13 15:54:58 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:54:58 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 15:54:58 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 15:54:58 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:54:58 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 15:54:58 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 15:54:58 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:54:58 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:54:58 --> Final output sent to browser
DEBUG - 2014-08-13 15:54:58 --> Total execution time: 0.0979
DEBUG - 2014-08-13 15:56:42 --> Config Class Initialized
DEBUG - 2014-08-13 15:56:42 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:56:42 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:56:42 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:56:42 --> URI Class Initialized
DEBUG - 2014-08-13 15:56:42 --> Router Class Initialized
DEBUG - 2014-08-13 15:56:42 --> Output Class Initialized
DEBUG - 2014-08-13 15:56:42 --> Security Class Initialized
DEBUG - 2014-08-13 15:56:42 --> Input Class Initialized
DEBUG - 2014-08-13 15:56:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:56:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:56:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:56:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:56:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:56:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:56:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:56:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:56:42 --> CRSF cookie Set
DEBUG - 2014-08-13 15:56:42 --> CSRF token verified
DEBUG - 2014-08-13 15:56:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:56:42 --> Language Class Initialized
DEBUG - 2014-08-13 15:56:42 --> Loader Class Initialized
DEBUG - 2014-08-13 15:56:42 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:56:42 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:56:42 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:56:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:56:42 --> Session Class Initialized
DEBUG - 2014-08-13 15:56:42 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:56:42 --> Session routines successfully run
DEBUG - 2014-08-13 15:56:42 --> Controller Class Initialized
DEBUG - 2014-08-13 15:56:42 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:56:42 --> Form Validation Class Initialized
DEBUG - 2014-08-13 15:56:42 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 15:56:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:56:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:56:42 --> Model Class Initialized
DEBUG - 2014-08-13 15:56:42 --> Model Class Initialized
DEBUG - 2014-08-13 15:56:42 --> Encrypt Class Initialized
DEBUG - 2014-08-13 15:56:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:56:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:56:42 --> Config Class Initialized
DEBUG - 2014-08-13 15:56:42 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:56:42 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:56:42 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:56:42 --> URI Class Initialized
DEBUG - 2014-08-13 15:56:42 --> Router Class Initialized
DEBUG - 2014-08-13 15:56:42 --> Output Class Initialized
DEBUG - 2014-08-13 15:56:42 --> Security Class Initialized
DEBUG - 2014-08-13 15:56:42 --> Input Class Initialized
DEBUG - 2014-08-13 15:56:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:56:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:56:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:56:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:56:42 --> XSS Filtering completed
DEBUG - 2014-08-13 15:56:42 --> CRSF cookie Set
DEBUG - 2014-08-13 15:56:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:56:42 --> Language Class Initialized
DEBUG - 2014-08-13 15:56:42 --> Loader Class Initialized
DEBUG - 2014-08-13 15:56:42 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:56:42 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:56:42 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:56:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:56:42 --> Session Class Initialized
DEBUG - 2014-08-13 15:56:42 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:56:42 --> Session routines successfully run
DEBUG - 2014-08-13 15:56:42 --> Controller Class Initialized
DEBUG - 2014-08-13 15:56:42 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:56:42 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-13 15:56:42 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-13 15:56:42 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 15:56:42 --> File loaded: application/views/placement_admin_home.php
DEBUG - 2014-08-13 15:56:42 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:56:42 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:56:42 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-13 15:56:42 --> Final output sent to browser
DEBUG - 2014-08-13 15:56:42 --> Total execution time: 0.1192
DEBUG - 2014-08-13 15:56:45 --> Config Class Initialized
DEBUG - 2014-08-13 15:56:45 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:56:45 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:56:45 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:56:45 --> URI Class Initialized
DEBUG - 2014-08-13 15:56:45 --> Router Class Initialized
DEBUG - 2014-08-13 15:56:45 --> Output Class Initialized
DEBUG - 2014-08-13 15:56:45 --> Security Class Initialized
DEBUG - 2014-08-13 15:56:45 --> Input Class Initialized
DEBUG - 2014-08-13 15:56:45 --> XSS Filtering completed
DEBUG - 2014-08-13 15:56:45 --> XSS Filtering completed
DEBUG - 2014-08-13 15:56:45 --> XSS Filtering completed
DEBUG - 2014-08-13 15:56:45 --> XSS Filtering completed
DEBUG - 2014-08-13 15:56:45 --> XSS Filtering completed
DEBUG - 2014-08-13 15:56:45 --> CRSF cookie Set
DEBUG - 2014-08-13 15:56:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:56:45 --> Language Class Initialized
DEBUG - 2014-08-13 15:56:45 --> Loader Class Initialized
DEBUG - 2014-08-13 15:56:45 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:56:45 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:56:46 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:56:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:56:46 --> Session Class Initialized
DEBUG - 2014-08-13 15:56:46 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:56:46 --> Session routines successfully run
DEBUG - 2014-08-13 15:56:46 --> Controller Class Initialized
DEBUG - 2014-08-13 15:56:46 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:56:46 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-13 15:56:46 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-13 15:56:46 --> File loaded: application/views/placement_admin_history.php
DEBUG - 2014-08-13 15:56:46 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:56:46 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:56:46 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-13 15:56:46 --> Final output sent to browser
DEBUG - 2014-08-13 15:56:46 --> Total execution time: 0.0913
DEBUG - 2014-08-13 15:56:47 --> Config Class Initialized
DEBUG - 2014-08-13 15:56:47 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:56:47 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:56:47 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:56:47 --> URI Class Initialized
DEBUG - 2014-08-13 15:56:47 --> Router Class Initialized
DEBUG - 2014-08-13 15:56:47 --> Output Class Initialized
DEBUG - 2014-08-13 15:56:47 --> Security Class Initialized
DEBUG - 2014-08-13 15:56:47 --> Input Class Initialized
DEBUG - 2014-08-13 15:56:47 --> XSS Filtering completed
DEBUG - 2014-08-13 15:56:47 --> XSS Filtering completed
DEBUG - 2014-08-13 15:56:47 --> XSS Filtering completed
DEBUG - 2014-08-13 15:56:47 --> XSS Filtering completed
DEBUG - 2014-08-13 15:56:47 --> XSS Filtering completed
DEBUG - 2014-08-13 15:56:47 --> CRSF cookie Set
DEBUG - 2014-08-13 15:56:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:56:47 --> Language Class Initialized
DEBUG - 2014-08-13 15:56:47 --> Loader Class Initialized
DEBUG - 2014-08-13 15:56:47 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:56:47 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:56:47 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:56:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:56:47 --> Session Class Initialized
DEBUG - 2014-08-13 15:56:47 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:56:47 --> Session routines successfully run
DEBUG - 2014-08-13 15:56:47 --> Controller Class Initialized
DEBUG - 2014-08-13 15:56:47 --> File loaded: application/views/logout.php
DEBUG - 2014-08-13 15:56:47 --> Final output sent to browser
DEBUG - 2014-08-13 15:56:47 --> Total execution time: 0.0881
DEBUG - 2014-08-13 15:56:47 --> Config Class Initialized
DEBUG - 2014-08-13 15:56:47 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:56:47 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:56:47 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:56:47 --> URI Class Initialized
DEBUG - 2014-08-13 15:56:47 --> Router Class Initialized
DEBUG - 2014-08-13 15:56:47 --> No URI present. Default controller set.
DEBUG - 2014-08-13 15:56:47 --> Output Class Initialized
DEBUG - 2014-08-13 15:56:47 --> Security Class Initialized
DEBUG - 2014-08-13 15:56:47 --> Input Class Initialized
DEBUG - 2014-08-13 15:56:47 --> XSS Filtering completed
DEBUG - 2014-08-13 15:56:47 --> XSS Filtering completed
DEBUG - 2014-08-13 15:56:47 --> XSS Filtering completed
DEBUG - 2014-08-13 15:56:47 --> XSS Filtering completed
DEBUG - 2014-08-13 15:56:47 --> CRSF cookie Set
DEBUG - 2014-08-13 15:56:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:56:47 --> Language Class Initialized
DEBUG - 2014-08-13 15:56:47 --> Loader Class Initialized
DEBUG - 2014-08-13 15:56:47 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:56:47 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:56:47 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:56:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:56:47 --> Session Class Initialized
DEBUG - 2014-08-13 15:56:47 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:56:47 --> A session cookie was not found.
DEBUG - 2014-08-13 15:56:47 --> Session routines successfully run
DEBUG - 2014-08-13 15:56:47 --> Controller Class Initialized
DEBUG - 2014-08-13 15:56:47 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:56:47 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 15:56:47 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 15:56:47 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:56:47 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 15:56:47 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 15:56:47 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:56:47 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:56:47 --> Final output sent to browser
DEBUG - 2014-08-13 15:56:47 --> Total execution time: 0.1276
DEBUG - 2014-08-13 15:56:51 --> Config Class Initialized
DEBUG - 2014-08-13 15:56:51 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:56:51 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:56:51 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:56:51 --> URI Class Initialized
DEBUG - 2014-08-13 15:56:51 --> Router Class Initialized
DEBUG - 2014-08-13 15:56:51 --> Output Class Initialized
DEBUG - 2014-08-13 15:56:51 --> Security Class Initialized
DEBUG - 2014-08-13 15:56:51 --> Input Class Initialized
DEBUG - 2014-08-13 15:56:51 --> XSS Filtering completed
DEBUG - 2014-08-13 15:56:51 --> XSS Filtering completed
DEBUG - 2014-08-13 15:56:51 --> XSS Filtering completed
DEBUG - 2014-08-13 15:56:51 --> XSS Filtering completed
DEBUG - 2014-08-13 15:56:51 --> XSS Filtering completed
DEBUG - 2014-08-13 15:56:51 --> CRSF cookie Set
DEBUG - 2014-08-13 15:56:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:56:51 --> Language Class Initialized
DEBUG - 2014-08-13 15:56:51 --> Loader Class Initialized
DEBUG - 2014-08-13 15:56:51 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:56:51 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:56:51 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:56:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:56:51 --> Session Class Initialized
DEBUG - 2014-08-13 15:56:51 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:56:51 --> Session routines successfully run
DEBUG - 2014-08-13 15:56:51 --> Controller Class Initialized
DEBUG - 2014-08-13 15:56:51 --> File loaded: application/views/login_to_continue.php
DEBUG - 2014-08-13 15:56:51 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:56:51 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-13 15:56:51 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-13 15:56:51 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 15:56:51 --> File loaded: application/views/placement_admin_home.php
DEBUG - 2014-08-13 15:56:51 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:56:51 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:56:51 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-13 15:56:51 --> Final output sent to browser
DEBUG - 2014-08-13 15:56:51 --> Total execution time: 0.0958
DEBUG - 2014-08-13 15:56:52 --> Config Class Initialized
DEBUG - 2014-08-13 15:56:52 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:56:52 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:56:52 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:56:52 --> URI Class Initialized
DEBUG - 2014-08-13 15:56:52 --> Router Class Initialized
DEBUG - 2014-08-13 15:56:52 --> No URI present. Default controller set.
DEBUG - 2014-08-13 15:56:52 --> Output Class Initialized
DEBUG - 2014-08-13 15:56:52 --> Security Class Initialized
DEBUG - 2014-08-13 15:56:52 --> Input Class Initialized
DEBUG - 2014-08-13 15:56:52 --> XSS Filtering completed
DEBUG - 2014-08-13 15:56:52 --> XSS Filtering completed
DEBUG - 2014-08-13 15:56:52 --> XSS Filtering completed
DEBUG - 2014-08-13 15:56:52 --> XSS Filtering completed
DEBUG - 2014-08-13 15:56:52 --> XSS Filtering completed
DEBUG - 2014-08-13 15:56:52 --> CRSF cookie Set
DEBUG - 2014-08-13 15:56:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:56:52 --> Language Class Initialized
DEBUG - 2014-08-13 15:56:52 --> Loader Class Initialized
DEBUG - 2014-08-13 15:56:52 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:56:52 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:56:52 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:56:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:56:52 --> Session Class Initialized
DEBUG - 2014-08-13 15:56:52 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:56:52 --> Session routines successfully run
DEBUG - 2014-08-13 15:56:52 --> Controller Class Initialized
DEBUG - 2014-08-13 15:56:52 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:56:52 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 15:56:52 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 15:56:52 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:56:52 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 15:56:52 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 15:56:52 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:56:52 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:56:52 --> Final output sent to browser
DEBUG - 2014-08-13 15:56:52 --> Total execution time: 0.1032
DEBUG - 2014-08-13 15:57:01 --> Config Class Initialized
DEBUG - 2014-08-13 15:57:01 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:57:02 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:57:02 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:57:02 --> URI Class Initialized
DEBUG - 2014-08-13 15:57:02 --> Router Class Initialized
DEBUG - 2014-08-13 15:57:02 --> Output Class Initialized
DEBUG - 2014-08-13 15:57:02 --> Security Class Initialized
DEBUG - 2014-08-13 15:57:02 --> Input Class Initialized
DEBUG - 2014-08-13 15:57:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:02 --> CRSF cookie Set
DEBUG - 2014-08-13 15:57:02 --> CSRF token verified
DEBUG - 2014-08-13 15:57:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:57:02 --> Language Class Initialized
DEBUG - 2014-08-13 15:57:02 --> Loader Class Initialized
DEBUG - 2014-08-13 15:57:02 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:57:02 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:57:02 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:57:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:57:02 --> Session Class Initialized
DEBUG - 2014-08-13 15:57:02 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:57:02 --> Session routines successfully run
DEBUG - 2014-08-13 15:57:02 --> Controller Class Initialized
DEBUG - 2014-08-13 15:57:02 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:57:02 --> Form Validation Class Initialized
DEBUG - 2014-08-13 15:57:02 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 15:57:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:02 --> Model Class Initialized
DEBUG - 2014-08-13 15:57:02 --> Model Class Initialized
DEBUG - 2014-08-13 15:57:02 --> Encrypt Class Initialized
DEBUG - 2014-08-13 15:57:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:02 --> Model Class Initialized
DEBUG - 2014-08-13 15:57:02 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 15:57:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:02 --> Config Class Initialized
DEBUG - 2014-08-13 15:57:02 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:57:02 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:57:02 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:57:02 --> URI Class Initialized
DEBUG - 2014-08-13 15:57:02 --> Router Class Initialized
DEBUG - 2014-08-13 15:57:02 --> Output Class Initialized
DEBUG - 2014-08-13 15:57:02 --> Security Class Initialized
DEBUG - 2014-08-13 15:57:02 --> Input Class Initialized
DEBUG - 2014-08-13 15:57:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:02 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:02 --> CRSF cookie Set
DEBUG - 2014-08-13 15:57:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:57:02 --> Language Class Initialized
DEBUG - 2014-08-13 15:57:02 --> Loader Class Initialized
DEBUG - 2014-08-13 15:57:02 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:57:02 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:57:02 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:57:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:57:02 --> Session Class Initialized
DEBUG - 2014-08-13 15:57:02 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:57:02 --> Session routines successfully run
DEBUG - 2014-08-13 15:57:02 --> Controller Class Initialized
DEBUG - 2014-08-13 15:57:02 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:57:02 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-13 15:57:02 --> Model Class Initialized
DEBUG - 2014-08-13 15:57:02 --> Model Class Initialized
DEBUG - 2014-08-13 15:57:02 --> Model Class Initialized
DEBUG - 2014-08-13 15:57:02 --> Model Class Initialized
DEBUG - 2014-08-13 15:57:02 --> Helper loaded: array_helper
DEBUG - 2014-08-13 15:57:02 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:57:02 --> File loaded: application/views/placement_students_home.php
DEBUG - 2014-08-13 15:57:02 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:57:02 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:57:02 --> Final output sent to browser
DEBUG - 2014-08-13 15:57:02 --> Total execution time: 0.1406
DEBUG - 2014-08-13 15:57:04 --> Config Class Initialized
DEBUG - 2014-08-13 15:57:04 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:57:04 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:57:04 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:57:04 --> URI Class Initialized
DEBUG - 2014-08-13 15:57:04 --> Router Class Initialized
DEBUG - 2014-08-13 15:57:04 --> Output Class Initialized
DEBUG - 2014-08-13 15:57:04 --> Security Class Initialized
DEBUG - 2014-08-13 15:57:04 --> Input Class Initialized
DEBUG - 2014-08-13 15:57:04 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:04 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:04 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:04 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:04 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:04 --> CRSF cookie Set
DEBUG - 2014-08-13 15:57:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:57:04 --> Language Class Initialized
DEBUG - 2014-08-13 15:57:04 --> Loader Class Initialized
DEBUG - 2014-08-13 15:57:04 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:57:04 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:57:04 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:57:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:57:04 --> Session Class Initialized
DEBUG - 2014-08-13 15:57:04 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:57:04 --> Session routines successfully run
DEBUG - 2014-08-13 15:57:04 --> Controller Class Initialized
DEBUG - 2014-08-13 15:57:04 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:57:04 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-13 15:57:04 --> Model Class Initialized
DEBUG - 2014-08-13 15:57:04 --> Model Class Initialized
DEBUG - 2014-08-13 15:57:04 --> Model Class Initialized
DEBUG - 2014-08-13 15:57:04 --> Model Class Initialized
DEBUG - 2014-08-13 15:57:04 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:57:04 --> Helper loaded: array_helper
DEBUG - 2014-08-13 15:57:04 --> File loaded: application/views/placement_students_update.php
DEBUG - 2014-08-13 15:57:04 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:57:04 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:57:04 --> Final output sent to browser
DEBUG - 2014-08-13 15:57:04 --> Total execution time: 0.1095
DEBUG - 2014-08-13 15:57:06 --> Config Class Initialized
DEBUG - 2014-08-13 15:57:06 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:57:06 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:57:06 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:57:06 --> URI Class Initialized
DEBUG - 2014-08-13 15:57:06 --> Router Class Initialized
DEBUG - 2014-08-13 15:57:06 --> Output Class Initialized
DEBUG - 2014-08-13 15:57:06 --> Security Class Initialized
DEBUG - 2014-08-13 15:57:06 --> Input Class Initialized
DEBUG - 2014-08-13 15:57:06 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:06 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:06 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:06 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:06 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:06 --> CRSF cookie Set
DEBUG - 2014-08-13 15:57:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:57:06 --> Language Class Initialized
DEBUG - 2014-08-13 15:57:06 --> Loader Class Initialized
DEBUG - 2014-08-13 15:57:06 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:57:06 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:57:06 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:57:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:57:06 --> Session Class Initialized
DEBUG - 2014-08-13 15:57:06 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:57:06 --> Session routines successfully run
DEBUG - 2014-08-13 15:57:06 --> Controller Class Initialized
DEBUG - 2014-08-13 15:57:06 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:57:06 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-13 15:57:06 --> Model Class Initialized
DEBUG - 2014-08-13 15:57:06 --> Model Class Initialized
DEBUG - 2014-08-13 15:57:06 --> Model Class Initialized
DEBUG - 2014-08-13 15:57:06 --> Model Class Initialized
DEBUG - 2014-08-13 15:57:06 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-13 15:57:06 --> File loaded: application/views/placement_under_construction_in.php
DEBUG - 2014-08-13 15:57:06 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:57:06 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:57:06 --> Final output sent to browser
DEBUG - 2014-08-13 15:57:06 --> Total execution time: 0.1162
DEBUG - 2014-08-13 15:57:07 --> Config Class Initialized
DEBUG - 2014-08-13 15:57:07 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:57:07 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:57:07 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:57:07 --> URI Class Initialized
DEBUG - 2014-08-13 15:57:07 --> Router Class Initialized
DEBUG - 2014-08-13 15:57:07 --> Output Class Initialized
DEBUG - 2014-08-13 15:57:07 --> Security Class Initialized
DEBUG - 2014-08-13 15:57:07 --> Input Class Initialized
DEBUG - 2014-08-13 15:57:07 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:07 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:07 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:07 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:07 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:07 --> CRSF cookie Set
DEBUG - 2014-08-13 15:57:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:57:07 --> Language Class Initialized
DEBUG - 2014-08-13 15:57:07 --> Loader Class Initialized
DEBUG - 2014-08-13 15:57:07 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:57:07 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:57:07 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:57:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:57:07 --> Session Class Initialized
DEBUG - 2014-08-13 15:57:07 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:57:07 --> Session routines successfully run
DEBUG - 2014-08-13 15:57:07 --> Controller Class Initialized
DEBUG - 2014-08-13 15:57:07 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:57:07 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-13 15:57:07 --> Model Class Initialized
DEBUG - 2014-08-13 15:57:07 --> Model Class Initialized
DEBUG - 2014-08-13 15:57:07 --> Model Class Initialized
DEBUG - 2014-08-13 15:57:07 --> Model Class Initialized
DEBUG - 2014-08-13 15:57:07 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-13 15:57:07 --> File loaded: application/views/placement_under_construction_in.php
DEBUG - 2014-08-13 15:57:07 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:57:07 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:57:07 --> Final output sent to browser
DEBUG - 2014-08-13 15:57:07 --> Total execution time: 0.1061
DEBUG - 2014-08-13 15:57:08 --> Config Class Initialized
DEBUG - 2014-08-13 15:57:08 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:57:08 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:57:08 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:57:08 --> URI Class Initialized
DEBUG - 2014-08-13 15:57:08 --> Router Class Initialized
DEBUG - 2014-08-13 15:57:08 --> Output Class Initialized
DEBUG - 2014-08-13 15:57:08 --> Security Class Initialized
DEBUG - 2014-08-13 15:57:08 --> Input Class Initialized
DEBUG - 2014-08-13 15:57:08 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:08 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:08 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:08 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:08 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:08 --> CRSF cookie Set
DEBUG - 2014-08-13 15:57:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:57:08 --> Language Class Initialized
DEBUG - 2014-08-13 15:57:08 --> Loader Class Initialized
DEBUG - 2014-08-13 15:57:08 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:57:08 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:57:08 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:57:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:57:08 --> Session Class Initialized
DEBUG - 2014-08-13 15:57:08 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:57:08 --> Session routines successfully run
DEBUG - 2014-08-13 15:57:08 --> Controller Class Initialized
DEBUG - 2014-08-13 15:57:08 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:57:08 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-13 15:57:08 --> Model Class Initialized
DEBUG - 2014-08-13 15:57:08 --> Model Class Initialized
DEBUG - 2014-08-13 15:57:08 --> Model Class Initialized
DEBUG - 2014-08-13 15:57:08 --> Model Class Initialized
DEBUG - 2014-08-13 15:57:08 --> Helper loaded: array_helper
DEBUG - 2014-08-13 15:57:08 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:57:08 --> File loaded: application/views/placement_students_home.php
DEBUG - 2014-08-13 15:57:08 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:57:08 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:57:08 --> Final output sent to browser
DEBUG - 2014-08-13 15:57:08 --> Total execution time: 0.1180
DEBUG - 2014-08-13 15:57:30 --> Config Class Initialized
DEBUG - 2014-08-13 15:57:30 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:57:30 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:57:30 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:57:30 --> URI Class Initialized
DEBUG - 2014-08-13 15:57:30 --> Router Class Initialized
DEBUG - 2014-08-13 15:57:30 --> Output Class Initialized
DEBUG - 2014-08-13 15:57:30 --> Security Class Initialized
DEBUG - 2014-08-13 15:57:30 --> Input Class Initialized
DEBUG - 2014-08-13 15:57:30 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:30 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:30 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:30 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:30 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:30 --> CRSF cookie Set
DEBUG - 2014-08-13 15:57:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:57:30 --> Language Class Initialized
DEBUG - 2014-08-13 15:57:30 --> Loader Class Initialized
DEBUG - 2014-08-13 15:57:30 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:57:30 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:57:30 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:57:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:57:30 --> Session Class Initialized
DEBUG - 2014-08-13 15:57:30 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:57:30 --> Session routines successfully run
DEBUG - 2014-08-13 15:57:30 --> Controller Class Initialized
DEBUG - 2014-08-13 15:57:30 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:57:30 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-13 15:57:30 --> Model Class Initialized
DEBUG - 2014-08-13 15:57:30 --> Model Class Initialized
DEBUG - 2014-08-13 15:57:30 --> Model Class Initialized
DEBUG - 2014-08-13 15:57:30 --> Model Class Initialized
DEBUG - 2014-08-13 15:57:30 --> Helper loaded: array_helper
DEBUG - 2014-08-13 15:57:30 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:57:30 --> File loaded: application/views/placement_students_home.php
DEBUG - 2014-08-13 15:57:30 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:57:30 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:57:30 --> Final output sent to browser
DEBUG - 2014-08-13 15:57:30 --> Total execution time: 0.1183
DEBUG - 2014-08-13 15:57:37 --> Config Class Initialized
DEBUG - 2014-08-13 15:57:37 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:57:37 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:57:37 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:57:37 --> URI Class Initialized
DEBUG - 2014-08-13 15:57:37 --> Router Class Initialized
DEBUG - 2014-08-13 15:57:37 --> Output Class Initialized
DEBUG - 2014-08-13 15:57:37 --> Security Class Initialized
DEBUG - 2014-08-13 15:57:37 --> Input Class Initialized
DEBUG - 2014-08-13 15:57:37 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:37 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:37 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:37 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:37 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:37 --> CRSF cookie Set
DEBUG - 2014-08-13 15:57:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:57:37 --> Language Class Initialized
DEBUG - 2014-08-13 15:57:37 --> Loader Class Initialized
DEBUG - 2014-08-13 15:57:37 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:57:37 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:57:37 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:57:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:57:37 --> Session Class Initialized
DEBUG - 2014-08-13 15:57:37 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:57:37 --> Session routines successfully run
DEBUG - 2014-08-13 15:57:37 --> Controller Class Initialized
DEBUG - 2014-08-13 15:57:37 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:57:37 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-13 15:57:37 --> Model Class Initialized
DEBUG - 2014-08-13 15:57:37 --> Model Class Initialized
DEBUG - 2014-08-13 15:57:37 --> Model Class Initialized
DEBUG - 2014-08-13 15:57:37 --> Model Class Initialized
DEBUG - 2014-08-13 15:57:37 --> Helper loaded: array_helper
DEBUG - 2014-08-13 15:57:38 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:57:38 --> File loaded: application/views/placement_students_home.php
DEBUG - 2014-08-13 15:57:38 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:57:38 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:57:38 --> Final output sent to browser
DEBUG - 2014-08-13 15:57:38 --> Total execution time: 0.1343
DEBUG - 2014-08-13 15:57:57 --> Config Class Initialized
DEBUG - 2014-08-13 15:57:57 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:57:57 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:57:57 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:57:57 --> URI Class Initialized
DEBUG - 2014-08-13 15:57:57 --> Router Class Initialized
DEBUG - 2014-08-13 15:57:57 --> Output Class Initialized
DEBUG - 2014-08-13 15:57:57 --> Security Class Initialized
DEBUG - 2014-08-13 15:57:57 --> Input Class Initialized
DEBUG - 2014-08-13 15:57:57 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:57 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:57 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:57 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:57 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:57 --> CRSF cookie Set
DEBUG - 2014-08-13 15:57:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:57:57 --> Language Class Initialized
DEBUG - 2014-08-13 15:57:57 --> Loader Class Initialized
DEBUG - 2014-08-13 15:57:57 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:57:57 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:57:57 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:57:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:57:57 --> Session Class Initialized
DEBUG - 2014-08-13 15:57:57 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:57:57 --> Session routines successfully run
DEBUG - 2014-08-13 15:57:57 --> Controller Class Initialized
DEBUG - 2014-08-13 15:57:57 --> File loaded: application/views/logout.php
DEBUG - 2014-08-13 15:57:57 --> Final output sent to browser
DEBUG - 2014-08-13 15:57:57 --> Total execution time: 0.0808
DEBUG - 2014-08-13 15:57:57 --> Config Class Initialized
DEBUG - 2014-08-13 15:57:57 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:57:57 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:57:57 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:57:57 --> URI Class Initialized
DEBUG - 2014-08-13 15:57:57 --> Router Class Initialized
DEBUG - 2014-08-13 15:57:57 --> No URI present. Default controller set.
DEBUG - 2014-08-13 15:57:57 --> Output Class Initialized
DEBUG - 2014-08-13 15:57:57 --> Security Class Initialized
DEBUG - 2014-08-13 15:57:57 --> Input Class Initialized
DEBUG - 2014-08-13 15:57:57 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:57 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:57 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:57 --> XSS Filtering completed
DEBUG - 2014-08-13 15:57:57 --> CRSF cookie Set
DEBUG - 2014-08-13 15:57:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:57:57 --> Language Class Initialized
DEBUG - 2014-08-13 15:57:57 --> Loader Class Initialized
DEBUG - 2014-08-13 15:57:57 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:57:57 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:57:57 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:57:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:57:57 --> Session Class Initialized
DEBUG - 2014-08-13 15:57:57 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:57:57 --> A session cookie was not found.
DEBUG - 2014-08-13 15:57:57 --> Session routines successfully run
DEBUG - 2014-08-13 15:57:57 --> Controller Class Initialized
DEBUG - 2014-08-13 15:57:57 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:57:57 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 15:57:57 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 15:57:57 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:57:57 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 15:57:57 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 15:57:57 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:57:57 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:57:57 --> Final output sent to browser
DEBUG - 2014-08-13 15:57:57 --> Total execution time: 0.1265
DEBUG - 2014-08-13 15:58:09 --> Config Class Initialized
DEBUG - 2014-08-13 15:58:09 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:58:09 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:58:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:58:09 --> URI Class Initialized
DEBUG - 2014-08-13 15:58:09 --> Router Class Initialized
DEBUG - 2014-08-13 15:58:09 --> Output Class Initialized
DEBUG - 2014-08-13 15:58:09 --> Security Class Initialized
DEBUG - 2014-08-13 15:58:09 --> Input Class Initialized
DEBUG - 2014-08-13 15:58:09 --> XSS Filtering completed
DEBUG - 2014-08-13 15:58:09 --> XSS Filtering completed
DEBUG - 2014-08-13 15:58:09 --> XSS Filtering completed
DEBUG - 2014-08-13 15:58:09 --> XSS Filtering completed
DEBUG - 2014-08-13 15:58:09 --> XSS Filtering completed
DEBUG - 2014-08-13 15:58:09 --> XSS Filtering completed
DEBUG - 2014-08-13 15:58:09 --> XSS Filtering completed
DEBUG - 2014-08-13 15:58:09 --> XSS Filtering completed
DEBUG - 2014-08-13 15:58:09 --> CRSF cookie Set
DEBUG - 2014-08-13 15:58:09 --> CSRF token verified
DEBUG - 2014-08-13 15:58:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:58:09 --> Language Class Initialized
DEBUG - 2014-08-13 15:58:09 --> Loader Class Initialized
DEBUG - 2014-08-13 15:58:09 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:58:09 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:58:10 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:58:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:58:10 --> Session Class Initialized
DEBUG - 2014-08-13 15:58:10 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:58:10 --> Session routines successfully run
DEBUG - 2014-08-13 15:58:10 --> Controller Class Initialized
DEBUG - 2014-08-13 15:58:10 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:58:10 --> Form Validation Class Initialized
DEBUG - 2014-08-13 15:58:10 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 15:58:10 --> XSS Filtering completed
DEBUG - 2014-08-13 15:58:10 --> XSS Filtering completed
DEBUG - 2014-08-13 15:58:10 --> Model Class Initialized
DEBUG - 2014-08-13 15:58:10 --> Model Class Initialized
DEBUG - 2014-08-13 15:58:10 --> Encrypt Class Initialized
DEBUG - 2014-08-13 15:58:10 --> XSS Filtering completed
DEBUG - 2014-08-13 15:58:10 --> XSS Filtering completed
DEBUG - 2014-08-13 15:58:10 --> Model Class Initialized
DEBUG - 2014-08-13 15:58:10 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 15:58:10 --> XSS Filtering completed
DEBUG - 2014-08-13 15:58:10 --> XSS Filtering completed
DEBUG - 2014-08-13 15:58:10 --> Config Class Initialized
DEBUG - 2014-08-13 15:58:10 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:58:10 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:58:10 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:58:10 --> URI Class Initialized
DEBUG - 2014-08-13 15:58:10 --> Router Class Initialized
DEBUG - 2014-08-13 15:58:10 --> Output Class Initialized
DEBUG - 2014-08-13 15:58:10 --> Security Class Initialized
DEBUG - 2014-08-13 15:58:10 --> Input Class Initialized
DEBUG - 2014-08-13 15:58:10 --> XSS Filtering completed
DEBUG - 2014-08-13 15:58:10 --> XSS Filtering completed
DEBUG - 2014-08-13 15:58:10 --> XSS Filtering completed
DEBUG - 2014-08-13 15:58:10 --> XSS Filtering completed
DEBUG - 2014-08-13 15:58:10 --> XSS Filtering completed
DEBUG - 2014-08-13 15:58:10 --> CRSF cookie Set
DEBUG - 2014-08-13 15:58:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:58:10 --> Language Class Initialized
DEBUG - 2014-08-13 15:58:10 --> Loader Class Initialized
DEBUG - 2014-08-13 15:58:10 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:58:10 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:58:10 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:58:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:58:10 --> Session Class Initialized
DEBUG - 2014-08-13 15:58:10 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:58:10 --> Session routines successfully run
DEBUG - 2014-08-13 15:58:10 --> Controller Class Initialized
DEBUG - 2014-08-13 15:58:10 --> File loaded: application/views/login_to_continue.php
DEBUG - 2014-08-13 15:58:10 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:58:10 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-13 15:58:10 --> Model Class Initialized
DEBUG - 2014-08-13 15:58:10 --> Model Class Initialized
DEBUG - 2014-08-13 15:58:10 --> Model Class Initialized
DEBUG - 2014-08-13 15:58:10 --> Model Class Initialized
DEBUG - 2014-08-13 15:58:10 --> Helper loaded: array_helper
DEBUG - 2014-08-13 15:58:10 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:58:10 --> File loaded: application/views/placement_students_home.php
DEBUG - 2014-08-13 15:58:10 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:58:10 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:58:10 --> Final output sent to browser
DEBUG - 2014-08-13 15:58:10 --> Total execution time: 0.1441
DEBUG - 2014-08-13 15:58:11 --> Config Class Initialized
DEBUG - 2014-08-13 15:58:11 --> Hooks Class Initialized
DEBUG - 2014-08-13 15:58:11 --> Utf8 Class Initialized
DEBUG - 2014-08-13 15:58:11 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 15:58:11 --> URI Class Initialized
DEBUG - 2014-08-13 15:58:11 --> Router Class Initialized
DEBUG - 2014-08-13 15:58:11 --> No URI present. Default controller set.
DEBUG - 2014-08-13 15:58:11 --> Output Class Initialized
DEBUG - 2014-08-13 15:58:11 --> Security Class Initialized
DEBUG - 2014-08-13 15:58:11 --> Input Class Initialized
DEBUG - 2014-08-13 15:58:11 --> XSS Filtering completed
DEBUG - 2014-08-13 15:58:11 --> XSS Filtering completed
DEBUG - 2014-08-13 15:58:11 --> XSS Filtering completed
DEBUG - 2014-08-13 15:58:11 --> XSS Filtering completed
DEBUG - 2014-08-13 15:58:11 --> XSS Filtering completed
DEBUG - 2014-08-13 15:58:11 --> CRSF cookie Set
DEBUG - 2014-08-13 15:58:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 15:58:11 --> Language Class Initialized
DEBUG - 2014-08-13 15:58:11 --> Loader Class Initialized
DEBUG - 2014-08-13 15:58:11 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 15:58:11 --> Helper loaded: url_helper
DEBUG - 2014-08-13 15:58:11 --> Database Driver Class Initialized
ERROR - 2014-08-13 15:58:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 15:58:11 --> Session Class Initialized
DEBUG - 2014-08-13 15:58:11 --> Helper loaded: string_helper
DEBUG - 2014-08-13 15:58:11 --> Session routines successfully run
DEBUG - 2014-08-13 15:58:11 --> Controller Class Initialized
DEBUG - 2014-08-13 15:58:11 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 15:58:11 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 15:58:11 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 15:58:11 --> Helper loaded: form_helper
DEBUG - 2014-08-13 15:58:11 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 15:58:11 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 15:58:11 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 15:58:11 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 15:58:11 --> Final output sent to browser
DEBUG - 2014-08-13 15:58:11 --> Total execution time: 0.1024
DEBUG - 2014-08-13 16:02:50 --> Config Class Initialized
DEBUG - 2014-08-13 16:02:50 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:02:50 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:02:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:02:50 --> URI Class Initialized
DEBUG - 2014-08-13 16:02:50 --> Router Class Initialized
DEBUG - 2014-08-13 16:02:50 --> Output Class Initialized
DEBUG - 2014-08-13 16:02:50 --> Security Class Initialized
DEBUG - 2014-08-13 16:02:50 --> Input Class Initialized
DEBUG - 2014-08-13 16:02:50 --> XSS Filtering completed
DEBUG - 2014-08-13 16:02:50 --> XSS Filtering completed
DEBUG - 2014-08-13 16:02:50 --> XSS Filtering completed
DEBUG - 2014-08-13 16:02:50 --> XSS Filtering completed
DEBUG - 2014-08-13 16:02:50 --> XSS Filtering completed
DEBUG - 2014-08-13 16:02:50 --> XSS Filtering completed
DEBUG - 2014-08-13 16:02:50 --> XSS Filtering completed
DEBUG - 2014-08-13 16:02:50 --> XSS Filtering completed
DEBUG - 2014-08-13 16:02:50 --> CRSF cookie Set
DEBUG - 2014-08-13 16:02:50 --> CSRF token verified
DEBUG - 2014-08-13 16:02:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:02:50 --> Language Class Initialized
DEBUG - 2014-08-13 16:02:50 --> Loader Class Initialized
DEBUG - 2014-08-13 16:02:50 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:02:50 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:02:50 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:02:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:02:50 --> Session Class Initialized
DEBUG - 2014-08-13 16:02:50 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:02:50 --> Session routines successfully run
DEBUG - 2014-08-13 16:02:50 --> Controller Class Initialized
DEBUG - 2014-08-13 16:02:50 --> Helper loaded: form_helper
DEBUG - 2014-08-13 16:02:50 --> Form Validation Class Initialized
DEBUG - 2014-08-13 16:02:50 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 16:02:50 --> XSS Filtering completed
DEBUG - 2014-08-13 16:02:50 --> XSS Filtering completed
DEBUG - 2014-08-13 16:02:50 --> Model Class Initialized
DEBUG - 2014-08-13 16:02:50 --> Model Class Initialized
DEBUG - 2014-08-13 16:02:50 --> Model Class Initialized
DEBUG - 2014-08-13 16:02:50 --> Model Class Initialized
DEBUG - 2014-08-13 16:02:50 --> Encrypt Class Initialized
DEBUG - 2014-08-13 16:02:50 --> XSS Filtering completed
DEBUG - 2014-08-13 16:02:50 --> XSS Filtering completed
DEBUG - 2014-08-13 16:02:50 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 16:02:50 --> XSS Filtering completed
DEBUG - 2014-08-13 16:02:50 --> XSS Filtering completed
DEBUG - 2014-08-13 16:02:50 --> Config Class Initialized
DEBUG - 2014-08-13 16:02:50 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:02:50 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:02:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:02:50 --> URI Class Initialized
DEBUG - 2014-08-13 16:02:50 --> Router Class Initialized
DEBUG - 2014-08-13 16:02:50 --> Output Class Initialized
DEBUG - 2014-08-13 16:02:50 --> Security Class Initialized
DEBUG - 2014-08-13 16:02:50 --> Input Class Initialized
DEBUG - 2014-08-13 16:02:50 --> XSS Filtering completed
DEBUG - 2014-08-13 16:02:50 --> XSS Filtering completed
DEBUG - 2014-08-13 16:02:50 --> XSS Filtering completed
DEBUG - 2014-08-13 16:02:50 --> XSS Filtering completed
DEBUG - 2014-08-13 16:02:50 --> XSS Filtering completed
DEBUG - 2014-08-13 16:02:50 --> CRSF cookie Set
DEBUG - 2014-08-13 16:02:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:02:50 --> Language Class Initialized
DEBUG - 2014-08-13 16:02:50 --> Loader Class Initialized
DEBUG - 2014-08-13 16:02:50 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:02:50 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:02:50 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:02:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:02:50 --> Session Class Initialized
DEBUG - 2014-08-13 16:02:50 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:02:50 --> Session routines successfully run
DEBUG - 2014-08-13 16:02:50 --> Controller Class Initialized
DEBUG - 2014-08-13 16:02:50 --> File loaded: application/views/login_to_continue.php
DEBUG - 2014-08-13 16:02:50 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 16:02:50 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-13 16:02:50 --> Model Class Initialized
DEBUG - 2014-08-13 16:02:50 --> Model Class Initialized
DEBUG - 2014-08-13 16:02:50 --> Model Class Initialized
DEBUG - 2014-08-13 16:02:50 --> Model Class Initialized
DEBUG - 2014-08-13 16:02:51 --> Helper loaded: array_helper
DEBUG - 2014-08-13 16:02:51 --> Helper loaded: form_helper
DEBUG - 2014-08-13 16:02:51 --> File loaded: application/views/placement_students_home.php
DEBUG - 2014-08-13 16:02:51 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 16:02:51 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 16:02:51 --> Final output sent to browser
DEBUG - 2014-08-13 16:02:51 --> Total execution time: 0.1449
DEBUG - 2014-08-13 16:02:52 --> Config Class Initialized
DEBUG - 2014-08-13 16:02:52 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:02:52 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:02:52 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:02:52 --> URI Class Initialized
DEBUG - 2014-08-13 16:02:52 --> Router Class Initialized
DEBUG - 2014-08-13 16:02:52 --> No URI present. Default controller set.
DEBUG - 2014-08-13 16:02:52 --> Output Class Initialized
DEBUG - 2014-08-13 16:02:52 --> Security Class Initialized
DEBUG - 2014-08-13 16:02:52 --> Input Class Initialized
DEBUG - 2014-08-13 16:02:52 --> XSS Filtering completed
DEBUG - 2014-08-13 16:02:52 --> XSS Filtering completed
DEBUG - 2014-08-13 16:02:52 --> XSS Filtering completed
DEBUG - 2014-08-13 16:02:52 --> XSS Filtering completed
DEBUG - 2014-08-13 16:02:52 --> XSS Filtering completed
DEBUG - 2014-08-13 16:02:52 --> CRSF cookie Set
DEBUG - 2014-08-13 16:02:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:02:52 --> Language Class Initialized
DEBUG - 2014-08-13 16:02:52 --> Loader Class Initialized
DEBUG - 2014-08-13 16:02:52 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:02:52 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:02:52 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:02:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:02:52 --> Session Class Initialized
DEBUG - 2014-08-13 16:02:52 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:02:52 --> Session routines successfully run
DEBUG - 2014-08-13 16:02:52 --> Controller Class Initialized
DEBUG - 2014-08-13 16:02:52 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 16:02:52 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 16:02:52 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 16:02:52 --> Helper loaded: form_helper
DEBUG - 2014-08-13 16:02:52 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 16:02:52 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 16:02:52 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 16:02:52 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 16:02:52 --> Final output sent to browser
DEBUG - 2014-08-13 16:02:52 --> Total execution time: 0.1073
DEBUG - 2014-08-13 16:03:31 --> Config Class Initialized
DEBUG - 2014-08-13 16:03:31 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:03:31 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:03:31 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:03:31 --> URI Class Initialized
DEBUG - 2014-08-13 16:03:31 --> Router Class Initialized
DEBUG - 2014-08-13 16:03:31 --> Output Class Initialized
DEBUG - 2014-08-13 16:03:31 --> Security Class Initialized
DEBUG - 2014-08-13 16:03:31 --> Input Class Initialized
DEBUG - 2014-08-13 16:03:31 --> XSS Filtering completed
DEBUG - 2014-08-13 16:03:31 --> XSS Filtering completed
DEBUG - 2014-08-13 16:03:31 --> XSS Filtering completed
DEBUG - 2014-08-13 16:03:31 --> XSS Filtering completed
DEBUG - 2014-08-13 16:03:31 --> XSS Filtering completed
DEBUG - 2014-08-13 16:03:31 --> XSS Filtering completed
DEBUG - 2014-08-13 16:03:31 --> XSS Filtering completed
DEBUG - 2014-08-13 16:03:31 --> XSS Filtering completed
DEBUG - 2014-08-13 16:03:31 --> CRSF cookie Set
DEBUG - 2014-08-13 16:03:31 --> CSRF token verified
DEBUG - 2014-08-13 16:03:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:03:31 --> Language Class Initialized
DEBUG - 2014-08-13 16:03:31 --> Loader Class Initialized
DEBUG - 2014-08-13 16:03:31 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:03:31 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:03:31 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:03:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:03:31 --> Session Class Initialized
DEBUG - 2014-08-13 16:03:31 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:03:31 --> Session routines successfully run
DEBUG - 2014-08-13 16:03:31 --> Controller Class Initialized
DEBUG - 2014-08-13 16:03:31 --> Helper loaded: form_helper
DEBUG - 2014-08-13 16:03:31 --> Form Validation Class Initialized
DEBUG - 2014-08-13 16:03:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 16:03:31 --> XSS Filtering completed
DEBUG - 2014-08-13 16:03:31 --> XSS Filtering completed
DEBUG - 2014-08-13 16:03:31 --> Model Class Initialized
DEBUG - 2014-08-13 16:03:31 --> Model Class Initialized
DEBUG - 2014-08-13 16:03:31 --> Model Class Initialized
DEBUG - 2014-08-13 16:03:31 --> Model Class Initialized
DEBUG - 2014-08-13 16:03:31 --> Encrypt Class Initialized
DEBUG - 2014-08-13 16:03:31 --> XSS Filtering completed
DEBUG - 2014-08-13 16:03:31 --> XSS Filtering completed
DEBUG - 2014-08-13 16:03:31 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 16:03:31 --> XSS Filtering completed
DEBUG - 2014-08-13 16:03:31 --> XSS Filtering completed
DEBUG - 2014-08-13 16:03:31 --> Config Class Initialized
DEBUG - 2014-08-13 16:03:31 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:03:31 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:03:31 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:03:31 --> URI Class Initialized
DEBUG - 2014-08-13 16:03:31 --> Router Class Initialized
DEBUG - 2014-08-13 16:03:31 --> Output Class Initialized
DEBUG - 2014-08-13 16:03:31 --> Security Class Initialized
DEBUG - 2014-08-13 16:03:31 --> Input Class Initialized
DEBUG - 2014-08-13 16:03:31 --> XSS Filtering completed
DEBUG - 2014-08-13 16:03:31 --> XSS Filtering completed
DEBUG - 2014-08-13 16:03:31 --> XSS Filtering completed
DEBUG - 2014-08-13 16:03:31 --> XSS Filtering completed
DEBUG - 2014-08-13 16:03:31 --> XSS Filtering completed
DEBUG - 2014-08-13 16:03:31 --> CRSF cookie Set
DEBUG - 2014-08-13 16:03:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:03:31 --> Language Class Initialized
DEBUG - 2014-08-13 16:03:31 --> Loader Class Initialized
DEBUG - 2014-08-13 16:03:31 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:03:31 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:03:31 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:03:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:03:31 --> Session Class Initialized
DEBUG - 2014-08-13 16:03:31 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:03:31 --> Session routines successfully run
DEBUG - 2014-08-13 16:03:31 --> Controller Class Initialized
DEBUG - 2014-08-13 16:03:31 --> File loaded: application/views/login_to_continue.php
DEBUG - 2014-08-13 16:03:31 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 16:05:05 --> Config Class Initialized
DEBUG - 2014-08-13 16:05:05 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:05:05 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:05:05 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:05:05 --> URI Class Initialized
DEBUG - 2014-08-13 16:05:05 --> Router Class Initialized
DEBUG - 2014-08-13 16:05:05 --> Output Class Initialized
DEBUG - 2014-08-13 16:05:05 --> Security Class Initialized
DEBUG - 2014-08-13 16:05:05 --> Input Class Initialized
DEBUG - 2014-08-13 16:05:05 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:05 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:05 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:05 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:05 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:05 --> CRSF cookie Set
DEBUG - 2014-08-13 16:05:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:05:05 --> Language Class Initialized
DEBUG - 2014-08-13 16:05:05 --> Loader Class Initialized
DEBUG - 2014-08-13 16:05:05 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:05:05 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:05:05 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:05:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:05:05 --> Session Class Initialized
DEBUG - 2014-08-13 16:05:05 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:05:05 --> Session routines successfully run
DEBUG - 2014-08-13 16:05:05 --> Controller Class Initialized
DEBUG - 2014-08-13 16:05:05 --> File loaded: application/views/login_to_continue.php
DEBUG - 2014-08-13 16:05:05 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 16:05:12 --> Config Class Initialized
DEBUG - 2014-08-13 16:05:12 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:05:12 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:05:12 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:05:12 --> URI Class Initialized
DEBUG - 2014-08-13 16:05:12 --> Router Class Initialized
DEBUG - 2014-08-13 16:05:12 --> Output Class Initialized
DEBUG - 2014-08-13 16:05:12 --> Security Class Initialized
DEBUG - 2014-08-13 16:05:12 --> Input Class Initialized
DEBUG - 2014-08-13 16:05:12 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:12 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:12 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:12 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:12 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:12 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:12 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:12 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:12 --> CRSF cookie Set
DEBUG - 2014-08-13 16:05:12 --> CSRF token verified
DEBUG - 2014-08-13 16:05:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:05:12 --> Language Class Initialized
DEBUG - 2014-08-13 16:05:12 --> Loader Class Initialized
DEBUG - 2014-08-13 16:05:12 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:05:12 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:05:12 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:05:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:05:12 --> Session Class Initialized
DEBUG - 2014-08-13 16:05:12 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:05:12 --> Session routines successfully run
DEBUG - 2014-08-13 16:05:12 --> Controller Class Initialized
DEBUG - 2014-08-13 16:05:12 --> Helper loaded: form_helper
DEBUG - 2014-08-13 16:05:12 --> Form Validation Class Initialized
DEBUG - 2014-08-13 16:05:12 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 16:05:12 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:12 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:12 --> Model Class Initialized
DEBUG - 2014-08-13 16:05:12 --> Model Class Initialized
DEBUG - 2014-08-13 16:05:12 --> Model Class Initialized
DEBUG - 2014-08-13 16:05:12 --> Model Class Initialized
DEBUG - 2014-08-13 16:05:12 --> Encrypt Class Initialized
DEBUG - 2014-08-13 16:05:12 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:12 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:12 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 16:05:12 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:12 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:12 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 16:05:12 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 16:05:12 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 16:05:12 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 16:05:12 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 16:05:12 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 16:05:12 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 16:05:12 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 16:05:12 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 16:05:12 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 16:05:12 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 16:05:12 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 16:05:12 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 16:05:12 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 16:05:12 --> Final output sent to browser
DEBUG - 2014-08-13 16:05:12 --> Total execution time: 0.1646
DEBUG - 2014-08-13 16:05:21 --> Config Class Initialized
DEBUG - 2014-08-13 16:05:21 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:05:21 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:05:21 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:05:21 --> URI Class Initialized
DEBUG - 2014-08-13 16:05:21 --> Router Class Initialized
DEBUG - 2014-08-13 16:05:21 --> Output Class Initialized
DEBUG - 2014-08-13 16:05:21 --> Security Class Initialized
DEBUG - 2014-08-13 16:05:21 --> Input Class Initialized
DEBUG - 2014-08-13 16:05:21 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:21 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:21 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:21 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:21 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:21 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:21 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:21 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:21 --> CRSF cookie Set
DEBUG - 2014-08-13 16:05:21 --> CSRF token verified
DEBUG - 2014-08-13 16:05:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:05:21 --> Language Class Initialized
DEBUG - 2014-08-13 16:05:21 --> Loader Class Initialized
DEBUG - 2014-08-13 16:05:21 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:05:21 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:05:21 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:05:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:05:21 --> Session Class Initialized
DEBUG - 2014-08-13 16:05:21 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:05:21 --> Session routines successfully run
DEBUG - 2014-08-13 16:05:21 --> Controller Class Initialized
DEBUG - 2014-08-13 16:05:21 --> Helper loaded: form_helper
DEBUG - 2014-08-13 16:05:21 --> Form Validation Class Initialized
DEBUG - 2014-08-13 16:05:21 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 16:05:21 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:22 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:22 --> Model Class Initialized
DEBUG - 2014-08-13 16:05:22 --> Model Class Initialized
DEBUG - 2014-08-13 16:05:22 --> Model Class Initialized
DEBUG - 2014-08-13 16:05:22 --> Model Class Initialized
DEBUG - 2014-08-13 16:05:22 --> Encrypt Class Initialized
DEBUG - 2014-08-13 16:05:22 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:22 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:22 --> Config Class Initialized
DEBUG - 2014-08-13 16:05:22 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:05:22 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:05:22 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:05:22 --> URI Class Initialized
DEBUG - 2014-08-13 16:05:22 --> Router Class Initialized
DEBUG - 2014-08-13 16:05:22 --> Output Class Initialized
DEBUG - 2014-08-13 16:05:22 --> Security Class Initialized
DEBUG - 2014-08-13 16:05:22 --> Input Class Initialized
DEBUG - 2014-08-13 16:05:22 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:22 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:22 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:22 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:22 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:22 --> CRSF cookie Set
DEBUG - 2014-08-13 16:05:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:05:22 --> Language Class Initialized
DEBUG - 2014-08-13 16:05:22 --> Loader Class Initialized
DEBUG - 2014-08-13 16:05:22 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:05:22 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:05:22 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:05:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:05:22 --> Session Class Initialized
DEBUG - 2014-08-13 16:05:22 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:05:22 --> Session routines successfully run
DEBUG - 2014-08-13 16:05:22 --> Controller Class Initialized
DEBUG - 2014-08-13 16:05:22 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 16:05:22 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-13 16:05:22 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-13 16:05:22 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 16:05:22 --> File loaded: application/views/placement_admin_home.php
DEBUG - 2014-08-13 16:05:22 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 16:05:22 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 16:05:22 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-13 16:05:22 --> Final output sent to browser
DEBUG - 2014-08-13 16:05:22 --> Total execution time: 0.1196
DEBUG - 2014-08-13 16:05:24 --> Config Class Initialized
DEBUG - 2014-08-13 16:05:24 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:05:24 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:05:24 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:05:24 --> URI Class Initialized
DEBUG - 2014-08-13 16:05:24 --> Router Class Initialized
DEBUG - 2014-08-13 16:05:24 --> Output Class Initialized
DEBUG - 2014-08-13 16:05:24 --> Security Class Initialized
DEBUG - 2014-08-13 16:05:24 --> Input Class Initialized
DEBUG - 2014-08-13 16:05:24 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:24 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:24 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:24 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:24 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:24 --> CRSF cookie Set
DEBUG - 2014-08-13 16:05:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:05:24 --> Language Class Initialized
DEBUG - 2014-08-13 16:05:24 --> Loader Class Initialized
DEBUG - 2014-08-13 16:05:24 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:05:24 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:05:24 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:05:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:05:24 --> Session Class Initialized
DEBUG - 2014-08-13 16:05:24 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:05:24 --> Session routines successfully run
DEBUG - 2014-08-13 16:05:24 --> Controller Class Initialized
DEBUG - 2014-08-13 16:05:24 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 16:05:24 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-13 16:05:24 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-13 16:05:24 --> File loaded: application/views/placement_admin_history.php
DEBUG - 2014-08-13 16:05:24 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 16:05:24 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 16:05:24 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-13 16:05:24 --> Final output sent to browser
DEBUG - 2014-08-13 16:05:24 --> Total execution time: 0.1320
DEBUG - 2014-08-13 16:05:25 --> Config Class Initialized
DEBUG - 2014-08-13 16:05:25 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:05:25 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:05:25 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:05:25 --> URI Class Initialized
DEBUG - 2014-08-13 16:05:25 --> Router Class Initialized
DEBUG - 2014-08-13 16:05:25 --> Output Class Initialized
DEBUG - 2014-08-13 16:05:25 --> Security Class Initialized
DEBUG - 2014-08-13 16:05:25 --> Input Class Initialized
DEBUG - 2014-08-13 16:05:25 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:25 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:25 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:25 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:25 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:25 --> CRSF cookie Set
DEBUG - 2014-08-13 16:05:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:05:25 --> Language Class Initialized
DEBUG - 2014-08-13 16:05:25 --> Loader Class Initialized
DEBUG - 2014-08-13 16:05:25 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:05:25 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:05:25 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:05:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:05:25 --> Session Class Initialized
DEBUG - 2014-08-13 16:05:25 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:05:25 --> Session routines successfully run
DEBUG - 2014-08-13 16:05:25 --> Controller Class Initialized
DEBUG - 2014-08-13 16:05:25 --> File loaded: application/views/logout.php
DEBUG - 2014-08-13 16:05:25 --> Final output sent to browser
DEBUG - 2014-08-13 16:05:25 --> Total execution time: 0.0980
DEBUG - 2014-08-13 16:05:26 --> Config Class Initialized
DEBUG - 2014-08-13 16:05:26 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:05:26 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:05:26 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:05:26 --> URI Class Initialized
DEBUG - 2014-08-13 16:05:26 --> Router Class Initialized
DEBUG - 2014-08-13 16:05:26 --> No URI present. Default controller set.
DEBUG - 2014-08-13 16:05:26 --> Output Class Initialized
DEBUG - 2014-08-13 16:05:26 --> Security Class Initialized
DEBUG - 2014-08-13 16:05:26 --> Input Class Initialized
DEBUG - 2014-08-13 16:05:26 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:26 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:26 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:26 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:26 --> CRSF cookie Set
DEBUG - 2014-08-13 16:05:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:05:26 --> Language Class Initialized
DEBUG - 2014-08-13 16:05:26 --> Loader Class Initialized
DEBUG - 2014-08-13 16:05:26 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:05:26 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:05:26 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:05:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:05:26 --> Session Class Initialized
DEBUG - 2014-08-13 16:05:26 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:05:26 --> A session cookie was not found.
DEBUG - 2014-08-13 16:05:26 --> Session routines successfully run
DEBUG - 2014-08-13 16:05:26 --> Controller Class Initialized
DEBUG - 2014-08-13 16:05:26 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 16:05:26 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 16:05:26 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 16:05:26 --> Helper loaded: form_helper
DEBUG - 2014-08-13 16:05:26 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 16:05:26 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 16:05:26 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 16:05:26 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 16:05:26 --> Final output sent to browser
DEBUG - 2014-08-13 16:05:26 --> Total execution time: 0.1317
DEBUG - 2014-08-13 16:05:31 --> Config Class Initialized
DEBUG - 2014-08-13 16:05:31 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:05:31 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:05:31 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:05:31 --> URI Class Initialized
DEBUG - 2014-08-13 16:05:31 --> Router Class Initialized
DEBUG - 2014-08-13 16:05:31 --> Output Class Initialized
DEBUG - 2014-08-13 16:05:31 --> Security Class Initialized
DEBUG - 2014-08-13 16:05:31 --> Input Class Initialized
DEBUG - 2014-08-13 16:05:31 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:31 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:31 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:31 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:31 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:31 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:31 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:31 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:31 --> CRSF cookie Set
DEBUG - 2014-08-13 16:05:31 --> CSRF token verified
DEBUG - 2014-08-13 16:05:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:05:31 --> Language Class Initialized
DEBUG - 2014-08-13 16:05:31 --> Loader Class Initialized
DEBUG - 2014-08-13 16:05:31 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:05:31 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:05:31 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:05:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:05:31 --> Session Class Initialized
DEBUG - 2014-08-13 16:05:31 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:05:32 --> Session routines successfully run
DEBUG - 2014-08-13 16:05:32 --> Controller Class Initialized
DEBUG - 2014-08-13 16:05:32 --> Helper loaded: form_helper
DEBUG - 2014-08-13 16:05:32 --> Form Validation Class Initialized
DEBUG - 2014-08-13 16:05:32 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 16:05:32 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:32 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:32 --> Model Class Initialized
DEBUG - 2014-08-13 16:05:32 --> Model Class Initialized
DEBUG - 2014-08-13 16:05:32 --> Model Class Initialized
DEBUG - 2014-08-13 16:05:32 --> Model Class Initialized
DEBUG - 2014-08-13 16:05:32 --> Encrypt Class Initialized
DEBUG - 2014-08-13 16:05:32 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:32 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:32 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 16:05:32 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:32 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:32 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 16:05:32 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:32 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:32 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 16:05:32 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 16:05:32 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 16:05:32 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 16:05:32 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 16:05:32 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 16:05:32 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 16:05:32 --> Final output sent to browser
DEBUG - 2014-08-13 16:05:32 --> Total execution time: 0.1575
DEBUG - 2014-08-13 16:05:50 --> Config Class Initialized
DEBUG - 2014-08-13 16:05:50 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:05:50 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:05:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:05:50 --> URI Class Initialized
DEBUG - 2014-08-13 16:05:50 --> Router Class Initialized
DEBUG - 2014-08-13 16:05:50 --> Output Class Initialized
DEBUG - 2014-08-13 16:05:50 --> Security Class Initialized
DEBUG - 2014-08-13 16:05:50 --> Input Class Initialized
DEBUG - 2014-08-13 16:05:50 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:50 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:50 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:50 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:50 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:50 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:50 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:50 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:50 --> CRSF cookie Set
DEBUG - 2014-08-13 16:05:50 --> CSRF token verified
DEBUG - 2014-08-13 16:05:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:05:50 --> Language Class Initialized
DEBUG - 2014-08-13 16:05:50 --> Loader Class Initialized
DEBUG - 2014-08-13 16:05:50 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:05:50 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:05:50 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:05:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:05:50 --> Session Class Initialized
DEBUG - 2014-08-13 16:05:50 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:05:50 --> Session routines successfully run
DEBUG - 2014-08-13 16:05:50 --> Controller Class Initialized
DEBUG - 2014-08-13 16:05:50 --> Helper loaded: form_helper
DEBUG - 2014-08-13 16:05:50 --> Form Validation Class Initialized
DEBUG - 2014-08-13 16:05:50 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 16:05:50 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:50 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:50 --> Model Class Initialized
DEBUG - 2014-08-13 16:05:50 --> Model Class Initialized
DEBUG - 2014-08-13 16:05:50 --> Model Class Initialized
DEBUG - 2014-08-13 16:05:50 --> Model Class Initialized
DEBUG - 2014-08-13 16:05:50 --> Encrypt Class Initialized
DEBUG - 2014-08-13 16:05:50 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:50 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:50 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 16:05:50 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:50 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:51 --> Config Class Initialized
DEBUG - 2014-08-13 16:05:51 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:05:51 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:05:51 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:05:51 --> URI Class Initialized
DEBUG - 2014-08-13 16:05:51 --> Router Class Initialized
DEBUG - 2014-08-13 16:05:51 --> Output Class Initialized
DEBUG - 2014-08-13 16:05:51 --> Security Class Initialized
DEBUG - 2014-08-13 16:05:51 --> Input Class Initialized
DEBUG - 2014-08-13 16:05:51 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:51 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:51 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:51 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:51 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:51 --> CRSF cookie Set
DEBUG - 2014-08-13 16:05:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:05:51 --> Language Class Initialized
DEBUG - 2014-08-13 16:05:51 --> Loader Class Initialized
DEBUG - 2014-08-13 16:05:51 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:05:51 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:05:51 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:05:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:05:51 --> Session Class Initialized
DEBUG - 2014-08-13 16:05:51 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:05:51 --> Session routines successfully run
DEBUG - 2014-08-13 16:05:51 --> Controller Class Initialized
DEBUG - 2014-08-13 16:05:51 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 16:05:51 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-13 16:05:51 --> Model Class Initialized
DEBUG - 2014-08-13 16:05:51 --> Model Class Initialized
DEBUG - 2014-08-13 16:05:51 --> Model Class Initialized
DEBUG - 2014-08-13 16:05:51 --> Model Class Initialized
DEBUG - 2014-08-13 16:05:51 --> Helper loaded: array_helper
DEBUG - 2014-08-13 16:05:51 --> Helper loaded: form_helper
DEBUG - 2014-08-13 16:05:51 --> File loaded: application/views/placement_students_home.php
DEBUG - 2014-08-13 16:05:51 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 16:05:51 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 16:05:51 --> Final output sent to browser
DEBUG - 2014-08-13 16:05:51 --> Total execution time: 0.1426
DEBUG - 2014-08-13 16:05:53 --> Config Class Initialized
DEBUG - 2014-08-13 16:05:53 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:05:53 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:05:53 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:05:53 --> URI Class Initialized
DEBUG - 2014-08-13 16:05:53 --> Router Class Initialized
DEBUG - 2014-08-13 16:05:53 --> Output Class Initialized
DEBUG - 2014-08-13 16:05:53 --> Security Class Initialized
DEBUG - 2014-08-13 16:05:53 --> Input Class Initialized
DEBUG - 2014-08-13 16:05:53 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:53 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:53 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:53 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:53 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:53 --> CRSF cookie Set
DEBUG - 2014-08-13 16:05:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:05:53 --> Language Class Initialized
DEBUG - 2014-08-13 16:05:53 --> Loader Class Initialized
DEBUG - 2014-08-13 16:05:53 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:05:53 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:05:53 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:05:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:05:53 --> Session Class Initialized
DEBUG - 2014-08-13 16:05:53 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:05:53 --> Session routines successfully run
DEBUG - 2014-08-13 16:05:53 --> Controller Class Initialized
DEBUG - 2014-08-13 16:05:53 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 16:05:53 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-13 16:05:53 --> Model Class Initialized
DEBUG - 2014-08-13 16:05:53 --> Model Class Initialized
DEBUG - 2014-08-13 16:05:53 --> Model Class Initialized
DEBUG - 2014-08-13 16:05:53 --> Model Class Initialized
DEBUG - 2014-08-13 16:05:54 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-13 16:05:54 --> File loaded: application/views/placement_under_construction_in.php
DEBUG - 2014-08-13 16:05:54 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 16:05:54 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 16:05:54 --> Final output sent to browser
DEBUG - 2014-08-13 16:05:54 --> Total execution time: 0.1026
DEBUG - 2014-08-13 16:05:55 --> Config Class Initialized
DEBUG - 2014-08-13 16:05:55 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:05:55 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:05:55 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:05:55 --> URI Class Initialized
DEBUG - 2014-08-13 16:05:55 --> Router Class Initialized
DEBUG - 2014-08-13 16:05:55 --> Output Class Initialized
DEBUG - 2014-08-13 16:05:55 --> Security Class Initialized
DEBUG - 2014-08-13 16:05:55 --> Input Class Initialized
DEBUG - 2014-08-13 16:05:55 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:55 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:55 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:55 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:55 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:55 --> CRSF cookie Set
DEBUG - 2014-08-13 16:05:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:05:55 --> Language Class Initialized
DEBUG - 2014-08-13 16:05:55 --> Loader Class Initialized
DEBUG - 2014-08-13 16:05:55 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:05:55 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:05:55 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:05:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:05:55 --> Session Class Initialized
DEBUG - 2014-08-13 16:05:55 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:05:55 --> Session routines successfully run
DEBUG - 2014-08-13 16:05:55 --> Controller Class Initialized
DEBUG - 2014-08-13 16:05:55 --> File loaded: application/views/logout.php
DEBUG - 2014-08-13 16:05:55 --> Final output sent to browser
DEBUG - 2014-08-13 16:05:55 --> Total execution time: 0.0801
DEBUG - 2014-08-13 16:05:55 --> Config Class Initialized
DEBUG - 2014-08-13 16:05:55 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:05:55 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:05:55 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:05:55 --> URI Class Initialized
DEBUG - 2014-08-13 16:05:55 --> Router Class Initialized
DEBUG - 2014-08-13 16:05:55 --> No URI present. Default controller set.
DEBUG - 2014-08-13 16:05:55 --> Output Class Initialized
DEBUG - 2014-08-13 16:05:55 --> Security Class Initialized
DEBUG - 2014-08-13 16:05:55 --> Input Class Initialized
DEBUG - 2014-08-13 16:05:55 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:55 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:55 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:55 --> XSS Filtering completed
DEBUG - 2014-08-13 16:05:55 --> CRSF cookie Set
DEBUG - 2014-08-13 16:05:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:05:55 --> Language Class Initialized
DEBUG - 2014-08-13 16:05:55 --> Loader Class Initialized
DEBUG - 2014-08-13 16:05:55 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:05:55 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:05:55 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:05:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:05:55 --> Session Class Initialized
DEBUG - 2014-08-13 16:05:55 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:05:55 --> A session cookie was not found.
DEBUG - 2014-08-13 16:05:55 --> Session routines successfully run
DEBUG - 2014-08-13 16:05:55 --> Controller Class Initialized
DEBUG - 2014-08-13 16:05:55 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 16:05:55 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 16:05:55 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 16:05:55 --> Helper loaded: form_helper
DEBUG - 2014-08-13 16:05:55 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 16:05:55 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 16:05:55 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 16:05:55 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 16:05:55 --> Final output sent to browser
DEBUG - 2014-08-13 16:05:55 --> Total execution time: 0.1297
DEBUG - 2014-08-13 16:06:51 --> Config Class Initialized
DEBUG - 2014-08-13 16:06:51 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:06:51 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:06:51 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:06:51 --> URI Class Initialized
DEBUG - 2014-08-13 16:06:51 --> Router Class Initialized
DEBUG - 2014-08-13 16:06:51 --> Output Class Initialized
DEBUG - 2014-08-13 16:06:51 --> Security Class Initialized
DEBUG - 2014-08-13 16:06:51 --> Input Class Initialized
DEBUG - 2014-08-13 16:06:51 --> XSS Filtering completed
DEBUG - 2014-08-13 16:06:51 --> XSS Filtering completed
DEBUG - 2014-08-13 16:06:51 --> XSS Filtering completed
DEBUG - 2014-08-13 16:06:51 --> XSS Filtering completed
DEBUG - 2014-08-13 16:06:51 --> XSS Filtering completed
DEBUG - 2014-08-13 16:06:51 --> XSS Filtering completed
DEBUG - 2014-08-13 16:06:51 --> XSS Filtering completed
DEBUG - 2014-08-13 16:06:51 --> XSS Filtering completed
DEBUG - 2014-08-13 16:06:51 --> CRSF cookie Set
DEBUG - 2014-08-13 16:06:51 --> CSRF token verified
DEBUG - 2014-08-13 16:06:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:06:51 --> Language Class Initialized
DEBUG - 2014-08-13 16:06:51 --> Loader Class Initialized
DEBUG - 2014-08-13 16:06:51 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:06:51 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:06:51 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:06:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:06:51 --> Session Class Initialized
DEBUG - 2014-08-13 16:06:51 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:06:51 --> Session routines successfully run
DEBUG - 2014-08-13 16:06:51 --> Controller Class Initialized
DEBUG - 2014-08-13 16:06:51 --> Helper loaded: form_helper
DEBUG - 2014-08-13 16:06:51 --> Form Validation Class Initialized
DEBUG - 2014-08-13 16:06:51 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 16:06:51 --> XSS Filtering completed
DEBUG - 2014-08-13 16:06:51 --> XSS Filtering completed
DEBUG - 2014-08-13 16:06:51 --> Model Class Initialized
DEBUG - 2014-08-13 16:06:51 --> Model Class Initialized
DEBUG - 2014-08-13 16:06:51 --> Model Class Initialized
DEBUG - 2014-08-13 16:06:51 --> Model Class Initialized
DEBUG - 2014-08-13 16:06:51 --> Encrypt Class Initialized
DEBUG - 2014-08-13 16:06:51 --> XSS Filtering completed
DEBUG - 2014-08-13 16:06:51 --> XSS Filtering completed
DEBUG - 2014-08-13 16:06:51 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 16:06:51 --> XSS Filtering completed
DEBUG - 2014-08-13 16:06:51 --> XSS Filtering completed
DEBUG - 2014-08-13 16:06:51 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 16:06:51 --> XSS Filtering completed
DEBUG - 2014-08-13 16:06:51 --> XSS Filtering completed
DEBUG - 2014-08-13 16:06:51 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 16:06:51 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 16:06:51 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 16:06:51 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 16:06:51 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 16:06:51 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 16:06:51 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 16:06:51 --> Final output sent to browser
DEBUG - 2014-08-13 16:06:51 --> Total execution time: 0.1586
DEBUG - 2014-08-13 16:06:59 --> Config Class Initialized
DEBUG - 2014-08-13 16:06:59 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:06:59 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:06:59 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:06:59 --> URI Class Initialized
DEBUG - 2014-08-13 16:06:59 --> Router Class Initialized
DEBUG - 2014-08-13 16:06:59 --> Output Class Initialized
DEBUG - 2014-08-13 16:06:59 --> Security Class Initialized
DEBUG - 2014-08-13 16:06:59 --> Input Class Initialized
DEBUG - 2014-08-13 16:06:59 --> XSS Filtering completed
DEBUG - 2014-08-13 16:06:59 --> XSS Filtering completed
DEBUG - 2014-08-13 16:06:59 --> XSS Filtering completed
DEBUG - 2014-08-13 16:06:59 --> XSS Filtering completed
DEBUG - 2014-08-13 16:06:59 --> XSS Filtering completed
DEBUG - 2014-08-13 16:06:59 --> XSS Filtering completed
DEBUG - 2014-08-13 16:06:59 --> XSS Filtering completed
DEBUG - 2014-08-13 16:06:59 --> XSS Filtering completed
DEBUG - 2014-08-13 16:06:59 --> CRSF cookie Set
DEBUG - 2014-08-13 16:06:59 --> CSRF token verified
DEBUG - 2014-08-13 16:06:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:06:59 --> Language Class Initialized
DEBUG - 2014-08-13 16:06:59 --> Loader Class Initialized
DEBUG - 2014-08-13 16:06:59 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:06:59 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:06:59 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:06:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:06:59 --> Session Class Initialized
DEBUG - 2014-08-13 16:06:59 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:06:59 --> Session routines successfully run
DEBUG - 2014-08-13 16:06:59 --> Controller Class Initialized
DEBUG - 2014-08-13 16:06:59 --> Helper loaded: form_helper
DEBUG - 2014-08-13 16:06:59 --> Form Validation Class Initialized
DEBUG - 2014-08-13 16:06:59 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 16:06:59 --> XSS Filtering completed
DEBUG - 2014-08-13 16:06:59 --> XSS Filtering completed
DEBUG - 2014-08-13 16:06:59 --> Model Class Initialized
DEBUG - 2014-08-13 16:06:59 --> Model Class Initialized
DEBUG - 2014-08-13 16:06:59 --> Model Class Initialized
DEBUG - 2014-08-13 16:06:59 --> Model Class Initialized
DEBUG - 2014-08-13 16:06:59 --> Encrypt Class Initialized
DEBUG - 2014-08-13 16:06:59 --> XSS Filtering completed
DEBUG - 2014-08-13 16:06:59 --> XSS Filtering completed
DEBUG - 2014-08-13 16:06:59 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 16:06:59 --> XSS Filtering completed
DEBUG - 2014-08-13 16:06:59 --> XSS Filtering completed
DEBUG - 2014-08-13 16:06:59 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 16:06:59 --> XSS Filtering completed
DEBUG - 2014-08-13 16:06:59 --> XSS Filtering completed
DEBUG - 2014-08-13 16:06:59 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 16:06:59 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 16:06:59 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 16:06:59 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 16:06:59 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 16:06:59 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 16:06:59 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 16:06:59 --> Final output sent to browser
DEBUG - 2014-08-13 16:06:59 --> Total execution time: 0.1595
DEBUG - 2014-08-13 16:07:19 --> Config Class Initialized
DEBUG - 2014-08-13 16:07:19 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:07:19 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:07:19 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:07:19 --> URI Class Initialized
DEBUG - 2014-08-13 16:07:19 --> Router Class Initialized
DEBUG - 2014-08-13 16:07:19 --> Output Class Initialized
DEBUG - 2014-08-13 16:07:19 --> Security Class Initialized
DEBUG - 2014-08-13 16:07:19 --> Input Class Initialized
DEBUG - 2014-08-13 16:07:19 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:19 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:19 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:19 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:19 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:19 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:19 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:19 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:19 --> CRSF cookie Set
DEBUG - 2014-08-13 16:07:19 --> CSRF token verified
DEBUG - 2014-08-13 16:07:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:07:19 --> Language Class Initialized
DEBUG - 2014-08-13 16:07:19 --> Loader Class Initialized
DEBUG - 2014-08-13 16:07:19 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:07:19 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:07:19 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:07:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:07:19 --> Session Class Initialized
DEBUG - 2014-08-13 16:07:19 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:07:19 --> Session routines successfully run
DEBUG - 2014-08-13 16:07:19 --> Controller Class Initialized
DEBUG - 2014-08-13 16:07:19 --> Helper loaded: form_helper
DEBUG - 2014-08-13 16:07:19 --> Form Validation Class Initialized
DEBUG - 2014-08-13 16:07:19 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 16:07:19 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:19 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:19 --> Model Class Initialized
DEBUG - 2014-08-13 16:07:19 --> Model Class Initialized
DEBUG - 2014-08-13 16:07:19 --> Model Class Initialized
DEBUG - 2014-08-13 16:07:19 --> Model Class Initialized
DEBUG - 2014-08-13 16:07:19 --> Encrypt Class Initialized
DEBUG - 2014-08-13 16:07:19 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:19 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:19 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 16:07:19 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:19 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:19 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 16:07:19 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:19 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:19 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 16:07:19 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 16:07:19 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 16:07:19 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 16:07:19 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 16:07:19 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 16:07:19 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 16:07:19 --> Final output sent to browser
DEBUG - 2014-08-13 16:07:19 --> Total execution time: 0.1702
DEBUG - 2014-08-13 16:07:27 --> Config Class Initialized
DEBUG - 2014-08-13 16:07:27 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:07:27 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:07:27 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:07:27 --> URI Class Initialized
DEBUG - 2014-08-13 16:07:27 --> Router Class Initialized
DEBUG - 2014-08-13 16:07:27 --> Output Class Initialized
DEBUG - 2014-08-13 16:07:27 --> Security Class Initialized
DEBUG - 2014-08-13 16:07:27 --> Input Class Initialized
DEBUG - 2014-08-13 16:07:27 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:27 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:27 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:27 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:27 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:27 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:27 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:27 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:27 --> CRSF cookie Set
DEBUG - 2014-08-13 16:07:27 --> CSRF token verified
DEBUG - 2014-08-13 16:07:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:07:27 --> Language Class Initialized
DEBUG - 2014-08-13 16:07:27 --> Loader Class Initialized
DEBUG - 2014-08-13 16:07:27 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:07:27 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:07:27 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:07:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:07:27 --> Session Class Initialized
DEBUG - 2014-08-13 16:07:27 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:07:27 --> Session routines successfully run
DEBUG - 2014-08-13 16:07:27 --> Controller Class Initialized
DEBUG - 2014-08-13 16:07:27 --> Helper loaded: form_helper
DEBUG - 2014-08-13 16:07:27 --> Form Validation Class Initialized
DEBUG - 2014-08-13 16:07:27 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 16:07:27 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:27 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:27 --> Model Class Initialized
DEBUG - 2014-08-13 16:07:27 --> Model Class Initialized
DEBUG - 2014-08-13 16:07:27 --> Model Class Initialized
DEBUG - 2014-08-13 16:07:27 --> Model Class Initialized
DEBUG - 2014-08-13 16:07:27 --> Encrypt Class Initialized
DEBUG - 2014-08-13 16:07:27 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:27 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:27 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 16:07:27 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:27 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:27 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 16:07:27 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:27 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:27 --> Config Class Initialized
DEBUG - 2014-08-13 16:07:27 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:07:27 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:07:27 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:07:27 --> URI Class Initialized
DEBUG - 2014-08-13 16:07:27 --> Router Class Initialized
DEBUG - 2014-08-13 16:07:27 --> Output Class Initialized
DEBUG - 2014-08-13 16:07:27 --> Security Class Initialized
DEBUG - 2014-08-13 16:07:27 --> Input Class Initialized
DEBUG - 2014-08-13 16:07:27 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:27 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:27 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:27 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:27 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:27 --> CRSF cookie Set
DEBUG - 2014-08-13 16:07:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:07:28 --> Language Class Initialized
DEBUG - 2014-08-13 16:07:28 --> Loader Class Initialized
DEBUG - 2014-08-13 16:07:28 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:07:28 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:07:28 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:07:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:07:28 --> Session Class Initialized
DEBUG - 2014-08-13 16:07:28 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:07:28 --> Session routines successfully run
DEBUG - 2014-08-13 16:07:28 --> Controller Class Initialized
DEBUG - 2014-08-13 16:07:28 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 16:07:58 --> Config Class Initialized
DEBUG - 2014-08-13 16:07:58 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:07:58 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:07:58 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:07:58 --> URI Class Initialized
DEBUG - 2014-08-13 16:07:58 --> Router Class Initialized
DEBUG - 2014-08-13 16:07:58 --> Output Class Initialized
DEBUG - 2014-08-13 16:07:58 --> Security Class Initialized
DEBUG - 2014-08-13 16:07:58 --> Input Class Initialized
DEBUG - 2014-08-13 16:07:58 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:58 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:58 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:58 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:58 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:58 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:58 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:58 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:58 --> CRSF cookie Set
DEBUG - 2014-08-13 16:07:58 --> CSRF token verified
DEBUG - 2014-08-13 16:07:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:07:58 --> Language Class Initialized
DEBUG - 2014-08-13 16:07:58 --> Loader Class Initialized
DEBUG - 2014-08-13 16:07:58 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:07:58 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:07:58 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:07:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:07:58 --> Session Class Initialized
DEBUG - 2014-08-13 16:07:58 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:07:58 --> Session routines successfully run
DEBUG - 2014-08-13 16:07:58 --> Controller Class Initialized
DEBUG - 2014-08-13 16:07:58 --> Helper loaded: form_helper
DEBUG - 2014-08-13 16:07:58 --> Form Validation Class Initialized
DEBUG - 2014-08-13 16:07:58 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 16:07:58 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:58 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:58 --> Model Class Initialized
DEBUG - 2014-08-13 16:07:58 --> Model Class Initialized
DEBUG - 2014-08-13 16:07:58 --> Model Class Initialized
DEBUG - 2014-08-13 16:07:58 --> Model Class Initialized
DEBUG - 2014-08-13 16:07:58 --> Encrypt Class Initialized
DEBUG - 2014-08-13 16:07:58 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:58 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:58 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 16:07:58 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:58 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:58 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 16:07:58 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:58 --> XSS Filtering completed
DEBUG - 2014-08-13 16:07:58 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 16:07:58 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 16:07:58 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 16:07:58 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 16:07:58 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 16:07:58 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 16:07:58 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 16:07:58 --> Final output sent to browser
DEBUG - 2014-08-13 16:07:58 --> Total execution time: 0.1587
DEBUG - 2014-08-13 16:08:16 --> Config Class Initialized
DEBUG - 2014-08-13 16:08:16 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:08:16 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:08:16 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:08:16 --> URI Class Initialized
DEBUG - 2014-08-13 16:08:16 --> Router Class Initialized
DEBUG - 2014-08-13 16:08:16 --> Output Class Initialized
DEBUG - 2014-08-13 16:08:16 --> Security Class Initialized
DEBUG - 2014-08-13 16:08:16 --> Input Class Initialized
DEBUG - 2014-08-13 16:08:16 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:16 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:16 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:16 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:16 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:16 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:16 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:16 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:16 --> CRSF cookie Set
DEBUG - 2014-08-13 16:08:16 --> CSRF token verified
DEBUG - 2014-08-13 16:08:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:08:16 --> Language Class Initialized
DEBUG - 2014-08-13 16:08:16 --> Loader Class Initialized
DEBUG - 2014-08-13 16:08:16 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:08:16 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:08:16 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:08:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:08:16 --> Session Class Initialized
DEBUG - 2014-08-13 16:08:16 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:08:16 --> Session routines successfully run
DEBUG - 2014-08-13 16:08:16 --> Controller Class Initialized
DEBUG - 2014-08-13 16:08:16 --> Helper loaded: form_helper
DEBUG - 2014-08-13 16:08:16 --> Form Validation Class Initialized
DEBUG - 2014-08-13 16:08:16 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 16:08:16 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:16 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:16 --> Model Class Initialized
DEBUG - 2014-08-13 16:08:16 --> Model Class Initialized
DEBUG - 2014-08-13 16:08:16 --> Model Class Initialized
DEBUG - 2014-08-13 16:08:16 --> Model Class Initialized
DEBUG - 2014-08-13 16:08:16 --> Encrypt Class Initialized
DEBUG - 2014-08-13 16:08:16 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:16 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:16 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 16:08:16 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:16 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:16 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 16:08:16 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:16 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:16 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 16:08:16 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 16:08:16 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 16:08:16 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 16:08:16 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 16:08:16 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 16:08:16 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 16:08:16 --> Final output sent to browser
DEBUG - 2014-08-13 16:08:16 --> Total execution time: 0.1632
DEBUG - 2014-08-13 16:08:23 --> Config Class Initialized
DEBUG - 2014-08-13 16:08:23 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:08:23 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:08:23 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:08:23 --> URI Class Initialized
DEBUG - 2014-08-13 16:08:23 --> Router Class Initialized
DEBUG - 2014-08-13 16:08:23 --> Output Class Initialized
DEBUG - 2014-08-13 16:08:23 --> Security Class Initialized
DEBUG - 2014-08-13 16:08:23 --> Input Class Initialized
DEBUG - 2014-08-13 16:08:23 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:23 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:23 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:23 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:23 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:23 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:23 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:23 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:23 --> CRSF cookie Set
DEBUG - 2014-08-13 16:08:23 --> CSRF token verified
DEBUG - 2014-08-13 16:08:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:08:23 --> Language Class Initialized
DEBUG - 2014-08-13 16:08:23 --> Loader Class Initialized
DEBUG - 2014-08-13 16:08:23 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:08:23 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:08:23 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:08:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:08:23 --> Session Class Initialized
DEBUG - 2014-08-13 16:08:23 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:08:23 --> Session routines successfully run
DEBUG - 2014-08-13 16:08:23 --> Controller Class Initialized
DEBUG - 2014-08-13 16:08:23 --> Helper loaded: form_helper
DEBUG - 2014-08-13 16:08:23 --> Form Validation Class Initialized
DEBUG - 2014-08-13 16:08:23 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 16:08:23 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:23 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:23 --> Model Class Initialized
DEBUG - 2014-08-13 16:08:23 --> Model Class Initialized
DEBUG - 2014-08-13 16:08:23 --> Model Class Initialized
DEBUG - 2014-08-13 16:08:23 --> Model Class Initialized
DEBUG - 2014-08-13 16:08:23 --> Encrypt Class Initialized
DEBUG - 2014-08-13 16:08:23 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:23 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:23 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 16:08:23 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:23 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:23 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 16:08:23 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:23 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:23 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 16:08:23 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 16:08:23 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 16:08:23 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 16:08:23 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 16:08:23 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 16:08:23 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 16:08:23 --> Final output sent to browser
DEBUG - 2014-08-13 16:08:23 --> Total execution time: 0.1540
DEBUG - 2014-08-13 16:08:45 --> Config Class Initialized
DEBUG - 2014-08-13 16:08:45 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:08:45 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:08:45 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:08:45 --> URI Class Initialized
DEBUG - 2014-08-13 16:08:45 --> Router Class Initialized
DEBUG - 2014-08-13 16:08:45 --> Output Class Initialized
DEBUG - 2014-08-13 16:08:45 --> Security Class Initialized
DEBUG - 2014-08-13 16:08:45 --> Input Class Initialized
DEBUG - 2014-08-13 16:08:45 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:45 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:45 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:45 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:45 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:45 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:45 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:45 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:45 --> CRSF cookie Set
DEBUG - 2014-08-13 16:08:45 --> CSRF token verified
DEBUG - 2014-08-13 16:08:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:08:45 --> Language Class Initialized
DEBUG - 2014-08-13 16:08:45 --> Loader Class Initialized
DEBUG - 2014-08-13 16:08:45 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:08:45 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:08:45 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:08:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:08:45 --> Session Class Initialized
DEBUG - 2014-08-13 16:08:45 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:08:45 --> Session routines successfully run
DEBUG - 2014-08-13 16:08:45 --> Controller Class Initialized
DEBUG - 2014-08-13 16:08:45 --> Helper loaded: form_helper
DEBUG - 2014-08-13 16:08:45 --> Form Validation Class Initialized
DEBUG - 2014-08-13 16:08:45 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 16:08:45 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:45 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:45 --> Model Class Initialized
DEBUG - 2014-08-13 16:08:45 --> Model Class Initialized
DEBUG - 2014-08-13 16:08:45 --> Model Class Initialized
DEBUG - 2014-08-13 16:08:45 --> Model Class Initialized
DEBUG - 2014-08-13 16:08:45 --> Encrypt Class Initialized
DEBUG - 2014-08-13 16:08:45 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:45 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:45 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 16:08:45 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:45 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:45 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 16:08:45 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:45 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:45 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 16:08:45 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 16:08:45 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 16:08:45 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 16:08:45 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 16:08:45 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 16:08:45 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 16:08:45 --> Final output sent to browser
DEBUG - 2014-08-13 16:08:45 --> Total execution time: 0.2045
DEBUG - 2014-08-13 16:08:52 --> Config Class Initialized
DEBUG - 2014-08-13 16:08:52 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:08:52 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:08:52 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:08:52 --> URI Class Initialized
DEBUG - 2014-08-13 16:08:52 --> Router Class Initialized
DEBUG - 2014-08-13 16:08:52 --> Output Class Initialized
DEBUG - 2014-08-13 16:08:52 --> Security Class Initialized
DEBUG - 2014-08-13 16:08:52 --> Input Class Initialized
DEBUG - 2014-08-13 16:08:52 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:52 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:52 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:52 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:52 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:52 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:52 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:52 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:52 --> CRSF cookie Set
DEBUG - 2014-08-13 16:08:52 --> CSRF token verified
DEBUG - 2014-08-13 16:08:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:08:52 --> Language Class Initialized
DEBUG - 2014-08-13 16:08:52 --> Loader Class Initialized
DEBUG - 2014-08-13 16:08:52 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:08:52 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:08:52 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:08:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:08:52 --> Session Class Initialized
DEBUG - 2014-08-13 16:08:52 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:08:52 --> Session routines successfully run
DEBUG - 2014-08-13 16:08:52 --> Controller Class Initialized
DEBUG - 2014-08-13 16:08:52 --> Helper loaded: form_helper
DEBUG - 2014-08-13 16:08:52 --> Form Validation Class Initialized
DEBUG - 2014-08-13 16:08:52 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 16:08:52 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:52 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:52 --> Model Class Initialized
DEBUG - 2014-08-13 16:08:52 --> Model Class Initialized
DEBUG - 2014-08-13 16:08:52 --> Model Class Initialized
DEBUG - 2014-08-13 16:08:52 --> Model Class Initialized
DEBUG - 2014-08-13 16:08:52 --> Encrypt Class Initialized
DEBUG - 2014-08-13 16:08:52 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:52 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:52 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 16:08:52 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:52 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:52 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-13 16:08:52 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:52 --> XSS Filtering completed
DEBUG - 2014-08-13 16:08:52 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 16:08:52 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 16:08:52 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 16:08:52 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 16:08:52 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 16:08:52 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 16:08:52 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 16:08:52 --> Final output sent to browser
DEBUG - 2014-08-13 16:08:52 --> Total execution time: 0.1561
DEBUG - 2014-08-13 16:12:23 --> Config Class Initialized
DEBUG - 2014-08-13 16:12:23 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:12:23 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:12:23 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:12:23 --> URI Class Initialized
DEBUG - 2014-08-13 16:12:23 --> Router Class Initialized
DEBUG - 2014-08-13 16:12:23 --> Output Class Initialized
DEBUG - 2014-08-13 16:12:23 --> Security Class Initialized
DEBUG - 2014-08-13 16:12:23 --> Input Class Initialized
DEBUG - 2014-08-13 16:12:23 --> XSS Filtering completed
DEBUG - 2014-08-13 16:12:23 --> XSS Filtering completed
DEBUG - 2014-08-13 16:12:23 --> XSS Filtering completed
DEBUG - 2014-08-13 16:12:23 --> XSS Filtering completed
DEBUG - 2014-08-13 16:12:23 --> XSS Filtering completed
DEBUG - 2014-08-13 16:12:23 --> XSS Filtering completed
DEBUG - 2014-08-13 16:12:23 --> XSS Filtering completed
DEBUG - 2014-08-13 16:12:23 --> XSS Filtering completed
DEBUG - 2014-08-13 16:12:23 --> CRSF cookie Set
DEBUG - 2014-08-13 16:12:23 --> CSRF token verified
DEBUG - 2014-08-13 16:12:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:12:23 --> Language Class Initialized
DEBUG - 2014-08-13 16:12:23 --> Loader Class Initialized
DEBUG - 2014-08-13 16:12:23 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:12:23 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:12:23 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:12:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:12:23 --> Session Class Initialized
DEBUG - 2014-08-13 16:12:23 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:12:23 --> Session routines successfully run
DEBUG - 2014-08-13 16:12:23 --> Controller Class Initialized
DEBUG - 2014-08-13 16:12:23 --> Helper loaded: form_helper
DEBUG - 2014-08-13 16:12:23 --> Form Validation Class Initialized
DEBUG - 2014-08-13 16:12:23 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-13 16:12:23 --> XSS Filtering completed
DEBUG - 2014-08-13 16:12:23 --> XSS Filtering completed
DEBUG - 2014-08-13 16:12:23 --> Model Class Initialized
DEBUG - 2014-08-13 16:12:23 --> Model Class Initialized
DEBUG - 2014-08-13 16:12:23 --> Model Class Initialized
DEBUG - 2014-08-13 16:12:23 --> Model Class Initialized
DEBUG - 2014-08-13 16:12:23 --> Encrypt Class Initialized
DEBUG - 2014-08-13 16:12:23 --> XSS Filtering completed
DEBUG - 2014-08-13 16:12:23 --> XSS Filtering completed
DEBUG - 2014-08-13 16:12:23 --> Config Class Initialized
DEBUG - 2014-08-13 16:12:23 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:12:23 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:12:23 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:12:24 --> URI Class Initialized
DEBUG - 2014-08-13 16:12:24 --> Router Class Initialized
DEBUG - 2014-08-13 16:12:24 --> Output Class Initialized
DEBUG - 2014-08-13 16:12:24 --> Security Class Initialized
DEBUG - 2014-08-13 16:12:24 --> Input Class Initialized
DEBUG - 2014-08-13 16:12:24 --> XSS Filtering completed
DEBUG - 2014-08-13 16:12:24 --> XSS Filtering completed
DEBUG - 2014-08-13 16:12:24 --> XSS Filtering completed
DEBUG - 2014-08-13 16:12:24 --> XSS Filtering completed
DEBUG - 2014-08-13 16:12:24 --> XSS Filtering completed
DEBUG - 2014-08-13 16:12:24 --> CRSF cookie Set
DEBUG - 2014-08-13 16:12:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:12:24 --> Language Class Initialized
DEBUG - 2014-08-13 16:12:24 --> Loader Class Initialized
DEBUG - 2014-08-13 16:12:24 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:12:24 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:12:24 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:12:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:12:24 --> Session Class Initialized
DEBUG - 2014-08-13 16:12:24 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:12:24 --> Session routines successfully run
DEBUG - 2014-08-13 16:12:24 --> Controller Class Initialized
DEBUG - 2014-08-13 16:12:24 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 16:12:24 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-13 16:12:24 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-13 16:12:24 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 16:12:24 --> File loaded: application/views/placement_admin_home.php
DEBUG - 2014-08-13 16:12:24 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 16:12:24 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 16:12:24 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-13 16:12:24 --> Final output sent to browser
DEBUG - 2014-08-13 16:12:24 --> Total execution time: 0.1210
DEBUG - 2014-08-13 16:12:25 --> Config Class Initialized
DEBUG - 2014-08-13 16:12:25 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:12:25 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:12:25 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:12:25 --> URI Class Initialized
DEBUG - 2014-08-13 16:12:25 --> Router Class Initialized
DEBUG - 2014-08-13 16:12:25 --> Output Class Initialized
DEBUG - 2014-08-13 16:12:25 --> Security Class Initialized
DEBUG - 2014-08-13 16:12:25 --> Input Class Initialized
DEBUG - 2014-08-13 16:12:25 --> XSS Filtering completed
DEBUG - 2014-08-13 16:12:25 --> XSS Filtering completed
DEBUG - 2014-08-13 16:12:25 --> XSS Filtering completed
DEBUG - 2014-08-13 16:12:25 --> XSS Filtering completed
DEBUG - 2014-08-13 16:12:25 --> XSS Filtering completed
DEBUG - 2014-08-13 16:12:25 --> CRSF cookie Set
DEBUG - 2014-08-13 16:12:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:12:25 --> Language Class Initialized
DEBUG - 2014-08-13 16:12:25 --> Loader Class Initialized
DEBUG - 2014-08-13 16:12:25 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:12:26 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:12:26 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:12:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:12:26 --> Session Class Initialized
DEBUG - 2014-08-13 16:12:26 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:12:26 --> Session routines successfully run
DEBUG - 2014-08-13 16:12:26 --> Controller Class Initialized
DEBUG - 2014-08-13 16:12:26 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 16:12:26 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-13 16:12:26 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-13 16:12:26 --> File loaded: application/views/placement_admin_history.php
DEBUG - 2014-08-13 16:12:26 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 16:12:26 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 16:12:26 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-13 16:12:26 --> Final output sent to browser
DEBUG - 2014-08-13 16:12:26 --> Total execution time: 0.0906
DEBUG - 2014-08-13 16:12:27 --> Config Class Initialized
DEBUG - 2014-08-13 16:12:27 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:12:27 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:12:27 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:12:27 --> URI Class Initialized
DEBUG - 2014-08-13 16:12:27 --> Router Class Initialized
DEBUG - 2014-08-13 16:12:27 --> Output Class Initialized
DEBUG - 2014-08-13 16:12:27 --> Security Class Initialized
DEBUG - 2014-08-13 16:12:27 --> Input Class Initialized
DEBUG - 2014-08-13 16:12:27 --> XSS Filtering completed
DEBUG - 2014-08-13 16:12:27 --> XSS Filtering completed
DEBUG - 2014-08-13 16:12:27 --> XSS Filtering completed
DEBUG - 2014-08-13 16:12:27 --> XSS Filtering completed
DEBUG - 2014-08-13 16:12:27 --> XSS Filtering completed
DEBUG - 2014-08-13 16:12:27 --> CRSF cookie Set
DEBUG - 2014-08-13 16:12:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:12:27 --> Language Class Initialized
DEBUG - 2014-08-13 16:12:27 --> Loader Class Initialized
DEBUG - 2014-08-13 16:12:27 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:12:27 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:12:27 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:12:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:12:27 --> Session Class Initialized
DEBUG - 2014-08-13 16:12:27 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:12:27 --> Session routines successfully run
DEBUG - 2014-08-13 16:12:27 --> Controller Class Initialized
DEBUG - 2014-08-13 16:12:27 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 16:12:27 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-13 16:12:30 --> Config Class Initialized
DEBUG - 2014-08-13 16:12:30 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:12:30 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:12:30 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:12:30 --> URI Class Initialized
DEBUG - 2014-08-13 16:12:30 --> Router Class Initialized
DEBUG - 2014-08-13 16:12:30 --> Output Class Initialized
DEBUG - 2014-08-13 16:12:30 --> Security Class Initialized
DEBUG - 2014-08-13 16:12:30 --> Input Class Initialized
DEBUG - 2014-08-13 16:12:30 --> XSS Filtering completed
DEBUG - 2014-08-13 16:12:30 --> XSS Filtering completed
DEBUG - 2014-08-13 16:12:30 --> XSS Filtering completed
DEBUG - 2014-08-13 16:12:30 --> XSS Filtering completed
DEBUG - 2014-08-13 16:12:30 --> XSS Filtering completed
DEBUG - 2014-08-13 16:12:30 --> CRSF cookie Set
DEBUG - 2014-08-13 16:12:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:12:30 --> Language Class Initialized
DEBUG - 2014-08-13 16:12:30 --> Loader Class Initialized
DEBUG - 2014-08-13 16:12:30 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:12:30 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:12:30 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:12:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:12:30 --> Session Class Initialized
DEBUG - 2014-08-13 16:12:30 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:12:30 --> Session routines successfully run
DEBUG - 2014-08-13 16:12:30 --> Controller Class Initialized
DEBUG - 2014-08-13 16:12:30 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 16:12:30 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-13 16:12:30 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-13 16:12:30 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 16:12:30 --> File loaded: application/views/placement_admin_home.php
DEBUG - 2014-08-13 16:12:30 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 16:12:30 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 16:12:30 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-13 16:12:30 --> Final output sent to browser
DEBUG - 2014-08-13 16:12:30 --> Total execution time: 0.0928
DEBUG - 2014-08-13 16:13:06 --> Config Class Initialized
DEBUG - 2014-08-13 16:13:06 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:13:06 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:13:06 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:13:06 --> URI Class Initialized
DEBUG - 2014-08-13 16:13:06 --> Router Class Initialized
DEBUG - 2014-08-13 16:13:06 --> Output Class Initialized
DEBUG - 2014-08-13 16:13:06 --> Security Class Initialized
DEBUG - 2014-08-13 16:13:06 --> Input Class Initialized
DEBUG - 2014-08-13 16:13:06 --> XSS Filtering completed
DEBUG - 2014-08-13 16:13:06 --> XSS Filtering completed
DEBUG - 2014-08-13 16:13:06 --> XSS Filtering completed
DEBUG - 2014-08-13 16:13:06 --> XSS Filtering completed
DEBUG - 2014-08-13 16:13:06 --> XSS Filtering completed
DEBUG - 2014-08-13 16:13:06 --> CRSF cookie Set
DEBUG - 2014-08-13 16:13:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:13:06 --> Language Class Initialized
DEBUG - 2014-08-13 16:13:06 --> Loader Class Initialized
DEBUG - 2014-08-13 16:13:06 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:13:06 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:13:06 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:13:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:13:06 --> Session Class Initialized
DEBUG - 2014-08-13 16:13:06 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:13:06 --> Session routines successfully run
DEBUG - 2014-08-13 16:13:06 --> Controller Class Initialized
DEBUG - 2014-08-13 16:13:06 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 16:13:06 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-13 16:13:06 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-13 16:13:06 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-13 16:13:06 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 16:13:06 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 16:13:06 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-13 16:13:06 --> Final output sent to browser
DEBUG - 2014-08-13 16:13:06 --> Total execution time: 0.0901
DEBUG - 2014-08-13 16:13:08 --> Config Class Initialized
DEBUG - 2014-08-13 16:13:08 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:13:08 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:13:08 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:13:08 --> URI Class Initialized
DEBUG - 2014-08-13 16:13:08 --> Router Class Initialized
DEBUG - 2014-08-13 16:13:08 --> Output Class Initialized
DEBUG - 2014-08-13 16:13:08 --> Security Class Initialized
DEBUG - 2014-08-13 16:13:08 --> Input Class Initialized
DEBUG - 2014-08-13 16:13:08 --> XSS Filtering completed
DEBUG - 2014-08-13 16:13:08 --> XSS Filtering completed
DEBUG - 2014-08-13 16:13:08 --> XSS Filtering completed
DEBUG - 2014-08-13 16:13:08 --> XSS Filtering completed
DEBUG - 2014-08-13 16:13:08 --> XSS Filtering completed
DEBUG - 2014-08-13 16:13:08 --> CRSF cookie Set
DEBUG - 2014-08-13 16:13:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:13:08 --> Language Class Initialized
DEBUG - 2014-08-13 16:13:08 --> Loader Class Initialized
DEBUG - 2014-08-13 16:13:08 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:13:08 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:13:08 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:13:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:13:08 --> Session Class Initialized
DEBUG - 2014-08-13 16:13:08 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:13:08 --> Session routines successfully run
DEBUG - 2014-08-13 16:13:08 --> Controller Class Initialized
DEBUG - 2014-08-13 16:13:08 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 16:13:08 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-13 16:13:08 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-13 16:13:08 --> File loaded: application/views/placement_admin_history.php
DEBUG - 2014-08-13 16:13:08 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 16:13:08 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 16:13:08 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-13 16:13:08 --> Final output sent to browser
DEBUG - 2014-08-13 16:13:08 --> Total execution time: 0.0912
DEBUG - 2014-08-13 16:13:09 --> Config Class Initialized
DEBUG - 2014-08-13 16:13:09 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:13:09 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:13:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:13:09 --> URI Class Initialized
DEBUG - 2014-08-13 16:13:09 --> Router Class Initialized
DEBUG - 2014-08-13 16:13:09 --> Output Class Initialized
DEBUG - 2014-08-13 16:13:09 --> Security Class Initialized
DEBUG - 2014-08-13 16:13:09 --> Input Class Initialized
DEBUG - 2014-08-13 16:13:09 --> XSS Filtering completed
DEBUG - 2014-08-13 16:13:09 --> XSS Filtering completed
DEBUG - 2014-08-13 16:13:09 --> XSS Filtering completed
DEBUG - 2014-08-13 16:13:09 --> XSS Filtering completed
DEBUG - 2014-08-13 16:13:09 --> XSS Filtering completed
DEBUG - 2014-08-13 16:13:09 --> CRSF cookie Set
DEBUG - 2014-08-13 16:13:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:13:09 --> Language Class Initialized
DEBUG - 2014-08-13 16:13:09 --> Loader Class Initialized
DEBUG - 2014-08-13 16:13:09 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:13:09 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:13:09 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:13:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:13:09 --> Session Class Initialized
DEBUG - 2014-08-13 16:13:09 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:13:09 --> Session routines successfully run
DEBUG - 2014-08-13 16:13:09 --> Controller Class Initialized
DEBUG - 2014-08-13 16:13:09 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 16:13:09 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-13 16:13:09 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-13 16:13:09 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-13 16:13:09 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 16:13:09 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 16:13:09 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-13 16:13:09 --> Final output sent to browser
DEBUG - 2014-08-13 16:13:09 --> Total execution time: 0.1100
DEBUG - 2014-08-13 16:13:26 --> Config Class Initialized
DEBUG - 2014-08-13 16:13:26 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:13:26 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:13:26 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:13:26 --> URI Class Initialized
DEBUG - 2014-08-13 16:13:26 --> Router Class Initialized
DEBUG - 2014-08-13 16:13:26 --> Output Class Initialized
DEBUG - 2014-08-13 16:13:26 --> Security Class Initialized
DEBUG - 2014-08-13 16:13:26 --> Input Class Initialized
DEBUG - 2014-08-13 16:13:26 --> XSS Filtering completed
DEBUG - 2014-08-13 16:13:26 --> XSS Filtering completed
DEBUG - 2014-08-13 16:13:26 --> XSS Filtering completed
DEBUG - 2014-08-13 16:13:26 --> XSS Filtering completed
DEBUG - 2014-08-13 16:13:26 --> XSS Filtering completed
DEBUG - 2014-08-13 16:13:26 --> CRSF cookie Set
DEBUG - 2014-08-13 16:13:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:13:26 --> Language Class Initialized
DEBUG - 2014-08-13 16:13:26 --> Loader Class Initialized
DEBUG - 2014-08-13 16:13:26 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:13:26 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:13:26 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:13:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:13:26 --> Session Class Initialized
DEBUG - 2014-08-13 16:13:26 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:13:26 --> Session routines successfully run
DEBUG - 2014-08-13 16:13:26 --> Controller Class Initialized
DEBUG - 2014-08-13 16:13:26 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 16:13:26 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-13 16:13:26 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-13 16:13:26 --> File loaded: application/views/placement_admin_history.php
DEBUG - 2014-08-13 16:13:26 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 16:13:26 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 16:13:26 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-13 16:13:26 --> Final output sent to browser
DEBUG - 2014-08-13 16:13:26 --> Total execution time: 0.0907
DEBUG - 2014-08-13 16:13:28 --> Config Class Initialized
DEBUG - 2014-08-13 16:13:28 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:13:28 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:13:28 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:13:28 --> URI Class Initialized
DEBUG - 2014-08-13 16:13:28 --> Router Class Initialized
DEBUG - 2014-08-13 16:13:28 --> Output Class Initialized
DEBUG - 2014-08-13 16:13:28 --> Security Class Initialized
DEBUG - 2014-08-13 16:13:28 --> Input Class Initialized
DEBUG - 2014-08-13 16:13:28 --> XSS Filtering completed
DEBUG - 2014-08-13 16:13:28 --> XSS Filtering completed
DEBUG - 2014-08-13 16:13:28 --> XSS Filtering completed
DEBUG - 2014-08-13 16:13:28 --> XSS Filtering completed
DEBUG - 2014-08-13 16:13:28 --> XSS Filtering completed
DEBUG - 2014-08-13 16:13:28 --> CRSF cookie Set
DEBUG - 2014-08-13 16:13:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:13:28 --> Language Class Initialized
DEBUG - 2014-08-13 16:13:28 --> Loader Class Initialized
DEBUG - 2014-08-13 16:13:28 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:13:28 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:13:28 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:13:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:13:28 --> Session Class Initialized
DEBUG - 2014-08-13 16:13:28 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:13:28 --> Session routines successfully run
DEBUG - 2014-08-13 16:13:28 --> Controller Class Initialized
DEBUG - 2014-08-13 16:13:28 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 16:13:28 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-13 16:13:28 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-13 16:13:28 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-13 16:13:28 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 16:13:28 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 16:13:28 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-13 16:13:28 --> Final output sent to browser
DEBUG - 2014-08-13 16:13:28 --> Total execution time: 0.0922
DEBUG - 2014-08-13 16:13:45 --> Config Class Initialized
DEBUG - 2014-08-13 16:13:45 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:13:45 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:13:45 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:13:45 --> URI Class Initialized
DEBUG - 2014-08-13 16:13:45 --> Router Class Initialized
DEBUG - 2014-08-13 16:13:45 --> Output Class Initialized
DEBUG - 2014-08-13 16:13:45 --> Security Class Initialized
DEBUG - 2014-08-13 16:13:45 --> Input Class Initialized
DEBUG - 2014-08-13 16:13:45 --> XSS Filtering completed
DEBUG - 2014-08-13 16:13:45 --> XSS Filtering completed
DEBUG - 2014-08-13 16:13:45 --> XSS Filtering completed
DEBUG - 2014-08-13 16:13:45 --> XSS Filtering completed
DEBUG - 2014-08-13 16:13:45 --> XSS Filtering completed
DEBUG - 2014-08-13 16:13:45 --> CRSF cookie Set
DEBUG - 2014-08-13 16:13:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:13:45 --> Language Class Initialized
DEBUG - 2014-08-13 16:13:45 --> Loader Class Initialized
DEBUG - 2014-08-13 16:13:45 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:13:45 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:13:45 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:13:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:13:45 --> Session Class Initialized
DEBUG - 2014-08-13 16:13:45 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:13:45 --> Session routines successfully run
DEBUG - 2014-08-13 16:13:45 --> Controller Class Initialized
DEBUG - 2014-08-13 16:13:45 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 16:13:45 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-13 16:13:45 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-13 16:13:45 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 16:13:45 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 16:13:45 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-13 16:13:45 --> Final output sent to browser
DEBUG - 2014-08-13 16:13:45 --> Total execution time: 0.0914
DEBUG - 2014-08-13 16:13:53 --> Config Class Initialized
DEBUG - 2014-08-13 16:13:53 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:13:53 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:13:53 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:13:53 --> URI Class Initialized
DEBUG - 2014-08-13 16:13:53 --> Router Class Initialized
DEBUG - 2014-08-13 16:13:53 --> Output Class Initialized
DEBUG - 2014-08-13 16:13:53 --> Security Class Initialized
DEBUG - 2014-08-13 16:13:53 --> Input Class Initialized
DEBUG - 2014-08-13 16:13:53 --> XSS Filtering completed
DEBUG - 2014-08-13 16:13:53 --> XSS Filtering completed
DEBUG - 2014-08-13 16:13:53 --> XSS Filtering completed
DEBUG - 2014-08-13 16:13:53 --> XSS Filtering completed
DEBUG - 2014-08-13 16:13:53 --> XSS Filtering completed
DEBUG - 2014-08-13 16:13:53 --> CRSF cookie Set
DEBUG - 2014-08-13 16:13:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:13:53 --> Language Class Initialized
DEBUG - 2014-08-13 16:13:53 --> Loader Class Initialized
DEBUG - 2014-08-13 16:13:53 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:13:53 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:13:53 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:13:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:13:53 --> Session Class Initialized
DEBUG - 2014-08-13 16:13:53 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:13:53 --> Session routines successfully run
DEBUG - 2014-08-13 16:13:53 --> Controller Class Initialized
DEBUG - 2014-08-13 16:13:53 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 16:13:53 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-13 16:13:53 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-13 16:13:53 --> File loaded: application/views/placement_admin_history.php
DEBUG - 2014-08-13 16:13:53 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 16:13:53 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 16:13:53 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-13 16:13:53 --> Final output sent to browser
DEBUG - 2014-08-13 16:13:53 --> Total execution time: 0.0921
DEBUG - 2014-08-13 16:13:54 --> Config Class Initialized
DEBUG - 2014-08-13 16:13:54 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:13:54 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:13:54 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:13:54 --> URI Class Initialized
DEBUG - 2014-08-13 16:13:54 --> Router Class Initialized
DEBUG - 2014-08-13 16:13:54 --> Output Class Initialized
DEBUG - 2014-08-13 16:13:54 --> Security Class Initialized
DEBUG - 2014-08-13 16:13:54 --> Input Class Initialized
DEBUG - 2014-08-13 16:13:54 --> XSS Filtering completed
DEBUG - 2014-08-13 16:13:54 --> XSS Filtering completed
DEBUG - 2014-08-13 16:13:54 --> XSS Filtering completed
DEBUG - 2014-08-13 16:13:54 --> XSS Filtering completed
DEBUG - 2014-08-13 16:13:54 --> XSS Filtering completed
DEBUG - 2014-08-13 16:13:54 --> CRSF cookie Set
DEBUG - 2014-08-13 16:13:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:13:54 --> Language Class Initialized
DEBUG - 2014-08-13 16:13:54 --> Loader Class Initialized
DEBUG - 2014-08-13 16:13:54 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:13:54 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:13:54 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:13:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:13:54 --> Session Class Initialized
DEBUG - 2014-08-13 16:13:54 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:13:54 --> Session routines successfully run
DEBUG - 2014-08-13 16:13:54 --> Controller Class Initialized
DEBUG - 2014-08-13 16:13:54 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 16:13:54 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-13 16:13:54 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-13 16:13:54 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 16:13:54 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 16:13:54 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-13 16:13:54 --> Final output sent to browser
DEBUG - 2014-08-13 16:13:54 --> Total execution time: 0.0896
DEBUG - 2014-08-13 16:17:42 --> Config Class Initialized
DEBUG - 2014-08-13 16:17:42 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:17:42 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:17:42 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:17:42 --> URI Class Initialized
DEBUG - 2014-08-13 16:17:42 --> Router Class Initialized
DEBUG - 2014-08-13 16:17:42 --> No URI present. Default controller set.
DEBUG - 2014-08-13 16:17:42 --> Output Class Initialized
DEBUG - 2014-08-13 16:17:42 --> Security Class Initialized
DEBUG - 2014-08-13 16:17:42 --> Input Class Initialized
DEBUG - 2014-08-13 16:17:42 --> XSS Filtering completed
DEBUG - 2014-08-13 16:17:42 --> XSS Filtering completed
DEBUG - 2014-08-13 16:17:42 --> XSS Filtering completed
DEBUG - 2014-08-13 16:17:42 --> XSS Filtering completed
DEBUG - 2014-08-13 16:17:42 --> CRSF cookie Set
DEBUG - 2014-08-13 16:17:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:17:42 --> Language Class Initialized
DEBUG - 2014-08-13 16:17:42 --> Loader Class Initialized
DEBUG - 2014-08-13 16:17:42 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:17:42 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:17:42 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:17:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:17:42 --> Session Class Initialized
DEBUG - 2014-08-13 16:17:42 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:17:42 --> A session cookie was not found.
DEBUG - 2014-08-13 16:17:42 --> Session routines successfully run
DEBUG - 2014-08-13 16:17:42 --> Controller Class Initialized
DEBUG - 2014-08-13 16:17:42 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 16:17:42 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 16:17:42 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 16:17:42 --> Helper loaded: form_helper
DEBUG - 2014-08-13 16:17:42 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 16:17:42 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-13 16:17:42 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 16:17:42 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 16:17:42 --> Final output sent to browser
DEBUG - 2014-08-13 16:17:42 --> Total execution time: 0.1056
DEBUG - 2014-08-13 16:17:51 --> Config Class Initialized
DEBUG - 2014-08-13 16:17:51 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:17:51 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:17:51 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:17:51 --> URI Class Initialized
DEBUG - 2014-08-13 16:17:51 --> Router Class Initialized
DEBUG - 2014-08-13 16:17:51 --> Output Class Initialized
DEBUG - 2014-08-13 16:17:51 --> Security Class Initialized
DEBUG - 2014-08-13 16:17:51 --> Input Class Initialized
DEBUG - 2014-08-13 16:17:51 --> XSS Filtering completed
DEBUG - 2014-08-13 16:17:51 --> XSS Filtering completed
DEBUG - 2014-08-13 16:17:51 --> XSS Filtering completed
DEBUG - 2014-08-13 16:17:51 --> XSS Filtering completed
DEBUG - 2014-08-13 16:17:51 --> XSS Filtering completed
DEBUG - 2014-08-13 16:17:51 --> XSS Filtering completed
DEBUG - 2014-08-13 16:17:51 --> CRSF cookie Set
DEBUG - 2014-08-13 16:17:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:17:51 --> Language Class Initialized
DEBUG - 2014-08-13 16:17:51 --> Loader Class Initialized
DEBUG - 2014-08-13 16:17:51 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:17:51 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:17:51 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:17:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:17:51 --> Session Class Initialized
DEBUG - 2014-08-13 16:17:51 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:17:51 --> Session routines successfully run
DEBUG - 2014-08-13 16:17:51 --> Controller Class Initialized
DEBUG - 2014-08-13 16:17:51 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 16:17:51 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 16:17:51 --> Helper loaded: form_helper
DEBUG - 2014-08-13 16:17:51 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 16:17:51 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 16:17:51 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 16:17:51 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 16:17:51 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 16:17:51 --> Final output sent to browser
DEBUG - 2014-08-13 16:17:51 --> Total execution time: 0.1025
DEBUG - 2014-08-13 16:18:13 --> Config Class Initialized
DEBUG - 2014-08-13 16:18:13 --> Hooks Class Initialized
DEBUG - 2014-08-13 16:18:13 --> Utf8 Class Initialized
DEBUG - 2014-08-13 16:18:13 --> UTF-8 Support Enabled
DEBUG - 2014-08-13 16:18:13 --> URI Class Initialized
DEBUG - 2014-08-13 16:18:13 --> Router Class Initialized
DEBUG - 2014-08-13 16:18:13 --> Output Class Initialized
DEBUG - 2014-08-13 16:18:13 --> Security Class Initialized
DEBUG - 2014-08-13 16:18:13 --> Input Class Initialized
DEBUG - 2014-08-13 16:18:13 --> XSS Filtering completed
DEBUG - 2014-08-13 16:18:13 --> XSS Filtering completed
DEBUG - 2014-08-13 16:18:13 --> XSS Filtering completed
DEBUG - 2014-08-13 16:18:13 --> XSS Filtering completed
DEBUG - 2014-08-13 16:18:13 --> XSS Filtering completed
DEBUG - 2014-08-13 16:18:13 --> XSS Filtering completed
DEBUG - 2014-08-13 16:18:13 --> CRSF cookie Set
DEBUG - 2014-08-13 16:18:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-13 16:18:13 --> Language Class Initialized
DEBUG - 2014-08-13 16:18:14 --> Loader Class Initialized
DEBUG - 2014-08-13 16:18:14 --> Helper loaded: functions_helper
DEBUG - 2014-08-13 16:18:14 --> Helper loaded: url_helper
DEBUG - 2014-08-13 16:18:14 --> Database Driver Class Initialized
ERROR - 2014-08-13 16:18:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-13 16:18:14 --> Session Class Initialized
DEBUG - 2014-08-13 16:18:14 --> Helper loaded: string_helper
DEBUG - 2014-08-13 16:18:14 --> Session routines successfully run
DEBUG - 2014-08-13 16:18:14 --> Controller Class Initialized
DEBUG - 2014-08-13 16:18:14 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-13 16:18:14 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-13 16:18:14 --> Helper loaded: form_helper
DEBUG - 2014-08-13 16:18:14 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-13 16:18:14 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-13 16:18:14 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-13 16:18:14 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-13 16:18:14 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-13 16:18:14 --> Final output sent to browser
DEBUG - 2014-08-13 16:18:14 --> Total execution time: 0.7207
