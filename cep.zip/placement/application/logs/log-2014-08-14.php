<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-08-14 13:45:00 --> Config Class Initialized
DEBUG - 2014-08-14 13:45:00 --> Hooks Class Initialized
DEBUG - 2014-08-14 13:45:00 --> Utf8 Class Initialized
DEBUG - 2014-08-14 13:45:00 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 13:45:00 --> URI Class Initialized
DEBUG - 2014-08-14 13:45:00 --> Router Class Initialized
DEBUG - 2014-08-14 13:45:00 --> Output Class Initialized
DEBUG - 2014-08-14 13:45:00 --> Security Class Initialized
DEBUG - 2014-08-14 13:45:00 --> Input Class Initialized
DEBUG - 2014-08-14 13:45:00 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:00 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:00 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:00 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:00 --> CRSF cookie Set
DEBUG - 2014-08-14 13:45:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 13:45:00 --> Language Class Initialized
DEBUG - 2014-08-14 13:45:00 --> Loader Class Initialized
DEBUG - 2014-08-14 13:45:00 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 13:45:00 --> Helper loaded: url_helper
DEBUG - 2014-08-14 13:45:00 --> Database Driver Class Initialized
ERROR - 2014-08-14 13:45:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-08-14 13:45:00 --> Severity: Warning  --> mysql_pconnect(): MySQL server has gone away C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 13:45:00 --> Session Class Initialized
DEBUG - 2014-08-14 13:45:00 --> Helper loaded: string_helper
DEBUG - 2014-08-14 13:45:00 --> Session routines successfully run
DEBUG - 2014-08-14 13:45:00 --> Controller Class Initialized
DEBUG - 2014-08-14 13:45:01 --> File loaded: application/views/login_to_continue.php
DEBUG - 2014-08-14 13:45:01 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 13:45:01 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 13:45:01 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-14 13:45:01 --> File loaded: application/views/placement_admin_history.php
DEBUG - 2014-08-14 13:45:01 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 13:45:01 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 13:45:01 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 13:45:01 --> Final output sent to browser
DEBUG - 2014-08-14 13:45:01 --> Total execution time: 0.1878
DEBUG - 2014-08-14 13:45:02 --> Config Class Initialized
DEBUG - 2014-08-14 13:45:02 --> Hooks Class Initialized
DEBUG - 2014-08-14 13:45:02 --> Utf8 Class Initialized
DEBUG - 2014-08-14 13:45:02 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 13:45:02 --> URI Class Initialized
DEBUG - 2014-08-14 13:45:02 --> Router Class Initialized
DEBUG - 2014-08-14 13:45:02 --> No URI present. Default controller set.
DEBUG - 2014-08-14 13:45:02 --> Output Class Initialized
DEBUG - 2014-08-14 13:45:02 --> Security Class Initialized
DEBUG - 2014-08-14 13:45:02 --> Input Class Initialized
DEBUG - 2014-08-14 13:45:02 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:02 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:02 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:02 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:02 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:02 --> CRSF cookie Set
DEBUG - 2014-08-14 13:45:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 13:45:02 --> Language Class Initialized
DEBUG - 2014-08-14 13:45:02 --> Loader Class Initialized
DEBUG - 2014-08-14 13:45:02 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 13:45:02 --> Helper loaded: url_helper
DEBUG - 2014-08-14 13:45:02 --> Database Driver Class Initialized
ERROR - 2014-08-14 13:45:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 13:45:02 --> Session Class Initialized
DEBUG - 2014-08-14 13:45:02 --> Helper loaded: string_helper
DEBUG - 2014-08-14 13:45:02 --> Session routines successfully run
DEBUG - 2014-08-14 13:45:02 --> Controller Class Initialized
DEBUG - 2014-08-14 13:45:02 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 13:45:02 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-14 13:45:02 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-14 13:45:02 --> Helper loaded: form_helper
DEBUG - 2014-08-14 13:45:02 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-14 13:45:02 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-14 13:45:02 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 13:45:02 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 13:45:02 --> Final output sent to browser
DEBUG - 2014-08-14 13:45:02 --> Total execution time: 0.1508
DEBUG - 2014-08-14 13:45:09 --> Config Class Initialized
DEBUG - 2014-08-14 13:45:09 --> Hooks Class Initialized
DEBUG - 2014-08-14 13:45:09 --> Utf8 Class Initialized
DEBUG - 2014-08-14 13:45:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 13:45:09 --> URI Class Initialized
DEBUG - 2014-08-14 13:45:09 --> Router Class Initialized
DEBUG - 2014-08-14 13:45:09 --> Output Class Initialized
DEBUG - 2014-08-14 13:45:09 --> Security Class Initialized
DEBUG - 2014-08-14 13:45:09 --> Input Class Initialized
DEBUG - 2014-08-14 13:45:09 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:09 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:09 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:09 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:09 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:09 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:09 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:09 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:09 --> CRSF cookie Set
DEBUG - 2014-08-14 13:45:09 --> CSRF token verified
DEBUG - 2014-08-14 13:45:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 13:45:09 --> Language Class Initialized
DEBUG - 2014-08-14 13:45:09 --> Loader Class Initialized
DEBUG - 2014-08-14 13:45:09 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 13:45:09 --> Helper loaded: url_helper
DEBUG - 2014-08-14 13:45:09 --> Database Driver Class Initialized
ERROR - 2014-08-14 13:45:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 13:45:09 --> Session Class Initialized
DEBUG - 2014-08-14 13:45:09 --> Helper loaded: string_helper
DEBUG - 2014-08-14 13:45:09 --> Session routines successfully run
DEBUG - 2014-08-14 13:45:09 --> Controller Class Initialized
DEBUG - 2014-08-14 13:45:09 --> Helper loaded: form_helper
DEBUG - 2014-08-14 13:45:09 --> Form Validation Class Initialized
DEBUG - 2014-08-14 13:45:09 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-14 13:45:09 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:09 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:09 --> Model Class Initialized
DEBUG - 2014-08-14 13:45:10 --> Model Class Initialized
DEBUG - 2014-08-14 13:45:10 --> Model Class Initialized
DEBUG - 2014-08-14 13:45:10 --> Model Class Initialized
DEBUG - 2014-08-14 13:45:10 --> Encrypt Class Initialized
DEBUG - 2014-08-14 13:45:10 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:10 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:10 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-14 13:45:10 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:10 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:10 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-14 13:45:10 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:10 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:10 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 13:45:10 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-14 13:45:10 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-14 13:45:10 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-14 13:45:10 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-14 13:45:10 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 13:45:10 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 13:45:10 --> Final output sent to browser
DEBUG - 2014-08-14 13:45:10 --> Total execution time: 0.2038
DEBUG - 2014-08-14 13:45:18 --> Config Class Initialized
DEBUG - 2014-08-14 13:45:18 --> Hooks Class Initialized
DEBUG - 2014-08-14 13:45:18 --> Utf8 Class Initialized
DEBUG - 2014-08-14 13:45:18 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 13:45:18 --> URI Class Initialized
DEBUG - 2014-08-14 13:45:18 --> Router Class Initialized
DEBUG - 2014-08-14 13:45:18 --> Output Class Initialized
DEBUG - 2014-08-14 13:45:18 --> Security Class Initialized
DEBUG - 2014-08-14 13:45:18 --> Input Class Initialized
DEBUG - 2014-08-14 13:45:18 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:18 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:18 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:18 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:18 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:18 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:18 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:18 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:18 --> CRSF cookie Set
DEBUG - 2014-08-14 13:45:18 --> CSRF token verified
DEBUG - 2014-08-14 13:45:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 13:45:18 --> Language Class Initialized
DEBUG - 2014-08-14 13:45:18 --> Loader Class Initialized
DEBUG - 2014-08-14 13:45:18 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 13:45:18 --> Helper loaded: url_helper
DEBUG - 2014-08-14 13:45:18 --> Database Driver Class Initialized
ERROR - 2014-08-14 13:45:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 13:45:18 --> Session Class Initialized
DEBUG - 2014-08-14 13:45:18 --> Helper loaded: string_helper
DEBUG - 2014-08-14 13:45:18 --> Session routines successfully run
DEBUG - 2014-08-14 13:45:18 --> Controller Class Initialized
DEBUG - 2014-08-14 13:45:18 --> Helper loaded: form_helper
DEBUG - 2014-08-14 13:45:18 --> Form Validation Class Initialized
DEBUG - 2014-08-14 13:45:18 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-14 13:45:18 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:18 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:18 --> Model Class Initialized
DEBUG - 2014-08-14 13:45:18 --> Model Class Initialized
DEBUG - 2014-08-14 13:45:18 --> Model Class Initialized
DEBUG - 2014-08-14 13:45:18 --> Model Class Initialized
DEBUG - 2014-08-14 13:45:18 --> Encrypt Class Initialized
DEBUG - 2014-08-14 13:45:18 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:18 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:18 --> Config Class Initialized
DEBUG - 2014-08-14 13:45:18 --> Hooks Class Initialized
DEBUG - 2014-08-14 13:45:18 --> Utf8 Class Initialized
DEBUG - 2014-08-14 13:45:18 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 13:45:18 --> URI Class Initialized
DEBUG - 2014-08-14 13:45:18 --> Router Class Initialized
DEBUG - 2014-08-14 13:45:18 --> Output Class Initialized
DEBUG - 2014-08-14 13:45:18 --> Security Class Initialized
DEBUG - 2014-08-14 13:45:18 --> Input Class Initialized
DEBUG - 2014-08-14 13:45:18 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:18 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:18 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:18 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:18 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:18 --> CRSF cookie Set
DEBUG - 2014-08-14 13:45:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 13:45:18 --> Language Class Initialized
DEBUG - 2014-08-14 13:45:18 --> Loader Class Initialized
DEBUG - 2014-08-14 13:45:18 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 13:45:18 --> Helper loaded: url_helper
DEBUG - 2014-08-14 13:45:18 --> Database Driver Class Initialized
ERROR - 2014-08-14 13:45:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 13:45:18 --> Session Class Initialized
DEBUG - 2014-08-14 13:45:18 --> Helper loaded: string_helper
DEBUG - 2014-08-14 13:45:18 --> Session routines successfully run
DEBUG - 2014-08-14 13:45:18 --> Controller Class Initialized
DEBUG - 2014-08-14 13:45:18 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 13:45:18 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 13:45:18 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-14 13:45:18 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-14 13:45:18 --> File loaded: application/views/placement_admin_home.php
DEBUG - 2014-08-14 13:45:18 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 13:45:18 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 13:45:18 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 13:45:18 --> Final output sent to browser
DEBUG - 2014-08-14 13:45:18 --> Total execution time: 0.1246
DEBUG - 2014-08-14 13:45:21 --> Config Class Initialized
DEBUG - 2014-08-14 13:45:21 --> Hooks Class Initialized
DEBUG - 2014-08-14 13:45:21 --> Utf8 Class Initialized
DEBUG - 2014-08-14 13:45:21 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 13:45:21 --> URI Class Initialized
DEBUG - 2014-08-14 13:45:21 --> Router Class Initialized
DEBUG - 2014-08-14 13:45:21 --> Output Class Initialized
DEBUG - 2014-08-14 13:45:21 --> Security Class Initialized
DEBUG - 2014-08-14 13:45:21 --> Input Class Initialized
DEBUG - 2014-08-14 13:45:21 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:21 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:21 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:21 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:21 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:21 --> CRSF cookie Set
DEBUG - 2014-08-14 13:45:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 13:45:21 --> Language Class Initialized
DEBUG - 2014-08-14 13:45:21 --> Loader Class Initialized
DEBUG - 2014-08-14 13:45:21 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 13:45:21 --> Helper loaded: url_helper
DEBUG - 2014-08-14 13:45:21 --> Database Driver Class Initialized
ERROR - 2014-08-14 13:45:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 13:45:21 --> Session Class Initialized
DEBUG - 2014-08-14 13:45:21 --> Helper loaded: string_helper
DEBUG - 2014-08-14 13:45:21 --> Session routines successfully run
DEBUG - 2014-08-14 13:45:21 --> Controller Class Initialized
DEBUG - 2014-08-14 13:45:21 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 13:45:21 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 13:45:21 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 13:45:21 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 13:45:21 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 13:45:21 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 13:45:21 --> Final output sent to browser
DEBUG - 2014-08-14 13:45:21 --> Total execution time: 0.0969
DEBUG - 2014-08-14 13:45:32 --> Config Class Initialized
DEBUG - 2014-08-14 13:45:32 --> Hooks Class Initialized
DEBUG - 2014-08-14 13:45:32 --> Utf8 Class Initialized
DEBUG - 2014-08-14 13:45:32 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 13:45:32 --> URI Class Initialized
DEBUG - 2014-08-14 13:45:32 --> Router Class Initialized
DEBUG - 2014-08-14 13:45:32 --> Output Class Initialized
DEBUG - 2014-08-14 13:45:32 --> Security Class Initialized
DEBUG - 2014-08-14 13:45:32 --> Input Class Initialized
DEBUG - 2014-08-14 13:45:32 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:32 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:32 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:32 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:32 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:32 --> CRSF cookie Set
DEBUG - 2014-08-14 13:45:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 13:45:32 --> Language Class Initialized
DEBUG - 2014-08-14 13:45:32 --> Loader Class Initialized
DEBUG - 2014-08-14 13:45:32 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 13:45:32 --> Helper loaded: url_helper
DEBUG - 2014-08-14 13:45:32 --> Database Driver Class Initialized
ERROR - 2014-08-14 13:45:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 13:45:32 --> Session Class Initialized
DEBUG - 2014-08-14 13:45:32 --> Helper loaded: string_helper
DEBUG - 2014-08-14 13:45:32 --> Session routines successfully run
DEBUG - 2014-08-14 13:45:32 --> Controller Class Initialized
DEBUG - 2014-08-14 13:45:32 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 13:45:32 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 13:45:32 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-14 13:45:32 --> File loaded: application/views/placement_admin_history.php
DEBUG - 2014-08-14 13:45:32 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 13:45:32 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 13:45:32 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 13:45:32 --> Final output sent to browser
DEBUG - 2014-08-14 13:45:32 --> Total execution time: 0.0950
DEBUG - 2014-08-14 13:45:34 --> Config Class Initialized
DEBUG - 2014-08-14 13:45:34 --> Hooks Class Initialized
DEBUG - 2014-08-14 13:45:34 --> Utf8 Class Initialized
DEBUG - 2014-08-14 13:45:34 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 13:45:34 --> URI Class Initialized
DEBUG - 2014-08-14 13:45:34 --> Router Class Initialized
DEBUG - 2014-08-14 13:45:34 --> Output Class Initialized
DEBUG - 2014-08-14 13:45:34 --> Security Class Initialized
DEBUG - 2014-08-14 13:45:34 --> Input Class Initialized
DEBUG - 2014-08-14 13:45:34 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:34 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:34 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:34 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:34 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:34 --> CRSF cookie Set
DEBUG - 2014-08-14 13:45:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 13:45:34 --> Language Class Initialized
DEBUG - 2014-08-14 13:45:34 --> Loader Class Initialized
DEBUG - 2014-08-14 13:45:34 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 13:45:34 --> Helper loaded: url_helper
DEBUG - 2014-08-14 13:45:34 --> Database Driver Class Initialized
ERROR - 2014-08-14 13:45:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 13:45:34 --> Session Class Initialized
DEBUG - 2014-08-14 13:45:34 --> Helper loaded: string_helper
DEBUG - 2014-08-14 13:45:34 --> Session routines successfully run
DEBUG - 2014-08-14 13:45:34 --> Controller Class Initialized
DEBUG - 2014-08-14 13:45:34 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 13:45:34 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 13:45:34 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 13:45:34 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 13:45:34 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 13:45:34 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 13:45:34 --> Final output sent to browser
DEBUG - 2014-08-14 13:45:34 --> Total execution time: 0.1031
DEBUG - 2014-08-14 13:45:55 --> Config Class Initialized
DEBUG - 2014-08-14 13:45:55 --> Hooks Class Initialized
DEBUG - 2014-08-14 13:45:55 --> Utf8 Class Initialized
DEBUG - 2014-08-14 13:45:55 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 13:45:55 --> URI Class Initialized
DEBUG - 2014-08-14 13:45:55 --> Router Class Initialized
DEBUG - 2014-08-14 13:45:55 --> Output Class Initialized
DEBUG - 2014-08-14 13:45:55 --> Security Class Initialized
DEBUG - 2014-08-14 13:45:55 --> Input Class Initialized
DEBUG - 2014-08-14 13:45:55 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:55 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:55 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:55 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:55 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:55 --> CRSF cookie Set
DEBUG - 2014-08-14 13:45:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 13:45:55 --> Language Class Initialized
DEBUG - 2014-08-14 13:45:55 --> Loader Class Initialized
DEBUG - 2014-08-14 13:45:55 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 13:45:55 --> Helper loaded: url_helper
DEBUG - 2014-08-14 13:45:55 --> Database Driver Class Initialized
ERROR - 2014-08-14 13:45:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 13:45:55 --> Session Class Initialized
DEBUG - 2014-08-14 13:45:55 --> Helper loaded: string_helper
DEBUG - 2014-08-14 13:45:55 --> Session routines successfully run
DEBUG - 2014-08-14 13:45:55 --> Controller Class Initialized
DEBUG - 2014-08-14 13:45:55 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 13:45:55 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 13:45:55 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-14 13:45:55 --> File loaded: application/views/placement_admin_history.php
DEBUG - 2014-08-14 13:45:55 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 13:45:55 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 13:45:55 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 13:45:55 --> Final output sent to browser
DEBUG - 2014-08-14 13:45:55 --> Total execution time: 0.0912
DEBUG - 2014-08-14 13:45:56 --> Config Class Initialized
DEBUG - 2014-08-14 13:45:56 --> Hooks Class Initialized
DEBUG - 2014-08-14 13:45:56 --> Utf8 Class Initialized
DEBUG - 2014-08-14 13:45:56 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 13:45:56 --> URI Class Initialized
DEBUG - 2014-08-14 13:45:56 --> Router Class Initialized
DEBUG - 2014-08-14 13:45:56 --> Output Class Initialized
DEBUG - 2014-08-14 13:45:56 --> Security Class Initialized
DEBUG - 2014-08-14 13:45:56 --> Input Class Initialized
DEBUG - 2014-08-14 13:45:56 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:56 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:56 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:56 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:56 --> XSS Filtering completed
DEBUG - 2014-08-14 13:45:56 --> CRSF cookie Set
DEBUG - 2014-08-14 13:45:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 13:45:56 --> Language Class Initialized
DEBUG - 2014-08-14 13:45:56 --> Loader Class Initialized
DEBUG - 2014-08-14 13:45:56 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 13:45:56 --> Helper loaded: url_helper
DEBUG - 2014-08-14 13:45:56 --> Database Driver Class Initialized
ERROR - 2014-08-14 13:45:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 13:45:56 --> Session Class Initialized
DEBUG - 2014-08-14 13:45:56 --> Helper loaded: string_helper
DEBUG - 2014-08-14 13:45:56 --> Session routines successfully run
DEBUG - 2014-08-14 13:45:56 --> Controller Class Initialized
DEBUG - 2014-08-14 13:45:56 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 13:45:56 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 13:45:56 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 13:45:56 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 13:45:56 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 13:45:56 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 13:45:56 --> Final output sent to browser
DEBUG - 2014-08-14 13:45:56 --> Total execution time: 0.0926
DEBUG - 2014-08-14 13:57:23 --> Config Class Initialized
DEBUG - 2014-08-14 13:57:23 --> Hooks Class Initialized
DEBUG - 2014-08-14 13:57:23 --> Utf8 Class Initialized
DEBUG - 2014-08-14 13:57:23 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 13:57:23 --> URI Class Initialized
DEBUG - 2014-08-14 13:57:23 --> Router Class Initialized
DEBUG - 2014-08-14 13:57:23 --> Output Class Initialized
DEBUG - 2014-08-14 13:57:23 --> Security Class Initialized
DEBUG - 2014-08-14 13:57:23 --> Input Class Initialized
DEBUG - 2014-08-14 13:57:23 --> XSS Filtering completed
DEBUG - 2014-08-14 13:57:23 --> XSS Filtering completed
DEBUG - 2014-08-14 13:57:23 --> XSS Filtering completed
DEBUG - 2014-08-14 13:57:23 --> XSS Filtering completed
DEBUG - 2014-08-14 13:57:23 --> XSS Filtering completed
DEBUG - 2014-08-14 13:57:23 --> CRSF cookie Set
DEBUG - 2014-08-14 13:57:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 13:57:23 --> Language Class Initialized
DEBUG - 2014-08-14 13:57:23 --> Loader Class Initialized
DEBUG - 2014-08-14 13:57:23 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 13:57:23 --> Helper loaded: url_helper
DEBUG - 2014-08-14 13:57:23 --> Database Driver Class Initialized
ERROR - 2014-08-14 13:57:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 13:57:23 --> Session Class Initialized
DEBUG - 2014-08-14 13:57:23 --> Helper loaded: string_helper
DEBUG - 2014-08-14 13:57:23 --> Session routines successfully run
DEBUG - 2014-08-14 13:57:23 --> Controller Class Initialized
DEBUG - 2014-08-14 13:57:23 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 13:57:23 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 13:57:23 --> Model Class Initialized
DEBUG - 2014-08-14 13:57:23 --> Model Class Initialized
DEBUG - 2014-08-14 13:57:23 --> Model Class Initialized
DEBUG - 2014-08-14 13:57:23 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 13:57:23 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 13:57:23 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 13:57:23 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 13:57:23 --> Final output sent to browser
DEBUG - 2014-08-14 13:57:23 --> Total execution time: 0.1083
DEBUG - 2014-08-14 14:05:36 --> Config Class Initialized
DEBUG - 2014-08-14 14:05:36 --> Hooks Class Initialized
DEBUG - 2014-08-14 14:05:36 --> Utf8 Class Initialized
DEBUG - 2014-08-14 14:05:36 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 14:05:36 --> URI Class Initialized
DEBUG - 2014-08-14 14:05:36 --> Router Class Initialized
DEBUG - 2014-08-14 14:05:36 --> Output Class Initialized
DEBUG - 2014-08-14 14:05:36 --> Security Class Initialized
DEBUG - 2014-08-14 14:05:36 --> Input Class Initialized
DEBUG - 2014-08-14 14:05:36 --> XSS Filtering completed
DEBUG - 2014-08-14 14:05:36 --> XSS Filtering completed
DEBUG - 2014-08-14 14:05:36 --> XSS Filtering completed
DEBUG - 2014-08-14 14:05:36 --> XSS Filtering completed
DEBUG - 2014-08-14 14:05:36 --> XSS Filtering completed
DEBUG - 2014-08-14 14:05:36 --> CRSF cookie Set
DEBUG - 2014-08-14 14:05:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 14:05:36 --> Language Class Initialized
DEBUG - 2014-08-14 14:05:36 --> Loader Class Initialized
DEBUG - 2014-08-14 14:05:36 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 14:05:36 --> Helper loaded: url_helper
DEBUG - 2014-08-14 14:05:36 --> Database Driver Class Initialized
ERROR - 2014-08-14 14:05:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-08-14 14:05:36 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 14:05:36 --> Session Class Initialized
DEBUG - 2014-08-14 14:05:36 --> Helper loaded: string_helper
DEBUG - 2014-08-14 14:05:36 --> Session routines successfully run
DEBUG - 2014-08-14 14:05:36 --> Controller Class Initialized
DEBUG - 2014-08-14 14:05:36 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 14:05:36 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 14:05:36 --> Model Class Initialized
DEBUG - 2014-08-14 14:05:36 --> Model Class Initialized
DEBUG - 2014-08-14 14:05:36 --> Model Class Initialized
ERROR - 2014-08-14 14:05:36 --> Severity: Notice  --> Undefined variable: student_newreg C:\wamp\www\cep\placement\application\views\placement_admin_verify.php 25
ERROR - 2014-08-14 14:05:36 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\cep\placement\application\views\placement_admin_verify.php 25
DEBUG - 2014-08-14 14:05:36 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 14:05:36 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 14:05:36 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 14:05:36 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 14:05:36 --> Final output sent to browser
DEBUG - 2014-08-14 14:05:36 --> Total execution time: 0.1170
DEBUG - 2014-08-14 14:06:44 --> Config Class Initialized
DEBUG - 2014-08-14 14:06:44 --> Hooks Class Initialized
DEBUG - 2014-08-14 14:06:44 --> Utf8 Class Initialized
DEBUG - 2014-08-14 14:06:44 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 14:06:44 --> URI Class Initialized
DEBUG - 2014-08-14 14:06:44 --> Router Class Initialized
DEBUG - 2014-08-14 14:06:44 --> Output Class Initialized
DEBUG - 2014-08-14 14:06:44 --> Security Class Initialized
DEBUG - 2014-08-14 14:06:44 --> Input Class Initialized
DEBUG - 2014-08-14 14:06:44 --> XSS Filtering completed
DEBUG - 2014-08-14 14:06:44 --> XSS Filtering completed
DEBUG - 2014-08-14 14:06:44 --> XSS Filtering completed
DEBUG - 2014-08-14 14:06:44 --> XSS Filtering completed
DEBUG - 2014-08-14 14:06:44 --> XSS Filtering completed
DEBUG - 2014-08-14 14:06:44 --> CRSF cookie Set
DEBUG - 2014-08-14 14:06:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 14:06:44 --> Language Class Initialized
DEBUG - 2014-08-14 14:06:44 --> Loader Class Initialized
DEBUG - 2014-08-14 14:06:44 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 14:06:44 --> Helper loaded: url_helper
DEBUG - 2014-08-14 14:06:44 --> Database Driver Class Initialized
ERROR - 2014-08-14 14:06:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-08-14 14:06:44 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 14:06:44 --> Session Class Initialized
DEBUG - 2014-08-14 14:06:44 --> Helper loaded: string_helper
DEBUG - 2014-08-14 14:06:44 --> Session routines successfully run
DEBUG - 2014-08-14 14:06:44 --> Controller Class Initialized
DEBUG - 2014-08-14 14:06:44 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 14:06:44 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 14:06:44 --> Model Class Initialized
DEBUG - 2014-08-14 14:06:45 --> Model Class Initialized
DEBUG - 2014-08-14 14:06:45 --> Model Class Initialized
DEBUG - 2014-08-14 14:06:45 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 14:06:45 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 14:06:45 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 14:06:45 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 14:06:45 --> Final output sent to browser
DEBUG - 2014-08-14 14:06:45 --> Total execution time: 0.1650
DEBUG - 2014-08-14 14:07:50 --> Config Class Initialized
DEBUG - 2014-08-14 14:07:50 --> Hooks Class Initialized
DEBUG - 2014-08-14 14:07:50 --> Utf8 Class Initialized
DEBUG - 2014-08-14 14:07:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 14:07:50 --> URI Class Initialized
DEBUG - 2014-08-14 14:07:50 --> Router Class Initialized
DEBUG - 2014-08-14 14:07:50 --> Output Class Initialized
DEBUG - 2014-08-14 14:07:50 --> Security Class Initialized
DEBUG - 2014-08-14 14:07:50 --> Input Class Initialized
DEBUG - 2014-08-14 14:07:50 --> XSS Filtering completed
DEBUG - 2014-08-14 14:07:50 --> XSS Filtering completed
DEBUG - 2014-08-14 14:07:50 --> XSS Filtering completed
DEBUG - 2014-08-14 14:07:50 --> XSS Filtering completed
DEBUG - 2014-08-14 14:07:50 --> XSS Filtering completed
DEBUG - 2014-08-14 14:07:50 --> CRSF cookie Set
DEBUG - 2014-08-14 14:07:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 14:07:50 --> Language Class Initialized
DEBUG - 2014-08-14 14:07:50 --> Loader Class Initialized
DEBUG - 2014-08-14 14:07:50 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 14:07:50 --> Helper loaded: url_helper
DEBUG - 2014-08-14 14:07:50 --> Database Driver Class Initialized
ERROR - 2014-08-14 14:07:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-08-14 14:07:50 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 14:07:50 --> Session Class Initialized
DEBUG - 2014-08-14 14:07:50 --> Helper loaded: string_helper
DEBUG - 2014-08-14 14:07:50 --> Session routines successfully run
DEBUG - 2014-08-14 14:07:50 --> Controller Class Initialized
DEBUG - 2014-08-14 14:07:50 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 14:07:50 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 14:07:50 --> Model Class Initialized
DEBUG - 2014-08-14 14:07:50 --> Model Class Initialized
DEBUG - 2014-08-14 14:07:50 --> Model Class Initialized
DEBUG - 2014-08-14 14:07:50 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 14:07:50 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 14:07:50 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 14:07:50 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 14:07:50 --> Final output sent to browser
DEBUG - 2014-08-14 14:07:50 --> Total execution time: 0.1113
DEBUG - 2014-08-14 14:08:14 --> Config Class Initialized
DEBUG - 2014-08-14 14:08:14 --> Hooks Class Initialized
DEBUG - 2014-08-14 14:08:14 --> Utf8 Class Initialized
DEBUG - 2014-08-14 14:08:14 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 14:08:14 --> URI Class Initialized
DEBUG - 2014-08-14 14:08:14 --> Router Class Initialized
DEBUG - 2014-08-14 14:08:14 --> Output Class Initialized
DEBUG - 2014-08-14 14:08:14 --> Security Class Initialized
DEBUG - 2014-08-14 14:08:14 --> Input Class Initialized
DEBUG - 2014-08-14 14:08:14 --> XSS Filtering completed
DEBUG - 2014-08-14 14:08:14 --> XSS Filtering completed
DEBUG - 2014-08-14 14:08:14 --> XSS Filtering completed
DEBUG - 2014-08-14 14:08:14 --> XSS Filtering completed
DEBUG - 2014-08-14 14:08:14 --> XSS Filtering completed
DEBUG - 2014-08-14 14:08:14 --> CRSF cookie Set
DEBUG - 2014-08-14 14:08:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 14:08:14 --> Language Class Initialized
DEBUG - 2014-08-14 14:08:14 --> Loader Class Initialized
DEBUG - 2014-08-14 14:08:14 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 14:08:14 --> Helper loaded: url_helper
DEBUG - 2014-08-14 14:08:14 --> Database Driver Class Initialized
ERROR - 2014-08-14 14:08:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 14:08:14 --> Session Class Initialized
DEBUG - 2014-08-14 14:08:14 --> Helper loaded: string_helper
DEBUG - 2014-08-14 14:08:14 --> Session routines successfully run
DEBUG - 2014-08-14 14:08:14 --> Controller Class Initialized
DEBUG - 2014-08-14 14:08:14 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 14:08:14 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 14:08:14 --> Model Class Initialized
DEBUG - 2014-08-14 14:08:14 --> Model Class Initialized
DEBUG - 2014-08-14 14:08:14 --> Model Class Initialized
DEBUG - 2014-08-14 14:08:14 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 14:08:14 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 14:08:14 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 14:08:14 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 14:08:14 --> Final output sent to browser
DEBUG - 2014-08-14 14:08:14 --> Total execution time: 0.1086
DEBUG - 2014-08-14 14:09:10 --> Config Class Initialized
DEBUG - 2014-08-14 14:09:10 --> Hooks Class Initialized
DEBUG - 2014-08-14 14:09:10 --> Utf8 Class Initialized
DEBUG - 2014-08-14 14:09:10 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 14:09:10 --> URI Class Initialized
DEBUG - 2014-08-14 14:09:10 --> Router Class Initialized
DEBUG - 2014-08-14 14:09:10 --> Output Class Initialized
DEBUG - 2014-08-14 14:09:10 --> Security Class Initialized
DEBUG - 2014-08-14 14:09:10 --> Input Class Initialized
DEBUG - 2014-08-14 14:09:10 --> XSS Filtering completed
DEBUG - 2014-08-14 14:09:10 --> XSS Filtering completed
DEBUG - 2014-08-14 14:09:10 --> XSS Filtering completed
DEBUG - 2014-08-14 14:09:10 --> XSS Filtering completed
DEBUG - 2014-08-14 14:09:10 --> XSS Filtering completed
DEBUG - 2014-08-14 14:09:10 --> CRSF cookie Set
DEBUG - 2014-08-14 14:09:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 14:09:10 --> Language Class Initialized
DEBUG - 2014-08-14 14:09:10 --> Loader Class Initialized
DEBUG - 2014-08-14 14:09:10 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 14:09:10 --> Helper loaded: url_helper
DEBUG - 2014-08-14 14:09:10 --> Database Driver Class Initialized
ERROR - 2014-08-14 14:09:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-08-14 14:09:10 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 14:09:10 --> Session Class Initialized
DEBUG - 2014-08-14 14:09:10 --> Helper loaded: string_helper
DEBUG - 2014-08-14 14:09:10 --> Session routines successfully run
DEBUG - 2014-08-14 14:09:10 --> Controller Class Initialized
DEBUG - 2014-08-14 14:09:10 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 14:09:10 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 14:09:10 --> Model Class Initialized
DEBUG - 2014-08-14 14:09:10 --> Model Class Initialized
DEBUG - 2014-08-14 14:09:10 --> Model Class Initialized
DEBUG - 2014-08-14 14:09:10 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 14:09:10 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 14:09:10 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 14:09:10 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 14:09:10 --> Final output sent to browser
DEBUG - 2014-08-14 14:09:10 --> Total execution time: 0.1114
DEBUG - 2014-08-14 14:09:23 --> Config Class Initialized
DEBUG - 2014-08-14 14:09:23 --> Hooks Class Initialized
DEBUG - 2014-08-14 14:09:23 --> Utf8 Class Initialized
DEBUG - 2014-08-14 14:09:23 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 14:09:23 --> URI Class Initialized
DEBUG - 2014-08-14 14:09:23 --> Router Class Initialized
DEBUG - 2014-08-14 14:09:23 --> Output Class Initialized
DEBUG - 2014-08-14 14:09:23 --> Security Class Initialized
DEBUG - 2014-08-14 14:09:23 --> Input Class Initialized
DEBUG - 2014-08-14 14:09:23 --> XSS Filtering completed
DEBUG - 2014-08-14 14:09:23 --> XSS Filtering completed
DEBUG - 2014-08-14 14:09:23 --> XSS Filtering completed
DEBUG - 2014-08-14 14:09:23 --> XSS Filtering completed
DEBUG - 2014-08-14 14:09:24 --> XSS Filtering completed
DEBUG - 2014-08-14 14:09:24 --> CRSF cookie Set
DEBUG - 2014-08-14 14:09:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 14:09:24 --> Language Class Initialized
DEBUG - 2014-08-14 14:09:24 --> Loader Class Initialized
DEBUG - 2014-08-14 14:09:24 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 14:09:24 --> Helper loaded: url_helper
DEBUG - 2014-08-14 14:09:24 --> Database Driver Class Initialized
ERROR - 2014-08-14 14:09:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 14:09:24 --> Session Class Initialized
DEBUG - 2014-08-14 14:09:24 --> Helper loaded: string_helper
DEBUG - 2014-08-14 14:09:24 --> Session routines successfully run
DEBUG - 2014-08-14 14:09:24 --> Controller Class Initialized
DEBUG - 2014-08-14 14:09:24 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 14:09:24 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 14:09:24 --> Model Class Initialized
DEBUG - 2014-08-14 14:09:24 --> Model Class Initialized
DEBUG - 2014-08-14 14:09:24 --> Model Class Initialized
DEBUG - 2014-08-14 14:09:24 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 14:09:24 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 14:09:24 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 14:09:24 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 14:09:24 --> Final output sent to browser
DEBUG - 2014-08-14 14:09:24 --> Total execution time: 0.1542
DEBUG - 2014-08-14 14:10:36 --> Config Class Initialized
DEBUG - 2014-08-14 14:10:36 --> Hooks Class Initialized
DEBUG - 2014-08-14 14:10:36 --> Utf8 Class Initialized
DEBUG - 2014-08-14 14:10:36 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 14:10:36 --> URI Class Initialized
DEBUG - 2014-08-14 14:10:36 --> Router Class Initialized
DEBUG - 2014-08-14 14:10:36 --> Output Class Initialized
DEBUG - 2014-08-14 14:10:36 --> Security Class Initialized
DEBUG - 2014-08-14 14:10:36 --> Input Class Initialized
DEBUG - 2014-08-14 14:10:36 --> XSS Filtering completed
DEBUG - 2014-08-14 14:10:36 --> XSS Filtering completed
DEBUG - 2014-08-14 14:10:36 --> XSS Filtering completed
DEBUG - 2014-08-14 14:10:36 --> XSS Filtering completed
DEBUG - 2014-08-14 14:10:36 --> XSS Filtering completed
DEBUG - 2014-08-14 14:10:36 --> CRSF cookie Set
DEBUG - 2014-08-14 14:10:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 14:10:36 --> Language Class Initialized
DEBUG - 2014-08-14 14:10:36 --> Loader Class Initialized
DEBUG - 2014-08-14 14:10:36 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 14:10:36 --> Helper loaded: url_helper
DEBUG - 2014-08-14 14:10:36 --> Database Driver Class Initialized
ERROR - 2014-08-14 14:10:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 14:10:36 --> Session Class Initialized
DEBUG - 2014-08-14 14:10:36 --> Helper loaded: string_helper
DEBUG - 2014-08-14 14:10:36 --> Session routines successfully run
DEBUG - 2014-08-14 14:10:36 --> Controller Class Initialized
DEBUG - 2014-08-14 14:10:36 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 14:10:36 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 14:10:36 --> Model Class Initialized
DEBUG - 2014-08-14 14:10:36 --> Model Class Initialized
DEBUG - 2014-08-14 14:10:36 --> Model Class Initialized
DEBUG - 2014-08-14 14:10:36 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 14:10:36 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 14:10:36 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 14:10:36 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 14:10:36 --> Final output sent to browser
DEBUG - 2014-08-14 14:10:36 --> Total execution time: 0.1124
DEBUG - 2014-08-14 14:11:04 --> Config Class Initialized
DEBUG - 2014-08-14 14:11:04 --> Hooks Class Initialized
DEBUG - 2014-08-14 14:11:04 --> Utf8 Class Initialized
DEBUG - 2014-08-14 14:11:04 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 14:11:04 --> URI Class Initialized
DEBUG - 2014-08-14 14:11:04 --> Router Class Initialized
DEBUG - 2014-08-14 14:11:04 --> Output Class Initialized
DEBUG - 2014-08-14 14:11:04 --> Security Class Initialized
DEBUG - 2014-08-14 14:11:04 --> Input Class Initialized
DEBUG - 2014-08-14 14:11:04 --> XSS Filtering completed
DEBUG - 2014-08-14 14:11:04 --> XSS Filtering completed
DEBUG - 2014-08-14 14:11:04 --> XSS Filtering completed
DEBUG - 2014-08-14 14:11:04 --> XSS Filtering completed
DEBUG - 2014-08-14 14:11:04 --> XSS Filtering completed
DEBUG - 2014-08-14 14:11:04 --> CRSF cookie Set
DEBUG - 2014-08-14 14:11:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 14:11:04 --> Language Class Initialized
DEBUG - 2014-08-14 14:11:04 --> Loader Class Initialized
DEBUG - 2014-08-14 14:11:04 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 14:11:04 --> Helper loaded: url_helper
DEBUG - 2014-08-14 14:11:04 --> Database Driver Class Initialized
ERROR - 2014-08-14 14:11:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 14:11:04 --> Session Class Initialized
DEBUG - 2014-08-14 14:11:04 --> Helper loaded: string_helper
DEBUG - 2014-08-14 14:11:04 --> Session routines successfully run
DEBUG - 2014-08-14 14:11:04 --> Controller Class Initialized
DEBUG - 2014-08-14 14:11:04 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 14:11:04 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 14:11:04 --> Model Class Initialized
DEBUG - 2014-08-14 14:11:04 --> Model Class Initialized
DEBUG - 2014-08-14 14:11:04 --> Model Class Initialized
DEBUG - 2014-08-14 14:11:04 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 14:11:04 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 14:11:04 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 14:11:04 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 14:11:04 --> Final output sent to browser
DEBUG - 2014-08-14 14:11:04 --> Total execution time: 0.1550
DEBUG - 2014-08-14 14:11:24 --> Config Class Initialized
DEBUG - 2014-08-14 14:11:24 --> Hooks Class Initialized
DEBUG - 2014-08-14 14:11:24 --> Utf8 Class Initialized
DEBUG - 2014-08-14 14:11:24 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 14:11:24 --> URI Class Initialized
DEBUG - 2014-08-14 14:11:24 --> Router Class Initialized
DEBUG - 2014-08-14 14:11:24 --> Output Class Initialized
DEBUG - 2014-08-14 14:11:24 --> Security Class Initialized
DEBUG - 2014-08-14 14:11:24 --> Input Class Initialized
DEBUG - 2014-08-14 14:11:24 --> XSS Filtering completed
DEBUG - 2014-08-14 14:11:24 --> XSS Filtering completed
DEBUG - 2014-08-14 14:11:24 --> XSS Filtering completed
DEBUG - 2014-08-14 14:11:24 --> XSS Filtering completed
DEBUG - 2014-08-14 14:11:24 --> XSS Filtering completed
DEBUG - 2014-08-14 14:11:24 --> CRSF cookie Set
DEBUG - 2014-08-14 14:11:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 14:11:24 --> Language Class Initialized
DEBUG - 2014-08-14 14:11:24 --> Loader Class Initialized
DEBUG - 2014-08-14 14:11:24 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 14:11:24 --> Helper loaded: url_helper
DEBUG - 2014-08-14 14:11:24 --> Database Driver Class Initialized
ERROR - 2014-08-14 14:11:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 14:11:24 --> Session Class Initialized
DEBUG - 2014-08-14 14:11:24 --> Helper loaded: string_helper
DEBUG - 2014-08-14 14:11:24 --> Session routines successfully run
DEBUG - 2014-08-14 14:11:24 --> Controller Class Initialized
DEBUG - 2014-08-14 14:11:24 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 14:11:24 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 14:11:24 --> Model Class Initialized
DEBUG - 2014-08-14 14:11:24 --> Model Class Initialized
DEBUG - 2014-08-14 14:11:24 --> Model Class Initialized
DEBUG - 2014-08-14 14:11:24 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 14:11:24 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 14:11:24 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 14:11:24 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 14:11:24 --> Final output sent to browser
DEBUG - 2014-08-14 14:11:24 --> Total execution time: 0.1097
DEBUG - 2014-08-14 14:11:30 --> Config Class Initialized
DEBUG - 2014-08-14 14:11:30 --> Hooks Class Initialized
DEBUG - 2014-08-14 14:11:30 --> Utf8 Class Initialized
DEBUG - 2014-08-14 14:11:30 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 14:11:30 --> URI Class Initialized
DEBUG - 2014-08-14 14:11:30 --> Router Class Initialized
DEBUG - 2014-08-14 14:11:30 --> Output Class Initialized
DEBUG - 2014-08-14 14:11:30 --> Security Class Initialized
DEBUG - 2014-08-14 14:11:30 --> Input Class Initialized
DEBUG - 2014-08-14 14:11:30 --> XSS Filtering completed
DEBUG - 2014-08-14 14:11:30 --> XSS Filtering completed
DEBUG - 2014-08-14 14:11:30 --> XSS Filtering completed
DEBUG - 2014-08-14 14:11:30 --> XSS Filtering completed
DEBUG - 2014-08-14 14:11:30 --> XSS Filtering completed
DEBUG - 2014-08-14 14:11:30 --> CRSF cookie Set
DEBUG - 2014-08-14 14:11:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 14:11:30 --> Language Class Initialized
DEBUG - 2014-08-14 14:11:30 --> Loader Class Initialized
DEBUG - 2014-08-14 14:11:30 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 14:11:30 --> Helper loaded: url_helper
DEBUG - 2014-08-14 14:11:30 --> Database Driver Class Initialized
ERROR - 2014-08-14 14:11:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 14:11:30 --> Session Class Initialized
DEBUG - 2014-08-14 14:11:30 --> Helper loaded: string_helper
DEBUG - 2014-08-14 14:11:30 --> Session routines successfully run
DEBUG - 2014-08-14 14:11:30 --> Controller Class Initialized
DEBUG - 2014-08-14 14:11:30 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 14:11:30 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 14:11:30 --> Model Class Initialized
DEBUG - 2014-08-14 14:11:30 --> Model Class Initialized
DEBUG - 2014-08-14 14:11:30 --> Model Class Initialized
DEBUG - 2014-08-14 14:11:30 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 14:11:30 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 14:11:30 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 14:11:30 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 14:11:30 --> Final output sent to browser
DEBUG - 2014-08-14 14:11:30 --> Total execution time: 0.1477
DEBUG - 2014-08-14 14:13:12 --> Config Class Initialized
DEBUG - 2014-08-14 14:13:12 --> Hooks Class Initialized
DEBUG - 2014-08-14 14:13:12 --> Utf8 Class Initialized
DEBUG - 2014-08-14 14:13:12 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 14:13:12 --> URI Class Initialized
DEBUG - 2014-08-14 14:13:12 --> Router Class Initialized
DEBUG - 2014-08-14 14:13:12 --> Output Class Initialized
DEBUG - 2014-08-14 14:13:12 --> Security Class Initialized
DEBUG - 2014-08-14 14:13:12 --> Input Class Initialized
DEBUG - 2014-08-14 14:13:12 --> XSS Filtering completed
DEBUG - 2014-08-14 14:13:12 --> XSS Filtering completed
DEBUG - 2014-08-14 14:13:12 --> XSS Filtering completed
DEBUG - 2014-08-14 14:13:12 --> XSS Filtering completed
DEBUG - 2014-08-14 14:13:12 --> XSS Filtering completed
DEBUG - 2014-08-14 14:13:12 --> CRSF cookie Set
DEBUG - 2014-08-14 14:13:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 14:13:12 --> Language Class Initialized
DEBUG - 2014-08-14 14:13:12 --> Loader Class Initialized
DEBUG - 2014-08-14 14:13:12 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 14:13:12 --> Helper loaded: url_helper
DEBUG - 2014-08-14 14:13:12 --> Database Driver Class Initialized
ERROR - 2014-08-14 14:13:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 14:13:12 --> Session Class Initialized
DEBUG - 2014-08-14 14:13:12 --> Helper loaded: string_helper
DEBUG - 2014-08-14 14:13:12 --> Session routines successfully run
DEBUG - 2014-08-14 14:13:12 --> Controller Class Initialized
DEBUG - 2014-08-14 14:13:12 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 14:13:12 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 14:13:12 --> Model Class Initialized
DEBUG - 2014-08-14 14:13:12 --> Model Class Initialized
DEBUG - 2014-08-14 14:13:12 --> Model Class Initialized
DEBUG - 2014-08-14 14:13:12 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 14:13:12 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 14:13:12 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 14:13:12 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 14:13:12 --> Final output sent to browser
DEBUG - 2014-08-14 14:13:12 --> Total execution time: 0.1105
DEBUG - 2014-08-14 14:13:29 --> Config Class Initialized
DEBUG - 2014-08-14 14:13:29 --> Hooks Class Initialized
DEBUG - 2014-08-14 14:13:29 --> Utf8 Class Initialized
DEBUG - 2014-08-14 14:13:29 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 14:13:29 --> URI Class Initialized
DEBUG - 2014-08-14 14:13:29 --> Router Class Initialized
DEBUG - 2014-08-14 14:13:29 --> Output Class Initialized
DEBUG - 2014-08-14 14:13:29 --> Security Class Initialized
DEBUG - 2014-08-14 14:13:29 --> Input Class Initialized
DEBUG - 2014-08-14 14:13:29 --> XSS Filtering completed
DEBUG - 2014-08-14 14:13:29 --> XSS Filtering completed
DEBUG - 2014-08-14 14:13:29 --> XSS Filtering completed
DEBUG - 2014-08-14 14:13:29 --> XSS Filtering completed
DEBUG - 2014-08-14 14:13:29 --> XSS Filtering completed
DEBUG - 2014-08-14 14:13:29 --> CRSF cookie Set
DEBUG - 2014-08-14 14:13:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 14:13:29 --> Language Class Initialized
DEBUG - 2014-08-14 14:13:29 --> Loader Class Initialized
DEBUG - 2014-08-14 14:13:29 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 14:13:29 --> Helper loaded: url_helper
DEBUG - 2014-08-14 14:13:29 --> Database Driver Class Initialized
ERROR - 2014-08-14 14:13:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 14:13:29 --> Session Class Initialized
DEBUG - 2014-08-14 14:13:29 --> Helper loaded: string_helper
DEBUG - 2014-08-14 14:13:29 --> Session routines successfully run
DEBUG - 2014-08-14 14:13:29 --> Controller Class Initialized
DEBUG - 2014-08-14 14:13:29 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 14:13:29 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 14:13:29 --> Model Class Initialized
DEBUG - 2014-08-14 14:13:29 --> Model Class Initialized
DEBUG - 2014-08-14 14:13:29 --> Model Class Initialized
DEBUG - 2014-08-14 14:13:29 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 14:13:29 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 14:13:29 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 14:13:29 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 14:13:29 --> Final output sent to browser
DEBUG - 2014-08-14 14:13:29 --> Total execution time: 0.1700
DEBUG - 2014-08-14 14:15:35 --> Config Class Initialized
DEBUG - 2014-08-14 14:15:35 --> Hooks Class Initialized
DEBUG - 2014-08-14 14:15:35 --> Utf8 Class Initialized
DEBUG - 2014-08-14 14:15:35 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 14:15:35 --> URI Class Initialized
DEBUG - 2014-08-14 14:15:35 --> Router Class Initialized
DEBUG - 2014-08-14 14:15:35 --> Output Class Initialized
DEBUG - 2014-08-14 14:15:35 --> Security Class Initialized
DEBUG - 2014-08-14 14:15:35 --> Input Class Initialized
DEBUG - 2014-08-14 14:15:35 --> XSS Filtering completed
DEBUG - 2014-08-14 14:15:35 --> XSS Filtering completed
DEBUG - 2014-08-14 14:15:35 --> XSS Filtering completed
DEBUG - 2014-08-14 14:15:35 --> XSS Filtering completed
DEBUG - 2014-08-14 14:15:35 --> XSS Filtering completed
DEBUG - 2014-08-14 14:15:35 --> CRSF cookie Set
DEBUG - 2014-08-14 14:15:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 14:15:35 --> Language Class Initialized
DEBUG - 2014-08-14 14:15:35 --> Loader Class Initialized
DEBUG - 2014-08-14 14:15:35 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 14:15:35 --> Helper loaded: url_helper
DEBUG - 2014-08-14 14:15:35 --> Database Driver Class Initialized
ERROR - 2014-08-14 14:15:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 14:15:35 --> Session Class Initialized
DEBUG - 2014-08-14 14:15:35 --> Helper loaded: string_helper
DEBUG - 2014-08-14 14:15:35 --> Session routines successfully run
DEBUG - 2014-08-14 14:15:35 --> Controller Class Initialized
DEBUG - 2014-08-14 14:15:35 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 14:15:35 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 14:15:35 --> Model Class Initialized
DEBUG - 2014-08-14 14:15:35 --> Model Class Initialized
DEBUG - 2014-08-14 14:15:35 --> Model Class Initialized
DEBUG - 2014-08-14 14:15:35 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 14:15:35 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 14:15:35 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 14:15:35 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 14:15:35 --> Final output sent to browser
DEBUG - 2014-08-14 14:15:35 --> Total execution time: 0.1101
DEBUG - 2014-08-14 14:15:48 --> Config Class Initialized
DEBUG - 2014-08-14 14:15:48 --> Hooks Class Initialized
DEBUG - 2014-08-14 14:15:48 --> Utf8 Class Initialized
DEBUG - 2014-08-14 14:15:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 14:15:48 --> URI Class Initialized
DEBUG - 2014-08-14 14:15:48 --> Router Class Initialized
DEBUG - 2014-08-14 14:15:48 --> Output Class Initialized
DEBUG - 2014-08-14 14:15:48 --> Security Class Initialized
DEBUG - 2014-08-14 14:15:48 --> Input Class Initialized
DEBUG - 2014-08-14 14:15:48 --> XSS Filtering completed
DEBUG - 2014-08-14 14:15:48 --> XSS Filtering completed
DEBUG - 2014-08-14 14:15:48 --> XSS Filtering completed
DEBUG - 2014-08-14 14:15:48 --> XSS Filtering completed
DEBUG - 2014-08-14 14:15:48 --> XSS Filtering completed
DEBUG - 2014-08-14 14:15:48 --> CRSF cookie Set
DEBUG - 2014-08-14 14:15:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 14:15:48 --> Language Class Initialized
DEBUG - 2014-08-14 14:15:48 --> Loader Class Initialized
DEBUG - 2014-08-14 14:15:48 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 14:15:48 --> Helper loaded: url_helper
DEBUG - 2014-08-14 14:15:48 --> Database Driver Class Initialized
ERROR - 2014-08-14 14:15:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 14:15:48 --> Session Class Initialized
DEBUG - 2014-08-14 14:15:48 --> Helper loaded: string_helper
DEBUG - 2014-08-14 14:15:48 --> Session routines successfully run
DEBUG - 2014-08-14 14:15:48 --> Controller Class Initialized
DEBUG - 2014-08-14 14:15:48 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 14:15:48 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 14:15:48 --> Model Class Initialized
DEBUG - 2014-08-14 14:15:48 --> Model Class Initialized
DEBUG - 2014-08-14 14:15:48 --> Model Class Initialized
DEBUG - 2014-08-14 14:15:48 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 14:15:48 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 14:15:48 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 14:15:48 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 14:15:48 --> Final output sent to browser
DEBUG - 2014-08-14 14:15:48 --> Total execution time: 0.1076
DEBUG - 2014-08-14 14:15:55 --> Config Class Initialized
DEBUG - 2014-08-14 14:15:55 --> Hooks Class Initialized
DEBUG - 2014-08-14 14:15:55 --> Utf8 Class Initialized
DEBUG - 2014-08-14 14:15:55 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 14:15:55 --> URI Class Initialized
DEBUG - 2014-08-14 14:15:55 --> Router Class Initialized
DEBUG - 2014-08-14 14:15:55 --> Output Class Initialized
DEBUG - 2014-08-14 14:15:55 --> Security Class Initialized
DEBUG - 2014-08-14 14:15:55 --> Input Class Initialized
DEBUG - 2014-08-14 14:15:55 --> XSS Filtering completed
DEBUG - 2014-08-14 14:15:55 --> XSS Filtering completed
DEBUG - 2014-08-14 14:15:55 --> XSS Filtering completed
DEBUG - 2014-08-14 14:15:55 --> XSS Filtering completed
DEBUG - 2014-08-14 14:15:55 --> XSS Filtering completed
DEBUG - 2014-08-14 14:15:55 --> CRSF cookie Set
DEBUG - 2014-08-14 14:15:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 14:15:55 --> Language Class Initialized
DEBUG - 2014-08-14 14:15:55 --> Loader Class Initialized
DEBUG - 2014-08-14 14:15:55 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 14:15:55 --> Helper loaded: url_helper
DEBUG - 2014-08-14 14:15:55 --> Database Driver Class Initialized
ERROR - 2014-08-14 14:15:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 14:15:55 --> Session Class Initialized
DEBUG - 2014-08-14 14:15:55 --> Helper loaded: string_helper
DEBUG - 2014-08-14 14:15:55 --> Session routines successfully run
DEBUG - 2014-08-14 14:15:55 --> Controller Class Initialized
DEBUG - 2014-08-14 14:15:55 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 14:15:55 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 14:15:55 --> Model Class Initialized
DEBUG - 2014-08-14 14:15:55 --> Model Class Initialized
DEBUG - 2014-08-14 14:15:55 --> Model Class Initialized
DEBUG - 2014-08-14 14:15:55 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 14:15:55 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 14:15:55 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 14:15:55 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 14:15:55 --> Final output sent to browser
DEBUG - 2014-08-14 14:15:55 --> Total execution time: 0.1618
DEBUG - 2014-08-14 14:16:57 --> Config Class Initialized
DEBUG - 2014-08-14 14:16:57 --> Hooks Class Initialized
DEBUG - 2014-08-14 14:16:57 --> Utf8 Class Initialized
DEBUG - 2014-08-14 14:16:57 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 14:16:58 --> URI Class Initialized
DEBUG - 2014-08-14 14:16:58 --> Router Class Initialized
DEBUG - 2014-08-14 14:16:58 --> Output Class Initialized
DEBUG - 2014-08-14 14:16:58 --> Security Class Initialized
DEBUG - 2014-08-14 14:16:58 --> Input Class Initialized
DEBUG - 2014-08-14 14:16:58 --> XSS Filtering completed
DEBUG - 2014-08-14 14:16:58 --> XSS Filtering completed
DEBUG - 2014-08-14 14:16:58 --> XSS Filtering completed
DEBUG - 2014-08-14 14:16:58 --> XSS Filtering completed
DEBUG - 2014-08-14 14:16:58 --> XSS Filtering completed
DEBUG - 2014-08-14 14:16:58 --> CRSF cookie Set
DEBUG - 2014-08-14 14:16:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 14:16:58 --> Language Class Initialized
DEBUG - 2014-08-14 14:16:58 --> Loader Class Initialized
DEBUG - 2014-08-14 14:16:58 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 14:16:58 --> Helper loaded: url_helper
DEBUG - 2014-08-14 14:16:58 --> Database Driver Class Initialized
ERROR - 2014-08-14 14:16:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 14:16:58 --> Session Class Initialized
DEBUG - 2014-08-14 14:16:58 --> Helper loaded: string_helper
DEBUG - 2014-08-14 14:16:58 --> Session routines successfully run
DEBUG - 2014-08-14 14:16:58 --> Controller Class Initialized
DEBUG - 2014-08-14 14:16:58 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 14:16:58 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 14:16:58 --> Model Class Initialized
DEBUG - 2014-08-14 14:16:58 --> Model Class Initialized
DEBUG - 2014-08-14 14:16:58 --> Model Class Initialized
DEBUG - 2014-08-14 14:16:58 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 14:16:58 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 14:16:58 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 14:16:58 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 14:16:58 --> Final output sent to browser
DEBUG - 2014-08-14 14:16:58 --> Total execution time: 0.1091
DEBUG - 2014-08-14 14:17:39 --> Config Class Initialized
DEBUG - 2014-08-14 14:17:39 --> Hooks Class Initialized
DEBUG - 2014-08-14 14:17:39 --> Utf8 Class Initialized
DEBUG - 2014-08-14 14:17:39 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 14:17:39 --> URI Class Initialized
DEBUG - 2014-08-14 14:17:39 --> Router Class Initialized
DEBUG - 2014-08-14 14:17:39 --> Output Class Initialized
DEBUG - 2014-08-14 14:17:39 --> Security Class Initialized
DEBUG - 2014-08-14 14:17:39 --> Input Class Initialized
DEBUG - 2014-08-14 14:17:39 --> XSS Filtering completed
DEBUG - 2014-08-14 14:17:39 --> XSS Filtering completed
DEBUG - 2014-08-14 14:17:39 --> XSS Filtering completed
DEBUG - 2014-08-14 14:17:39 --> XSS Filtering completed
DEBUG - 2014-08-14 14:17:39 --> XSS Filtering completed
DEBUG - 2014-08-14 14:17:39 --> CRSF cookie Set
DEBUG - 2014-08-14 14:17:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 14:17:39 --> Language Class Initialized
DEBUG - 2014-08-14 14:17:39 --> Loader Class Initialized
DEBUG - 2014-08-14 14:17:39 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 14:17:39 --> Helper loaded: url_helper
DEBUG - 2014-08-14 14:17:39 --> Database Driver Class Initialized
ERROR - 2014-08-14 14:17:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 14:17:39 --> Session Class Initialized
DEBUG - 2014-08-14 14:17:39 --> Helper loaded: string_helper
DEBUG - 2014-08-14 14:17:39 --> Session routines successfully run
DEBUG - 2014-08-14 14:17:39 --> Controller Class Initialized
DEBUG - 2014-08-14 14:17:39 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 14:17:39 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 14:17:39 --> Model Class Initialized
DEBUG - 2014-08-14 14:17:39 --> Model Class Initialized
DEBUG - 2014-08-14 14:17:39 --> Model Class Initialized
DEBUG - 2014-08-14 14:17:39 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 14:17:39 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 14:17:39 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 14:17:39 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 14:17:39 --> Final output sent to browser
DEBUG - 2014-08-14 14:17:39 --> Total execution time: 0.1595
DEBUG - 2014-08-14 14:19:42 --> Config Class Initialized
DEBUG - 2014-08-14 14:19:42 --> Hooks Class Initialized
DEBUG - 2014-08-14 14:19:42 --> Utf8 Class Initialized
DEBUG - 2014-08-14 14:19:42 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 14:19:42 --> URI Class Initialized
DEBUG - 2014-08-14 14:19:42 --> Router Class Initialized
DEBUG - 2014-08-14 14:19:42 --> Output Class Initialized
DEBUG - 2014-08-14 14:19:42 --> Security Class Initialized
DEBUG - 2014-08-14 14:19:42 --> Input Class Initialized
DEBUG - 2014-08-14 14:19:42 --> XSS Filtering completed
DEBUG - 2014-08-14 14:19:42 --> XSS Filtering completed
DEBUG - 2014-08-14 14:19:42 --> XSS Filtering completed
DEBUG - 2014-08-14 14:19:42 --> XSS Filtering completed
DEBUG - 2014-08-14 14:19:42 --> XSS Filtering completed
DEBUG - 2014-08-14 14:19:42 --> CRSF cookie Set
DEBUG - 2014-08-14 14:19:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 14:19:42 --> Language Class Initialized
DEBUG - 2014-08-14 14:19:42 --> Loader Class Initialized
DEBUG - 2014-08-14 14:19:42 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 14:19:42 --> Helper loaded: url_helper
DEBUG - 2014-08-14 14:19:42 --> Database Driver Class Initialized
ERROR - 2014-08-14 14:19:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 14:19:42 --> Session Class Initialized
DEBUG - 2014-08-14 14:19:42 --> Helper loaded: string_helper
DEBUG - 2014-08-14 14:19:42 --> Session routines successfully run
DEBUG - 2014-08-14 14:19:42 --> Controller Class Initialized
DEBUG - 2014-08-14 14:19:43 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 14:19:43 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 14:19:43 --> Model Class Initialized
DEBUG - 2014-08-14 14:19:43 --> Model Class Initialized
DEBUG - 2014-08-14 14:19:43 --> Model Class Initialized
DEBUG - 2014-08-14 14:19:43 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 14:19:43 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 14:19:43 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 14:19:43 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 14:19:43 --> Final output sent to browser
DEBUG - 2014-08-14 14:19:43 --> Total execution time: 0.1095
DEBUG - 2014-08-14 14:20:12 --> Config Class Initialized
DEBUG - 2014-08-14 14:20:12 --> Hooks Class Initialized
DEBUG - 2014-08-14 14:20:12 --> Utf8 Class Initialized
DEBUG - 2014-08-14 14:20:12 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 14:20:12 --> URI Class Initialized
DEBUG - 2014-08-14 14:20:12 --> Router Class Initialized
DEBUG - 2014-08-14 14:20:12 --> Output Class Initialized
DEBUG - 2014-08-14 14:20:12 --> Security Class Initialized
DEBUG - 2014-08-14 14:20:12 --> Input Class Initialized
DEBUG - 2014-08-14 14:20:12 --> XSS Filtering completed
DEBUG - 2014-08-14 14:20:12 --> XSS Filtering completed
DEBUG - 2014-08-14 14:20:12 --> XSS Filtering completed
DEBUG - 2014-08-14 14:20:12 --> XSS Filtering completed
DEBUG - 2014-08-14 14:20:12 --> XSS Filtering completed
DEBUG - 2014-08-14 14:20:12 --> CRSF cookie Set
DEBUG - 2014-08-14 14:20:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 14:20:12 --> Language Class Initialized
DEBUG - 2014-08-14 14:20:12 --> Loader Class Initialized
DEBUG - 2014-08-14 14:20:12 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 14:20:12 --> Helper loaded: url_helper
DEBUG - 2014-08-14 14:20:12 --> Database Driver Class Initialized
ERROR - 2014-08-14 14:20:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 14:20:12 --> Session Class Initialized
DEBUG - 2014-08-14 14:20:12 --> Helper loaded: string_helper
DEBUG - 2014-08-14 14:20:12 --> Session routines successfully run
DEBUG - 2014-08-14 14:20:12 --> Controller Class Initialized
DEBUG - 2014-08-14 14:20:12 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 14:20:12 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 14:20:12 --> Model Class Initialized
DEBUG - 2014-08-14 14:20:12 --> Model Class Initialized
DEBUG - 2014-08-14 14:20:12 --> Model Class Initialized
DEBUG - 2014-08-14 14:20:12 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 14:20:12 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 14:20:12 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 14:20:12 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 14:20:12 --> Final output sent to browser
DEBUG - 2014-08-14 14:20:12 --> Total execution time: 0.1075
DEBUG - 2014-08-14 14:20:27 --> Config Class Initialized
DEBUG - 2014-08-14 14:20:27 --> Hooks Class Initialized
DEBUG - 2014-08-14 14:20:27 --> Utf8 Class Initialized
DEBUG - 2014-08-14 14:20:27 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 14:20:27 --> URI Class Initialized
DEBUG - 2014-08-14 14:20:27 --> Router Class Initialized
DEBUG - 2014-08-14 14:20:27 --> Output Class Initialized
DEBUG - 2014-08-14 14:20:27 --> Security Class Initialized
DEBUG - 2014-08-14 14:20:27 --> Input Class Initialized
DEBUG - 2014-08-14 14:20:27 --> XSS Filtering completed
DEBUG - 2014-08-14 14:20:27 --> XSS Filtering completed
DEBUG - 2014-08-14 14:20:27 --> XSS Filtering completed
DEBUG - 2014-08-14 14:20:27 --> XSS Filtering completed
DEBUG - 2014-08-14 14:20:27 --> XSS Filtering completed
DEBUG - 2014-08-14 14:20:27 --> CRSF cookie Set
DEBUG - 2014-08-14 14:20:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 14:20:27 --> Language Class Initialized
DEBUG - 2014-08-14 14:20:27 --> Loader Class Initialized
DEBUG - 2014-08-14 14:20:27 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 14:20:27 --> Helper loaded: url_helper
DEBUG - 2014-08-14 14:20:27 --> Database Driver Class Initialized
ERROR - 2014-08-14 14:20:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 14:20:27 --> Session Class Initialized
DEBUG - 2014-08-14 14:20:27 --> Helper loaded: string_helper
DEBUG - 2014-08-14 14:20:27 --> Session routines successfully run
DEBUG - 2014-08-14 14:20:27 --> Controller Class Initialized
DEBUG - 2014-08-14 14:20:27 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 14:20:27 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 14:20:27 --> Model Class Initialized
DEBUG - 2014-08-14 14:20:27 --> Model Class Initialized
DEBUG - 2014-08-14 14:20:27 --> Model Class Initialized
DEBUG - 2014-08-14 14:20:27 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 14:20:27 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 14:20:27 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 14:20:27 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 14:20:27 --> Final output sent to browser
DEBUG - 2014-08-14 14:20:27 --> Total execution time: 0.1062
DEBUG - 2014-08-14 14:21:53 --> Config Class Initialized
DEBUG - 2014-08-14 14:21:53 --> Hooks Class Initialized
DEBUG - 2014-08-14 14:21:53 --> Utf8 Class Initialized
DEBUG - 2014-08-14 14:21:53 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 14:21:53 --> URI Class Initialized
DEBUG - 2014-08-14 14:21:53 --> Router Class Initialized
DEBUG - 2014-08-14 14:21:53 --> Output Class Initialized
DEBUG - 2014-08-14 14:21:53 --> Security Class Initialized
DEBUG - 2014-08-14 14:21:53 --> Input Class Initialized
DEBUG - 2014-08-14 14:21:53 --> XSS Filtering completed
DEBUG - 2014-08-14 14:21:53 --> XSS Filtering completed
DEBUG - 2014-08-14 14:21:53 --> XSS Filtering completed
DEBUG - 2014-08-14 14:21:53 --> XSS Filtering completed
DEBUG - 2014-08-14 14:21:53 --> XSS Filtering completed
DEBUG - 2014-08-14 14:21:53 --> CRSF cookie Set
DEBUG - 2014-08-14 14:21:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 14:21:53 --> Language Class Initialized
DEBUG - 2014-08-14 14:21:53 --> Loader Class Initialized
DEBUG - 2014-08-14 14:21:53 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 14:21:53 --> Helper loaded: url_helper
DEBUG - 2014-08-14 14:21:53 --> Database Driver Class Initialized
ERROR - 2014-08-14 14:21:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 14:21:53 --> Session Class Initialized
DEBUG - 2014-08-14 14:21:53 --> Helper loaded: string_helper
DEBUG - 2014-08-14 14:21:53 --> Session routines successfully run
DEBUG - 2014-08-14 14:21:53 --> Controller Class Initialized
DEBUG - 2014-08-14 14:21:53 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 14:21:53 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 14:21:53 --> Model Class Initialized
DEBUG - 2014-08-14 14:21:53 --> Model Class Initialized
DEBUG - 2014-08-14 14:21:53 --> Model Class Initialized
DEBUG - 2014-08-14 14:21:53 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 14:21:53 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 14:21:53 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 14:21:53 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 14:21:53 --> Final output sent to browser
DEBUG - 2014-08-14 14:21:53 --> Total execution time: 0.1109
DEBUG - 2014-08-14 14:23:57 --> Config Class Initialized
DEBUG - 2014-08-14 14:23:57 --> Hooks Class Initialized
DEBUG - 2014-08-14 14:23:57 --> Utf8 Class Initialized
DEBUG - 2014-08-14 14:23:57 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 14:23:57 --> URI Class Initialized
DEBUG - 2014-08-14 14:23:57 --> Router Class Initialized
DEBUG - 2014-08-14 14:23:57 --> Output Class Initialized
DEBUG - 2014-08-14 14:23:57 --> Security Class Initialized
DEBUG - 2014-08-14 14:23:57 --> Input Class Initialized
DEBUG - 2014-08-14 14:23:57 --> XSS Filtering completed
DEBUG - 2014-08-14 14:23:57 --> XSS Filtering completed
DEBUG - 2014-08-14 14:23:57 --> XSS Filtering completed
DEBUG - 2014-08-14 14:23:57 --> XSS Filtering completed
DEBUG - 2014-08-14 14:23:57 --> XSS Filtering completed
DEBUG - 2014-08-14 14:23:57 --> CRSF cookie Set
DEBUG - 2014-08-14 14:23:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 14:23:57 --> Language Class Initialized
DEBUG - 2014-08-14 14:23:57 --> Loader Class Initialized
DEBUG - 2014-08-14 14:23:57 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 14:23:57 --> Helper loaded: url_helper
DEBUG - 2014-08-14 14:23:57 --> Database Driver Class Initialized
ERROR - 2014-08-14 14:23:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-08-14 14:23:57 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 14:23:57 --> Session Class Initialized
DEBUG - 2014-08-14 14:23:57 --> Helper loaded: string_helper
DEBUG - 2014-08-14 14:23:57 --> Session routines successfully run
DEBUG - 2014-08-14 14:23:57 --> Controller Class Initialized
DEBUG - 2014-08-14 14:23:57 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 14:23:57 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 14:23:57 --> Model Class Initialized
DEBUG - 2014-08-14 14:23:57 --> Model Class Initialized
DEBUG - 2014-08-14 14:23:57 --> Model Class Initialized
DEBUG - 2014-08-14 14:23:57 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 14:23:57 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 14:23:57 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 14:23:57 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 14:23:57 --> Final output sent to browser
DEBUG - 2014-08-14 14:23:57 --> Total execution time: 0.1146
DEBUG - 2014-08-14 14:25:11 --> Config Class Initialized
DEBUG - 2014-08-14 14:25:11 --> Hooks Class Initialized
DEBUG - 2014-08-14 14:25:11 --> Utf8 Class Initialized
DEBUG - 2014-08-14 14:25:11 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 14:25:11 --> URI Class Initialized
DEBUG - 2014-08-14 14:25:11 --> Router Class Initialized
DEBUG - 2014-08-14 14:25:11 --> Output Class Initialized
DEBUG - 2014-08-14 14:25:11 --> Security Class Initialized
DEBUG - 2014-08-14 14:25:11 --> Input Class Initialized
DEBUG - 2014-08-14 14:25:11 --> XSS Filtering completed
DEBUG - 2014-08-14 14:25:11 --> XSS Filtering completed
DEBUG - 2014-08-14 14:25:11 --> XSS Filtering completed
DEBUG - 2014-08-14 14:25:11 --> XSS Filtering completed
DEBUG - 2014-08-14 14:25:11 --> XSS Filtering completed
DEBUG - 2014-08-14 14:25:11 --> CRSF cookie Set
DEBUG - 2014-08-14 14:25:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 14:25:11 --> Language Class Initialized
DEBUG - 2014-08-14 14:25:11 --> Loader Class Initialized
DEBUG - 2014-08-14 14:25:11 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 14:25:11 --> Helper loaded: url_helper
DEBUG - 2014-08-14 14:25:11 --> Database Driver Class Initialized
ERROR - 2014-08-14 14:25:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 14:25:11 --> Session Class Initialized
DEBUG - 2014-08-14 14:25:11 --> Helper loaded: string_helper
DEBUG - 2014-08-14 14:25:11 --> Session routines successfully run
DEBUG - 2014-08-14 14:25:11 --> Controller Class Initialized
DEBUG - 2014-08-14 14:25:11 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 14:25:11 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 14:25:11 --> Model Class Initialized
DEBUG - 2014-08-14 14:25:11 --> Model Class Initialized
DEBUG - 2014-08-14 14:25:11 --> Model Class Initialized
ERROR - 2014-08-14 14:25:11 --> Severity: Notice  --> Undefined index: website C:\wamp\www\cep\placement\application\views\placement_admin_verify.php 36
ERROR - 2014-08-14 14:25:11 --> Severity: Notice  --> Undefined index: website C:\wamp\www\cep\placement\application\views\placement_admin_verify.php 36
ERROR - 2014-08-14 14:25:11 --> Severity: Notice  --> Undefined index: website C:\wamp\www\cep\placement\application\views\placement_admin_verify.php 36
ERROR - 2014-08-14 14:25:11 --> Severity: Notice  --> Undefined index: website C:\wamp\www\cep\placement\application\views\placement_admin_verify.php 36
ERROR - 2014-08-14 14:25:11 --> Severity: Notice  --> Undefined index: website C:\wamp\www\cep\placement\application\views\placement_admin_verify.php 36
ERROR - 2014-08-14 14:25:11 --> Severity: Notice  --> Undefined index: website C:\wamp\www\cep\placement\application\views\placement_admin_verify.php 36
ERROR - 2014-08-14 14:25:11 --> Severity: Notice  --> Undefined index: website C:\wamp\www\cep\placement\application\views\placement_admin_verify.php 36
ERROR - 2014-08-14 14:25:11 --> Severity: Notice  --> Undefined index: website C:\wamp\www\cep\placement\application\views\placement_admin_verify.php 36
DEBUG - 2014-08-14 14:25:11 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 14:25:11 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 14:25:11 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 14:25:11 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 14:25:11 --> Final output sent to browser
DEBUG - 2014-08-14 14:25:11 --> Total execution time: 0.1742
DEBUG - 2014-08-14 14:26:03 --> Config Class Initialized
DEBUG - 2014-08-14 14:26:03 --> Hooks Class Initialized
DEBUG - 2014-08-14 14:26:03 --> Utf8 Class Initialized
DEBUG - 2014-08-14 14:26:03 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 14:26:03 --> URI Class Initialized
DEBUG - 2014-08-14 14:26:03 --> Router Class Initialized
DEBUG - 2014-08-14 14:26:03 --> Output Class Initialized
DEBUG - 2014-08-14 14:26:03 --> Security Class Initialized
DEBUG - 2014-08-14 14:26:03 --> Input Class Initialized
DEBUG - 2014-08-14 14:26:03 --> XSS Filtering completed
DEBUG - 2014-08-14 14:26:03 --> XSS Filtering completed
DEBUG - 2014-08-14 14:26:03 --> XSS Filtering completed
DEBUG - 2014-08-14 14:26:03 --> XSS Filtering completed
DEBUG - 2014-08-14 14:26:03 --> XSS Filtering completed
DEBUG - 2014-08-14 14:26:03 --> CRSF cookie Set
DEBUG - 2014-08-14 14:26:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 14:26:03 --> Language Class Initialized
DEBUG - 2014-08-14 14:26:03 --> Loader Class Initialized
DEBUG - 2014-08-14 14:26:03 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 14:26:03 --> Helper loaded: url_helper
DEBUG - 2014-08-14 14:26:03 --> Database Driver Class Initialized
ERROR - 2014-08-14 14:26:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 14:26:03 --> Session Class Initialized
DEBUG - 2014-08-14 14:26:03 --> Helper loaded: string_helper
DEBUG - 2014-08-14 14:26:03 --> Session routines successfully run
DEBUG - 2014-08-14 14:26:03 --> Controller Class Initialized
DEBUG - 2014-08-14 14:26:03 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 14:26:03 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 14:26:03 --> Model Class Initialized
DEBUG - 2014-08-14 14:26:03 --> Model Class Initialized
DEBUG - 2014-08-14 14:26:03 --> Model Class Initialized
ERROR - 2014-08-14 14:26:03 --> Severity: Notice  --> Undefined index: website C:\wamp\www\cep\placement\application\views\placement_admin_verify.php 36
ERROR - 2014-08-14 14:26:03 --> Severity: Notice  --> Undefined index: website C:\wamp\www\cep\placement\application\views\placement_admin_verify.php 36
ERROR - 2014-08-14 14:26:03 --> Severity: Notice  --> Undefined index: website C:\wamp\www\cep\placement\application\views\placement_admin_verify.php 36
ERROR - 2014-08-14 14:26:03 --> Severity: Notice  --> Undefined index: website C:\wamp\www\cep\placement\application\views\placement_admin_verify.php 36
ERROR - 2014-08-14 14:26:03 --> Severity: Notice  --> Undefined index: website C:\wamp\www\cep\placement\application\views\placement_admin_verify.php 36
ERROR - 2014-08-14 14:26:03 --> Severity: Notice  --> Undefined index: website C:\wamp\www\cep\placement\application\views\placement_admin_verify.php 36
ERROR - 2014-08-14 14:26:03 --> Severity: Notice  --> Undefined index: website C:\wamp\www\cep\placement\application\views\placement_admin_verify.php 36
ERROR - 2014-08-14 14:26:03 --> Severity: Notice  --> Undefined index: website C:\wamp\www\cep\placement\application\views\placement_admin_verify.php 36
DEBUG - 2014-08-14 14:26:03 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 14:26:03 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 14:26:03 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 14:26:03 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 14:26:03 --> Final output sent to browser
DEBUG - 2014-08-14 14:26:03 --> Total execution time: 0.1222
DEBUG - 2014-08-14 14:27:01 --> Config Class Initialized
DEBUG - 2014-08-14 14:27:01 --> Hooks Class Initialized
DEBUG - 2014-08-14 14:27:01 --> Utf8 Class Initialized
DEBUG - 2014-08-14 14:27:01 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 14:27:01 --> URI Class Initialized
DEBUG - 2014-08-14 14:27:01 --> Router Class Initialized
DEBUG - 2014-08-14 14:27:01 --> Output Class Initialized
DEBUG - 2014-08-14 14:27:01 --> Security Class Initialized
DEBUG - 2014-08-14 14:27:01 --> Input Class Initialized
DEBUG - 2014-08-14 14:27:01 --> XSS Filtering completed
DEBUG - 2014-08-14 14:27:01 --> XSS Filtering completed
DEBUG - 2014-08-14 14:27:01 --> XSS Filtering completed
DEBUG - 2014-08-14 14:27:01 --> XSS Filtering completed
DEBUG - 2014-08-14 14:27:01 --> XSS Filtering completed
DEBUG - 2014-08-14 14:27:01 --> CRSF cookie Set
DEBUG - 2014-08-14 14:27:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 14:27:01 --> Language Class Initialized
DEBUG - 2014-08-14 14:27:01 --> Loader Class Initialized
DEBUG - 2014-08-14 14:27:01 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 14:27:01 --> Helper loaded: url_helper
DEBUG - 2014-08-14 14:27:01 --> Database Driver Class Initialized
ERROR - 2014-08-14 14:27:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 14:27:01 --> Session Class Initialized
DEBUG - 2014-08-14 14:27:01 --> Helper loaded: string_helper
DEBUG - 2014-08-14 14:27:01 --> Session routines successfully run
DEBUG - 2014-08-14 14:27:01 --> Controller Class Initialized
DEBUG - 2014-08-14 14:27:01 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 14:27:01 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 14:27:01 --> Model Class Initialized
DEBUG - 2014-08-14 14:27:01 --> Model Class Initialized
DEBUG - 2014-08-14 14:27:01 --> Model Class Initialized
ERROR - 2014-08-14 14:27:01 --> Severity: Notice  --> Undefined index: name C:\wamp\www\cep\placement\application\views\placement_admin_verify.php 30
ERROR - 2014-08-14 14:27:01 --> Severity: Notice  --> Undefined index: email C:\wamp\www\cep\placement\application\views\placement_admin_verify.php 33
ERROR - 2014-08-14 14:27:01 --> Severity: Notice  --> Undefined index: website C:\wamp\www\cep\placement\application\views\placement_admin_verify.php 36
ERROR - 2014-08-14 14:27:01 --> Severity: Notice  --> Undefined index: mobno C:\wamp\www\cep\placement\application\views\placement_admin_verify.php 39
DEBUG - 2014-08-14 14:27:01 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 14:27:01 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 14:27:01 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 14:27:01 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 14:27:01 --> Final output sent to browser
DEBUG - 2014-08-14 14:27:01 --> Total execution time: 0.1148
DEBUG - 2014-08-14 14:28:11 --> Config Class Initialized
DEBUG - 2014-08-14 14:28:11 --> Hooks Class Initialized
DEBUG - 2014-08-14 14:28:11 --> Utf8 Class Initialized
DEBUG - 2014-08-14 14:28:11 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 14:28:11 --> URI Class Initialized
DEBUG - 2014-08-14 14:28:11 --> Router Class Initialized
DEBUG - 2014-08-14 14:28:11 --> Output Class Initialized
DEBUG - 2014-08-14 14:28:11 --> Security Class Initialized
DEBUG - 2014-08-14 14:28:11 --> Input Class Initialized
DEBUG - 2014-08-14 14:28:11 --> XSS Filtering completed
DEBUG - 2014-08-14 14:28:11 --> XSS Filtering completed
DEBUG - 2014-08-14 14:28:11 --> XSS Filtering completed
DEBUG - 2014-08-14 14:28:11 --> XSS Filtering completed
DEBUG - 2014-08-14 14:28:11 --> XSS Filtering completed
DEBUG - 2014-08-14 14:28:11 --> CRSF cookie Set
DEBUG - 2014-08-14 14:28:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 14:28:11 --> Language Class Initialized
DEBUG - 2014-08-14 14:28:11 --> Loader Class Initialized
DEBUG - 2014-08-14 14:28:11 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 14:28:11 --> Helper loaded: url_helper
DEBUG - 2014-08-14 14:28:11 --> Database Driver Class Initialized
ERROR - 2014-08-14 14:28:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 14:28:11 --> Session Class Initialized
DEBUG - 2014-08-14 14:28:11 --> Helper loaded: string_helper
DEBUG - 2014-08-14 14:28:11 --> Session routines successfully run
DEBUG - 2014-08-14 14:28:11 --> Controller Class Initialized
DEBUG - 2014-08-14 14:28:11 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 14:28:11 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 14:28:11 --> Model Class Initialized
DEBUG - 2014-08-14 14:28:11 --> Model Class Initialized
DEBUG - 2014-08-14 14:28:11 --> Model Class Initialized
DEBUG - 2014-08-14 14:28:11 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 14:28:11 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 14:28:11 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 14:28:11 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 14:28:11 --> Final output sent to browser
DEBUG - 2014-08-14 14:28:11 --> Total execution time: 0.1172
DEBUG - 2014-08-14 14:28:30 --> Config Class Initialized
DEBUG - 2014-08-14 14:28:30 --> Hooks Class Initialized
DEBUG - 2014-08-14 14:28:30 --> Utf8 Class Initialized
DEBUG - 2014-08-14 14:28:30 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 14:28:30 --> URI Class Initialized
DEBUG - 2014-08-14 14:28:30 --> Router Class Initialized
DEBUG - 2014-08-14 14:28:30 --> Output Class Initialized
DEBUG - 2014-08-14 14:28:30 --> Security Class Initialized
DEBUG - 2014-08-14 14:28:30 --> Input Class Initialized
DEBUG - 2014-08-14 14:28:30 --> XSS Filtering completed
DEBUG - 2014-08-14 14:28:30 --> XSS Filtering completed
DEBUG - 2014-08-14 14:28:30 --> XSS Filtering completed
DEBUG - 2014-08-14 14:28:30 --> XSS Filtering completed
DEBUG - 2014-08-14 14:28:30 --> XSS Filtering completed
DEBUG - 2014-08-14 14:28:30 --> CRSF cookie Set
DEBUG - 2014-08-14 14:28:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 14:28:30 --> Language Class Initialized
DEBUG - 2014-08-14 14:28:30 --> Loader Class Initialized
DEBUG - 2014-08-14 14:28:30 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 14:28:30 --> Helper loaded: url_helper
DEBUG - 2014-08-14 14:28:30 --> Database Driver Class Initialized
ERROR - 2014-08-14 14:28:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 14:28:30 --> Session Class Initialized
DEBUG - 2014-08-14 14:28:30 --> Helper loaded: string_helper
DEBUG - 2014-08-14 14:28:30 --> Session routines successfully run
DEBUG - 2014-08-14 14:28:30 --> Controller Class Initialized
DEBUG - 2014-08-14 14:28:30 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 14:28:30 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 14:28:30 --> Model Class Initialized
DEBUG - 2014-08-14 14:28:30 --> Model Class Initialized
DEBUG - 2014-08-14 14:28:30 --> Model Class Initialized
DEBUG - 2014-08-14 14:28:30 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 14:28:30 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 14:28:30 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 14:28:30 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 14:28:30 --> Final output sent to browser
DEBUG - 2014-08-14 14:28:30 --> Total execution time: 0.1569
DEBUG - 2014-08-14 14:29:19 --> Config Class Initialized
DEBUG - 2014-08-14 14:29:19 --> Hooks Class Initialized
DEBUG - 2014-08-14 14:29:19 --> Utf8 Class Initialized
DEBUG - 2014-08-14 14:29:19 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 14:29:19 --> URI Class Initialized
DEBUG - 2014-08-14 14:29:19 --> Router Class Initialized
DEBUG - 2014-08-14 14:29:19 --> Output Class Initialized
DEBUG - 2014-08-14 14:29:19 --> Security Class Initialized
DEBUG - 2014-08-14 14:29:19 --> Input Class Initialized
DEBUG - 2014-08-14 14:29:19 --> XSS Filtering completed
DEBUG - 2014-08-14 14:29:19 --> XSS Filtering completed
DEBUG - 2014-08-14 14:29:19 --> XSS Filtering completed
DEBUG - 2014-08-14 14:29:19 --> XSS Filtering completed
DEBUG - 2014-08-14 14:29:19 --> XSS Filtering completed
DEBUG - 2014-08-14 14:29:19 --> CRSF cookie Set
DEBUG - 2014-08-14 14:29:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 14:29:19 --> Language Class Initialized
DEBUG - 2014-08-14 14:29:19 --> Loader Class Initialized
DEBUG - 2014-08-14 14:29:19 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 14:29:19 --> Helper loaded: url_helper
DEBUG - 2014-08-14 14:29:19 --> Database Driver Class Initialized
ERROR - 2014-08-14 14:29:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 14:29:19 --> Session Class Initialized
DEBUG - 2014-08-14 14:29:19 --> Helper loaded: string_helper
DEBUG - 2014-08-14 14:29:19 --> Session routines successfully run
DEBUG - 2014-08-14 14:29:19 --> Controller Class Initialized
DEBUG - 2014-08-14 14:29:19 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 14:29:19 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 14:29:19 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-14 14:29:19 --> File loaded: application/views/placement_admin_history.php
DEBUG - 2014-08-14 14:29:19 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 14:29:19 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 14:29:19 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 14:29:19 --> Final output sent to browser
DEBUG - 2014-08-14 14:29:19 --> Total execution time: 0.0941
DEBUG - 2014-08-14 14:29:21 --> Config Class Initialized
DEBUG - 2014-08-14 14:29:21 --> Hooks Class Initialized
DEBUG - 2014-08-14 14:29:21 --> Utf8 Class Initialized
DEBUG - 2014-08-14 14:29:21 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 14:29:21 --> URI Class Initialized
DEBUG - 2014-08-14 14:29:21 --> Router Class Initialized
DEBUG - 2014-08-14 14:29:21 --> Output Class Initialized
DEBUG - 2014-08-14 14:29:21 --> Security Class Initialized
DEBUG - 2014-08-14 14:29:21 --> Input Class Initialized
DEBUG - 2014-08-14 14:29:21 --> XSS Filtering completed
DEBUG - 2014-08-14 14:29:21 --> XSS Filtering completed
DEBUG - 2014-08-14 14:29:21 --> XSS Filtering completed
DEBUG - 2014-08-14 14:29:21 --> XSS Filtering completed
DEBUG - 2014-08-14 14:29:21 --> XSS Filtering completed
DEBUG - 2014-08-14 14:29:21 --> CRSF cookie Set
DEBUG - 2014-08-14 14:29:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 14:29:21 --> Language Class Initialized
DEBUG - 2014-08-14 14:29:21 --> Loader Class Initialized
DEBUG - 2014-08-14 14:29:21 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 14:29:21 --> Helper loaded: url_helper
DEBUG - 2014-08-14 14:29:21 --> Database Driver Class Initialized
ERROR - 2014-08-14 14:29:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 14:29:21 --> Session Class Initialized
DEBUG - 2014-08-14 14:29:21 --> Helper loaded: string_helper
DEBUG - 2014-08-14 14:29:21 --> Session routines successfully run
DEBUG - 2014-08-14 14:29:21 --> Controller Class Initialized
DEBUG - 2014-08-14 14:29:21 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 14:29:21 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 14:29:21 --> Model Class Initialized
DEBUG - 2014-08-14 14:29:21 --> Model Class Initialized
DEBUG - 2014-08-14 14:29:21 --> Model Class Initialized
DEBUG - 2014-08-14 14:29:21 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 14:29:21 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 14:29:21 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 14:29:21 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 14:29:21 --> Final output sent to browser
DEBUG - 2014-08-14 14:29:21 --> Total execution time: 0.1104
DEBUG - 2014-08-14 14:29:58 --> Config Class Initialized
DEBUG - 2014-08-14 14:29:58 --> Hooks Class Initialized
DEBUG - 2014-08-14 14:29:58 --> Utf8 Class Initialized
DEBUG - 2014-08-14 14:29:58 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 14:29:58 --> URI Class Initialized
DEBUG - 2014-08-14 14:29:58 --> Router Class Initialized
DEBUG - 2014-08-14 14:29:58 --> Output Class Initialized
DEBUG - 2014-08-14 14:29:58 --> Security Class Initialized
DEBUG - 2014-08-14 14:29:58 --> Input Class Initialized
DEBUG - 2014-08-14 14:29:58 --> XSS Filtering completed
DEBUG - 2014-08-14 14:29:58 --> XSS Filtering completed
DEBUG - 2014-08-14 14:29:58 --> XSS Filtering completed
DEBUG - 2014-08-14 14:29:58 --> XSS Filtering completed
DEBUG - 2014-08-14 14:29:58 --> XSS Filtering completed
DEBUG - 2014-08-14 14:29:58 --> CRSF cookie Set
DEBUG - 2014-08-14 14:29:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 14:29:58 --> Language Class Initialized
DEBUG - 2014-08-14 14:29:58 --> Loader Class Initialized
DEBUG - 2014-08-14 14:29:58 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 14:29:58 --> Helper loaded: url_helper
DEBUG - 2014-08-14 14:29:58 --> Database Driver Class Initialized
ERROR - 2014-08-14 14:29:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 14:29:58 --> Session Class Initialized
DEBUG - 2014-08-14 14:29:58 --> Helper loaded: string_helper
DEBUG - 2014-08-14 14:29:58 --> Session routines successfully run
DEBUG - 2014-08-14 14:29:58 --> Controller Class Initialized
DEBUG - 2014-08-14 14:29:58 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 14:29:58 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 14:29:58 --> Model Class Initialized
DEBUG - 2014-08-14 14:29:58 --> Model Class Initialized
DEBUG - 2014-08-14 14:29:58 --> Model Class Initialized
DEBUG - 2014-08-14 14:29:58 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 14:29:58 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 14:29:58 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 14:29:58 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 14:29:58 --> Final output sent to browser
DEBUG - 2014-08-14 14:29:58 --> Total execution time: 0.1083
DEBUG - 2014-08-14 14:31:45 --> Config Class Initialized
DEBUG - 2014-08-14 14:31:45 --> Hooks Class Initialized
DEBUG - 2014-08-14 14:31:45 --> Utf8 Class Initialized
DEBUG - 2014-08-14 14:31:45 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 14:31:45 --> URI Class Initialized
DEBUG - 2014-08-14 14:31:45 --> Router Class Initialized
DEBUG - 2014-08-14 14:31:45 --> Output Class Initialized
DEBUG - 2014-08-14 14:31:45 --> Security Class Initialized
DEBUG - 2014-08-14 14:31:45 --> Input Class Initialized
DEBUG - 2014-08-14 14:31:45 --> XSS Filtering completed
DEBUG - 2014-08-14 14:31:45 --> XSS Filtering completed
DEBUG - 2014-08-14 14:31:45 --> XSS Filtering completed
DEBUG - 2014-08-14 14:31:45 --> XSS Filtering completed
DEBUG - 2014-08-14 14:31:45 --> XSS Filtering completed
DEBUG - 2014-08-14 14:31:45 --> CRSF cookie Set
DEBUG - 2014-08-14 14:31:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 14:31:45 --> Language Class Initialized
DEBUG - 2014-08-14 14:31:45 --> Loader Class Initialized
DEBUG - 2014-08-14 14:31:45 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 14:31:45 --> Helper loaded: url_helper
DEBUG - 2014-08-14 14:31:45 --> Database Driver Class Initialized
ERROR - 2014-08-14 14:31:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 14:31:45 --> Session Class Initialized
DEBUG - 2014-08-14 14:31:45 --> Helper loaded: string_helper
DEBUG - 2014-08-14 14:31:45 --> Session routines successfully run
DEBUG - 2014-08-14 14:31:45 --> Controller Class Initialized
DEBUG - 2014-08-14 14:31:45 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 14:31:45 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 14:31:45 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-14 14:31:45 --> File loaded: application/views/placement_admin_history.php
DEBUG - 2014-08-14 14:31:45 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 14:31:45 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 14:31:45 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 14:31:45 --> Final output sent to browser
DEBUG - 2014-08-14 14:31:45 --> Total execution time: 0.0908
DEBUG - 2014-08-14 14:31:47 --> Config Class Initialized
DEBUG - 2014-08-14 14:31:47 --> Hooks Class Initialized
DEBUG - 2014-08-14 14:31:47 --> Utf8 Class Initialized
DEBUG - 2014-08-14 14:31:47 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 14:31:47 --> URI Class Initialized
DEBUG - 2014-08-14 14:31:47 --> Router Class Initialized
DEBUG - 2014-08-14 14:31:47 --> Output Class Initialized
DEBUG - 2014-08-14 14:31:47 --> Security Class Initialized
DEBUG - 2014-08-14 14:31:47 --> Input Class Initialized
DEBUG - 2014-08-14 14:31:47 --> XSS Filtering completed
DEBUG - 2014-08-14 14:31:47 --> XSS Filtering completed
DEBUG - 2014-08-14 14:31:47 --> XSS Filtering completed
DEBUG - 2014-08-14 14:31:47 --> XSS Filtering completed
DEBUG - 2014-08-14 14:31:47 --> XSS Filtering completed
DEBUG - 2014-08-14 14:31:47 --> CRSF cookie Set
DEBUG - 2014-08-14 14:31:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 14:31:47 --> Language Class Initialized
DEBUG - 2014-08-14 14:31:47 --> Loader Class Initialized
DEBUG - 2014-08-14 14:31:47 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 14:31:47 --> Helper loaded: url_helper
DEBUG - 2014-08-14 14:31:47 --> Database Driver Class Initialized
ERROR - 2014-08-14 14:31:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 14:31:47 --> Session Class Initialized
DEBUG - 2014-08-14 14:31:47 --> Helper loaded: string_helper
DEBUG - 2014-08-14 14:31:47 --> Session routines successfully run
DEBUG - 2014-08-14 14:31:47 --> Controller Class Initialized
DEBUG - 2014-08-14 14:31:47 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 14:31:47 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 14:31:47 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-14 14:31:47 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-14 14:31:47 --> File loaded: application/views/placement_admin_home.php
DEBUG - 2014-08-14 14:31:47 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 14:31:47 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 14:31:47 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 14:31:47 --> Final output sent to browser
DEBUG - 2014-08-14 14:31:47 --> Total execution time: 0.0925
DEBUG - 2014-08-14 14:31:48 --> Config Class Initialized
DEBUG - 2014-08-14 14:31:48 --> Hooks Class Initialized
DEBUG - 2014-08-14 14:31:48 --> Utf8 Class Initialized
DEBUG - 2014-08-14 14:31:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 14:31:48 --> URI Class Initialized
DEBUG - 2014-08-14 14:31:48 --> Router Class Initialized
DEBUG - 2014-08-14 14:31:48 --> Output Class Initialized
DEBUG - 2014-08-14 14:31:48 --> Security Class Initialized
DEBUG - 2014-08-14 14:31:48 --> Input Class Initialized
DEBUG - 2014-08-14 14:31:48 --> XSS Filtering completed
DEBUG - 2014-08-14 14:31:48 --> XSS Filtering completed
DEBUG - 2014-08-14 14:31:48 --> XSS Filtering completed
DEBUG - 2014-08-14 14:31:48 --> XSS Filtering completed
DEBUG - 2014-08-14 14:31:48 --> XSS Filtering completed
DEBUG - 2014-08-14 14:31:48 --> CRSF cookie Set
DEBUG - 2014-08-14 14:31:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 14:31:48 --> Language Class Initialized
DEBUG - 2014-08-14 14:31:48 --> Loader Class Initialized
DEBUG - 2014-08-14 14:31:48 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 14:31:48 --> Helper loaded: url_helper
DEBUG - 2014-08-14 14:31:48 --> Database Driver Class Initialized
ERROR - 2014-08-14 14:31:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 14:31:48 --> Session Class Initialized
DEBUG - 2014-08-14 14:31:48 --> Helper loaded: string_helper
DEBUG - 2014-08-14 14:31:48 --> Session routines successfully run
DEBUG - 2014-08-14 14:31:48 --> Controller Class Initialized
DEBUG - 2014-08-14 14:31:48 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 14:31:48 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 14:31:48 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-14 14:31:48 --> File loaded: application/views/placement_admin_history.php
DEBUG - 2014-08-14 14:31:48 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 14:31:48 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 14:31:49 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 14:31:49 --> Final output sent to browser
DEBUG - 2014-08-14 14:31:49 --> Total execution time: 0.0915
DEBUG - 2014-08-14 14:37:50 --> Config Class Initialized
DEBUG - 2014-08-14 14:37:50 --> Hooks Class Initialized
DEBUG - 2014-08-14 14:37:50 --> Utf8 Class Initialized
DEBUG - 2014-08-14 14:37:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 14:37:50 --> URI Class Initialized
DEBUG - 2014-08-14 14:37:50 --> Router Class Initialized
DEBUG - 2014-08-14 14:37:50 --> Output Class Initialized
DEBUG - 2014-08-14 14:37:50 --> Security Class Initialized
DEBUG - 2014-08-14 14:37:50 --> Input Class Initialized
DEBUG - 2014-08-14 14:37:50 --> XSS Filtering completed
DEBUG - 2014-08-14 14:37:50 --> XSS Filtering completed
DEBUG - 2014-08-14 14:37:50 --> XSS Filtering completed
DEBUG - 2014-08-14 14:37:50 --> XSS Filtering completed
DEBUG - 2014-08-14 14:37:50 --> XSS Filtering completed
DEBUG - 2014-08-14 14:37:50 --> CRSF cookie Set
DEBUG - 2014-08-14 14:37:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 14:37:50 --> Language Class Initialized
DEBUG - 2014-08-14 14:37:50 --> Loader Class Initialized
DEBUG - 2014-08-14 14:37:50 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 14:37:50 --> Helper loaded: url_helper
DEBUG - 2014-08-14 14:37:50 --> Database Driver Class Initialized
ERROR - 2014-08-14 14:37:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 14:37:50 --> Session Class Initialized
DEBUG - 2014-08-14 14:37:50 --> Helper loaded: string_helper
DEBUG - 2014-08-14 14:37:50 --> Session routines successfully run
DEBUG - 2014-08-14 14:37:50 --> Controller Class Initialized
DEBUG - 2014-08-14 14:37:50 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 14:37:50 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 14:37:50 --> Model Class Initialized
DEBUG - 2014-08-14 14:37:50 --> Model Class Initialized
DEBUG - 2014-08-14 14:37:50 --> Model Class Initialized
DEBUG - 2014-08-14 14:37:50 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 14:37:50 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 14:37:50 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 14:37:50 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 14:37:50 --> Final output sent to browser
DEBUG - 2014-08-14 14:37:50 --> Total execution time: 1.5722
DEBUG - 2014-08-14 14:39:50 --> Config Class Initialized
DEBUG - 2014-08-14 14:39:50 --> Hooks Class Initialized
DEBUG - 2014-08-14 14:39:50 --> Utf8 Class Initialized
DEBUG - 2014-08-14 14:39:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 14:39:50 --> URI Class Initialized
DEBUG - 2014-08-14 14:39:50 --> Router Class Initialized
DEBUG - 2014-08-14 14:39:50 --> Output Class Initialized
DEBUG - 2014-08-14 14:39:50 --> Security Class Initialized
DEBUG - 2014-08-14 14:39:50 --> Input Class Initialized
DEBUG - 2014-08-14 14:39:50 --> XSS Filtering completed
DEBUG - 2014-08-14 14:39:50 --> XSS Filtering completed
DEBUG - 2014-08-14 14:39:50 --> XSS Filtering completed
DEBUG - 2014-08-14 14:39:50 --> XSS Filtering completed
DEBUG - 2014-08-14 14:39:50 --> XSS Filtering completed
DEBUG - 2014-08-14 14:39:50 --> CRSF cookie Set
DEBUG - 2014-08-14 14:39:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 14:39:50 --> Language Class Initialized
DEBUG - 2014-08-14 14:39:50 --> Loader Class Initialized
DEBUG - 2014-08-14 14:39:50 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 14:39:50 --> Helper loaded: url_helper
DEBUG - 2014-08-14 14:39:50 --> Database Driver Class Initialized
ERROR - 2014-08-14 14:39:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 14:39:50 --> Session Class Initialized
DEBUG - 2014-08-14 14:39:50 --> Helper loaded: string_helper
DEBUG - 2014-08-14 14:39:50 --> Session routines successfully run
DEBUG - 2014-08-14 14:39:50 --> Controller Class Initialized
DEBUG - 2014-08-14 14:39:50 --> File loaded: application/views/logout.php
DEBUG - 2014-08-14 14:39:50 --> Final output sent to browser
DEBUG - 2014-08-14 14:39:50 --> Total execution time: 0.0355
DEBUG - 2014-08-14 14:39:50 --> Config Class Initialized
DEBUG - 2014-08-14 14:39:50 --> Hooks Class Initialized
DEBUG - 2014-08-14 14:39:50 --> Utf8 Class Initialized
DEBUG - 2014-08-14 14:39:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 14:39:50 --> URI Class Initialized
DEBUG - 2014-08-14 14:39:50 --> Router Class Initialized
DEBUG - 2014-08-14 14:39:50 --> No URI present. Default controller set.
DEBUG - 2014-08-14 14:39:50 --> Output Class Initialized
DEBUG - 2014-08-14 14:39:50 --> Security Class Initialized
DEBUG - 2014-08-14 14:39:50 --> Input Class Initialized
DEBUG - 2014-08-14 14:39:50 --> XSS Filtering completed
DEBUG - 2014-08-14 14:39:50 --> XSS Filtering completed
DEBUG - 2014-08-14 14:39:50 --> XSS Filtering completed
DEBUG - 2014-08-14 14:39:50 --> XSS Filtering completed
DEBUG - 2014-08-14 14:39:50 --> CRSF cookie Set
DEBUG - 2014-08-14 14:39:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 14:39:50 --> Language Class Initialized
DEBUG - 2014-08-14 14:39:50 --> Loader Class Initialized
DEBUG - 2014-08-14 14:39:50 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 14:39:50 --> Helper loaded: url_helper
DEBUG - 2014-08-14 14:39:50 --> Database Driver Class Initialized
ERROR - 2014-08-14 14:39:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 14:39:50 --> Session Class Initialized
DEBUG - 2014-08-14 14:39:50 --> Helper loaded: string_helper
DEBUG - 2014-08-14 14:39:50 --> A session cookie was not found.
DEBUG - 2014-08-14 14:39:50 --> Session routines successfully run
DEBUG - 2014-08-14 14:39:50 --> Controller Class Initialized
DEBUG - 2014-08-14 14:39:50 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 14:39:50 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-14 14:39:50 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-14 14:39:50 --> Helper loaded: form_helper
DEBUG - 2014-08-14 14:39:50 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-14 14:39:50 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-14 14:39:50 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 14:39:50 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 14:39:50 --> Final output sent to browser
DEBUG - 2014-08-14 14:39:50 --> Total execution time: 0.0526
DEBUG - 2014-08-14 14:39:57 --> Config Class Initialized
DEBUG - 2014-08-14 14:39:57 --> Hooks Class Initialized
DEBUG - 2014-08-14 14:39:57 --> Utf8 Class Initialized
DEBUG - 2014-08-14 14:39:57 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 14:39:57 --> URI Class Initialized
DEBUG - 2014-08-14 14:39:57 --> Router Class Initialized
DEBUG - 2014-08-14 14:39:57 --> Output Class Initialized
DEBUG - 2014-08-14 14:39:57 --> Security Class Initialized
DEBUG - 2014-08-14 14:39:57 --> Input Class Initialized
DEBUG - 2014-08-14 14:39:57 --> XSS Filtering completed
DEBUG - 2014-08-14 14:39:57 --> XSS Filtering completed
DEBUG - 2014-08-14 14:39:57 --> XSS Filtering completed
DEBUG - 2014-08-14 14:39:57 --> XSS Filtering completed
DEBUG - 2014-08-14 14:39:57 --> XSS Filtering completed
DEBUG - 2014-08-14 14:39:57 --> XSS Filtering completed
DEBUG - 2014-08-14 14:39:57 --> XSS Filtering completed
DEBUG - 2014-08-14 14:39:57 --> XSS Filtering completed
DEBUG - 2014-08-14 14:39:57 --> CRSF cookie Set
DEBUG - 2014-08-14 14:39:57 --> CSRF token verified
DEBUG - 2014-08-14 14:39:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 14:39:57 --> Language Class Initialized
DEBUG - 2014-08-14 14:39:57 --> Loader Class Initialized
DEBUG - 2014-08-14 14:39:57 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 14:39:57 --> Helper loaded: url_helper
DEBUG - 2014-08-14 14:39:57 --> Database Driver Class Initialized
ERROR - 2014-08-14 14:39:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 14:39:57 --> Session Class Initialized
DEBUG - 2014-08-14 14:39:57 --> Helper loaded: string_helper
DEBUG - 2014-08-14 14:39:57 --> Session routines successfully run
DEBUG - 2014-08-14 14:39:57 --> Controller Class Initialized
DEBUG - 2014-08-14 14:39:57 --> Helper loaded: form_helper
DEBUG - 2014-08-14 14:39:57 --> Form Validation Class Initialized
DEBUG - 2014-08-14 14:39:57 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-14 14:39:57 --> XSS Filtering completed
DEBUG - 2014-08-14 14:39:57 --> XSS Filtering completed
DEBUG - 2014-08-14 14:39:57 --> Model Class Initialized
DEBUG - 2014-08-14 14:39:57 --> Model Class Initialized
DEBUG - 2014-08-14 14:39:57 --> Model Class Initialized
DEBUG - 2014-08-14 14:39:57 --> Model Class Initialized
DEBUG - 2014-08-14 14:39:57 --> Encrypt Class Initialized
DEBUG - 2014-08-14 14:39:57 --> XSS Filtering completed
DEBUG - 2014-08-14 14:39:57 --> XSS Filtering completed
DEBUG - 2014-08-14 14:39:57 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-14 14:39:57 --> XSS Filtering completed
DEBUG - 2014-08-14 14:39:57 --> XSS Filtering completed
DEBUG - 2014-08-14 14:39:57 --> Config Class Initialized
DEBUG - 2014-08-14 14:39:57 --> Hooks Class Initialized
DEBUG - 2014-08-14 14:39:57 --> Utf8 Class Initialized
DEBUG - 2014-08-14 14:39:57 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 14:39:57 --> URI Class Initialized
DEBUG - 2014-08-14 14:39:57 --> Router Class Initialized
DEBUG - 2014-08-14 14:39:57 --> Output Class Initialized
DEBUG - 2014-08-14 14:39:57 --> Security Class Initialized
DEBUG - 2014-08-14 14:39:57 --> Input Class Initialized
DEBUG - 2014-08-14 14:39:57 --> XSS Filtering completed
DEBUG - 2014-08-14 14:39:57 --> XSS Filtering completed
DEBUG - 2014-08-14 14:39:57 --> XSS Filtering completed
DEBUG - 2014-08-14 14:39:57 --> XSS Filtering completed
DEBUG - 2014-08-14 14:39:57 --> XSS Filtering completed
DEBUG - 2014-08-14 14:39:57 --> CRSF cookie Set
DEBUG - 2014-08-14 14:39:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 14:39:57 --> Language Class Initialized
DEBUG - 2014-08-14 14:39:57 --> Loader Class Initialized
DEBUG - 2014-08-14 14:39:57 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 14:39:57 --> Helper loaded: url_helper
DEBUG - 2014-08-14 14:39:57 --> Database Driver Class Initialized
ERROR - 2014-08-14 14:39:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 14:39:57 --> Session Class Initialized
DEBUG - 2014-08-14 14:39:57 --> Helper loaded: string_helper
DEBUG - 2014-08-14 14:39:57 --> Session routines successfully run
DEBUG - 2014-08-14 14:39:57 --> Controller Class Initialized
DEBUG - 2014-08-14 14:39:57 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 14:39:57 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-14 14:39:57 --> Model Class Initialized
DEBUG - 2014-08-14 14:39:57 --> Model Class Initialized
DEBUG - 2014-08-14 14:39:57 --> Model Class Initialized
DEBUG - 2014-08-14 14:39:57 --> Model Class Initialized
DEBUG - 2014-08-14 14:39:57 --> Helper loaded: array_helper
DEBUG - 2014-08-14 14:39:57 --> Helper loaded: form_helper
DEBUG - 2014-08-14 14:39:57 --> File loaded: application/views/placement_students_home.php
DEBUG - 2014-08-14 14:39:57 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 14:39:57 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 14:39:57 --> Final output sent to browser
DEBUG - 2014-08-14 14:39:57 --> Total execution time: 0.0614
DEBUG - 2014-08-14 14:44:50 --> Config Class Initialized
DEBUG - 2014-08-14 14:44:50 --> Hooks Class Initialized
DEBUG - 2014-08-14 14:44:50 --> Utf8 Class Initialized
DEBUG - 2014-08-14 14:44:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 14:44:50 --> URI Class Initialized
DEBUG - 2014-08-14 14:44:50 --> Router Class Initialized
DEBUG - 2014-08-14 14:44:50 --> Output Class Initialized
DEBUG - 2014-08-14 14:44:50 --> Security Class Initialized
DEBUG - 2014-08-14 14:44:50 --> Input Class Initialized
DEBUG - 2014-08-14 14:44:50 --> XSS Filtering completed
DEBUG - 2014-08-14 14:44:50 --> XSS Filtering completed
DEBUG - 2014-08-14 14:44:50 --> XSS Filtering completed
DEBUG - 2014-08-14 14:44:50 --> XSS Filtering completed
DEBUG - 2014-08-14 14:44:50 --> XSS Filtering completed
DEBUG - 2014-08-14 14:44:50 --> CRSF cookie Set
DEBUG - 2014-08-14 14:44:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 14:44:50 --> Language Class Initialized
DEBUG - 2014-08-14 14:44:50 --> Loader Class Initialized
DEBUG - 2014-08-14 14:44:50 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 14:44:50 --> Helper loaded: url_helper
DEBUG - 2014-08-14 14:44:50 --> Database Driver Class Initialized
ERROR - 2014-08-14 14:44:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 14:44:50 --> Session Class Initialized
DEBUG - 2014-08-14 14:44:50 --> Helper loaded: string_helper
DEBUG - 2014-08-14 14:44:50 --> Session routines successfully run
DEBUG - 2014-08-14 14:44:50 --> Controller Class Initialized
DEBUG - 2014-08-14 14:44:50 --> File loaded: application/views/logout.php
DEBUG - 2014-08-14 14:44:50 --> Final output sent to browser
DEBUG - 2014-08-14 14:44:50 --> Total execution time: 0.0402
DEBUG - 2014-08-14 14:44:50 --> Config Class Initialized
DEBUG - 2014-08-14 14:44:50 --> Hooks Class Initialized
DEBUG - 2014-08-14 14:44:50 --> Utf8 Class Initialized
DEBUG - 2014-08-14 14:44:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 14:44:50 --> URI Class Initialized
DEBUG - 2014-08-14 14:44:50 --> Router Class Initialized
DEBUG - 2014-08-14 14:44:50 --> No URI present. Default controller set.
DEBUG - 2014-08-14 14:44:50 --> Output Class Initialized
DEBUG - 2014-08-14 14:44:50 --> Security Class Initialized
DEBUG - 2014-08-14 14:44:50 --> Input Class Initialized
DEBUG - 2014-08-14 14:44:50 --> XSS Filtering completed
DEBUG - 2014-08-14 14:44:50 --> XSS Filtering completed
DEBUG - 2014-08-14 14:44:50 --> XSS Filtering completed
DEBUG - 2014-08-14 14:44:50 --> XSS Filtering completed
DEBUG - 2014-08-14 14:44:50 --> CRSF cookie Set
DEBUG - 2014-08-14 14:44:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 14:44:50 --> Language Class Initialized
DEBUG - 2014-08-14 14:44:50 --> Loader Class Initialized
DEBUG - 2014-08-14 14:44:50 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 14:44:50 --> Helper loaded: url_helper
DEBUG - 2014-08-14 14:44:50 --> Database Driver Class Initialized
ERROR - 2014-08-14 14:44:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 14:44:50 --> Session Class Initialized
DEBUG - 2014-08-14 14:44:50 --> Helper loaded: string_helper
DEBUG - 2014-08-14 14:44:50 --> A session cookie was not found.
DEBUG - 2014-08-14 14:44:50 --> Session routines successfully run
DEBUG - 2014-08-14 14:44:50 --> Controller Class Initialized
DEBUG - 2014-08-14 14:44:50 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 14:44:50 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-14 14:44:50 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-14 14:44:50 --> Helper loaded: form_helper
DEBUG - 2014-08-14 14:44:50 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-14 14:44:50 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-14 14:44:50 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 14:44:50 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 14:44:50 --> Final output sent to browser
DEBUG - 2014-08-14 14:44:50 --> Total execution time: 0.0551
DEBUG - 2014-08-14 14:44:56 --> Config Class Initialized
DEBUG - 2014-08-14 14:44:56 --> Hooks Class Initialized
DEBUG - 2014-08-14 14:44:56 --> Utf8 Class Initialized
DEBUG - 2014-08-14 14:44:56 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 14:44:56 --> URI Class Initialized
DEBUG - 2014-08-14 14:44:56 --> Router Class Initialized
DEBUG - 2014-08-14 14:44:56 --> Output Class Initialized
DEBUG - 2014-08-14 14:44:56 --> Security Class Initialized
DEBUG - 2014-08-14 14:44:56 --> Input Class Initialized
DEBUG - 2014-08-14 14:44:56 --> XSS Filtering completed
DEBUG - 2014-08-14 14:44:56 --> XSS Filtering completed
DEBUG - 2014-08-14 14:44:56 --> XSS Filtering completed
DEBUG - 2014-08-14 14:44:56 --> XSS Filtering completed
DEBUG - 2014-08-14 14:44:56 --> XSS Filtering completed
DEBUG - 2014-08-14 14:44:56 --> XSS Filtering completed
DEBUG - 2014-08-14 14:44:56 --> XSS Filtering completed
DEBUG - 2014-08-14 14:44:56 --> XSS Filtering completed
DEBUG - 2014-08-14 14:44:56 --> CRSF cookie Set
DEBUG - 2014-08-14 14:44:56 --> CSRF token verified
DEBUG - 2014-08-14 14:44:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 14:44:56 --> Language Class Initialized
DEBUG - 2014-08-14 14:44:56 --> Loader Class Initialized
DEBUG - 2014-08-14 14:44:56 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 14:44:56 --> Helper loaded: url_helper
DEBUG - 2014-08-14 14:44:56 --> Database Driver Class Initialized
ERROR - 2014-08-14 14:44:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 14:44:56 --> Session Class Initialized
DEBUG - 2014-08-14 14:44:56 --> Helper loaded: string_helper
DEBUG - 2014-08-14 14:44:56 --> Session routines successfully run
DEBUG - 2014-08-14 14:44:56 --> Controller Class Initialized
DEBUG - 2014-08-14 14:44:56 --> Helper loaded: form_helper
DEBUG - 2014-08-14 14:44:56 --> Form Validation Class Initialized
DEBUG - 2014-08-14 14:44:56 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-14 14:44:56 --> XSS Filtering completed
DEBUG - 2014-08-14 14:44:56 --> XSS Filtering completed
DEBUG - 2014-08-14 14:44:56 --> Model Class Initialized
DEBUG - 2014-08-14 14:44:56 --> Model Class Initialized
DEBUG - 2014-08-14 14:44:56 --> Model Class Initialized
DEBUG - 2014-08-14 14:44:56 --> Model Class Initialized
DEBUG - 2014-08-14 14:44:56 --> Encrypt Class Initialized
DEBUG - 2014-08-14 14:44:56 --> XSS Filtering completed
DEBUG - 2014-08-14 14:44:56 --> XSS Filtering completed
DEBUG - 2014-08-14 14:44:56 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-14 14:44:56 --> XSS Filtering completed
DEBUG - 2014-08-14 14:44:56 --> XSS Filtering completed
DEBUG - 2014-08-14 14:44:56 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 14:44:56 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-14 14:44:56 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-14 14:44:56 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-14 14:44:56 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-14 14:44:56 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 14:44:56 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 14:44:56 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 14:44:56 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-14 14:44:56 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-14 14:44:56 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-14 14:44:56 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-14 14:44:56 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 14:44:56 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 14:44:56 --> Final output sent to browser
DEBUG - 2014-08-14 14:44:56 --> Total execution time: 0.0718
DEBUG - 2014-08-14 15:27:54 --> Config Class Initialized
DEBUG - 2014-08-14 15:27:54 --> Hooks Class Initialized
DEBUG - 2014-08-14 15:27:54 --> Utf8 Class Initialized
DEBUG - 2014-08-14 15:27:54 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 15:27:54 --> URI Class Initialized
DEBUG - 2014-08-14 15:27:54 --> Router Class Initialized
DEBUG - 2014-08-14 15:27:54 --> Output Class Initialized
DEBUG - 2014-08-14 15:27:54 --> Security Class Initialized
DEBUG - 2014-08-14 15:27:54 --> Input Class Initialized
DEBUG - 2014-08-14 15:27:54 --> XSS Filtering completed
DEBUG - 2014-08-14 15:27:54 --> XSS Filtering completed
DEBUG - 2014-08-14 15:27:54 --> XSS Filtering completed
DEBUG - 2014-08-14 15:27:54 --> XSS Filtering completed
DEBUG - 2014-08-14 15:27:54 --> XSS Filtering completed
DEBUG - 2014-08-14 15:27:54 --> XSS Filtering completed
DEBUG - 2014-08-14 15:27:54 --> XSS Filtering completed
DEBUG - 2014-08-14 15:27:54 --> XSS Filtering completed
DEBUG - 2014-08-14 15:27:54 --> CRSF cookie Set
DEBUG - 2014-08-14 15:27:54 --> CSRF token verified
DEBUG - 2014-08-14 15:27:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 15:27:54 --> Language Class Initialized
DEBUG - 2014-08-14 15:27:54 --> Loader Class Initialized
DEBUG - 2014-08-14 15:27:54 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 15:27:54 --> Helper loaded: url_helper
DEBUG - 2014-08-14 15:27:54 --> Database Driver Class Initialized
ERROR - 2014-08-14 15:27:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 15:27:54 --> Session Class Initialized
DEBUG - 2014-08-14 15:27:54 --> Helper loaded: string_helper
DEBUG - 2014-08-14 15:27:54 --> Session routines successfully run
DEBUG - 2014-08-14 15:27:54 --> Controller Class Initialized
DEBUG - 2014-08-14 15:27:54 --> Helper loaded: form_helper
DEBUG - 2014-08-14 15:27:54 --> Form Validation Class Initialized
DEBUG - 2014-08-14 15:27:54 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-14 15:27:54 --> XSS Filtering completed
DEBUG - 2014-08-14 15:27:54 --> XSS Filtering completed
DEBUG - 2014-08-14 15:27:54 --> Model Class Initialized
DEBUG - 2014-08-14 15:27:54 --> Model Class Initialized
DEBUG - 2014-08-14 15:27:54 --> Model Class Initialized
DEBUG - 2014-08-14 15:27:54 --> Model Class Initialized
DEBUG - 2014-08-14 15:27:54 --> Encrypt Class Initialized
DEBUG - 2014-08-14 15:27:54 --> XSS Filtering completed
DEBUG - 2014-08-14 15:27:54 --> XSS Filtering completed
DEBUG - 2014-08-14 15:27:54 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-14 15:27:54 --> XSS Filtering completed
DEBUG - 2014-08-14 15:27:54 --> XSS Filtering completed
DEBUG - 2014-08-14 15:27:54 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 15:27:54 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-14 15:27:54 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-14 15:27:54 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-14 15:27:54 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-14 15:27:54 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 15:27:54 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 15:27:54 --> Final output sent to browser
DEBUG - 2014-08-14 15:27:54 --> Total execution time: 0.0768
DEBUG - 2014-08-14 15:28:00 --> Config Class Initialized
DEBUG - 2014-08-14 15:28:00 --> Hooks Class Initialized
DEBUG - 2014-08-14 15:28:00 --> Utf8 Class Initialized
DEBUG - 2014-08-14 15:28:00 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 15:28:00 --> URI Class Initialized
DEBUG - 2014-08-14 15:28:00 --> Router Class Initialized
DEBUG - 2014-08-14 15:28:00 --> Output Class Initialized
DEBUG - 2014-08-14 15:28:00 --> Security Class Initialized
DEBUG - 2014-08-14 15:28:00 --> Input Class Initialized
DEBUG - 2014-08-14 15:28:00 --> XSS Filtering completed
DEBUG - 2014-08-14 15:28:00 --> XSS Filtering completed
DEBUG - 2014-08-14 15:28:00 --> XSS Filtering completed
DEBUG - 2014-08-14 15:28:00 --> XSS Filtering completed
DEBUG - 2014-08-14 15:28:00 --> XSS Filtering completed
DEBUG - 2014-08-14 15:28:00 --> CRSF cookie Set
DEBUG - 2014-08-14 15:28:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 15:28:00 --> Language Class Initialized
DEBUG - 2014-08-14 15:28:00 --> Loader Class Initialized
DEBUG - 2014-08-14 15:28:00 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 15:28:00 --> Helper loaded: url_helper
DEBUG - 2014-08-14 15:28:00 --> Database Driver Class Initialized
ERROR - 2014-08-14 15:28:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 15:28:00 --> Session Class Initialized
DEBUG - 2014-08-14 15:28:00 --> Helper loaded: string_helper
DEBUG - 2014-08-14 15:28:00 --> Session routines successfully run
DEBUG - 2014-08-14 15:28:00 --> Controller Class Initialized
DEBUG - 2014-08-14 15:28:00 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 15:28:00 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-14 15:28:00 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-14 15:28:00 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-14 15:28:00 --> Helper loaded: form_helper
DEBUG - 2014-08-14 15:28:00 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-14 15:28:00 --> File loaded: application/views/placement_history.php
DEBUG - 2014-08-14 15:28:00 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 15:28:00 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 15:28:00 --> Final output sent to browser
DEBUG - 2014-08-14 15:28:00 --> Total execution time: 0.0497
DEBUG - 2014-08-14 15:28:02 --> Config Class Initialized
DEBUG - 2014-08-14 15:28:02 --> Hooks Class Initialized
DEBUG - 2014-08-14 15:28:02 --> Utf8 Class Initialized
DEBUG - 2014-08-14 15:28:02 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 15:28:02 --> URI Class Initialized
DEBUG - 2014-08-14 15:28:02 --> Router Class Initialized
DEBUG - 2014-08-14 15:28:02 --> Output Class Initialized
DEBUG - 2014-08-14 15:28:02 --> Security Class Initialized
DEBUG - 2014-08-14 15:28:02 --> Input Class Initialized
DEBUG - 2014-08-14 15:28:02 --> XSS Filtering completed
DEBUG - 2014-08-14 15:28:02 --> XSS Filtering completed
DEBUG - 2014-08-14 15:28:02 --> XSS Filtering completed
DEBUG - 2014-08-14 15:28:02 --> XSS Filtering completed
DEBUG - 2014-08-14 15:28:02 --> XSS Filtering completed
DEBUG - 2014-08-14 15:28:02 --> CRSF cookie Set
DEBUG - 2014-08-14 15:28:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 15:28:02 --> Language Class Initialized
DEBUG - 2014-08-14 15:28:02 --> Loader Class Initialized
DEBUG - 2014-08-14 15:28:02 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 15:28:02 --> Helper loaded: url_helper
DEBUG - 2014-08-14 15:28:02 --> Database Driver Class Initialized
ERROR - 2014-08-14 15:28:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 15:28:02 --> Session Class Initialized
DEBUG - 2014-08-14 15:28:02 --> Helper loaded: string_helper
DEBUG - 2014-08-14 15:28:02 --> Session routines successfully run
DEBUG - 2014-08-14 15:28:02 --> Controller Class Initialized
DEBUG - 2014-08-14 15:28:02 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 15:28:02 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-14 15:28:02 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-14 15:28:02 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-14 15:28:02 --> Helper loaded: form_helper
DEBUG - 2014-08-14 15:28:02 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-14 15:28:02 --> File loaded: application/views/placement_contact.php
DEBUG - 2014-08-14 15:28:02 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 15:28:02 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 15:28:02 --> Final output sent to browser
DEBUG - 2014-08-14 15:28:02 --> Total execution time: 0.0514
DEBUG - 2014-08-14 15:28:08 --> Config Class Initialized
DEBUG - 2014-08-14 15:28:08 --> Hooks Class Initialized
DEBUG - 2014-08-14 15:28:08 --> Utf8 Class Initialized
DEBUG - 2014-08-14 15:28:08 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 15:28:08 --> URI Class Initialized
DEBUG - 2014-08-14 15:28:08 --> Router Class Initialized
DEBUG - 2014-08-14 15:28:08 --> Output Class Initialized
DEBUG - 2014-08-14 15:28:08 --> Security Class Initialized
DEBUG - 2014-08-14 15:28:08 --> Input Class Initialized
DEBUG - 2014-08-14 15:28:08 --> XSS Filtering completed
DEBUG - 2014-08-14 15:28:08 --> XSS Filtering completed
DEBUG - 2014-08-14 15:28:08 --> XSS Filtering completed
DEBUG - 2014-08-14 15:28:08 --> XSS Filtering completed
DEBUG - 2014-08-14 15:28:08 --> XSS Filtering completed
DEBUG - 2014-08-14 15:28:08 --> CRSF cookie Set
DEBUG - 2014-08-14 15:28:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 15:28:08 --> Language Class Initialized
DEBUG - 2014-08-14 15:28:08 --> Loader Class Initialized
DEBUG - 2014-08-14 15:28:08 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 15:28:08 --> Helper loaded: url_helper
DEBUG - 2014-08-14 15:28:08 --> Database Driver Class Initialized
ERROR - 2014-08-14 15:28:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 15:28:08 --> Session Class Initialized
DEBUG - 2014-08-14 15:28:08 --> Helper loaded: string_helper
DEBUG - 2014-08-14 15:28:08 --> Session routines successfully run
DEBUG - 2014-08-14 15:28:08 --> Controller Class Initialized
DEBUG - 2014-08-14 15:28:08 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 15:28:08 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-14 15:28:08 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-14 15:28:08 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-14 15:28:08 --> Helper loaded: form_helper
DEBUG - 2014-08-14 15:28:08 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-14 15:28:08 --> File loaded: application/views/placement_history.php
DEBUG - 2014-08-14 15:28:08 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 15:28:08 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 15:28:08 --> Final output sent to browser
DEBUG - 2014-08-14 15:28:08 --> Total execution time: 0.0492
DEBUG - 2014-08-14 15:28:11 --> Config Class Initialized
DEBUG - 2014-08-14 15:28:11 --> Hooks Class Initialized
DEBUG - 2014-08-14 15:28:11 --> Utf8 Class Initialized
DEBUG - 2014-08-14 15:28:11 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 15:28:11 --> URI Class Initialized
DEBUG - 2014-08-14 15:28:11 --> Router Class Initialized
DEBUG - 2014-08-14 15:28:11 --> Output Class Initialized
DEBUG - 2014-08-14 15:28:11 --> Security Class Initialized
DEBUG - 2014-08-14 15:28:11 --> Input Class Initialized
DEBUG - 2014-08-14 15:28:11 --> XSS Filtering completed
DEBUG - 2014-08-14 15:28:11 --> XSS Filtering completed
DEBUG - 2014-08-14 15:28:11 --> XSS Filtering completed
DEBUG - 2014-08-14 15:28:11 --> XSS Filtering completed
DEBUG - 2014-08-14 15:28:11 --> XSS Filtering completed
DEBUG - 2014-08-14 15:28:11 --> CRSF cookie Set
DEBUG - 2014-08-14 15:28:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 15:28:11 --> Language Class Initialized
DEBUG - 2014-08-14 15:28:11 --> Loader Class Initialized
DEBUG - 2014-08-14 15:28:11 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 15:28:11 --> Helper loaded: url_helper
DEBUG - 2014-08-14 15:28:11 --> Database Driver Class Initialized
ERROR - 2014-08-14 15:28:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 15:28:11 --> Session Class Initialized
DEBUG - 2014-08-14 15:28:11 --> Helper loaded: string_helper
DEBUG - 2014-08-14 15:28:11 --> Session routines successfully run
DEBUG - 2014-08-14 15:28:11 --> Controller Class Initialized
DEBUG - 2014-08-14 15:28:11 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 15:28:11 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-14 15:28:11 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-14 15:28:11 --> Helper loaded: form_helper
DEBUG - 2014-08-14 15:28:11 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-14 15:28:11 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-14 15:28:11 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 15:28:11 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 15:28:11 --> Final output sent to browser
DEBUG - 2014-08-14 15:28:11 --> Total execution time: 0.0439
DEBUG - 2014-08-14 15:28:38 --> Config Class Initialized
DEBUG - 2014-08-14 15:28:38 --> Hooks Class Initialized
DEBUG - 2014-08-14 15:28:38 --> Utf8 Class Initialized
DEBUG - 2014-08-14 15:28:38 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 15:28:38 --> URI Class Initialized
DEBUG - 2014-08-14 15:28:38 --> Router Class Initialized
DEBUG - 2014-08-14 15:28:38 --> Output Class Initialized
DEBUG - 2014-08-14 15:28:38 --> Security Class Initialized
DEBUG - 2014-08-14 15:28:38 --> Input Class Initialized
DEBUG - 2014-08-14 15:28:38 --> XSS Filtering completed
DEBUG - 2014-08-14 15:28:38 --> XSS Filtering completed
DEBUG - 2014-08-14 15:28:38 --> XSS Filtering completed
DEBUG - 2014-08-14 15:28:38 --> XSS Filtering completed
DEBUG - 2014-08-14 15:28:38 --> XSS Filtering completed
DEBUG - 2014-08-14 15:28:38 --> XSS Filtering completed
DEBUG - 2014-08-14 15:28:38 --> XSS Filtering completed
DEBUG - 2014-08-14 15:28:38 --> XSS Filtering completed
DEBUG - 2014-08-14 15:28:38 --> CRSF cookie Set
DEBUG - 2014-08-14 15:28:38 --> CSRF token verified
DEBUG - 2014-08-14 15:28:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 15:28:38 --> Language Class Initialized
DEBUG - 2014-08-14 15:28:38 --> Loader Class Initialized
DEBUG - 2014-08-14 15:28:38 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 15:28:38 --> Helper loaded: url_helper
DEBUG - 2014-08-14 15:28:38 --> Database Driver Class Initialized
ERROR - 2014-08-14 15:28:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 15:28:38 --> Session Class Initialized
DEBUG - 2014-08-14 15:28:38 --> Helper loaded: string_helper
DEBUG - 2014-08-14 15:28:38 --> Session routines successfully run
DEBUG - 2014-08-14 15:28:38 --> Controller Class Initialized
DEBUG - 2014-08-14 15:28:38 --> Helper loaded: form_helper
DEBUG - 2014-08-14 15:28:38 --> Form Validation Class Initialized
DEBUG - 2014-08-14 15:28:38 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-14 15:28:38 --> XSS Filtering completed
DEBUG - 2014-08-14 15:28:38 --> XSS Filtering completed
DEBUG - 2014-08-14 15:28:38 --> Model Class Initialized
DEBUG - 2014-08-14 15:28:38 --> Model Class Initialized
DEBUG - 2014-08-14 15:28:38 --> Model Class Initialized
DEBUG - 2014-08-14 15:28:38 --> Model Class Initialized
DEBUG - 2014-08-14 15:28:38 --> Encrypt Class Initialized
DEBUG - 2014-08-14 15:28:38 --> XSS Filtering completed
DEBUG - 2014-08-14 15:28:38 --> XSS Filtering completed
DEBUG - 2014-08-14 15:28:38 --> Config Class Initialized
DEBUG - 2014-08-14 15:28:38 --> Hooks Class Initialized
DEBUG - 2014-08-14 15:28:38 --> Utf8 Class Initialized
DEBUG - 2014-08-14 15:28:38 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 15:28:38 --> URI Class Initialized
DEBUG - 2014-08-14 15:28:38 --> Router Class Initialized
DEBUG - 2014-08-14 15:28:38 --> Output Class Initialized
DEBUG - 2014-08-14 15:28:38 --> Security Class Initialized
DEBUG - 2014-08-14 15:28:38 --> Input Class Initialized
DEBUG - 2014-08-14 15:28:38 --> XSS Filtering completed
DEBUG - 2014-08-14 15:28:38 --> XSS Filtering completed
DEBUG - 2014-08-14 15:28:38 --> XSS Filtering completed
DEBUG - 2014-08-14 15:28:38 --> XSS Filtering completed
DEBUG - 2014-08-14 15:28:38 --> XSS Filtering completed
DEBUG - 2014-08-14 15:28:38 --> CRSF cookie Set
DEBUG - 2014-08-14 15:28:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 15:28:38 --> Language Class Initialized
DEBUG - 2014-08-14 15:28:38 --> Loader Class Initialized
DEBUG - 2014-08-14 15:28:38 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 15:28:38 --> Helper loaded: url_helper
DEBUG - 2014-08-14 15:28:38 --> Database Driver Class Initialized
ERROR - 2014-08-14 15:28:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 15:28:38 --> Session Class Initialized
DEBUG - 2014-08-14 15:28:38 --> Helper loaded: string_helper
DEBUG - 2014-08-14 15:28:38 --> Session routines successfully run
DEBUG - 2014-08-14 15:28:38 --> Controller Class Initialized
DEBUG - 2014-08-14 15:28:38 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 15:28:38 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 15:28:38 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-14 15:28:38 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-14 15:28:38 --> File loaded: application/views/placement_admin_home.php
DEBUG - 2014-08-14 15:28:38 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 15:28:38 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 15:28:38 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 15:28:38 --> Final output sent to browser
DEBUG - 2014-08-14 15:28:38 --> Total execution time: 0.0540
DEBUG - 2014-08-14 15:28:40 --> Config Class Initialized
DEBUG - 2014-08-14 15:28:40 --> Hooks Class Initialized
DEBUG - 2014-08-14 15:28:40 --> Utf8 Class Initialized
DEBUG - 2014-08-14 15:28:40 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 15:28:40 --> URI Class Initialized
DEBUG - 2014-08-14 15:28:40 --> Router Class Initialized
DEBUG - 2014-08-14 15:28:40 --> Output Class Initialized
DEBUG - 2014-08-14 15:28:40 --> Security Class Initialized
DEBUG - 2014-08-14 15:28:40 --> Input Class Initialized
DEBUG - 2014-08-14 15:28:40 --> XSS Filtering completed
DEBUG - 2014-08-14 15:28:40 --> XSS Filtering completed
DEBUG - 2014-08-14 15:28:40 --> XSS Filtering completed
DEBUG - 2014-08-14 15:28:40 --> XSS Filtering completed
DEBUG - 2014-08-14 15:28:40 --> XSS Filtering completed
DEBUG - 2014-08-14 15:28:40 --> CRSF cookie Set
DEBUG - 2014-08-14 15:28:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 15:28:40 --> Language Class Initialized
DEBUG - 2014-08-14 15:28:40 --> Loader Class Initialized
DEBUG - 2014-08-14 15:28:40 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 15:28:40 --> Helper loaded: url_helper
DEBUG - 2014-08-14 15:28:40 --> Database Driver Class Initialized
ERROR - 2014-08-14 15:28:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 15:28:40 --> Session Class Initialized
DEBUG - 2014-08-14 15:28:40 --> Helper loaded: string_helper
DEBUG - 2014-08-14 15:28:40 --> Session routines successfully run
DEBUG - 2014-08-14 15:28:40 --> Controller Class Initialized
DEBUG - 2014-08-14 15:28:40 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 15:28:40 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 15:28:40 --> Model Class Initialized
DEBUG - 2014-08-14 15:28:40 --> Model Class Initialized
DEBUG - 2014-08-14 15:28:40 --> Model Class Initialized
DEBUG - 2014-08-14 15:28:40 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 15:28:40 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 15:28:40 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 15:28:40 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 15:28:40 --> Final output sent to browser
DEBUG - 2014-08-14 15:28:40 --> Total execution time: 0.0491
DEBUG - 2014-08-14 15:29:41 --> Config Class Initialized
DEBUG - 2014-08-14 15:29:41 --> Hooks Class Initialized
DEBUG - 2014-08-14 15:29:41 --> Utf8 Class Initialized
DEBUG - 2014-08-14 15:29:41 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 15:29:41 --> URI Class Initialized
DEBUG - 2014-08-14 15:29:41 --> Router Class Initialized
DEBUG - 2014-08-14 15:29:41 --> Output Class Initialized
DEBUG - 2014-08-14 15:29:41 --> Security Class Initialized
DEBUG - 2014-08-14 15:29:41 --> Input Class Initialized
DEBUG - 2014-08-14 15:29:41 --> XSS Filtering completed
DEBUG - 2014-08-14 15:29:41 --> XSS Filtering completed
DEBUG - 2014-08-14 15:29:41 --> XSS Filtering completed
DEBUG - 2014-08-14 15:29:41 --> XSS Filtering completed
DEBUG - 2014-08-14 15:29:41 --> XSS Filtering completed
DEBUG - 2014-08-14 15:29:41 --> CRSF cookie Set
DEBUG - 2014-08-14 15:29:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 15:29:41 --> Language Class Initialized
DEBUG - 2014-08-14 15:29:41 --> Loader Class Initialized
DEBUG - 2014-08-14 15:29:41 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 15:29:41 --> Helper loaded: url_helper
DEBUG - 2014-08-14 15:29:41 --> Database Driver Class Initialized
ERROR - 2014-08-14 15:29:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 15:29:41 --> Session Class Initialized
DEBUG - 2014-08-14 15:29:41 --> Helper loaded: string_helper
DEBUG - 2014-08-14 15:29:41 --> Session routines successfully run
DEBUG - 2014-08-14 15:29:41 --> Controller Class Initialized
DEBUG - 2014-08-14 15:29:41 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 15:29:41 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 15:29:41 --> Model Class Initialized
DEBUG - 2014-08-14 15:29:41 --> Model Class Initialized
DEBUG - 2014-08-14 15:29:41 --> Model Class Initialized
DEBUG - 2014-08-14 15:29:41 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 15:29:41 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 15:29:41 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 15:29:41 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 15:29:41 --> Final output sent to browser
DEBUG - 2014-08-14 15:29:41 --> Total execution time: 0.0547
DEBUG - 2014-08-14 15:29:44 --> Config Class Initialized
DEBUG - 2014-08-14 15:29:44 --> Hooks Class Initialized
DEBUG - 2014-08-14 15:29:44 --> Utf8 Class Initialized
DEBUG - 2014-08-14 15:29:44 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 15:29:44 --> URI Class Initialized
DEBUG - 2014-08-14 15:29:44 --> Router Class Initialized
DEBUG - 2014-08-14 15:29:44 --> Output Class Initialized
DEBUG - 2014-08-14 15:29:44 --> Security Class Initialized
DEBUG - 2014-08-14 15:29:44 --> Input Class Initialized
DEBUG - 2014-08-14 15:29:44 --> XSS Filtering completed
DEBUG - 2014-08-14 15:29:44 --> XSS Filtering completed
DEBUG - 2014-08-14 15:29:44 --> XSS Filtering completed
DEBUG - 2014-08-14 15:29:44 --> XSS Filtering completed
DEBUG - 2014-08-14 15:29:44 --> XSS Filtering completed
DEBUG - 2014-08-14 15:29:44 --> CRSF cookie Set
DEBUG - 2014-08-14 15:29:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 15:29:44 --> Language Class Initialized
DEBUG - 2014-08-14 15:29:44 --> Loader Class Initialized
DEBUG - 2014-08-14 15:29:44 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 15:29:44 --> Helper loaded: url_helper
DEBUG - 2014-08-14 15:29:44 --> Database Driver Class Initialized
ERROR - 2014-08-14 15:29:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 15:29:44 --> Session Class Initialized
DEBUG - 2014-08-14 15:29:44 --> Helper loaded: string_helper
DEBUG - 2014-08-14 15:29:44 --> Session routines successfully run
DEBUG - 2014-08-14 15:29:44 --> Controller Class Initialized
DEBUG - 2014-08-14 15:29:44 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 15:29:44 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 15:29:44 --> Model Class Initialized
DEBUG - 2014-08-14 15:29:44 --> Model Class Initialized
DEBUG - 2014-08-14 15:29:44 --> Model Class Initialized
DEBUG - 2014-08-14 15:29:44 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 15:29:44 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 15:29:44 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 15:29:44 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 15:29:44 --> Final output sent to browser
DEBUG - 2014-08-14 15:29:44 --> Total execution time: 0.0810
DEBUG - 2014-08-14 15:37:22 --> Config Class Initialized
DEBUG - 2014-08-14 15:37:22 --> Hooks Class Initialized
DEBUG - 2014-08-14 15:37:22 --> Utf8 Class Initialized
DEBUG - 2014-08-14 15:37:22 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 15:37:22 --> URI Class Initialized
DEBUG - 2014-08-14 15:37:22 --> Router Class Initialized
DEBUG - 2014-08-14 15:37:22 --> Output Class Initialized
DEBUG - 2014-08-14 15:37:22 --> Security Class Initialized
DEBUG - 2014-08-14 15:37:22 --> Input Class Initialized
DEBUG - 2014-08-14 15:37:22 --> XSS Filtering completed
DEBUG - 2014-08-14 15:37:22 --> XSS Filtering completed
DEBUG - 2014-08-14 15:37:22 --> XSS Filtering completed
DEBUG - 2014-08-14 15:37:22 --> XSS Filtering completed
DEBUG - 2014-08-14 15:37:22 --> XSS Filtering completed
DEBUG - 2014-08-14 15:37:22 --> CRSF cookie Set
DEBUG - 2014-08-14 15:37:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 15:37:22 --> Language Class Initialized
DEBUG - 2014-08-14 15:37:22 --> Loader Class Initialized
DEBUG - 2014-08-14 15:37:22 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 15:37:22 --> Helper loaded: url_helper
DEBUG - 2014-08-14 15:37:22 --> Database Driver Class Initialized
ERROR - 2014-08-14 15:37:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 15:37:22 --> Session Class Initialized
DEBUG - 2014-08-14 15:37:22 --> Helper loaded: string_helper
DEBUG - 2014-08-14 15:37:22 --> Session routines successfully run
DEBUG - 2014-08-14 15:37:22 --> Controller Class Initialized
DEBUG - 2014-08-14 15:37:22 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 15:37:22 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 15:37:22 --> Model Class Initialized
DEBUG - 2014-08-14 15:37:22 --> Model Class Initialized
DEBUG - 2014-08-14 15:37:22 --> Model Class Initialized
DEBUG - 2014-08-14 15:37:22 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 15:37:22 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 15:37:22 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 15:37:22 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 15:37:22 --> Final output sent to browser
DEBUG - 2014-08-14 15:37:22 --> Total execution time: 0.0558
DEBUG - 2014-08-14 16:40:07 --> Config Class Initialized
DEBUG - 2014-08-14 16:40:07 --> Hooks Class Initialized
DEBUG - 2014-08-14 16:40:07 --> Utf8 Class Initialized
DEBUG - 2014-08-14 16:40:07 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 16:40:07 --> URI Class Initialized
DEBUG - 2014-08-14 16:40:07 --> Router Class Initialized
DEBUG - 2014-08-14 16:40:07 --> Output Class Initialized
DEBUG - 2014-08-14 16:40:07 --> Security Class Initialized
DEBUG - 2014-08-14 16:40:07 --> Input Class Initialized
DEBUG - 2014-08-14 16:40:07 --> XSS Filtering completed
DEBUG - 2014-08-14 16:40:07 --> XSS Filtering completed
DEBUG - 2014-08-14 16:40:07 --> XSS Filtering completed
DEBUG - 2014-08-14 16:40:07 --> XSS Filtering completed
DEBUG - 2014-08-14 16:40:07 --> XSS Filtering completed
DEBUG - 2014-08-14 16:40:07 --> CRSF cookie Set
DEBUG - 2014-08-14 16:40:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 16:40:07 --> Language Class Initialized
DEBUG - 2014-08-14 16:40:07 --> Loader Class Initialized
DEBUG - 2014-08-14 16:40:07 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 16:40:07 --> Helper loaded: url_helper
DEBUG - 2014-08-14 16:40:07 --> Database Driver Class Initialized
ERROR - 2014-08-14 16:40:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 16:40:07 --> Session Class Initialized
DEBUG - 2014-08-14 16:40:07 --> Helper loaded: string_helper
DEBUG - 2014-08-14 16:40:07 --> Session routines successfully run
DEBUG - 2014-08-14 16:40:07 --> Controller Class Initialized
DEBUG - 2014-08-14 16:40:07 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 16:40:07 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 16:40:07 --> Model Class Initialized
DEBUG - 2014-08-14 16:40:07 --> Model Class Initialized
DEBUG - 2014-08-14 16:40:07 --> Model Class Initialized
DEBUG - 2014-08-14 16:40:07 --> Encrypt Class Initialized
ERROR - 2014-08-14 16:40:07 --> Severity: Notice  --> Undefined property: CI_Loader::$encrypt C:\wamp\www\cep\placement\application\views\placement_admin_verify.php 42
DEBUG - 2014-08-14 16:41:03 --> Config Class Initialized
DEBUG - 2014-08-14 16:41:03 --> Hooks Class Initialized
DEBUG - 2014-08-14 16:41:03 --> Utf8 Class Initialized
DEBUG - 2014-08-14 16:41:03 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 16:41:03 --> URI Class Initialized
DEBUG - 2014-08-14 16:41:03 --> Router Class Initialized
DEBUG - 2014-08-14 16:41:03 --> Output Class Initialized
DEBUG - 2014-08-14 16:41:03 --> Security Class Initialized
DEBUG - 2014-08-14 16:41:03 --> Input Class Initialized
DEBUG - 2014-08-14 16:41:03 --> XSS Filtering completed
DEBUG - 2014-08-14 16:41:03 --> XSS Filtering completed
DEBUG - 2014-08-14 16:41:03 --> XSS Filtering completed
DEBUG - 2014-08-14 16:41:03 --> XSS Filtering completed
DEBUG - 2014-08-14 16:41:03 --> XSS Filtering completed
DEBUG - 2014-08-14 16:41:03 --> CRSF cookie Set
DEBUG - 2014-08-14 16:41:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 16:41:03 --> Language Class Initialized
DEBUG - 2014-08-14 16:41:03 --> Loader Class Initialized
DEBUG - 2014-08-14 16:41:03 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 16:41:03 --> Helper loaded: url_helper
DEBUG - 2014-08-14 16:41:03 --> Database Driver Class Initialized
ERROR - 2014-08-14 16:41:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 16:41:03 --> Session Class Initialized
DEBUG - 2014-08-14 16:41:03 --> Helper loaded: string_helper
DEBUG - 2014-08-14 16:41:03 --> Session routines successfully run
DEBUG - 2014-08-14 16:41:03 --> Controller Class Initialized
DEBUG - 2014-08-14 16:41:03 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 16:41:03 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 16:41:03 --> Model Class Initialized
DEBUG - 2014-08-14 16:41:03 --> Model Class Initialized
DEBUG - 2014-08-14 16:41:03 --> Model Class Initialized
DEBUG - 2014-08-14 16:41:03 --> Encrypt Class Initialized
ERROR - 2014-08-14 16:41:03 --> Severity: Notice  --> Undefined property: CI_Loader::$encrypt C:\wamp\www\cep\placement\application\views\placement_admin_verify.php 42
DEBUG - 2014-08-14 16:41:55 --> Config Class Initialized
DEBUG - 2014-08-14 16:41:55 --> Hooks Class Initialized
DEBUG - 2014-08-14 16:41:55 --> Utf8 Class Initialized
DEBUG - 2014-08-14 16:41:55 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 16:41:55 --> URI Class Initialized
DEBUG - 2014-08-14 16:41:55 --> Router Class Initialized
DEBUG - 2014-08-14 16:41:55 --> Output Class Initialized
DEBUG - 2014-08-14 16:41:55 --> Security Class Initialized
DEBUG - 2014-08-14 16:41:55 --> Input Class Initialized
DEBUG - 2014-08-14 16:41:55 --> XSS Filtering completed
DEBUG - 2014-08-14 16:41:55 --> XSS Filtering completed
DEBUG - 2014-08-14 16:41:55 --> XSS Filtering completed
DEBUG - 2014-08-14 16:41:55 --> XSS Filtering completed
DEBUG - 2014-08-14 16:41:55 --> XSS Filtering completed
DEBUG - 2014-08-14 16:41:55 --> CRSF cookie Set
DEBUG - 2014-08-14 16:41:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 16:41:55 --> Language Class Initialized
DEBUG - 2014-08-14 16:41:55 --> Loader Class Initialized
DEBUG - 2014-08-14 16:41:55 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 16:41:55 --> Helper loaded: url_helper
DEBUG - 2014-08-14 16:41:55 --> Database Driver Class Initialized
ERROR - 2014-08-14 16:41:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 16:41:55 --> Session Class Initialized
DEBUG - 2014-08-14 16:41:55 --> Helper loaded: string_helper
DEBUG - 2014-08-14 16:41:55 --> Session routines successfully run
DEBUG - 2014-08-14 16:41:55 --> Controller Class Initialized
DEBUG - 2014-08-14 16:41:55 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 16:41:55 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 16:41:55 --> Model Class Initialized
DEBUG - 2014-08-14 16:41:55 --> Model Class Initialized
DEBUG - 2014-08-14 16:41:55 --> Model Class Initialized
DEBUG - 2014-08-14 16:41:55 --> Encrypt Class Initialized
ERROR - 2014-08-14 16:41:55 --> Severity: Notice  --> Undefined property: CI_Loader::$encrypt C:\wamp\www\cep\placement\application\views\placement_admin_verify.php 42
DEBUG - 2014-08-14 16:42:20 --> Config Class Initialized
DEBUG - 2014-08-14 16:42:20 --> Hooks Class Initialized
DEBUG - 2014-08-14 16:42:20 --> Utf8 Class Initialized
DEBUG - 2014-08-14 16:42:20 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 16:42:20 --> URI Class Initialized
DEBUG - 2014-08-14 16:42:20 --> Router Class Initialized
DEBUG - 2014-08-14 16:42:20 --> Output Class Initialized
DEBUG - 2014-08-14 16:42:20 --> Security Class Initialized
DEBUG - 2014-08-14 16:42:20 --> Input Class Initialized
DEBUG - 2014-08-14 16:42:20 --> XSS Filtering completed
DEBUG - 2014-08-14 16:42:20 --> XSS Filtering completed
DEBUG - 2014-08-14 16:42:20 --> XSS Filtering completed
DEBUG - 2014-08-14 16:42:20 --> XSS Filtering completed
DEBUG - 2014-08-14 16:42:20 --> XSS Filtering completed
DEBUG - 2014-08-14 16:42:20 --> CRSF cookie Set
DEBUG - 2014-08-14 16:42:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 16:42:20 --> Language Class Initialized
DEBUG - 2014-08-14 16:42:20 --> Loader Class Initialized
DEBUG - 2014-08-14 16:42:20 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 16:42:20 --> Helper loaded: url_helper
DEBUG - 2014-08-14 16:42:20 --> Database Driver Class Initialized
ERROR - 2014-08-14 16:42:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 16:42:20 --> Session Class Initialized
DEBUG - 2014-08-14 16:42:20 --> Helper loaded: string_helper
DEBUG - 2014-08-14 16:42:20 --> Session routines successfully run
DEBUG - 2014-08-14 16:42:20 --> Controller Class Initialized
DEBUG - 2014-08-14 16:42:20 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 16:42:20 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 16:42:20 --> Model Class Initialized
DEBUG - 2014-08-14 16:42:20 --> Model Class Initialized
DEBUG - 2014-08-14 16:42:20 --> Model Class Initialized
DEBUG - 2014-08-14 16:42:21 --> Encrypt Class Initialized
ERROR - 2014-08-14 16:42:21 --> Severity: Notice  --> Undefined property: CI_Loader::$encrypt C:\wamp\www\cep\placement\application\views\placement_admin_verify.php 42
DEBUG - 2014-08-14 16:42:33 --> Config Class Initialized
DEBUG - 2014-08-14 16:42:33 --> Hooks Class Initialized
DEBUG - 2014-08-14 16:42:33 --> Utf8 Class Initialized
DEBUG - 2014-08-14 16:42:33 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 16:42:33 --> URI Class Initialized
DEBUG - 2014-08-14 16:42:33 --> Router Class Initialized
DEBUG - 2014-08-14 16:42:33 --> Output Class Initialized
DEBUG - 2014-08-14 16:42:33 --> Security Class Initialized
DEBUG - 2014-08-14 16:42:33 --> Input Class Initialized
DEBUG - 2014-08-14 16:42:33 --> XSS Filtering completed
DEBUG - 2014-08-14 16:42:33 --> XSS Filtering completed
DEBUG - 2014-08-14 16:42:33 --> XSS Filtering completed
DEBUG - 2014-08-14 16:42:33 --> XSS Filtering completed
DEBUG - 2014-08-14 16:42:33 --> XSS Filtering completed
DEBUG - 2014-08-14 16:42:33 --> CRSF cookie Set
DEBUG - 2014-08-14 16:42:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 16:42:33 --> Language Class Initialized
DEBUG - 2014-08-14 16:42:33 --> Loader Class Initialized
DEBUG - 2014-08-14 16:42:33 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 16:42:33 --> Helper loaded: url_helper
DEBUG - 2014-08-14 16:42:33 --> Database Driver Class Initialized
ERROR - 2014-08-14 16:42:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 16:42:33 --> Session Class Initialized
DEBUG - 2014-08-14 16:42:33 --> Helper loaded: string_helper
DEBUG - 2014-08-14 16:42:33 --> Session routines successfully run
DEBUG - 2014-08-14 16:42:33 --> Controller Class Initialized
DEBUG - 2014-08-14 16:42:33 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 16:42:33 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 16:42:33 --> Model Class Initialized
DEBUG - 2014-08-14 16:42:33 --> Model Class Initialized
DEBUG - 2014-08-14 16:42:33 --> Model Class Initialized
DEBUG - 2014-08-14 16:42:33 --> Encrypt Class Initialized
ERROR - 2014-08-14 16:42:33 --> Severity: Notice  --> Undefined property: CI_Loader::$encrypt C:\wamp\www\cep\placement\application\views\placement_admin_verify.php 42
DEBUG - 2014-08-14 16:44:05 --> Config Class Initialized
DEBUG - 2014-08-14 16:44:05 --> Hooks Class Initialized
DEBUG - 2014-08-14 16:44:05 --> Utf8 Class Initialized
DEBUG - 2014-08-14 16:44:05 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 16:44:05 --> URI Class Initialized
DEBUG - 2014-08-14 16:44:05 --> Router Class Initialized
DEBUG - 2014-08-14 16:44:05 --> Output Class Initialized
DEBUG - 2014-08-14 16:44:05 --> Security Class Initialized
DEBUG - 2014-08-14 16:44:05 --> Input Class Initialized
DEBUG - 2014-08-14 16:44:05 --> XSS Filtering completed
DEBUG - 2014-08-14 16:44:05 --> XSS Filtering completed
DEBUG - 2014-08-14 16:44:05 --> XSS Filtering completed
DEBUG - 2014-08-14 16:44:05 --> XSS Filtering completed
DEBUG - 2014-08-14 16:44:05 --> XSS Filtering completed
DEBUG - 2014-08-14 16:44:05 --> CRSF cookie Set
DEBUG - 2014-08-14 16:44:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 16:44:05 --> Language Class Initialized
DEBUG - 2014-08-14 16:44:05 --> Loader Class Initialized
DEBUG - 2014-08-14 16:44:05 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 16:44:05 --> Helper loaded: url_helper
DEBUG - 2014-08-14 16:44:05 --> Database Driver Class Initialized
ERROR - 2014-08-14 16:44:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 16:44:05 --> Session Class Initialized
DEBUG - 2014-08-14 16:44:05 --> Helper loaded: string_helper
DEBUG - 2014-08-14 16:44:05 --> Session routines successfully run
DEBUG - 2014-08-14 16:44:05 --> Controller Class Initialized
DEBUG - 2014-08-14 16:44:05 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 16:44:05 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 16:44:05 --> Model Class Initialized
DEBUG - 2014-08-14 16:44:05 --> Model Class Initialized
DEBUG - 2014-08-14 16:44:05 --> Model Class Initialized
DEBUG - 2014-08-14 16:44:05 --> Encrypt Class Initialized
ERROR - 2014-08-14 16:44:05 --> Severity: Notice  --> Undefined property: CI_Loader::$encrypt C:\wamp\www\cep\placement\application\views\placement_admin_verify.php 39
DEBUG - 2014-08-14 16:44:30 --> Config Class Initialized
DEBUG - 2014-08-14 16:44:30 --> Hooks Class Initialized
DEBUG - 2014-08-14 16:44:30 --> Utf8 Class Initialized
DEBUG - 2014-08-14 16:44:30 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 16:44:30 --> URI Class Initialized
DEBUG - 2014-08-14 16:44:30 --> Router Class Initialized
DEBUG - 2014-08-14 16:44:30 --> Output Class Initialized
DEBUG - 2014-08-14 16:44:30 --> Security Class Initialized
DEBUG - 2014-08-14 16:44:30 --> Input Class Initialized
DEBUG - 2014-08-14 16:44:30 --> XSS Filtering completed
DEBUG - 2014-08-14 16:44:30 --> XSS Filtering completed
DEBUG - 2014-08-14 16:44:30 --> XSS Filtering completed
DEBUG - 2014-08-14 16:44:30 --> XSS Filtering completed
DEBUG - 2014-08-14 16:44:30 --> XSS Filtering completed
DEBUG - 2014-08-14 16:44:30 --> CRSF cookie Set
DEBUG - 2014-08-14 16:44:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 16:44:30 --> Language Class Initialized
DEBUG - 2014-08-14 16:44:30 --> Loader Class Initialized
DEBUG - 2014-08-14 16:44:30 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 16:44:30 --> Helper loaded: url_helper
DEBUG - 2014-08-14 16:44:30 --> Database Driver Class Initialized
ERROR - 2014-08-14 16:44:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 16:44:30 --> Session Class Initialized
DEBUG - 2014-08-14 16:44:30 --> Helper loaded: string_helper
DEBUG - 2014-08-14 16:44:30 --> Session routines successfully run
DEBUG - 2014-08-14 16:44:30 --> Controller Class Initialized
DEBUG - 2014-08-14 16:44:30 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 16:44:30 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 16:44:30 --> Model Class Initialized
DEBUG - 2014-08-14 16:44:30 --> Model Class Initialized
DEBUG - 2014-08-14 16:44:30 --> Model Class Initialized
DEBUG - 2014-08-14 16:44:58 --> Config Class Initialized
DEBUG - 2014-08-14 16:44:58 --> Hooks Class Initialized
DEBUG - 2014-08-14 16:44:58 --> Utf8 Class Initialized
DEBUG - 2014-08-14 16:44:58 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 16:44:58 --> URI Class Initialized
DEBUG - 2014-08-14 16:44:58 --> Router Class Initialized
DEBUG - 2014-08-14 16:44:58 --> Output Class Initialized
DEBUG - 2014-08-14 16:44:58 --> Security Class Initialized
DEBUG - 2014-08-14 16:44:58 --> Input Class Initialized
DEBUG - 2014-08-14 16:44:58 --> XSS Filtering completed
DEBUG - 2014-08-14 16:44:58 --> XSS Filtering completed
DEBUG - 2014-08-14 16:44:58 --> XSS Filtering completed
DEBUG - 2014-08-14 16:44:58 --> XSS Filtering completed
DEBUG - 2014-08-14 16:44:58 --> XSS Filtering completed
DEBUG - 2014-08-14 16:44:58 --> CRSF cookie Set
DEBUG - 2014-08-14 16:44:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 16:44:58 --> Language Class Initialized
DEBUG - 2014-08-14 16:44:58 --> Loader Class Initialized
DEBUG - 2014-08-14 16:44:58 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 16:44:58 --> Helper loaded: url_helper
DEBUG - 2014-08-14 16:44:58 --> Database Driver Class Initialized
ERROR - 2014-08-14 16:44:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 16:44:58 --> Session Class Initialized
DEBUG - 2014-08-14 16:44:58 --> Helper loaded: string_helper
DEBUG - 2014-08-14 16:44:58 --> Session routines successfully run
DEBUG - 2014-08-14 16:44:58 --> Controller Class Initialized
DEBUG - 2014-08-14 16:44:58 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 16:44:58 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 16:44:58 --> Model Class Initialized
DEBUG - 2014-08-14 16:44:58 --> Model Class Initialized
DEBUG - 2014-08-14 16:44:58 --> Model Class Initialized
DEBUG - 2014-08-14 16:44:58 --> Encrypt Class Initialized
ERROR - 2014-08-14 16:44:58 --> Severity: Notice  --> Undefined property: CI_Loader::$encrypt C:\wamp\www\cep\placement\application\views\placement_admin_verify.php 39
DEBUG - 2014-08-14 16:46:16 --> Config Class Initialized
DEBUG - 2014-08-14 16:46:16 --> Hooks Class Initialized
DEBUG - 2014-08-14 16:46:16 --> Utf8 Class Initialized
DEBUG - 2014-08-14 16:46:16 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 16:46:16 --> URI Class Initialized
DEBUG - 2014-08-14 16:46:16 --> Router Class Initialized
DEBUG - 2014-08-14 16:46:16 --> Output Class Initialized
DEBUG - 2014-08-14 16:46:16 --> Security Class Initialized
DEBUG - 2014-08-14 16:46:16 --> Input Class Initialized
DEBUG - 2014-08-14 16:46:16 --> XSS Filtering completed
DEBUG - 2014-08-14 16:46:16 --> XSS Filtering completed
DEBUG - 2014-08-14 16:46:16 --> XSS Filtering completed
DEBUG - 2014-08-14 16:46:16 --> XSS Filtering completed
DEBUG - 2014-08-14 16:46:16 --> XSS Filtering completed
DEBUG - 2014-08-14 16:46:16 --> CRSF cookie Set
DEBUG - 2014-08-14 16:46:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 16:46:16 --> Language Class Initialized
DEBUG - 2014-08-14 16:46:16 --> Loader Class Initialized
DEBUG - 2014-08-14 16:46:16 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 16:46:16 --> Helper loaded: url_helper
DEBUG - 2014-08-14 16:46:16 --> Database Driver Class Initialized
ERROR - 2014-08-14 16:46:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 16:46:16 --> Session Class Initialized
DEBUG - 2014-08-14 16:46:16 --> Helper loaded: string_helper
DEBUG - 2014-08-14 16:46:16 --> Session routines successfully run
DEBUG - 2014-08-14 16:46:16 --> Controller Class Initialized
DEBUG - 2014-08-14 16:46:16 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 16:46:16 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 16:46:16 --> Encrypt Class Initialized
DEBUG - 2014-08-14 16:46:16 --> Model Class Initialized
DEBUG - 2014-08-14 16:46:16 --> Model Class Initialized
DEBUG - 2014-08-14 16:46:16 --> Model Class Initialized
DEBUG - 2014-08-14 16:46:16 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-14 16:46:16 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 16:46:16 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 16:46:16 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 16:46:16 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 16:46:16 --> Final output sent to browser
DEBUG - 2014-08-14 16:46:16 --> Total execution time: 0.1038
DEBUG - 2014-08-14 16:46:28 --> Config Class Initialized
DEBUG - 2014-08-14 16:46:28 --> Hooks Class Initialized
DEBUG - 2014-08-14 16:46:28 --> Utf8 Class Initialized
DEBUG - 2014-08-14 16:46:28 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 16:46:28 --> URI Class Initialized
DEBUG - 2014-08-14 16:46:28 --> Router Class Initialized
DEBUG - 2014-08-14 16:46:28 --> Output Class Initialized
DEBUG - 2014-08-14 16:46:28 --> Security Class Initialized
DEBUG - 2014-08-14 16:46:28 --> Input Class Initialized
DEBUG - 2014-08-14 16:46:28 --> XSS Filtering completed
DEBUG - 2014-08-14 16:46:28 --> XSS Filtering completed
DEBUG - 2014-08-14 16:46:28 --> XSS Filtering completed
DEBUG - 2014-08-14 16:46:28 --> XSS Filtering completed
DEBUG - 2014-08-14 16:46:28 --> XSS Filtering completed
DEBUG - 2014-08-14 16:46:28 --> CRSF cookie Set
DEBUG - 2014-08-14 16:46:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 16:46:28 --> Language Class Initialized
DEBUG - 2014-08-14 16:46:28 --> Loader Class Initialized
DEBUG - 2014-08-14 16:46:28 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 16:46:28 --> Helper loaded: url_helper
DEBUG - 2014-08-14 16:46:28 --> Database Driver Class Initialized
ERROR - 2014-08-14 16:46:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 16:46:28 --> Session Class Initialized
DEBUG - 2014-08-14 16:46:28 --> Helper loaded: string_helper
DEBUG - 2014-08-14 16:46:28 --> Session routines successfully run
DEBUG - 2014-08-14 16:46:28 --> Controller Class Initialized
DEBUG - 2014-08-14 16:46:28 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 16:46:28 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 16:46:28 --> Encrypt Class Initialized
DEBUG - 2014-08-14 16:46:28 --> Model Class Initialized
DEBUG - 2014-08-14 16:46:28 --> Model Class Initialized
DEBUG - 2014-08-14 16:46:28 --> Model Class Initialized
DEBUG - 2014-08-14 16:46:28 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 16:46:28 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 16:46:28 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 16:46:28 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 16:46:28 --> Final output sent to browser
DEBUG - 2014-08-14 16:46:28 --> Total execution time: 0.0603
DEBUG - 2014-08-14 16:46:53 --> Config Class Initialized
DEBUG - 2014-08-14 16:46:53 --> Hooks Class Initialized
DEBUG - 2014-08-14 16:46:53 --> Utf8 Class Initialized
DEBUG - 2014-08-14 16:46:53 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 16:46:53 --> URI Class Initialized
DEBUG - 2014-08-14 16:46:53 --> Router Class Initialized
DEBUG - 2014-08-14 16:46:53 --> Output Class Initialized
DEBUG - 2014-08-14 16:46:53 --> Security Class Initialized
DEBUG - 2014-08-14 16:46:53 --> Input Class Initialized
DEBUG - 2014-08-14 16:46:53 --> XSS Filtering completed
DEBUG - 2014-08-14 16:46:53 --> XSS Filtering completed
DEBUG - 2014-08-14 16:46:53 --> XSS Filtering completed
DEBUG - 2014-08-14 16:46:53 --> XSS Filtering completed
DEBUG - 2014-08-14 16:46:53 --> XSS Filtering completed
DEBUG - 2014-08-14 16:46:53 --> CRSF cookie Set
DEBUG - 2014-08-14 16:46:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 16:46:53 --> Language Class Initialized
DEBUG - 2014-08-14 16:46:53 --> Loader Class Initialized
DEBUG - 2014-08-14 16:46:53 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 16:46:53 --> Helper loaded: url_helper
DEBUG - 2014-08-14 16:46:53 --> Database Driver Class Initialized
ERROR - 2014-08-14 16:46:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 16:46:53 --> Session Class Initialized
DEBUG - 2014-08-14 16:46:53 --> Helper loaded: string_helper
DEBUG - 2014-08-14 16:46:53 --> Session routines successfully run
DEBUG - 2014-08-14 16:46:53 --> Controller Class Initialized
DEBUG - 2014-08-14 16:46:53 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 16:46:53 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 16:46:53 --> Encrypt Class Initialized
DEBUG - 2014-08-14 16:46:53 --> Model Class Initialized
DEBUG - 2014-08-14 16:46:53 --> Model Class Initialized
DEBUG - 2014-08-14 16:46:53 --> Model Class Initialized
DEBUG - 2014-08-14 16:46:53 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 16:46:53 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 16:46:53 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 16:46:53 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 16:46:53 --> Final output sent to browser
DEBUG - 2014-08-14 16:46:53 --> Total execution time: 0.0614
DEBUG - 2014-08-14 16:46:59 --> Config Class Initialized
DEBUG - 2014-08-14 16:46:59 --> Hooks Class Initialized
DEBUG - 2014-08-14 16:46:59 --> Utf8 Class Initialized
DEBUG - 2014-08-14 16:46:59 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 16:46:59 --> URI Class Initialized
DEBUG - 2014-08-14 16:46:59 --> Router Class Initialized
DEBUG - 2014-08-14 16:46:59 --> Output Class Initialized
DEBUG - 2014-08-14 16:46:59 --> Security Class Initialized
DEBUG - 2014-08-14 16:46:59 --> Input Class Initialized
DEBUG - 2014-08-14 16:46:59 --> XSS Filtering completed
DEBUG - 2014-08-14 16:46:59 --> XSS Filtering completed
DEBUG - 2014-08-14 16:46:59 --> XSS Filtering completed
DEBUG - 2014-08-14 16:46:59 --> XSS Filtering completed
DEBUG - 2014-08-14 16:46:59 --> XSS Filtering completed
DEBUG - 2014-08-14 16:46:59 --> CRSF cookie Set
DEBUG - 2014-08-14 16:46:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 16:46:59 --> Language Class Initialized
DEBUG - 2014-08-14 16:46:59 --> Loader Class Initialized
DEBUG - 2014-08-14 16:46:59 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 16:46:59 --> Helper loaded: url_helper
DEBUG - 2014-08-14 16:46:59 --> Database Driver Class Initialized
ERROR - 2014-08-14 16:46:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 16:46:59 --> Session Class Initialized
DEBUG - 2014-08-14 16:46:59 --> Helper loaded: string_helper
DEBUG - 2014-08-14 16:46:59 --> Session routines successfully run
DEBUG - 2014-08-14 16:46:59 --> Controller Class Initialized
DEBUG - 2014-08-14 16:46:59 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 16:46:59 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 16:46:59 --> Encrypt Class Initialized
DEBUG - 2014-08-14 16:46:59 --> Model Class Initialized
DEBUG - 2014-08-14 16:46:59 --> Model Class Initialized
DEBUG - 2014-08-14 16:46:59 --> Model Class Initialized
DEBUG - 2014-08-14 16:46:59 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 16:46:59 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 16:46:59 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 16:46:59 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 16:46:59 --> Final output sent to browser
DEBUG - 2014-08-14 16:46:59 --> Total execution time: 0.0854
DEBUG - 2014-08-14 16:47:29 --> Config Class Initialized
DEBUG - 2014-08-14 16:47:29 --> Hooks Class Initialized
DEBUG - 2014-08-14 16:47:29 --> Utf8 Class Initialized
DEBUG - 2014-08-14 16:47:29 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 16:47:29 --> URI Class Initialized
DEBUG - 2014-08-14 16:47:29 --> Router Class Initialized
DEBUG - 2014-08-14 16:47:29 --> Output Class Initialized
DEBUG - 2014-08-14 16:47:29 --> Security Class Initialized
DEBUG - 2014-08-14 16:47:29 --> Input Class Initialized
DEBUG - 2014-08-14 16:47:29 --> XSS Filtering completed
DEBUG - 2014-08-14 16:47:29 --> XSS Filtering completed
DEBUG - 2014-08-14 16:47:29 --> XSS Filtering completed
DEBUG - 2014-08-14 16:47:29 --> XSS Filtering completed
DEBUG - 2014-08-14 16:47:29 --> XSS Filtering completed
DEBUG - 2014-08-14 16:47:29 --> CRSF cookie Set
DEBUG - 2014-08-14 16:47:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 16:47:29 --> Language Class Initialized
DEBUG - 2014-08-14 16:47:29 --> Loader Class Initialized
DEBUG - 2014-08-14 16:47:29 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 16:47:29 --> Helper loaded: url_helper
DEBUG - 2014-08-14 16:47:29 --> Database Driver Class Initialized
ERROR - 2014-08-14 16:47:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 16:47:29 --> Session Class Initialized
DEBUG - 2014-08-14 16:47:29 --> Helper loaded: string_helper
DEBUG - 2014-08-14 16:47:29 --> Session routines successfully run
DEBUG - 2014-08-14 16:47:29 --> Controller Class Initialized
DEBUG - 2014-08-14 16:47:29 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 16:47:29 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 16:47:29 --> Encrypt Class Initialized
DEBUG - 2014-08-14 16:47:29 --> Model Class Initialized
DEBUG - 2014-08-14 16:47:29 --> Model Class Initialized
DEBUG - 2014-08-14 16:47:29 --> Model Class Initialized
DEBUG - 2014-08-14 16:47:29 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 16:47:29 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 16:47:29 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 16:47:29 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 16:47:29 --> Final output sent to browser
DEBUG - 2014-08-14 16:47:29 --> Total execution time: 0.0703
DEBUG - 2014-08-14 16:48:04 --> Config Class Initialized
DEBUG - 2014-08-14 16:48:04 --> Hooks Class Initialized
DEBUG - 2014-08-14 16:48:04 --> Utf8 Class Initialized
DEBUG - 2014-08-14 16:48:04 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 16:48:04 --> URI Class Initialized
DEBUG - 2014-08-14 16:48:04 --> Router Class Initialized
DEBUG - 2014-08-14 16:48:04 --> Output Class Initialized
DEBUG - 2014-08-14 16:48:04 --> Security Class Initialized
DEBUG - 2014-08-14 16:48:04 --> Input Class Initialized
DEBUG - 2014-08-14 16:48:04 --> XSS Filtering completed
DEBUG - 2014-08-14 16:48:04 --> XSS Filtering completed
DEBUG - 2014-08-14 16:48:04 --> XSS Filtering completed
DEBUG - 2014-08-14 16:48:04 --> XSS Filtering completed
DEBUG - 2014-08-14 16:48:04 --> XSS Filtering completed
DEBUG - 2014-08-14 16:48:04 --> CRSF cookie Set
DEBUG - 2014-08-14 16:48:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 16:48:04 --> Language Class Initialized
DEBUG - 2014-08-14 16:48:04 --> Loader Class Initialized
DEBUG - 2014-08-14 16:48:04 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 16:48:04 --> Helper loaded: url_helper
DEBUG - 2014-08-14 16:48:04 --> Database Driver Class Initialized
ERROR - 2014-08-14 16:48:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 16:48:04 --> Session Class Initialized
DEBUG - 2014-08-14 16:48:04 --> Helper loaded: string_helper
DEBUG - 2014-08-14 16:48:04 --> Session routines successfully run
DEBUG - 2014-08-14 16:48:04 --> Controller Class Initialized
DEBUG - 2014-08-14 16:48:04 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 16:48:04 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 16:48:04 --> Encrypt Class Initialized
DEBUG - 2014-08-14 16:48:04 --> Model Class Initialized
DEBUG - 2014-08-14 16:48:04 --> Model Class Initialized
DEBUG - 2014-08-14 16:48:04 --> Model Class Initialized
DEBUG - 2014-08-14 16:48:04 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 16:48:04 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 16:48:04 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 16:48:04 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 16:48:04 --> Final output sent to browser
DEBUG - 2014-08-14 16:48:04 --> Total execution time: 0.0536
DEBUG - 2014-08-14 18:50:44 --> Config Class Initialized
DEBUG - 2014-08-14 18:50:44 --> Hooks Class Initialized
DEBUG - 2014-08-14 18:50:44 --> Utf8 Class Initialized
DEBUG - 2014-08-14 18:50:44 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 18:50:44 --> URI Class Initialized
DEBUG - 2014-08-14 18:50:44 --> Router Class Initialized
DEBUG - 2014-08-14 18:50:44 --> No URI present. Default controller set.
DEBUG - 2014-08-14 18:50:44 --> Output Class Initialized
DEBUG - 2014-08-14 18:50:44 --> Security Class Initialized
DEBUG - 2014-08-14 18:50:44 --> Input Class Initialized
DEBUG - 2014-08-14 18:50:44 --> XSS Filtering completed
DEBUG - 2014-08-14 18:50:44 --> XSS Filtering completed
DEBUG - 2014-08-14 18:50:44 --> CRSF cookie Set
DEBUG - 2014-08-14 18:50:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 18:50:44 --> Language Class Initialized
DEBUG - 2014-08-14 18:50:44 --> Loader Class Initialized
DEBUG - 2014-08-14 18:50:44 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 18:50:44 --> Helper loaded: url_helper
DEBUG - 2014-08-14 18:50:44 --> Database Driver Class Initialized
ERROR - 2014-08-14 18:50:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 18:50:44 --> Session Class Initialized
DEBUG - 2014-08-14 18:50:44 --> Helper loaded: string_helper
DEBUG - 2014-08-14 18:50:44 --> A session cookie was not found.
DEBUG - 2014-08-14 18:50:44 --> Session routines successfully run
DEBUG - 2014-08-14 18:50:44 --> Controller Class Initialized
DEBUG - 2014-08-14 18:50:44 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 18:50:44 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-14 18:50:44 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-14 18:50:44 --> Helper loaded: form_helper
DEBUG - 2014-08-14 18:50:44 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-14 18:50:44 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-14 18:50:44 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 18:50:44 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 18:50:44 --> Final output sent to browser
DEBUG - 2014-08-14 18:50:44 --> Total execution time: 0.0386
DEBUG - 2014-08-14 18:51:45 --> Config Class Initialized
DEBUG - 2014-08-14 18:51:45 --> Hooks Class Initialized
DEBUG - 2014-08-14 18:51:45 --> Utf8 Class Initialized
DEBUG - 2014-08-14 18:51:45 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 18:51:45 --> URI Class Initialized
DEBUG - 2014-08-14 18:51:45 --> Router Class Initialized
DEBUG - 2014-08-14 18:51:45 --> Output Class Initialized
DEBUG - 2014-08-14 18:51:45 --> Security Class Initialized
DEBUG - 2014-08-14 18:51:45 --> Input Class Initialized
DEBUG - 2014-08-14 18:51:45 --> XSS Filtering completed
DEBUG - 2014-08-14 18:51:45 --> XSS Filtering completed
DEBUG - 2014-08-14 18:51:45 --> XSS Filtering completed
DEBUG - 2014-08-14 18:51:45 --> XSS Filtering completed
DEBUG - 2014-08-14 18:51:45 --> XSS Filtering completed
DEBUG - 2014-08-14 18:51:45 --> XSS Filtering completed
DEBUG - 2014-08-14 18:51:45 --> XSS Filtering completed
DEBUG - 2014-08-14 18:51:45 --> CRSF cookie Set
DEBUG - 2014-08-14 18:51:45 --> CSRF token verified
DEBUG - 2014-08-14 18:51:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 18:51:45 --> Language Class Initialized
DEBUG - 2014-08-14 18:51:45 --> Loader Class Initialized
DEBUG - 2014-08-14 18:51:45 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 18:51:45 --> Helper loaded: url_helper
DEBUG - 2014-08-14 18:51:45 --> Database Driver Class Initialized
ERROR - 2014-08-14 18:51:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 18:51:45 --> Session Class Initialized
DEBUG - 2014-08-14 18:51:45 --> Helper loaded: string_helper
DEBUG - 2014-08-14 18:51:45 --> Session routines successfully run
DEBUG - 2014-08-14 18:51:45 --> Controller Class Initialized
DEBUG - 2014-08-14 18:51:45 --> Helper loaded: form_helper
DEBUG - 2014-08-14 18:51:45 --> Form Validation Class Initialized
DEBUG - 2014-08-14 18:51:45 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-14 18:51:45 --> XSS Filtering completed
DEBUG - 2014-08-14 18:51:45 --> XSS Filtering completed
DEBUG - 2014-08-14 18:51:45 --> Model Class Initialized
DEBUG - 2014-08-14 18:51:45 --> Model Class Initialized
DEBUG - 2014-08-14 18:51:45 --> Model Class Initialized
DEBUG - 2014-08-14 18:51:45 --> Model Class Initialized
DEBUG - 2014-08-14 18:51:45 --> Encrypt Class Initialized
DEBUG - 2014-08-14 18:51:45 --> XSS Filtering completed
DEBUG - 2014-08-14 18:51:45 --> XSS Filtering completed
DEBUG - 2014-08-14 18:51:45 --> Config Class Initialized
DEBUG - 2014-08-14 18:51:45 --> Hooks Class Initialized
DEBUG - 2014-08-14 18:51:45 --> Utf8 Class Initialized
DEBUG - 2014-08-14 18:51:45 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 18:51:45 --> URI Class Initialized
DEBUG - 2014-08-14 18:51:45 --> Router Class Initialized
DEBUG - 2014-08-14 18:51:45 --> Output Class Initialized
DEBUG - 2014-08-14 18:51:45 --> Security Class Initialized
DEBUG - 2014-08-14 18:51:45 --> Input Class Initialized
DEBUG - 2014-08-14 18:51:45 --> XSS Filtering completed
DEBUG - 2014-08-14 18:51:46 --> XSS Filtering completed
DEBUG - 2014-08-14 18:51:46 --> XSS Filtering completed
DEBUG - 2014-08-14 18:51:46 --> XSS Filtering completed
DEBUG - 2014-08-14 18:51:46 --> CRSF cookie Set
DEBUG - 2014-08-14 18:51:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 18:51:46 --> Language Class Initialized
DEBUG - 2014-08-14 18:51:46 --> Loader Class Initialized
DEBUG - 2014-08-14 18:51:46 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 18:51:46 --> Helper loaded: url_helper
DEBUG - 2014-08-14 18:51:46 --> Database Driver Class Initialized
ERROR - 2014-08-14 18:51:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 18:51:46 --> Session Class Initialized
DEBUG - 2014-08-14 18:51:46 --> Helper loaded: string_helper
DEBUG - 2014-08-14 18:51:46 --> Session routines successfully run
DEBUG - 2014-08-14 18:51:46 --> Controller Class Initialized
DEBUG - 2014-08-14 18:51:46 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 18:51:46 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 18:51:46 --> Encrypt Class Initialized
DEBUG - 2014-08-14 18:51:46 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-14 18:51:46 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-14 18:51:46 --> File loaded: application/views/placement_admin_home.php
DEBUG - 2014-08-14 18:51:46 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 18:51:46 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 18:51:46 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 18:51:46 --> Final output sent to browser
DEBUG - 2014-08-14 18:51:46 --> Total execution time: 0.1423
DEBUG - 2014-08-14 18:51:48 --> Config Class Initialized
DEBUG - 2014-08-14 18:51:48 --> Hooks Class Initialized
DEBUG - 2014-08-14 18:51:48 --> Utf8 Class Initialized
DEBUG - 2014-08-14 18:51:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 18:51:48 --> URI Class Initialized
DEBUG - 2014-08-14 18:51:48 --> Router Class Initialized
DEBUG - 2014-08-14 18:51:48 --> Output Class Initialized
DEBUG - 2014-08-14 18:51:48 --> Security Class Initialized
DEBUG - 2014-08-14 18:51:48 --> Input Class Initialized
DEBUG - 2014-08-14 18:51:48 --> XSS Filtering completed
DEBUG - 2014-08-14 18:51:48 --> XSS Filtering completed
DEBUG - 2014-08-14 18:51:48 --> XSS Filtering completed
DEBUG - 2014-08-14 18:51:48 --> XSS Filtering completed
DEBUG - 2014-08-14 18:51:48 --> CRSF cookie Set
DEBUG - 2014-08-14 18:51:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 18:51:48 --> Language Class Initialized
DEBUG - 2014-08-14 18:51:48 --> Loader Class Initialized
DEBUG - 2014-08-14 18:51:48 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 18:51:48 --> Helper loaded: url_helper
DEBUG - 2014-08-14 18:51:48 --> Database Driver Class Initialized
ERROR - 2014-08-14 18:51:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 18:51:48 --> Session Class Initialized
DEBUG - 2014-08-14 18:51:48 --> Helper loaded: string_helper
DEBUG - 2014-08-14 18:51:48 --> Session routines successfully run
DEBUG - 2014-08-14 18:51:48 --> Controller Class Initialized
DEBUG - 2014-08-14 18:51:48 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 18:51:48 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 18:51:48 --> Encrypt Class Initialized
DEBUG - 2014-08-14 18:51:48 --> Model Class Initialized
DEBUG - 2014-08-14 18:51:48 --> Model Class Initialized
DEBUG - 2014-08-14 18:51:48 --> Model Class Initialized
DEBUG - 2014-08-14 18:51:48 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 18:51:48 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 18:51:48 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 18:51:48 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 18:51:48 --> Final output sent to browser
DEBUG - 2014-08-14 18:51:48 --> Total execution time: 0.1060
DEBUG - 2014-08-14 19:02:46 --> Config Class Initialized
DEBUG - 2014-08-14 19:02:46 --> Hooks Class Initialized
DEBUG - 2014-08-14 19:02:46 --> Utf8 Class Initialized
DEBUG - 2014-08-14 19:02:46 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 19:02:46 --> URI Class Initialized
DEBUG - 2014-08-14 19:02:46 --> Router Class Initialized
DEBUG - 2014-08-14 19:02:46 --> Output Class Initialized
DEBUG - 2014-08-14 19:02:46 --> Security Class Initialized
DEBUG - 2014-08-14 19:02:46 --> Input Class Initialized
DEBUG - 2014-08-14 19:02:46 --> XSS Filtering completed
DEBUG - 2014-08-14 19:02:46 --> XSS Filtering completed
DEBUG - 2014-08-14 19:02:46 --> XSS Filtering completed
DEBUG - 2014-08-14 19:02:46 --> XSS Filtering completed
DEBUG - 2014-08-14 19:02:46 --> CRSF cookie Set
DEBUG - 2014-08-14 19:02:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 19:02:46 --> Language Class Initialized
DEBUG - 2014-08-14 19:02:46 --> Loader Class Initialized
DEBUG - 2014-08-14 19:02:46 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 19:02:46 --> Helper loaded: url_helper
DEBUG - 2014-08-14 19:02:46 --> Database Driver Class Initialized
ERROR - 2014-08-14 19:02:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 19:02:46 --> Session Class Initialized
DEBUG - 2014-08-14 19:02:46 --> Helper loaded: string_helper
DEBUG - 2014-08-14 19:02:46 --> Session routines successfully run
DEBUG - 2014-08-14 19:02:46 --> Controller Class Initialized
DEBUG - 2014-08-14 19:02:46 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 19:02:46 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 19:02:46 --> Encrypt Class Initialized
DEBUG - 2014-08-14 19:02:46 --> Model Class Initialized
DEBUG - 2014-08-14 19:02:46 --> Model Class Initialized
DEBUG - 2014-08-14 19:02:46 --> Model Class Initialized
DEBUG - 2014-08-14 19:02:46 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 19:02:46 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 19:02:46 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 19:02:46 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 19:02:46 --> Final output sent to browser
DEBUG - 2014-08-14 19:02:46 --> Total execution time: 0.1158
DEBUG - 2014-08-14 19:02:52 --> Config Class Initialized
DEBUG - 2014-08-14 19:02:52 --> Hooks Class Initialized
DEBUG - 2014-08-14 19:02:52 --> Utf8 Class Initialized
DEBUG - 2014-08-14 19:02:52 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 19:02:52 --> URI Class Initialized
DEBUG - 2014-08-14 19:02:52 --> Router Class Initialized
DEBUG - 2014-08-14 19:02:52 --> Output Class Initialized
DEBUG - 2014-08-14 19:02:52 --> Security Class Initialized
DEBUG - 2014-08-14 19:02:52 --> Input Class Initialized
DEBUG - 2014-08-14 19:02:52 --> XSS Filtering completed
DEBUG - 2014-08-14 19:02:52 --> XSS Filtering completed
DEBUG - 2014-08-14 19:02:52 --> XSS Filtering completed
DEBUG - 2014-08-14 19:02:52 --> XSS Filtering completed
DEBUG - 2014-08-14 19:02:52 --> CRSF cookie Set
DEBUG - 2014-08-14 19:02:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 19:02:52 --> Language Class Initialized
DEBUG - 2014-08-14 19:02:52 --> Loader Class Initialized
DEBUG - 2014-08-14 19:02:52 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 19:02:52 --> Helper loaded: url_helper
DEBUG - 2014-08-14 19:02:52 --> Database Driver Class Initialized
ERROR - 2014-08-14 19:02:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 19:02:52 --> Session Class Initialized
DEBUG - 2014-08-14 19:02:52 --> Helper loaded: string_helper
DEBUG - 2014-08-14 19:02:52 --> Session routines successfully run
DEBUG - 2014-08-14 19:02:52 --> Controller Class Initialized
DEBUG - 2014-08-14 19:02:52 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 19:02:52 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 19:02:52 --> Encrypt Class Initialized
DEBUG - 2014-08-14 19:02:52 --> Model Class Initialized
DEBUG - 2014-08-14 19:02:52 --> Model Class Initialized
DEBUG - 2014-08-14 19:02:52 --> Model Class Initialized
DEBUG - 2014-08-14 19:02:52 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 19:02:52 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 19:02:52 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 19:02:52 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 19:02:52 --> Final output sent to browser
DEBUG - 2014-08-14 19:02:52 --> Total execution time: 0.1736
DEBUG - 2014-08-14 19:03:41 --> Config Class Initialized
DEBUG - 2014-08-14 19:03:41 --> Hooks Class Initialized
DEBUG - 2014-08-14 19:03:41 --> Utf8 Class Initialized
DEBUG - 2014-08-14 19:03:41 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 19:03:41 --> URI Class Initialized
DEBUG - 2014-08-14 19:03:41 --> Router Class Initialized
DEBUG - 2014-08-14 19:03:41 --> Output Class Initialized
DEBUG - 2014-08-14 19:03:41 --> Security Class Initialized
DEBUG - 2014-08-14 19:03:41 --> Input Class Initialized
DEBUG - 2014-08-14 19:03:41 --> XSS Filtering completed
DEBUG - 2014-08-14 19:03:41 --> XSS Filtering completed
DEBUG - 2014-08-14 19:03:41 --> XSS Filtering completed
DEBUG - 2014-08-14 19:03:41 --> XSS Filtering completed
DEBUG - 2014-08-14 19:03:41 --> CRSF cookie Set
DEBUG - 2014-08-14 19:03:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 19:03:41 --> Language Class Initialized
DEBUG - 2014-08-14 19:03:41 --> Loader Class Initialized
DEBUG - 2014-08-14 19:03:41 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 19:03:41 --> Helper loaded: url_helper
DEBUG - 2014-08-14 19:03:41 --> Database Driver Class Initialized
ERROR - 2014-08-14 19:03:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 19:03:41 --> Session Class Initialized
DEBUG - 2014-08-14 19:03:41 --> Helper loaded: string_helper
DEBUG - 2014-08-14 19:03:41 --> Session routines successfully run
DEBUG - 2014-08-14 19:03:41 --> Controller Class Initialized
DEBUG - 2014-08-14 19:03:41 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 19:03:41 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 19:03:41 --> Encrypt Class Initialized
DEBUG - 2014-08-14 19:03:41 --> Model Class Initialized
DEBUG - 2014-08-14 19:03:41 --> Model Class Initialized
DEBUG - 2014-08-14 19:03:41 --> Model Class Initialized
DEBUG - 2014-08-14 19:03:41 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 19:03:41 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 19:03:41 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 19:03:41 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 19:03:41 --> Final output sent to browser
DEBUG - 2014-08-14 19:03:41 --> Total execution time: 0.1173
DEBUG - 2014-08-14 19:06:16 --> Config Class Initialized
DEBUG - 2014-08-14 19:06:16 --> Hooks Class Initialized
DEBUG - 2014-08-14 19:06:16 --> Utf8 Class Initialized
DEBUG - 2014-08-14 19:06:16 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 19:06:16 --> URI Class Initialized
DEBUG - 2014-08-14 19:06:16 --> Router Class Initialized
DEBUG - 2014-08-14 19:06:16 --> Output Class Initialized
DEBUG - 2014-08-14 19:06:16 --> Security Class Initialized
DEBUG - 2014-08-14 19:06:16 --> Input Class Initialized
DEBUG - 2014-08-14 19:06:16 --> XSS Filtering completed
DEBUG - 2014-08-14 19:06:16 --> XSS Filtering completed
DEBUG - 2014-08-14 19:06:16 --> XSS Filtering completed
DEBUG - 2014-08-14 19:06:16 --> XSS Filtering completed
DEBUG - 2014-08-14 19:06:16 --> CRSF cookie Set
DEBUG - 2014-08-14 19:06:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 19:06:16 --> Language Class Initialized
DEBUG - 2014-08-14 19:06:16 --> Loader Class Initialized
DEBUG - 2014-08-14 19:06:16 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 19:06:16 --> Helper loaded: url_helper
DEBUG - 2014-08-14 19:06:16 --> Database Driver Class Initialized
ERROR - 2014-08-14 19:06:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 19:06:16 --> Session Class Initialized
DEBUG - 2014-08-14 19:06:16 --> Helper loaded: string_helper
DEBUG - 2014-08-14 19:06:16 --> Session routines successfully run
DEBUG - 2014-08-14 19:06:16 --> Controller Class Initialized
DEBUG - 2014-08-14 19:06:16 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 19:06:16 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 19:06:16 --> Encrypt Class Initialized
DEBUG - 2014-08-14 19:06:16 --> Model Class Initialized
DEBUG - 2014-08-14 19:06:16 --> Model Class Initialized
DEBUG - 2014-08-14 19:06:16 --> Model Class Initialized
DEBUG - 2014-08-14 19:06:16 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 19:06:16 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 19:06:16 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 19:06:16 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 19:06:16 --> Final output sent to browser
DEBUG - 2014-08-14 19:06:16 --> Total execution time: 0.1631
DEBUG - 2014-08-14 19:08:32 --> Config Class Initialized
DEBUG - 2014-08-14 19:08:32 --> Hooks Class Initialized
DEBUG - 2014-08-14 19:08:32 --> Utf8 Class Initialized
DEBUG - 2014-08-14 19:08:32 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 19:08:32 --> URI Class Initialized
DEBUG - 2014-08-14 19:08:32 --> Router Class Initialized
DEBUG - 2014-08-14 19:08:32 --> Output Class Initialized
DEBUG - 2014-08-14 19:08:32 --> Security Class Initialized
DEBUG - 2014-08-14 19:08:32 --> Input Class Initialized
DEBUG - 2014-08-14 19:08:32 --> XSS Filtering completed
DEBUG - 2014-08-14 19:08:32 --> XSS Filtering completed
DEBUG - 2014-08-14 19:08:32 --> XSS Filtering completed
DEBUG - 2014-08-14 19:08:32 --> XSS Filtering completed
DEBUG - 2014-08-14 19:08:32 --> CRSF cookie Set
DEBUG - 2014-08-14 19:08:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 19:08:32 --> Language Class Initialized
DEBUG - 2014-08-14 19:08:32 --> Loader Class Initialized
DEBUG - 2014-08-14 19:08:32 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 19:08:32 --> Helper loaded: url_helper
DEBUG - 2014-08-14 19:08:32 --> Database Driver Class Initialized
ERROR - 2014-08-14 19:08:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 19:08:32 --> Session Class Initialized
DEBUG - 2014-08-14 19:08:32 --> Helper loaded: string_helper
DEBUG - 2014-08-14 19:08:32 --> Session routines successfully run
DEBUG - 2014-08-14 19:08:32 --> Controller Class Initialized
DEBUG - 2014-08-14 19:08:32 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 19:08:32 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 19:08:32 --> Encrypt Class Initialized
DEBUG - 2014-08-14 19:08:32 --> Model Class Initialized
DEBUG - 2014-08-14 19:08:32 --> Model Class Initialized
DEBUG - 2014-08-14 19:08:32 --> Model Class Initialized
DEBUG - 2014-08-14 19:08:32 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 19:08:32 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 19:08:32 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 19:08:32 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 19:08:32 --> Final output sent to browser
DEBUG - 2014-08-14 19:08:32 --> Total execution time: 0.1443
DEBUG - 2014-08-14 19:08:40 --> Config Class Initialized
DEBUG - 2014-08-14 19:08:40 --> Hooks Class Initialized
DEBUG - 2014-08-14 19:08:40 --> Utf8 Class Initialized
DEBUG - 2014-08-14 19:08:40 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 19:08:40 --> URI Class Initialized
DEBUG - 2014-08-14 19:08:40 --> Router Class Initialized
DEBUG - 2014-08-14 19:08:40 --> Output Class Initialized
DEBUG - 2014-08-14 19:08:40 --> Security Class Initialized
DEBUG - 2014-08-14 19:08:40 --> Input Class Initialized
DEBUG - 2014-08-14 19:08:40 --> XSS Filtering completed
DEBUG - 2014-08-14 19:08:40 --> XSS Filtering completed
DEBUG - 2014-08-14 19:08:40 --> XSS Filtering completed
DEBUG - 2014-08-14 19:08:40 --> XSS Filtering completed
DEBUG - 2014-08-14 19:08:40 --> CRSF cookie Set
DEBUG - 2014-08-14 19:08:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 19:08:40 --> Language Class Initialized
DEBUG - 2014-08-14 19:08:40 --> Loader Class Initialized
DEBUG - 2014-08-14 19:08:40 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 19:08:40 --> Helper loaded: url_helper
DEBUG - 2014-08-14 19:08:40 --> Database Driver Class Initialized
ERROR - 2014-08-14 19:08:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 19:08:40 --> Session Class Initialized
DEBUG - 2014-08-14 19:08:40 --> Helper loaded: string_helper
DEBUG - 2014-08-14 19:08:40 --> Session routines successfully run
DEBUG - 2014-08-14 19:08:40 --> Controller Class Initialized
DEBUG - 2014-08-14 19:08:40 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 19:08:40 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 19:08:40 --> Encrypt Class Initialized
DEBUG - 2014-08-14 19:08:40 --> Model Class Initialized
DEBUG - 2014-08-14 19:08:40 --> Model Class Initialized
DEBUG - 2014-08-14 19:08:40 --> Model Class Initialized
DEBUG - 2014-08-14 19:08:40 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 19:08:40 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 19:08:40 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 19:08:40 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 19:08:40 --> Final output sent to browser
DEBUG - 2014-08-14 19:08:40 --> Total execution time: 0.2210
DEBUG - 2014-08-14 19:15:32 --> Config Class Initialized
DEBUG - 2014-08-14 19:15:32 --> Hooks Class Initialized
DEBUG - 2014-08-14 19:15:32 --> Utf8 Class Initialized
DEBUG - 2014-08-14 19:15:32 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 19:15:32 --> URI Class Initialized
DEBUG - 2014-08-14 19:15:32 --> Router Class Initialized
DEBUG - 2014-08-14 19:15:32 --> Output Class Initialized
DEBUG - 2014-08-14 19:15:32 --> Security Class Initialized
DEBUG - 2014-08-14 19:15:32 --> Input Class Initialized
DEBUG - 2014-08-14 19:15:32 --> XSS Filtering completed
DEBUG - 2014-08-14 19:15:32 --> XSS Filtering completed
DEBUG - 2014-08-14 19:15:32 --> XSS Filtering completed
DEBUG - 2014-08-14 19:15:32 --> XSS Filtering completed
DEBUG - 2014-08-14 19:15:32 --> CRSF cookie Set
DEBUG - 2014-08-14 19:15:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 19:15:32 --> Language Class Initialized
DEBUG - 2014-08-14 19:15:32 --> Loader Class Initialized
DEBUG - 2014-08-14 19:15:32 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 19:15:32 --> Helper loaded: url_helper
DEBUG - 2014-08-14 19:15:32 --> Database Driver Class Initialized
ERROR - 2014-08-14 19:15:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 19:15:32 --> Session Class Initialized
DEBUG - 2014-08-14 19:15:32 --> Helper loaded: string_helper
DEBUG - 2014-08-14 19:15:32 --> Session routines successfully run
DEBUG - 2014-08-14 19:15:32 --> Controller Class Initialized
DEBUG - 2014-08-14 19:15:32 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 19:15:32 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 19:15:32 --> Encrypt Class Initialized
DEBUG - 2014-08-14 19:15:32 --> Model Class Initialized
DEBUG - 2014-08-14 19:15:32 --> Model Class Initialized
DEBUG - 2014-08-14 19:15:32 --> Model Class Initialized
DEBUG - 2014-08-14 19:15:53 --> Config Class Initialized
DEBUG - 2014-08-14 19:15:53 --> Hooks Class Initialized
DEBUG - 2014-08-14 19:15:53 --> Utf8 Class Initialized
DEBUG - 2014-08-14 19:15:53 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 19:15:53 --> URI Class Initialized
DEBUG - 2014-08-14 19:15:53 --> Router Class Initialized
DEBUG - 2014-08-14 19:15:53 --> Output Class Initialized
DEBUG - 2014-08-14 19:15:53 --> Security Class Initialized
DEBUG - 2014-08-14 19:15:53 --> Input Class Initialized
DEBUG - 2014-08-14 19:15:53 --> XSS Filtering completed
DEBUG - 2014-08-14 19:15:53 --> XSS Filtering completed
DEBUG - 2014-08-14 19:15:53 --> XSS Filtering completed
DEBUG - 2014-08-14 19:15:53 --> XSS Filtering completed
DEBUG - 2014-08-14 19:15:53 --> CRSF cookie Set
DEBUG - 2014-08-14 19:15:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 19:15:53 --> Language Class Initialized
DEBUG - 2014-08-14 19:15:53 --> Loader Class Initialized
DEBUG - 2014-08-14 19:15:53 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 19:15:53 --> Helper loaded: url_helper
DEBUG - 2014-08-14 19:15:53 --> Database Driver Class Initialized
ERROR - 2014-08-14 19:15:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 19:15:53 --> Session Class Initialized
DEBUG - 2014-08-14 19:15:53 --> Helper loaded: string_helper
DEBUG - 2014-08-14 19:15:53 --> Session routines successfully run
DEBUG - 2014-08-14 19:15:53 --> Controller Class Initialized
DEBUG - 2014-08-14 19:15:53 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 19:15:53 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 19:15:53 --> Encrypt Class Initialized
DEBUG - 2014-08-14 19:15:53 --> Model Class Initialized
DEBUG - 2014-08-14 19:15:53 --> Model Class Initialized
DEBUG - 2014-08-14 19:15:53 --> Model Class Initialized
DEBUG - 2014-08-14 19:17:18 --> Config Class Initialized
DEBUG - 2014-08-14 19:17:18 --> Hooks Class Initialized
DEBUG - 2014-08-14 19:17:18 --> Utf8 Class Initialized
DEBUG - 2014-08-14 19:17:18 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 19:17:18 --> URI Class Initialized
DEBUG - 2014-08-14 19:17:18 --> Router Class Initialized
DEBUG - 2014-08-14 19:17:18 --> Output Class Initialized
DEBUG - 2014-08-14 19:17:18 --> Security Class Initialized
DEBUG - 2014-08-14 19:17:18 --> Input Class Initialized
DEBUG - 2014-08-14 19:17:18 --> XSS Filtering completed
DEBUG - 2014-08-14 19:17:18 --> XSS Filtering completed
DEBUG - 2014-08-14 19:17:18 --> XSS Filtering completed
DEBUG - 2014-08-14 19:17:18 --> XSS Filtering completed
DEBUG - 2014-08-14 19:17:18 --> CRSF cookie Set
DEBUG - 2014-08-14 19:17:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 19:17:18 --> Language Class Initialized
DEBUG - 2014-08-14 19:17:18 --> Loader Class Initialized
DEBUG - 2014-08-14 19:17:18 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 19:17:18 --> Helper loaded: url_helper
DEBUG - 2014-08-14 19:17:19 --> Database Driver Class Initialized
ERROR - 2014-08-14 19:17:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 19:17:19 --> Session Class Initialized
DEBUG - 2014-08-14 19:17:19 --> Helper loaded: string_helper
DEBUG - 2014-08-14 19:17:19 --> Session routines successfully run
DEBUG - 2014-08-14 19:17:19 --> Controller Class Initialized
DEBUG - 2014-08-14 19:17:19 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 19:17:19 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 19:17:19 --> Encrypt Class Initialized
DEBUG - 2014-08-14 19:17:19 --> Model Class Initialized
DEBUG - 2014-08-14 19:17:19 --> Model Class Initialized
DEBUG - 2014-08-14 19:17:19 --> Model Class Initialized
ERROR - 2014-08-14 19:17:19 --> Severity: Notice  --> Use of undefined constant username - assumed 'username' C:\wamp\www\cep\placement\application\views\placement_admin_verify.php 42
ERROR - 2014-08-14 19:17:19 --> Severity: Notice  --> Use of undefined constant username - assumed 'username' C:\wamp\www\cep\placement\application\views\placement_admin_verify.php 43
DEBUG - 2014-08-14 19:17:19 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 19:17:19 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 19:17:19 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 19:17:19 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 19:17:19 --> Final output sent to browser
DEBUG - 2014-08-14 19:17:19 --> Total execution time: 0.1483
DEBUG - 2014-08-14 19:17:46 --> Config Class Initialized
DEBUG - 2014-08-14 19:17:46 --> Hooks Class Initialized
DEBUG - 2014-08-14 19:17:46 --> Utf8 Class Initialized
DEBUG - 2014-08-14 19:17:46 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 19:17:46 --> URI Class Initialized
DEBUG - 2014-08-14 19:17:46 --> Router Class Initialized
DEBUG - 2014-08-14 19:17:46 --> Output Class Initialized
DEBUG - 2014-08-14 19:17:46 --> Security Class Initialized
DEBUG - 2014-08-14 19:17:46 --> Input Class Initialized
DEBUG - 2014-08-14 19:17:46 --> XSS Filtering completed
DEBUG - 2014-08-14 19:17:46 --> XSS Filtering completed
DEBUG - 2014-08-14 19:17:46 --> XSS Filtering completed
DEBUG - 2014-08-14 19:17:46 --> XSS Filtering completed
DEBUG - 2014-08-14 19:17:46 --> CRSF cookie Set
DEBUG - 2014-08-14 19:17:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 19:17:46 --> Language Class Initialized
DEBUG - 2014-08-14 19:17:46 --> Loader Class Initialized
DEBUG - 2014-08-14 19:17:46 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 19:17:46 --> Helper loaded: url_helper
DEBUG - 2014-08-14 19:17:46 --> Database Driver Class Initialized
ERROR - 2014-08-14 19:17:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 19:17:46 --> Session Class Initialized
DEBUG - 2014-08-14 19:17:46 --> Helper loaded: string_helper
DEBUG - 2014-08-14 19:17:46 --> Session routines successfully run
DEBUG - 2014-08-14 19:17:46 --> Controller Class Initialized
DEBUG - 2014-08-14 19:17:46 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 19:17:46 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 19:17:46 --> Encrypt Class Initialized
DEBUG - 2014-08-14 19:17:46 --> Model Class Initialized
DEBUG - 2014-08-14 19:17:46 --> Model Class Initialized
DEBUG - 2014-08-14 19:17:46 --> Model Class Initialized
DEBUG - 2014-08-14 19:17:47 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 19:17:47 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 19:17:47 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 19:17:47 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 19:17:47 --> Final output sent to browser
DEBUG - 2014-08-14 19:17:47 --> Total execution time: 0.1445
DEBUG - 2014-08-14 19:17:51 --> Config Class Initialized
DEBUG - 2014-08-14 19:17:51 --> Hooks Class Initialized
DEBUG - 2014-08-14 19:17:51 --> Utf8 Class Initialized
DEBUG - 2014-08-14 19:17:51 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 19:17:51 --> URI Class Initialized
DEBUG - 2014-08-14 19:17:51 --> Router Class Initialized
DEBUG - 2014-08-14 19:17:51 --> Output Class Initialized
DEBUG - 2014-08-14 19:17:51 --> Security Class Initialized
DEBUG - 2014-08-14 19:17:51 --> Input Class Initialized
DEBUG - 2014-08-14 19:17:51 --> XSS Filtering completed
DEBUG - 2014-08-14 19:17:51 --> XSS Filtering completed
DEBUG - 2014-08-14 19:17:51 --> XSS Filtering completed
DEBUG - 2014-08-14 19:17:51 --> XSS Filtering completed
DEBUG - 2014-08-14 19:17:51 --> CRSF cookie Set
DEBUG - 2014-08-14 19:17:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 19:17:51 --> Language Class Initialized
DEBUG - 2014-08-14 19:17:51 --> Loader Class Initialized
DEBUG - 2014-08-14 19:17:51 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 19:17:51 --> Helper loaded: url_helper
DEBUG - 2014-08-14 19:17:51 --> Database Driver Class Initialized
ERROR - 2014-08-14 19:17:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 19:17:52 --> Session Class Initialized
DEBUG - 2014-08-14 19:17:52 --> Helper loaded: string_helper
DEBUG - 2014-08-14 19:17:52 --> Session routines successfully run
DEBUG - 2014-08-14 19:17:52 --> Controller Class Initialized
DEBUG - 2014-08-14 19:17:52 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 19:17:52 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 19:17:52 --> Encrypt Class Initialized
DEBUG - 2014-08-14 19:17:52 --> Model Class Initialized
DEBUG - 2014-08-14 19:17:52 --> Model Class Initialized
DEBUG - 2014-08-14 19:17:52 --> Model Class Initialized
DEBUG - 2014-08-14 19:17:52 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 19:17:52 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 19:17:52 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 19:17:52 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 19:17:52 --> Final output sent to browser
DEBUG - 2014-08-14 19:17:52 --> Total execution time: 0.2374
DEBUG - 2014-08-14 19:19:21 --> Config Class Initialized
DEBUG - 2014-08-14 19:19:21 --> Hooks Class Initialized
DEBUG - 2014-08-14 19:19:21 --> Utf8 Class Initialized
DEBUG - 2014-08-14 19:19:21 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 19:19:21 --> URI Class Initialized
DEBUG - 2014-08-14 19:19:21 --> Router Class Initialized
DEBUG - 2014-08-14 19:19:21 --> Output Class Initialized
DEBUG - 2014-08-14 19:19:21 --> Security Class Initialized
DEBUG - 2014-08-14 19:19:21 --> Input Class Initialized
DEBUG - 2014-08-14 19:19:21 --> XSS Filtering completed
DEBUG - 2014-08-14 19:19:21 --> XSS Filtering completed
DEBUG - 2014-08-14 19:19:21 --> XSS Filtering completed
DEBUG - 2014-08-14 19:19:21 --> XSS Filtering completed
DEBUG - 2014-08-14 19:19:21 --> CRSF cookie Set
DEBUG - 2014-08-14 19:19:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 19:19:21 --> Language Class Initialized
DEBUG - 2014-08-14 19:19:21 --> Loader Class Initialized
DEBUG - 2014-08-14 19:19:21 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 19:19:21 --> Helper loaded: url_helper
DEBUG - 2014-08-14 19:19:21 --> Database Driver Class Initialized
ERROR - 2014-08-14 19:19:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 19:19:21 --> Session Class Initialized
DEBUG - 2014-08-14 19:19:21 --> Helper loaded: string_helper
DEBUG - 2014-08-14 19:19:21 --> Session routines successfully run
DEBUG - 2014-08-14 19:19:21 --> Controller Class Initialized
DEBUG - 2014-08-14 19:19:21 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 19:19:21 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 19:19:21 --> Encrypt Class Initialized
DEBUG - 2014-08-14 19:19:21 --> Model Class Initialized
DEBUG - 2014-08-14 19:19:21 --> Model Class Initialized
DEBUG - 2014-08-14 19:19:21 --> Model Class Initialized
DEBUG - 2014-08-14 19:19:21 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 19:19:21 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 19:19:21 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 19:19:21 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 19:19:21 --> Final output sent to browser
DEBUG - 2014-08-14 19:19:21 --> Total execution time: 0.1448
DEBUG - 2014-08-14 19:23:53 --> Config Class Initialized
DEBUG - 2014-08-14 19:23:53 --> Hooks Class Initialized
DEBUG - 2014-08-14 19:23:53 --> Utf8 Class Initialized
DEBUG - 2014-08-14 19:23:53 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 19:23:53 --> URI Class Initialized
DEBUG - 2014-08-14 19:23:53 --> Router Class Initialized
DEBUG - 2014-08-14 19:23:53 --> Output Class Initialized
DEBUG - 2014-08-14 19:23:53 --> Security Class Initialized
DEBUG - 2014-08-14 19:23:53 --> Input Class Initialized
DEBUG - 2014-08-14 19:23:53 --> XSS Filtering completed
DEBUG - 2014-08-14 19:23:53 --> XSS Filtering completed
DEBUG - 2014-08-14 19:23:53 --> XSS Filtering completed
DEBUG - 2014-08-14 19:23:53 --> XSS Filtering completed
DEBUG - 2014-08-14 19:23:53 --> CRSF cookie Set
DEBUG - 2014-08-14 19:23:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 19:23:53 --> Language Class Initialized
DEBUG - 2014-08-14 19:23:53 --> Loader Class Initialized
DEBUG - 2014-08-14 19:23:53 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 19:23:53 --> Helper loaded: url_helper
DEBUG - 2014-08-14 19:23:53 --> Database Driver Class Initialized
ERROR - 2014-08-14 19:23:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 19:23:53 --> Session Class Initialized
DEBUG - 2014-08-14 19:23:53 --> Helper loaded: string_helper
DEBUG - 2014-08-14 19:23:53 --> Session routines successfully run
DEBUG - 2014-08-14 19:23:53 --> Controller Class Initialized
DEBUG - 2014-08-14 19:23:53 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 19:23:53 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 19:23:53 --> Encrypt Class Initialized
DEBUG - 2014-08-14 19:23:53 --> Model Class Initialized
DEBUG - 2014-08-14 19:23:53 --> Model Class Initialized
DEBUG - 2014-08-14 19:23:53 --> Model Class Initialized
DEBUG - 2014-08-14 19:23:53 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 19:23:53 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 19:23:53 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 19:23:53 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 19:23:53 --> Final output sent to browser
DEBUG - 2014-08-14 19:23:53 --> Total execution time: 0.1474
DEBUG - 2014-08-14 19:24:00 --> Config Class Initialized
DEBUG - 2014-08-14 19:24:00 --> Hooks Class Initialized
DEBUG - 2014-08-14 19:24:00 --> Utf8 Class Initialized
DEBUG - 2014-08-14 19:24:00 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 19:24:00 --> URI Class Initialized
DEBUG - 2014-08-14 19:24:00 --> Router Class Initialized
DEBUG - 2014-08-14 19:24:00 --> Output Class Initialized
DEBUG - 2014-08-14 19:24:00 --> Security Class Initialized
DEBUG - 2014-08-14 19:24:00 --> Input Class Initialized
DEBUG - 2014-08-14 19:24:00 --> XSS Filtering completed
DEBUG - 2014-08-14 19:24:00 --> XSS Filtering completed
DEBUG - 2014-08-14 19:24:00 --> XSS Filtering completed
DEBUG - 2014-08-14 19:24:00 --> XSS Filtering completed
DEBUG - 2014-08-14 19:24:00 --> CRSF cookie Set
DEBUG - 2014-08-14 19:24:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 19:24:00 --> Language Class Initialized
DEBUG - 2014-08-14 19:24:00 --> Loader Class Initialized
DEBUG - 2014-08-14 19:24:00 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 19:24:00 --> Helper loaded: url_helper
DEBUG - 2014-08-14 19:24:00 --> Database Driver Class Initialized
ERROR - 2014-08-14 19:24:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 19:24:00 --> Session Class Initialized
DEBUG - 2014-08-14 19:24:00 --> Helper loaded: string_helper
DEBUG - 2014-08-14 19:24:00 --> Session routines successfully run
DEBUG - 2014-08-14 19:24:00 --> Controller Class Initialized
DEBUG - 2014-08-14 19:24:00 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 19:24:00 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 19:24:00 --> Encrypt Class Initialized
DEBUG - 2014-08-14 19:24:00 --> Model Class Initialized
DEBUG - 2014-08-14 19:24:00 --> Model Class Initialized
DEBUG - 2014-08-14 19:24:00 --> Model Class Initialized
DEBUG - 2014-08-14 19:24:00 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 19:24:00 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 19:24:00 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 19:24:00 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 19:24:00 --> Final output sent to browser
DEBUG - 2014-08-14 19:24:00 --> Total execution time: 0.1968
DEBUG - 2014-08-14 19:24:30 --> Config Class Initialized
DEBUG - 2014-08-14 19:24:30 --> Hooks Class Initialized
DEBUG - 2014-08-14 19:24:30 --> Utf8 Class Initialized
DEBUG - 2014-08-14 19:24:30 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 19:24:30 --> URI Class Initialized
DEBUG - 2014-08-14 19:24:30 --> Router Class Initialized
DEBUG - 2014-08-14 19:24:30 --> Output Class Initialized
DEBUG - 2014-08-14 19:24:30 --> Security Class Initialized
DEBUG - 2014-08-14 19:24:30 --> Input Class Initialized
DEBUG - 2014-08-14 19:24:30 --> XSS Filtering completed
DEBUG - 2014-08-14 19:24:30 --> XSS Filtering completed
DEBUG - 2014-08-14 19:24:30 --> XSS Filtering completed
DEBUG - 2014-08-14 19:24:30 --> XSS Filtering completed
DEBUG - 2014-08-14 19:24:30 --> CRSF cookie Set
DEBUG - 2014-08-14 19:24:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 19:24:30 --> Language Class Initialized
DEBUG - 2014-08-14 19:24:30 --> Loader Class Initialized
DEBUG - 2014-08-14 19:24:30 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 19:24:30 --> Helper loaded: url_helper
DEBUG - 2014-08-14 19:24:30 --> Database Driver Class Initialized
ERROR - 2014-08-14 19:24:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 19:24:30 --> Session Class Initialized
DEBUG - 2014-08-14 19:24:30 --> Helper loaded: string_helper
DEBUG - 2014-08-14 19:24:30 --> Session routines successfully run
DEBUG - 2014-08-14 19:24:30 --> Controller Class Initialized
DEBUG - 2014-08-14 19:24:30 --> Final output sent to browser
DEBUG - 2014-08-14 19:24:30 --> Total execution time: 0.0796
DEBUG - 2014-08-14 19:28:13 --> Config Class Initialized
DEBUG - 2014-08-14 19:28:13 --> Hooks Class Initialized
DEBUG - 2014-08-14 19:28:13 --> Utf8 Class Initialized
DEBUG - 2014-08-14 19:28:13 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 19:28:13 --> URI Class Initialized
DEBUG - 2014-08-14 19:28:13 --> Router Class Initialized
DEBUG - 2014-08-14 19:28:13 --> Output Class Initialized
DEBUG - 2014-08-14 19:28:13 --> Security Class Initialized
DEBUG - 2014-08-14 19:28:13 --> Input Class Initialized
DEBUG - 2014-08-14 19:28:13 --> XSS Filtering completed
DEBUG - 2014-08-14 19:28:13 --> XSS Filtering completed
DEBUG - 2014-08-14 19:28:13 --> XSS Filtering completed
DEBUG - 2014-08-14 19:28:13 --> XSS Filtering completed
DEBUG - 2014-08-14 19:28:13 --> CRSF cookie Set
DEBUG - 2014-08-14 19:28:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 19:28:13 --> Language Class Initialized
DEBUG - 2014-08-14 19:28:13 --> Loader Class Initialized
DEBUG - 2014-08-14 19:28:13 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 19:28:13 --> Helper loaded: url_helper
DEBUG - 2014-08-14 19:28:13 --> Database Driver Class Initialized
ERROR - 2014-08-14 19:28:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 19:28:13 --> Session Class Initialized
DEBUG - 2014-08-14 19:28:13 --> Helper loaded: string_helper
DEBUG - 2014-08-14 19:28:13 --> Session routines successfully run
DEBUG - 2014-08-14 19:28:13 --> Controller Class Initialized
DEBUG - 2014-08-14 19:28:13 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 19:28:13 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 19:28:13 --> Encrypt Class Initialized
DEBUG - 2014-08-14 19:28:13 --> Model Class Initialized
DEBUG - 2014-08-14 19:28:13 --> Model Class Initialized
DEBUG - 2014-08-14 19:28:13 --> Model Class Initialized
DEBUG - 2014-08-14 19:28:13 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 19:28:13 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 19:28:13 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 19:28:13 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 19:28:13 --> Final output sent to browser
DEBUG - 2014-08-14 19:28:13 --> Total execution time: 0.1516
DEBUG - 2014-08-14 19:29:05 --> Config Class Initialized
DEBUG - 2014-08-14 19:29:05 --> Hooks Class Initialized
DEBUG - 2014-08-14 19:29:05 --> Utf8 Class Initialized
DEBUG - 2014-08-14 19:29:05 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 19:29:05 --> URI Class Initialized
DEBUG - 2014-08-14 19:29:05 --> Router Class Initialized
DEBUG - 2014-08-14 19:29:05 --> Output Class Initialized
DEBUG - 2014-08-14 19:29:05 --> Security Class Initialized
DEBUG - 2014-08-14 19:29:05 --> Input Class Initialized
DEBUG - 2014-08-14 19:29:05 --> XSS Filtering completed
DEBUG - 2014-08-14 19:29:05 --> XSS Filtering completed
DEBUG - 2014-08-14 19:29:05 --> XSS Filtering completed
DEBUG - 2014-08-14 19:29:05 --> XSS Filtering completed
DEBUG - 2014-08-14 19:29:05 --> CRSF cookie Set
DEBUG - 2014-08-14 19:29:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 19:29:05 --> Language Class Initialized
DEBUG - 2014-08-14 19:29:05 --> Loader Class Initialized
DEBUG - 2014-08-14 19:29:05 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 19:29:05 --> Helper loaded: url_helper
DEBUG - 2014-08-14 19:29:05 --> Database Driver Class Initialized
ERROR - 2014-08-14 19:29:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 19:29:05 --> Session Class Initialized
DEBUG - 2014-08-14 19:29:05 --> Helper loaded: string_helper
DEBUG - 2014-08-14 19:29:05 --> Session routines successfully run
DEBUG - 2014-08-14 19:29:05 --> Controller Class Initialized
DEBUG - 2014-08-14 19:29:05 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-14 19:29:05 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-14 19:29:05 --> Encrypt Class Initialized
DEBUG - 2014-08-14 19:29:05 --> Model Class Initialized
DEBUG - 2014-08-14 19:29:05 --> Model Class Initialized
DEBUG - 2014-08-14 19:29:05 --> Model Class Initialized
DEBUG - 2014-08-14 19:29:05 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-14 19:29:05 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-14 19:29:05 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-14 19:29:05 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-14 19:29:05 --> Final output sent to browser
DEBUG - 2014-08-14 19:29:05 --> Total execution time: 0.1522
DEBUG - 2014-08-14 19:29:07 --> Config Class Initialized
DEBUG - 2014-08-14 19:29:07 --> Hooks Class Initialized
DEBUG - 2014-08-14 19:29:07 --> Utf8 Class Initialized
DEBUG - 2014-08-14 19:29:07 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 19:29:07 --> URI Class Initialized
DEBUG - 2014-08-14 19:29:07 --> Router Class Initialized
DEBUG - 2014-08-14 19:29:07 --> Output Class Initialized
DEBUG - 2014-08-14 19:29:07 --> Security Class Initialized
DEBUG - 2014-08-14 19:29:07 --> Input Class Initialized
DEBUG - 2014-08-14 19:29:07 --> XSS Filtering completed
DEBUG - 2014-08-14 19:29:07 --> XSS Filtering completed
DEBUG - 2014-08-14 19:29:07 --> XSS Filtering completed
DEBUG - 2014-08-14 19:29:07 --> XSS Filtering completed
DEBUG - 2014-08-14 19:29:07 --> XSS Filtering completed
DEBUG - 2014-08-14 19:29:23 --> Config Class Initialized
DEBUG - 2014-08-14 19:29:23 --> Hooks Class Initialized
DEBUG - 2014-08-14 19:29:23 --> Utf8 Class Initialized
DEBUG - 2014-08-14 19:29:23 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 19:29:23 --> URI Class Initialized
DEBUG - 2014-08-14 19:29:23 --> Router Class Initialized
DEBUG - 2014-08-14 19:29:23 --> Output Class Initialized
DEBUG - 2014-08-14 19:29:23 --> Security Class Initialized
DEBUG - 2014-08-14 19:29:23 --> Input Class Initialized
DEBUG - 2014-08-14 19:29:23 --> XSS Filtering completed
DEBUG - 2014-08-14 19:29:23 --> XSS Filtering completed
DEBUG - 2014-08-14 19:29:23 --> XSS Filtering completed
DEBUG - 2014-08-14 19:29:23 --> XSS Filtering completed
DEBUG - 2014-08-14 19:29:23 --> XSS Filtering completed
DEBUG - 2014-08-14 19:31:23 --> Config Class Initialized
DEBUG - 2014-08-14 19:31:23 --> Hooks Class Initialized
DEBUG - 2014-08-14 19:31:23 --> Utf8 Class Initialized
DEBUG - 2014-08-14 19:31:23 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 19:31:23 --> URI Class Initialized
DEBUG - 2014-08-14 19:31:23 --> Router Class Initialized
DEBUG - 2014-08-14 19:31:23 --> Output Class Initialized
DEBUG - 2014-08-14 19:31:23 --> Security Class Initialized
DEBUG - 2014-08-14 19:31:23 --> Input Class Initialized
DEBUG - 2014-08-14 19:31:23 --> XSS Filtering completed
DEBUG - 2014-08-14 19:31:23 --> XSS Filtering completed
DEBUG - 2014-08-14 19:31:23 --> XSS Filtering completed
DEBUG - 2014-08-14 19:31:23 --> XSS Filtering completed
DEBUG - 2014-08-14 19:31:23 --> CRSF cookie Set
DEBUG - 2014-08-14 19:31:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 19:31:23 --> Language Class Initialized
DEBUG - 2014-08-14 19:31:23 --> Loader Class Initialized
DEBUG - 2014-08-14 19:31:23 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 19:31:23 --> Helper loaded: url_helper
DEBUG - 2014-08-14 19:31:23 --> Database Driver Class Initialized
ERROR - 2014-08-14 19:31:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 19:31:23 --> Session Class Initialized
DEBUG - 2014-08-14 19:31:23 --> Helper loaded: string_helper
DEBUG - 2014-08-14 19:31:23 --> Session routines successfully run
DEBUG - 2014-08-14 19:31:23 --> Controller Class Initialized
DEBUG - 2014-08-14 19:31:23 --> Final output sent to browser
DEBUG - 2014-08-14 19:31:23 --> Total execution time: 0.0875
DEBUG - 2014-08-14 19:31:30 --> Config Class Initialized
DEBUG - 2014-08-14 19:31:30 --> Hooks Class Initialized
DEBUG - 2014-08-14 19:31:30 --> Utf8 Class Initialized
DEBUG - 2014-08-14 19:31:30 --> UTF-8 Support Enabled
DEBUG - 2014-08-14 19:31:30 --> URI Class Initialized
DEBUG - 2014-08-14 19:31:30 --> Router Class Initialized
DEBUG - 2014-08-14 19:31:30 --> Output Class Initialized
DEBUG - 2014-08-14 19:31:30 --> Security Class Initialized
DEBUG - 2014-08-14 19:31:30 --> Input Class Initialized
DEBUG - 2014-08-14 19:31:30 --> XSS Filtering completed
DEBUG - 2014-08-14 19:31:30 --> XSS Filtering completed
DEBUG - 2014-08-14 19:31:30 --> XSS Filtering completed
DEBUG - 2014-08-14 19:31:30 --> XSS Filtering completed
DEBUG - 2014-08-14 19:31:30 --> CRSF cookie Set
DEBUG - 2014-08-14 19:31:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-14 19:31:30 --> Language Class Initialized
DEBUG - 2014-08-14 19:31:30 --> Loader Class Initialized
DEBUG - 2014-08-14 19:31:30 --> Helper loaded: functions_helper
DEBUG - 2014-08-14 19:31:30 --> Helper loaded: url_helper
DEBUG - 2014-08-14 19:31:30 --> Database Driver Class Initialized
ERROR - 2014-08-14 19:31:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-14 19:31:30 --> Session Class Initialized
DEBUG - 2014-08-14 19:31:30 --> Helper loaded: string_helper
DEBUG - 2014-08-14 19:31:30 --> Session routines successfully run
DEBUG - 2014-08-14 19:31:30 --> Controller Class Initialized
DEBUG - 2014-08-14 19:31:30 --> Final output sent to browser
DEBUG - 2014-08-14 19:31:30 --> Total execution time: 0.0964
