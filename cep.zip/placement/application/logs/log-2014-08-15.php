<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-08-15 13:50:21 --> Config Class Initialized
DEBUG - 2014-08-15 13:50:21 --> Hooks Class Initialized
DEBUG - 2014-08-15 13:50:21 --> Utf8 Class Initialized
DEBUG - 2014-08-15 13:50:21 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 13:50:21 --> URI Class Initialized
DEBUG - 2014-08-15 13:50:21 --> Router Class Initialized
DEBUG - 2014-08-15 13:50:21 --> Output Class Initialized
DEBUG - 2014-08-15 13:50:21 --> Security Class Initialized
DEBUG - 2014-08-15 13:50:21 --> Input Class Initialized
DEBUG - 2014-08-15 13:50:21 --> XSS Filtering completed
DEBUG - 2014-08-15 13:50:21 --> XSS Filtering completed
DEBUG - 2014-08-15 13:50:21 --> XSS Filtering completed
DEBUG - 2014-08-15 13:50:21 --> CRSF cookie Set
DEBUG - 2014-08-15 13:50:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 13:50:21 --> Language Class Initialized
DEBUG - 2014-08-15 13:50:21 --> Loader Class Initialized
DEBUG - 2014-08-15 13:50:21 --> Helper loaded: functions_helper
DEBUG - 2014-08-15 13:50:21 --> Helper loaded: url_helper
DEBUG - 2014-08-15 13:50:21 --> Database Driver Class Initialized
ERROR - 2014-08-15 13:50:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-08-15 13:50:21 --> Severity: Warning  --> mysql_pconnect(): MySQL server has gone away C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-15 13:50:21 --> Session Class Initialized
DEBUG - 2014-08-15 13:50:21 --> Helper loaded: string_helper
DEBUG - 2014-08-15 13:50:21 --> Session routines successfully run
DEBUG - 2014-08-15 13:50:21 --> Controller Class Initialized
DEBUG - 2014-08-15 13:50:21 --> File loaded: application/views/logout.php
DEBUG - 2014-08-15 13:50:21 --> Final output sent to browser
DEBUG - 2014-08-15 13:50:21 --> Total execution time: 0.0478
DEBUG - 2014-08-15 13:50:21 --> Config Class Initialized
DEBUG - 2014-08-15 13:50:21 --> Hooks Class Initialized
DEBUG - 2014-08-15 13:50:21 --> Utf8 Class Initialized
DEBUG - 2014-08-15 13:50:21 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 13:50:21 --> URI Class Initialized
DEBUG - 2014-08-15 13:50:21 --> Router Class Initialized
DEBUG - 2014-08-15 13:50:21 --> No URI present. Default controller set.
DEBUG - 2014-08-15 13:50:21 --> Output Class Initialized
DEBUG - 2014-08-15 13:50:21 --> Security Class Initialized
DEBUG - 2014-08-15 13:50:21 --> Input Class Initialized
DEBUG - 2014-08-15 13:50:21 --> XSS Filtering completed
DEBUG - 2014-08-15 13:50:21 --> XSS Filtering completed
DEBUG - 2014-08-15 13:50:21 --> XSS Filtering completed
DEBUG - 2014-08-15 13:50:21 --> CRSF cookie Set
DEBUG - 2014-08-15 13:50:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 13:50:21 --> Language Class Initialized
DEBUG - 2014-08-15 13:50:21 --> Loader Class Initialized
DEBUG - 2014-08-15 13:50:21 --> Helper loaded: functions_helper
DEBUG - 2014-08-15 13:50:21 --> Helper loaded: url_helper
DEBUG - 2014-08-15 13:50:21 --> Database Driver Class Initialized
ERROR - 2014-08-15 13:50:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-15 13:50:21 --> Session Class Initialized
DEBUG - 2014-08-15 13:50:21 --> Helper loaded: string_helper
DEBUG - 2014-08-15 13:50:21 --> A session cookie was not found.
DEBUG - 2014-08-15 13:50:21 --> Session routines successfully run
DEBUG - 2014-08-15 13:50:21 --> Controller Class Initialized
DEBUG - 2014-08-15 13:50:21 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-15 13:50:21 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-15 13:50:21 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-15 13:50:21 --> Helper loaded: form_helper
DEBUG - 2014-08-15 13:50:21 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-15 13:50:21 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-15 13:50:21 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-15 13:50:21 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-15 13:50:21 --> Final output sent to browser
DEBUG - 2014-08-15 13:50:21 --> Total execution time: 0.0563
DEBUG - 2014-08-15 13:50:26 --> Config Class Initialized
DEBUG - 2014-08-15 13:50:26 --> Hooks Class Initialized
DEBUG - 2014-08-15 13:50:26 --> Utf8 Class Initialized
DEBUG - 2014-08-15 13:50:26 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 13:50:26 --> URI Class Initialized
DEBUG - 2014-08-15 13:50:26 --> Router Class Initialized
DEBUG - 2014-08-15 13:50:26 --> No URI present. Default controller set.
DEBUG - 2014-08-15 13:50:26 --> Output Class Initialized
DEBUG - 2014-08-15 13:50:26 --> Security Class Initialized
DEBUG - 2014-08-15 13:50:26 --> Input Class Initialized
DEBUG - 2014-08-15 13:50:26 --> XSS Filtering completed
DEBUG - 2014-08-15 13:50:26 --> XSS Filtering completed
DEBUG - 2014-08-15 13:50:26 --> XSS Filtering completed
DEBUG - 2014-08-15 13:50:26 --> XSS Filtering completed
DEBUG - 2014-08-15 13:50:26 --> CRSF cookie Set
DEBUG - 2014-08-15 13:50:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 13:50:26 --> Language Class Initialized
DEBUG - 2014-08-15 13:50:26 --> Loader Class Initialized
DEBUG - 2014-08-15 13:50:26 --> Helper loaded: functions_helper
DEBUG - 2014-08-15 13:50:26 --> Helper loaded: url_helper
DEBUG - 2014-08-15 13:50:26 --> Database Driver Class Initialized
ERROR - 2014-08-15 13:50:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-08-15 13:50:26 --> Severity: Warning  --> mysql_pconnect(): MySQL server has gone away C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-15 13:50:26 --> Session Class Initialized
DEBUG - 2014-08-15 13:50:26 --> Helper loaded: string_helper
DEBUG - 2014-08-15 13:50:26 --> Session routines successfully run
DEBUG - 2014-08-15 13:50:26 --> Controller Class Initialized
DEBUG - 2014-08-15 13:50:26 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-15 13:50:26 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-15 13:50:26 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-15 13:50:26 --> Helper loaded: form_helper
DEBUG - 2014-08-15 13:50:26 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-15 13:50:26 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-15 13:50:26 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-15 13:50:26 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-15 13:50:26 --> Final output sent to browser
DEBUG - 2014-08-15 13:50:26 --> Total execution time: 0.0800
DEBUG - 2014-08-15 13:50:38 --> Config Class Initialized
DEBUG - 2014-08-15 13:50:38 --> Hooks Class Initialized
DEBUG - 2014-08-15 13:50:38 --> Utf8 Class Initialized
DEBUG - 2014-08-15 13:50:38 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 13:50:38 --> URI Class Initialized
DEBUG - 2014-08-15 13:50:38 --> Router Class Initialized
DEBUG - 2014-08-15 13:50:38 --> Output Class Initialized
DEBUG - 2014-08-15 13:50:38 --> Security Class Initialized
DEBUG - 2014-08-15 13:50:38 --> Input Class Initialized
DEBUG - 2014-08-15 13:50:38 --> XSS Filtering completed
DEBUG - 2014-08-15 13:50:38 --> XSS Filtering completed
DEBUG - 2014-08-15 13:50:38 --> XSS Filtering completed
DEBUG - 2014-08-15 13:50:38 --> XSS Filtering completed
DEBUG - 2014-08-15 13:50:38 --> XSS Filtering completed
DEBUG - 2014-08-15 13:50:38 --> XSS Filtering completed
DEBUG - 2014-08-15 13:50:38 --> XSS Filtering completed
DEBUG - 2014-08-15 13:50:38 --> CRSF cookie Set
DEBUG - 2014-08-15 13:50:38 --> CSRF token verified
DEBUG - 2014-08-15 13:50:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 13:50:38 --> Language Class Initialized
DEBUG - 2014-08-15 13:50:38 --> Loader Class Initialized
DEBUG - 2014-08-15 13:50:38 --> Helper loaded: functions_helper
DEBUG - 2014-08-15 13:50:38 --> Helper loaded: url_helper
DEBUG - 2014-08-15 13:50:38 --> Database Driver Class Initialized
ERROR - 2014-08-15 13:50:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-15 13:50:38 --> Session Class Initialized
DEBUG - 2014-08-15 13:50:38 --> Helper loaded: string_helper
DEBUG - 2014-08-15 13:50:38 --> Session routines successfully run
DEBUG - 2014-08-15 13:50:38 --> Controller Class Initialized
DEBUG - 2014-08-15 13:50:38 --> Helper loaded: form_helper
DEBUG - 2014-08-15 13:50:38 --> Form Validation Class Initialized
DEBUG - 2014-08-15 13:50:38 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-15 13:50:38 --> XSS Filtering completed
DEBUG - 2014-08-15 13:50:38 --> XSS Filtering completed
DEBUG - 2014-08-15 13:50:38 --> Model Class Initialized
DEBUG - 2014-08-15 13:50:38 --> Model Class Initialized
DEBUG - 2014-08-15 13:50:38 --> Model Class Initialized
DEBUG - 2014-08-15 13:50:38 --> Model Class Initialized
DEBUG - 2014-08-15 13:50:38 --> Encrypt Class Initialized
DEBUG - 2014-08-15 13:50:38 --> XSS Filtering completed
DEBUG - 2014-08-15 13:50:38 --> XSS Filtering completed
DEBUG - 2014-08-15 13:50:38 --> Config Class Initialized
DEBUG - 2014-08-15 13:50:38 --> Hooks Class Initialized
DEBUG - 2014-08-15 13:50:38 --> Utf8 Class Initialized
DEBUG - 2014-08-15 13:50:38 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 13:50:38 --> URI Class Initialized
DEBUG - 2014-08-15 13:50:38 --> Router Class Initialized
DEBUG - 2014-08-15 13:50:38 --> Output Class Initialized
DEBUG - 2014-08-15 13:50:38 --> Security Class Initialized
DEBUG - 2014-08-15 13:50:38 --> Input Class Initialized
DEBUG - 2014-08-15 13:50:38 --> XSS Filtering completed
DEBUG - 2014-08-15 13:50:38 --> XSS Filtering completed
DEBUG - 2014-08-15 13:50:38 --> XSS Filtering completed
DEBUG - 2014-08-15 13:50:38 --> XSS Filtering completed
DEBUG - 2014-08-15 13:50:38 --> CRSF cookie Set
DEBUG - 2014-08-15 13:50:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 13:50:38 --> Language Class Initialized
DEBUG - 2014-08-15 13:50:38 --> Loader Class Initialized
DEBUG - 2014-08-15 13:50:38 --> Helper loaded: functions_helper
DEBUG - 2014-08-15 13:50:38 --> Helper loaded: url_helper
DEBUG - 2014-08-15 13:50:38 --> Database Driver Class Initialized
ERROR - 2014-08-15 13:50:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-15 13:50:38 --> Session Class Initialized
DEBUG - 2014-08-15 13:50:38 --> Helper loaded: string_helper
DEBUG - 2014-08-15 13:50:38 --> Session routines successfully run
DEBUG - 2014-08-15 13:50:38 --> Controller Class Initialized
DEBUG - 2014-08-15 13:50:38 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-15 13:50:38 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-15 13:50:38 --> Encrypt Class Initialized
DEBUG - 2014-08-15 13:50:38 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-15 13:50:38 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-15 13:50:38 --> File loaded: application/views/placement_admin_home.php
DEBUG - 2014-08-15 13:50:38 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-15 13:50:38 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-15 13:50:38 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-15 13:50:38 --> Final output sent to browser
DEBUG - 2014-08-15 13:50:38 --> Total execution time: 0.0711
DEBUG - 2014-08-15 13:52:23 --> Config Class Initialized
DEBUG - 2014-08-15 13:52:23 --> Hooks Class Initialized
DEBUG - 2014-08-15 13:52:23 --> Utf8 Class Initialized
DEBUG - 2014-08-15 13:52:23 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 13:52:23 --> URI Class Initialized
DEBUG - 2014-08-15 13:52:23 --> Router Class Initialized
DEBUG - 2014-08-15 13:52:23 --> Output Class Initialized
DEBUG - 2014-08-15 13:52:23 --> Security Class Initialized
DEBUG - 2014-08-15 13:52:23 --> Input Class Initialized
DEBUG - 2014-08-15 13:52:23 --> XSS Filtering completed
DEBUG - 2014-08-15 13:52:23 --> XSS Filtering completed
DEBUG - 2014-08-15 13:52:23 --> XSS Filtering completed
DEBUG - 2014-08-15 13:52:23 --> XSS Filtering completed
DEBUG - 2014-08-15 13:52:23 --> CRSF cookie Set
DEBUG - 2014-08-15 13:52:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 13:52:23 --> Language Class Initialized
DEBUG - 2014-08-15 13:52:23 --> Loader Class Initialized
DEBUG - 2014-08-15 13:52:23 --> Helper loaded: functions_helper
DEBUG - 2014-08-15 13:52:23 --> Helper loaded: url_helper
DEBUG - 2014-08-15 13:52:23 --> Database Driver Class Initialized
ERROR - 2014-08-15 13:52:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-15 13:52:23 --> Session Class Initialized
DEBUG - 2014-08-15 13:52:23 --> Helper loaded: string_helper
DEBUG - 2014-08-15 13:52:23 --> Session routines successfully run
DEBUG - 2014-08-15 13:52:23 --> Controller Class Initialized
DEBUG - 2014-08-15 13:52:23 --> File loaded: application/views/logout.php
DEBUG - 2014-08-15 13:52:23 --> Final output sent to browser
DEBUG - 2014-08-15 13:52:23 --> Total execution time: 0.0385
DEBUG - 2014-08-15 13:52:23 --> Config Class Initialized
DEBUG - 2014-08-15 13:52:23 --> Hooks Class Initialized
DEBUG - 2014-08-15 13:52:23 --> Utf8 Class Initialized
DEBUG - 2014-08-15 13:52:23 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 13:52:23 --> URI Class Initialized
DEBUG - 2014-08-15 13:52:23 --> Router Class Initialized
DEBUG - 2014-08-15 13:52:23 --> No URI present. Default controller set.
DEBUG - 2014-08-15 13:52:23 --> Output Class Initialized
DEBUG - 2014-08-15 13:52:23 --> Security Class Initialized
DEBUG - 2014-08-15 13:52:23 --> Input Class Initialized
DEBUG - 2014-08-15 13:52:23 --> XSS Filtering completed
DEBUG - 2014-08-15 13:52:23 --> XSS Filtering completed
DEBUG - 2014-08-15 13:52:23 --> XSS Filtering completed
DEBUG - 2014-08-15 13:52:23 --> CRSF cookie Set
DEBUG - 2014-08-15 13:52:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 13:52:23 --> Language Class Initialized
DEBUG - 2014-08-15 13:52:23 --> Loader Class Initialized
DEBUG - 2014-08-15 13:52:23 --> Helper loaded: functions_helper
DEBUG - 2014-08-15 13:52:23 --> Helper loaded: url_helper
DEBUG - 2014-08-15 13:52:23 --> Database Driver Class Initialized
ERROR - 2014-08-15 13:52:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-15 13:52:23 --> Session Class Initialized
DEBUG - 2014-08-15 13:52:23 --> Helper loaded: string_helper
DEBUG - 2014-08-15 13:52:23 --> A session cookie was not found.
DEBUG - 2014-08-15 13:52:23 --> Session routines successfully run
DEBUG - 2014-08-15 13:52:23 --> Controller Class Initialized
DEBUG - 2014-08-15 13:52:23 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-15 13:52:23 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-15 13:52:23 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-15 13:52:23 --> Helper loaded: form_helper
DEBUG - 2014-08-15 13:52:23 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-15 13:52:23 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-15 13:52:23 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-15 13:52:23 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-15 13:52:23 --> Final output sent to browser
DEBUG - 2014-08-15 13:52:23 --> Total execution time: 0.0579
DEBUG - 2014-08-15 13:55:49 --> Config Class Initialized
DEBUG - 2014-08-15 13:55:49 --> Hooks Class Initialized
DEBUG - 2014-08-15 13:55:49 --> Utf8 Class Initialized
DEBUG - 2014-08-15 13:55:49 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 13:55:49 --> URI Class Initialized
DEBUG - 2014-08-15 13:55:49 --> Router Class Initialized
DEBUG - 2014-08-15 13:55:49 --> Output Class Initialized
DEBUG - 2014-08-15 13:55:49 --> Security Class Initialized
DEBUG - 2014-08-15 13:55:49 --> Input Class Initialized
DEBUG - 2014-08-15 13:55:49 --> XSS Filtering completed
DEBUG - 2014-08-15 13:55:49 --> XSS Filtering completed
DEBUG - 2014-08-15 13:55:49 --> XSS Filtering completed
DEBUG - 2014-08-15 13:55:49 --> XSS Filtering completed
DEBUG - 2014-08-15 13:55:49 --> CRSF cookie Set
DEBUG - 2014-08-15 13:55:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 13:55:49 --> Language Class Initialized
DEBUG - 2014-08-15 13:55:49 --> Loader Class Initialized
DEBUG - 2014-08-15 13:55:49 --> Helper loaded: functions_helper
DEBUG - 2014-08-15 13:55:49 --> Helper loaded: url_helper
DEBUG - 2014-08-15 13:55:49 --> Database Driver Class Initialized
ERROR - 2014-08-15 13:55:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-15 13:55:49 --> Session Class Initialized
DEBUG - 2014-08-15 13:55:49 --> Helper loaded: string_helper
DEBUG - 2014-08-15 13:55:49 --> Session routines successfully run
DEBUG - 2014-08-15 13:55:49 --> Controller Class Initialized
DEBUG - 2014-08-15 13:55:49 --> File loaded: application/views/login_to_continue.php
DEBUG - 2014-08-15 13:55:49 --> Final output sent to browser
DEBUG - 2014-08-15 13:55:49 --> Total execution time: 0.0395
DEBUG - 2014-08-15 13:55:50 --> Config Class Initialized
DEBUG - 2014-08-15 13:55:50 --> Hooks Class Initialized
DEBUG - 2014-08-15 13:55:50 --> Utf8 Class Initialized
DEBUG - 2014-08-15 13:55:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-15 13:55:50 --> URI Class Initialized
DEBUG - 2014-08-15 13:55:50 --> Router Class Initialized
DEBUG - 2014-08-15 13:55:50 --> No URI present. Default controller set.
DEBUG - 2014-08-15 13:55:50 --> Output Class Initialized
DEBUG - 2014-08-15 13:55:50 --> Security Class Initialized
DEBUG - 2014-08-15 13:55:50 --> Input Class Initialized
DEBUG - 2014-08-15 13:55:50 --> XSS Filtering completed
DEBUG - 2014-08-15 13:55:50 --> XSS Filtering completed
DEBUG - 2014-08-15 13:55:50 --> XSS Filtering completed
DEBUG - 2014-08-15 13:55:50 --> XSS Filtering completed
DEBUG - 2014-08-15 13:55:50 --> CRSF cookie Set
DEBUG - 2014-08-15 13:55:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-15 13:55:50 --> Language Class Initialized
DEBUG - 2014-08-15 13:55:50 --> Loader Class Initialized
DEBUG - 2014-08-15 13:55:50 --> Helper loaded: functions_helper
DEBUG - 2014-08-15 13:55:50 --> Helper loaded: url_helper
DEBUG - 2014-08-15 13:55:50 --> Database Driver Class Initialized
ERROR - 2014-08-15 13:55:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-15 13:55:50 --> Session Class Initialized
DEBUG - 2014-08-15 13:55:50 --> Helper loaded: string_helper
DEBUG - 2014-08-15 13:55:50 --> Session routines successfully run
DEBUG - 2014-08-15 13:55:50 --> Controller Class Initialized
DEBUG - 2014-08-15 13:55:50 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-15 13:55:50 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-15 13:55:50 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-15 13:55:50 --> Helper loaded: form_helper
DEBUG - 2014-08-15 13:55:50 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-15 13:55:50 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-15 13:55:50 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-15 13:55:50 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-15 13:55:50 --> Final output sent to browser
DEBUG - 2014-08-15 13:55:50 --> Total execution time: 0.0425
