DEBUG - 2014-08-12 18:45:42 --> Config Class Initialized
DEBUG - 2014-08-12 18:45:42 --> Hooks Class Initialized
DEBUG - 2014-08-12 18:45:42 --> Utf8 Class Initialized
DEBUG - 2014-08-12 18:45:42 --> UTF-8 Support Enabled
DEBUG - 2014-08-12 18:45:42 --> URI Class Initialized
DEBUG - 2014-08-12 18:45:42 --> Router Class Initialized
DEBUG - 2014-08-12 18:45:42 --> Output Class Initialized
DEBUG - 2014-08-12 18:45:42 --> Security Class Initialized
DEBUG - 2014-08-12 18:45:42 --> Input Class Initialized
DEBUG - 2014-08-12 18:45:42 --> XSS Filtering completed
DEBUG - 2014-08-12 18:45:42 --> XSS Filtering completed
DEBUG - 2014-08-12 18:45:42 --> XSS Filtering completed
DEBUG - 2014-08-12 18:45:42 --> XSS Filtering completed
DEBUG - 2014-08-12 18:45:42 --> XSS Filtering completed
DEBUG - 2014-08-12 18:45:42 --> XSS Filtering completed
DEBUG - 2014-08-12 18:45:42 --> XSS Filtering completed
DEBUG - 2014-08-12 18:45:42 --> XSS Filtering completed
DEBUG - 2014-08-12 18:45:42 --> XSS Filtering completed
DEBUG - 2014-08-12 18:45:42 --> XSS Filtering completed
DEBUG - 2014-08-12 18:45:42 --> XSS Filtering completed
DEBUG - 2014-08-12 18:45:42 --> XSS Filtering completed
DEBUG - 2014-08-12 18:45:42 --> XSS Filtering completed
DEBUG - 2014-08-12 18:45:42 --> XSS Filtering completed
DEBUG - 2014-08-12 18:45:42 --> XSS Filtering completed
DEBUG - 2014-08-12 18:45:42 --> XSS Filtering completed
DEBUG - 2014-08-12 18:45:42 --> CRSF cookie Set
DEBUG - 2014-08-12 18:45:42 --> CSRF token verified
DEBUG - 2014-08-12 18:45:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-12 18:45:42 --> Language Class Initialized
DEBUG - 2014-08-12 18:45:42 --> Loader Class Initialized
DEBUG - 2014-08-12 18:45:42 --> Helper loaded: functions_helper
DEBUG - 2014-08-12 18:45:42 --> Helper loaded: url_helper
DEBUG - 2014-08-12 18:45:42 --> Database Driver Class Initialized
ERROR - 2014-08-12 18:45:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-12 18:45:42 --> Session Class Initialized
DEBUG - 2014-08-12 18:45:42 --> Helper loaded: string_helper
DEBUG - 2014-08-12 18:45:42 --> Session routines successfully run
DEBUG - 2014-08-12 18:45:42 --> Controller Class Initialized
DEBUG - 2014-08-12 18:45:42 --> Helper loaded: form_helper
DEBUG - 2014-08-12 18:45:42 --> Form Validation Class Initialized
DEBUG - 2014-08-12 18:45:42 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-12 18:45:42 --> XSS Filtering completed
DEBUG - 2014-08-12 18:45:42 --> XSS Filtering completed
DEBUG - 2014-08-12 18:45:42 --> XSS Filtering completed
DEBUG - 2014-08-12 18:45:42 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-12 18:45:42 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-12 18:45:42 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-12 18:45:42 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-12 18:45:42 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-12 18:45:42 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-12 18:45:42 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-12 18:45:42 --> Final output sent to browser
DEBUG - 2014-08-12 18:45:42 --> Total execution time: 0.1605
DEBUG - 2014-08-12 18:46:29 --> Config Class Initialized
DEBUG - 2014-08-12 18:46:29 --> Hooks Class Initialized
DEBUG - 2014-08-12 18:46:29 --> Utf8 Class Initialized
DEBUG - 2014-08-12 18:46:29 --> UTF-8 Support Enabled
DEBUG - 2014-08-12 18:46:29 --> URI Class Initialized
DEBUG - 2014-08-12 18:46:29 --> Router Class Initialized
DEBUG - 2014-08-12 18:46:29 --> Output Class Initialized
DEBUG - 2014-08-12 18:46:29 --> Security Class Initialized
DEBUG - 2014-08-12 18:46:29 --> Input Class Initialized
DEBUG - 2014-08-12 18:46:29 --> XSS Filtering completed
DEBUG - 2014-08-12 18:46:29 --> XSS Filtering completed
DEBUG - 2014-08-12 18:46:29 --> XSS Filtering completed
DEBUG - 2014-08-12 18:46:29 --> XSS Filtering completed
DEBUG - 2014-08-12 18:46:29 --> XSS Filtering completed
DEBUG - 2014-08-12 18:46:29 --> XSS Filtering completed
DEBUG - 2014-08-12 18:46:29 --> XSS Filtering completed
DEBUG - 2014-08-12 18:46:29 --> XSS Filtering completed
DEBUG - 2014-08-12 18:46:29 --> XSS Filtering completed
DEBUG - 2014-08-12 18:46:29 --> XSS Filtering completed
DEBUG - 2014-08-12 18:46:29 --> XSS Filtering completed
DEBUG - 2014-08-12 18:46:29 --> XSS Filtering completed
DEBUG - 2014-08-12 18:46:29 --> XSS Filtering completed
DEBUG - 2014-08-12 18:46:29 --> XSS Filtering completed
DEBUG - 2014-08-12 18:46:29 --> XSS Filtering completed
DEBUG - 2014-08-12 18:46:29 --> XSS Filtering completed
DEBUG - 2014-08-12 18:46:29 --> CRSF cookie Set
DEBUG - 2014-08-12 18:46:29 --> CSRF token verified
DEBUG - 2014-08-12 18:46:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-12 18:46:29 --> Language Class Initialized
DEBUG - 2014-08-12 18:46:29 --> Loader Class Initialized
DEBUG - 2014-08-12 18:46:29 --> Helper loaded: functions_helper
DEBUG - 2014-08-12 18:46:29 --> Helper loaded: url_helper
DEBUG - 2014-08-12 18:46:29 --> Database Driver Class Initialized
ERROR - 2014-08-12 18:46:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-12 18:46:29 --> Session Class Initialized
DEBUG - 2014-08-12 18:46:29 --> Helper loaded: string_helper
DEBUG - 2014-08-12 18:46:29 --> Session routines successfully run
DEBUG - 2014-08-12 18:46:29 --> Controller Class Initialized
DEBUG - 2014-08-12 18:46:29 --> Helper loaded: form_helper
DEBUG - 2014-08-12 18:46:29 --> Form Validation Class Initialized
DEBUG - 2014-08-12 18:46:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-12 18:46:29 --> XSS Filtering completed
DEBUG - 2014-08-12 18:46:29 --> XSS Filtering completed
DEBUG - 2014-08-12 18:46:29 --> XSS Filtering completed
DEBUG - 2014-08-12 18:46:29 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-12 18:46:29 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-12 18:46:29 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-12 18:46:29 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-12 18:46:29 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-12 18:46:29 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-12 18:46:29 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-12 18:46:29 --> Final output sent to browser
DEBUG - 2014-08-12 18:46:29 --> Total execution time: 0.1653
DEBUG - 2014-08-12 18:46:43 --> Config Class Initialized
DEBUG - 2014-08-12 18:46:43 --> Hooks Class Initialized
DEBUG - 2014-08-12 18:46:43 --> Utf8 Class Initialized
DEBUG - 2014-08-12 18:46:43 --> UTF-8 Support Enabled
DEBUG - 2014-08-12 18:46:43 --> URI Class Initialized
DEBUG - 2014-08-12 18:46:43 --> Router Class Initialized
DEBUG - 2014-08-12 18:46:43 --> Output Class Initialized
DEBUG - 2014-08-12 18:46:43 --> Security Class Initialized
DEBUG - 2014-08-12 18:46:43 --> Input Class Initialized
DEBUG - 2014-08-12 18:46:43 --> XSS Filtering completed
DEBUG - 2014-08-12 18:46:43 --> XSS Filtering completed
DEBUG - 2014-08-12 18:46:43 --> XSS Filtering completed
DEBUG - 2014-08-12 18:46:43 --> XSS Filtering completed
DEBUG - 2014-08-12 18:46:43 --> XSS Filtering completed
DEBUG - 2014-08-12 18:46:43 --> XSS Filtering completed
DEBUG - 2014-08-12 18:46:43 --> XSS Filtering completed
DEBUG - 2014-08-12 18:46:43 --> XSS Filtering completed
DEBUG - 2014-08-12 18:46:43 --> XSS Filtering completed
DEBUG - 2014-08-12 18:46:43 --> XSS Filtering completed
DEBUG - 2014-08-12 18:46:43 --> XSS Filtering completed
DEBUG - 2014-08-12 18:46:43 --> XSS Filtering completed
DEBUG - 2014-08-12 18:46:43 --> XSS Filtering completed
DEBUG - 2014-08-12 18:46:43 --> XSS Filtering completed
DEBUG - 2014-08-12 18:46:43 --> XSS Filtering completed
DEBUG - 2014-08-12 18:46:43 --> XSS Filtering completed
DEBUG - 2014-08-12 18:46:43 --> CRSF cookie Set
DEBUG - 2014-08-12 18:46:43 --> CSRF token verified
DEBUG - 2014-08-12 18:46:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-12 18:46:43 --> Language Class Initialized
DEBUG - 2014-08-12 18:46:43 --> Loader Class Initialized
DEBUG - 2014-08-12 18:46:43 --> Helper loaded: functions_helper
DEBUG - 2014-08-12 18:46:43 --> Helper loaded: url_helper
DEBUG - 2014-08-12 18:46:43 --> Database Driver Class Initialized
ERROR - 2014-08-12 18:46:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-12 18:46:43 --> Session Class Initialized
DEBUG - 2014-08-12 18:46:43 --> Helper loaded: string_helper
DEBUG - 2014-08-12 18:46:43 --> Session routines successfully run
DEBUG - 2014-08-12 18:46:43 --> Controller Class Initialized
DEBUG - 2014-08-12 18:46:43 --> Helper loaded: form_helper
DEBUG - 2014-08-12 18:46:43 --> Form Validation Class Initialized
DEBUG - 2014-08-12 18:46:43 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-12 18:46:43 --> XSS Filtering completed
DEBUG - 2014-08-12 18:46:43 --> XSS Filtering completed
DEBUG - 2014-08-12 18:46:43 --> XSS Filtering completed
DEBUG - 2014-08-12 18:46:43 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-12 18:46:43 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-12 18:46:43 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-12 18:46:43 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-12 18:46:43 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-12 18:46:43 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-12 18:46:43 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-12 18:46:44 --> Final output sent to browser
DEBUG - 2014-08-12 18:46:44 --> Total execution time: 0.1596
DEBUG - 2014-08-12 18:47:35 --> Config Class Initialized
DEBUG - 2014-08-12 18:47:35 --> Hooks Class Initialized
DEBUG - 2014-08-12 18:47:35 --> Utf8 Class Initialized
DEBUG - 2014-08-12 18:47:35 --> UTF-8 Support Enabled
DEBUG - 2014-08-12 18:47:35 --> URI Class Initialized
DEBUG - 2014-08-12 18:47:35 --> Router Class Initialized
DEBUG - 2014-08-12 18:47:35 --> Output Class Initialized
DEBUG - 2014-08-12 18:47:35 --> Security Class Initialized
DEBUG - 2014-08-12 18:47:35 --> Input Class Initialized
DEBUG - 2014-08-12 18:47:35 --> XSS Filtering completed
DEBUG - 2014-08-12 18:47:35 --> XSS Filtering completed
DEBUG - 2014-08-12 18:47:35 --> XSS Filtering completed
DEBUG - 2014-08-12 18:47:35 --> XSS Filtering completed
DEBUG - 2014-08-12 18:47:35 --> XSS Filtering completed
DEBUG - 2014-08-12 18:47:35 --> XSS Filtering completed
DEBUG - 2014-08-12 18:47:35 --> XSS Filtering completed
DEBUG - 2014-08-12 18:47:35 --> XSS Filtering completed
DEBUG - 2014-08-12 18:47:35 --> XSS Filtering completed
DEBUG - 2014-08-12 18:47:35 --> XSS Filtering completed
DEBUG - 2014-08-12 18:47:35 --> XSS Filtering completed
DEBUG - 2014-08-12 18:47:35 --> XSS Filtering completed
DEBUG - 2014-08-12 18:47:35 --> XSS Filtering completed
DEBUG - 2014-08-12 18:47:35 --> XSS Filtering completed
DEBUG - 2014-08-12 18:47:35 --> XSS Filtering completed
DEBUG - 2014-08-12 18:47:35 --> XSS Filtering completed
DEBUG - 2014-08-12 18:47:35 --> CRSF cookie Set
DEBUG - 2014-08-12 18:47:35 --> CSRF token verified
DEBUG - 2014-08-12 18:47:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-12 18:47:35 --> Language Class Initialized
DEBUG - 2014-08-12 18:47:35 --> Loader Class Initialized
DEBUG - 2014-08-12 18:47:35 --> Helper loaded: functions_helper
DEBUG - 2014-08-12 18:47:35 --> Helper loaded: url_helper
DEBUG - 2014-08-12 18:47:35 --> Database Driver Class Initialized
ERROR - 2014-08-12 18:47:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-12 18:47:35 --> Session Class Initialized
DEBUG - 2014-08-12 18:47:35 --> Helper loaded: string_helper
DEBUG - 2014-08-12 18:47:35 --> Session routines successfully run
DEBUG - 2014-08-12 18:47:35 --> Controller Class Initialized
DEBUG - 2014-08-12 18:47:35 --> Helper loaded: form_helper
DEBUG - 2014-08-12 18:47:35 --> Form Validation Class Initialized
DEBUG - 2014-08-12 18:47:35 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-12 18:47:35 --> XSS Filtering completed
DEBUG - 2014-08-12 18:47:35 --> XSS Filtering completed
DEBUG - 2014-08-12 18:47:35 --> XSS Filtering completed
DEBUG - 2014-08-12 18:47:35 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-12 18:47:35 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-12 18:47:35 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-12 18:47:35 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-12 18:47:35 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-12 18:47:35 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-12 18:47:35 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-12 18:47:35 --> Final output sent to browser
DEBUG - 2014-08-12 18:47:35 --> Total execution time: 0.1654
DEBUG - 2014-08-12 18:48:39 --> Config Class Initialized
DEBUG - 2014-08-12 18:48:39 --> Hooks Class Initialized
DEBUG - 2014-08-12 18:48:39 --> Utf8 Class Initialized
DEBUG - 2014-08-12 18:48:39 --> UTF-8 Support Enabled
DEBUG - 2014-08-12 18:48:39 --> URI Class Initialized
DEBUG - 2014-08-12 18:48:39 --> Router Class Initialized
DEBUG - 2014-08-12 18:48:39 --> Output Class Initialized
DEBUG - 2014-08-12 18:48:39 --> Security Class Initialized
DEBUG - 2014-08-12 18:48:39 --> Input Class Initialized
DEBUG - 2014-08-12 18:48:39 --> XSS Filtering completed
DEBUG - 2014-08-12 18:48:39 --> XSS Filtering completed
DEBUG - 2014-08-12 18:48:39 --> XSS Filtering completed
DEBUG - 2014-08-12 18:48:39 --> XSS Filtering completed
DEBUG - 2014-08-12 18:48:39 --> XSS Filtering completed
DEBUG - 2014-08-12 18:48:39 --> XSS Filtering completed
DEBUG - 2014-08-12 18:48:39 --> XSS Filtering completed
DEBUG - 2014-08-12 18:48:39 --> XSS Filtering completed
DEBUG - 2014-08-12 18:48:39 --> XSS Filtering completed
DEBUG - 2014-08-12 18:48:39 --> XSS Filtering completed
DEBUG - 2014-08-12 18:48:39 --> XSS Filtering completed
DEBUG - 2014-08-12 18:48:39 --> XSS Filtering completed
DEBUG - 2014-08-12 18:48:39 --> XSS Filtering completed
DEBUG - 2014-08-12 18:48:39 --> XSS Filtering completed
DEBUG - 2014-08-12 18:48:39 --> XSS Filtering completed
DEBUG - 2014-08-12 18:48:39 --> XSS Filtering completed
DEBUG - 2014-08-12 18:48:39 --> CRSF cookie Set
DEBUG - 2014-08-12 18:48:39 --> CSRF token verified
DEBUG - 2014-08-12 18:48:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-12 18:48:39 --> Language Class Initialized
DEBUG - 2014-08-12 18:48:39 --> Loader Class Initialized
DEBUG - 2014-08-12 18:48:39 --> Helper loaded: functions_helper
DEBUG - 2014-08-12 18:48:39 --> Helper loaded: url_helper
DEBUG - 2014-08-12 18:48:39 --> Database Driver Class Initialized
ERROR - 2014-08-12 18:48:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-12 18:48:39 --> Session Class Initialized
DEBUG - 2014-08-12 18:48:39 --> Helper loaded: string_helper
DEBUG - 2014-08-12 18:48:39 --> Session routines successfully run
DEBUG - 2014-08-12 18:48:39 --> Controller Class Initialized
DEBUG - 2014-08-12 18:48:39 --> Helper loaded: form_helper
DEBUG - 2014-08-12 18:48:39 --> Form Validation Class Initialized
DEBUG - 2014-08-12 18:48:39 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-12 18:48:39 --> XSS Filtering completed
DEBUG - 2014-08-12 18:48:39 --> XSS Filtering completed
DEBUG - 2014-08-12 18:48:39 --> XSS Filtering completed
DEBUG - 2014-08-12 18:48:39 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-12 18:48:39 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-12 18:48:39 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-12 18:48:39 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-12 18:48:39 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-12 18:48:39 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-12 18:48:39 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-12 18:48:39 --> Final output sent to browser
DEBUG - 2014-08-12 18:48:39 --> Total execution time: 0.1643
DEBUG - 2014-08-12 18:48:45 --> Config Class Initialized
DEBUG - 2014-08-12 18:48:45 --> Hooks Class Initialized
DEBUG - 2014-08-12 18:48:45 --> Utf8 Class Initialized
DEBUG - 2014-08-12 18:48:45 --> UTF-8 Support Enabled
DEBUG - 2014-08-12 18:48:45 --> URI Class Initialized
DEBUG - 2014-08-12 18:48:45 --> Router Class Initialized
DEBUG - 2014-08-12 18:48:45 --> Output Class Initialized
DEBUG - 2014-08-12 18:48:45 --> Security Class Initialized
DEBUG - 2014-08-12 18:48:45 --> Input Class Initialized
DEBUG - 2014-08-12 18:48:45 --> XSS Filtering completed
DEBUG - 2014-08-12 18:48:45 --> XSS Filtering completed
DEBUG - 2014-08-12 18:48:45 --> XSS Filtering completed
DEBUG - 2014-08-12 18:48:45 --> XSS Filtering completed
DEBUG - 2014-08-12 18:48:45 --> XSS Filtering completed
DEBUG - 2014-08-12 18:48:45 --> XSS Filtering completed
DEBUG - 2014-08-12 18:48:45 --> XSS Filtering completed
DEBUG - 2014-08-12 18:48:45 --> XSS Filtering completed
DEBUG - 2014-08-12 18:48:45 --> XSS Filtering completed
DEBUG - 2014-08-12 18:48:45 --> XSS Filtering completed
DEBUG - 2014-08-12 18:48:45 --> XSS Filtering completed
DEBUG - 2014-08-12 18:48:45 --> XSS Filtering completed
DEBUG - 2014-08-12 18:48:45 --> XSS Filtering completed
DEBUG - 2014-08-12 18:48:45 --> XSS Filtering completed
DEBUG - 2014-08-12 18:48:45 --> XSS Filtering completed
DEBUG - 2014-08-12 18:48:45 --> XSS Filtering completed
DEBUG - 2014-08-12 18:48:45 --> CRSF cookie Set
DEBUG - 2014-08-12 18:48:45 --> CSRF token verified
DEBUG - 2014-08-12 18:48:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-12 18:48:45 --> Language Class Initialized
DEBUG - 2014-08-12 18:48:45 --> Loader Class Initialized
DEBUG - 2014-08-12 18:48:45 --> Helper loaded: functions_helper
DEBUG - 2014-08-12 18:48:45 --> Helper loaded: url_helper
DEBUG - 2014-08-12 18:48:45 --> Database Driver Class Initialized
ERROR - 2014-08-12 18:48:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-12 18:48:45 --> Session Class Initialized
DEBUG - 2014-08-12 18:48:45 --> Helper loaded: string_helper
DEBUG - 2014-08-12 18:48:45 --> Session routines successfully run
DEBUG - 2014-08-12 18:48:45 --> Controller Class Initialized
DEBUG - 2014-08-12 18:48:45 --> Helper loaded: form_helper
DEBUG - 2014-08-12 18:48:45 --> Form Validation Class Initialized
DEBUG - 2014-08-12 18:48:45 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-12 18:48:45 --> XSS Filtering completed
DEBUG - 2014-08-12 18:48:45 --> XSS Filtering completed
DEBUG - 2014-08-12 18:48:45 --> XSS Filtering completed
DEBUG - 2014-08-12 18:48:45 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-12 18:48:45 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-12 18:48:45 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-12 18:48:45 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-12 18:48:45 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-12 18:48:45 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-12 18:48:45 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-12 18:48:45 --> Final output sent to browser
DEBUG - 2014-08-12 18:48:45 --> Total execution time: 0.1589
DEBUG - 2014-08-12 18:49:10 --> Config Class Initialized
DEBUG - 2014-08-12 18:49:10 --> Hooks Class Initialized
DEBUG - 2014-08-12 18:49:10 --> Utf8 Class Initialized
DEBUG - 2014-08-12 18:49:10 --> UTF-8 Support Enabled
DEBUG - 2014-08-12 18:49:10 --> URI Class Initialized
DEBUG - 2014-08-12 18:49:10 --> Router Class Initialized
DEBUG - 2014-08-12 18:49:10 --> Output Class Initialized
DEBUG - 2014-08-12 18:49:10 --> Security Class Initialized
DEBUG - 2014-08-12 18:49:10 --> Input Class Initialized
DEBUG - 2014-08-12 18:49:10 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:10 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:10 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:10 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:10 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:10 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:10 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:10 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:10 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:10 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:10 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:10 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:10 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:10 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:10 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:10 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:10 --> CRSF cookie Set
DEBUG - 2014-08-12 18:49:10 --> CSRF token verified
DEBUG - 2014-08-12 18:49:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-12 18:49:10 --> Language Class Initialized
DEBUG - 2014-08-12 18:49:10 --> Loader Class Initialized
DEBUG - 2014-08-12 18:49:10 --> Helper loaded: functions_helper
DEBUG - 2014-08-12 18:49:10 --> Helper loaded: url_helper
DEBUG - 2014-08-12 18:49:10 --> Database Driver Class Initialized
ERROR - 2014-08-12 18:49:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-12 18:49:10 --> Session Class Initialized
DEBUG - 2014-08-12 18:49:10 --> Helper loaded: string_helper
DEBUG - 2014-08-12 18:49:10 --> Session routines successfully run
DEBUG - 2014-08-12 18:49:10 --> Controller Class Initialized
DEBUG - 2014-08-12 18:49:10 --> Helper loaded: form_helper
DEBUG - 2014-08-12 18:49:10 --> Form Validation Class Initialized
DEBUG - 2014-08-12 18:49:10 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-12 18:49:10 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:10 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:10 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:10 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-12 18:49:10 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-12 18:49:10 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-12 18:49:10 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-12 18:49:10 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-12 18:49:10 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-12 18:49:10 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-12 18:49:10 --> Final output sent to browser
DEBUG - 2014-08-12 18:49:10 --> Total execution time: 0.1669
DEBUG - 2014-08-12 18:49:29 --> Config Class Initialized
DEBUG - 2014-08-12 18:49:29 --> Hooks Class Initialized
DEBUG - 2014-08-12 18:49:29 --> Utf8 Class Initialized
DEBUG - 2014-08-12 18:49:29 --> UTF-8 Support Enabled
DEBUG - 2014-08-12 18:49:29 --> URI Class Initialized
DEBUG - 2014-08-12 18:49:29 --> Router Class Initialized
DEBUG - 2014-08-12 18:49:29 --> Output Class Initialized
DEBUG - 2014-08-12 18:49:29 --> Security Class Initialized
DEBUG - 2014-08-12 18:49:29 --> Input Class Initialized
DEBUG - 2014-08-12 18:49:29 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:29 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:29 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:29 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:29 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:29 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:29 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:29 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:29 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:29 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:29 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:29 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:29 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:29 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:29 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:29 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:29 --> CRSF cookie Set
DEBUG - 2014-08-12 18:49:29 --> CSRF token verified
DEBUG - 2014-08-12 18:49:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-12 18:49:29 --> Language Class Initialized
DEBUG - 2014-08-12 18:49:29 --> Loader Class Initialized
DEBUG - 2014-08-12 18:49:29 --> Helper loaded: functions_helper
DEBUG - 2014-08-12 18:49:29 --> Helper loaded: url_helper
DEBUG - 2014-08-12 18:49:29 --> Database Driver Class Initialized
ERROR - 2014-08-12 18:49:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-12 18:49:29 --> Session Class Initialized
DEBUG - 2014-08-12 18:49:29 --> Helper loaded: string_helper
DEBUG - 2014-08-12 18:49:29 --> Session routines successfully run
DEBUG - 2014-08-12 18:49:29 --> Controller Class Initialized
DEBUG - 2014-08-12 18:49:29 --> Helper loaded: form_helper
DEBUG - 2014-08-12 18:49:29 --> Form Validation Class Initialized
DEBUG - 2014-08-12 18:49:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-12 18:49:29 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:29 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:29 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:29 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-12 18:49:29 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-12 18:49:29 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-12 18:49:29 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-12 18:49:29 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-12 18:49:29 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-12 18:49:29 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-12 18:49:29 --> Final output sent to browser
DEBUG - 2014-08-12 18:49:29 --> Total execution time: 0.1598
DEBUG - 2014-08-12 18:49:33 --> Config Class Initialized
DEBUG - 2014-08-12 18:49:33 --> Hooks Class Initialized
DEBUG - 2014-08-12 18:49:33 --> Utf8 Class Initialized
DEBUG - 2014-08-12 18:49:33 --> UTF-8 Support Enabled
DEBUG - 2014-08-12 18:49:33 --> URI Class Initialized
DEBUG - 2014-08-12 18:49:33 --> Router Class Initialized
DEBUG - 2014-08-12 18:49:33 --> Output Class Initialized
DEBUG - 2014-08-12 18:49:33 --> Security Class Initialized
DEBUG - 2014-08-12 18:49:33 --> Input Class Initialized
DEBUG - 2014-08-12 18:49:33 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:33 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:33 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:33 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:33 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:33 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:33 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:33 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:33 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:33 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:33 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:33 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:33 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:33 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:33 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:33 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:33 --> CRSF cookie Set
DEBUG - 2014-08-12 18:49:33 --> CSRF token verified
DEBUG - 2014-08-12 18:49:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-12 18:49:33 --> Language Class Initialized
DEBUG - 2014-08-12 18:49:33 --> Loader Class Initialized
DEBUG - 2014-08-12 18:49:33 --> Helper loaded: functions_helper
DEBUG - 2014-08-12 18:49:33 --> Helper loaded: url_helper
DEBUG - 2014-08-12 18:49:33 --> Database Driver Class Initialized
ERROR - 2014-08-12 18:49:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-12 18:49:33 --> Session Class Initialized
DEBUG - 2014-08-12 18:49:33 --> Helper loaded: string_helper
DEBUG - 2014-08-12 18:49:33 --> Session routines successfully run
DEBUG - 2014-08-12 18:49:33 --> Controller Class Initialized
DEBUG - 2014-08-12 18:49:33 --> Helper loaded: form_helper
DEBUG - 2014-08-12 18:49:33 --> Form Validation Class Initialized
DEBUG - 2014-08-12 18:49:33 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-12 18:49:33 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:33 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:33 --> XSS Filtering completed
DEBUG - 2014-08-12 18:49:33 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-12 18:49:33 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-12 18:49:33 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-12 18:49:33 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-12 18:49:33 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-12 18:49:33 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-12 18:49:33 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-12 18:49:33 --> Final output sent to browser
DEBUG - 2014-08-12 18:49:33 --> Total execution time: 0.1589
DEBUG - 2014-08-12 18:50:05 --> Config Class Initialized
DEBUG - 2014-08-12 18:50:05 --> Hooks Class Initialized
DEBUG - 2014-08-12 18:50:05 --> Utf8 Class Initialized
DEBUG - 2014-08-12 18:50:05 --> UTF-8 Support Enabled
DEBUG - 2014-08-12 18:50:05 --> URI Class Initialized
DEBUG - 2014-08-12 18:50:05 --> Router Class Initialized
DEBUG - 2014-08-12 18:50:05 --> Output Class Initialized
DEBUG - 2014-08-12 18:50:05 --> Security Class Initialized
DEBUG - 2014-08-12 18:50:05 --> Input Class Initialized
DEBUG - 2014-08-12 18:50:05 --> XSS Filtering completed
DEBUG - 2014-08-12 18:50:05 --> XSS Filtering completed
DEBUG - 2014-08-12 18:50:05 --> XSS Filtering completed
DEBUG - 2014-08-12 18:50:05 --> XSS Filtering completed
DEBUG - 2014-08-12 18:50:05 --> XSS Filtering completed
DEBUG - 2014-08-12 18:50:05 --> XSS Filtering completed
DEBUG - 2014-08-12 18:50:05 --> XSS Filtering completed
DEBUG - 2014-08-12 18:50:05 --> XSS Filtering completed
DEBUG - 2014-08-12 18:50:05 --> XSS Filtering completed
DEBUG - 2014-08-12 18:50:05 --> XSS Filtering completed
DEBUG - 2014-08-12 18:50:05 --> XSS Filtering completed
DEBUG - 2014-08-12 18:50:05 --> XSS Filtering completed
DEBUG - 2014-08-12 18:50:05 --> XSS Filtering completed
DEBUG - 2014-08-12 18:50:05 --> XSS Filtering completed
DEBUG - 2014-08-12 18:50:05 --> XSS Filtering completed
DEBUG - 2014-08-12 18:50:05 --> XSS Filtering completed
DEBUG - 2014-08-12 18:50:05 --> CRSF cookie Set
DEBUG - 2014-08-12 18:50:05 --> CSRF token verified
DEBUG - 2014-08-12 18:50:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-12 18:50:05 --> Language Class Initialized
DEBUG - 2014-08-12 18:50:05 --> Loader Class Initialized
DEBUG - 2014-08-12 18:50:05 --> Helper loaded: functions_helper
DEBUG - 2014-08-12 18:50:05 --> Helper loaded: url_helper
DEBUG - 2014-08-12 18:50:05 --> Database Driver Class Initialized
ERROR - 2014-08-12 18:50:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-12 18:50:05 --> Session Class Initialized
DEBUG - 2014-08-12 18:50:05 --> Helper loaded: string_helper
DEBUG - 2014-08-12 18:50:05 --> Session routines successfully run
DEBUG - 2014-08-12 18:50:05 --> Controller Class Initialized
DEBUG - 2014-08-12 18:50:05 --> Helper loaded: form_helper
DEBUG - 2014-08-12 18:50:05 --> Form Validation Class Initialized
DEBUG - 2014-08-12 18:50:05 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-12 18:50:05 --> XSS Filtering completed
DEBUG - 2014-08-12 18:50:05 --> XSS Filtering completed
DEBUG - 2014-08-12 18:50:05 --> XSS Filtering completed
DEBUG - 2014-08-12 18:50:05 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-12 18:50:05 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-12 18:50:05 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-12 18:50:05 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-12 18:50:05 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-12 18:50:05 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-12 18:50:05 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-12 18:50:05 --> Final output sent to browser
DEBUG - 2014-08-12 18:50:05 --> Total execution time: 0.1551
