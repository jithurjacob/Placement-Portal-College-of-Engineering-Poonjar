<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-08-11 21:05:03 --> Config Class Initialized
DEBUG - 2014-08-11 21:05:03 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:05:03 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:05:03 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:05:03 --> URI Class Initialized
DEBUG - 2014-08-11 21:05:03 --> Router Class Initialized
DEBUG - 2014-08-11 21:05:03 --> Output Class Initialized
DEBUG - 2014-08-11 21:05:03 --> Security Class Initialized
DEBUG - 2014-08-11 21:05:03 --> Input Class Initialized
DEBUG - 2014-08-11 21:05:03 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:03 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:03 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:03 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:03 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:03 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:03 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:03 --> CRSF cookie Set
DEBUG - 2014-08-11 21:05:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:05:03 --> Language Class Initialized
DEBUG - 2014-08-11 21:05:03 --> Loader Class Initialized
DEBUG - 2014-08-11 21:05:03 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:05:03 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:05:03 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:05:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:05:03 --> Session Class Initialized
DEBUG - 2014-08-11 21:05:03 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:05:03 --> Session routines successfully run
DEBUG - 2014-08-11 21:05:03 --> Controller Class Initialized
DEBUG - 2014-08-11 21:05:03 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:05:03 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-11 21:05:03 --> Model Class Initialized
DEBUG - 2014-08-11 21:05:03 --> Model Class Initialized
DEBUG - 2014-08-11 21:05:03 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-11 21:05:03 --> File loaded: application/views/placement_under_construction_in.php
DEBUG - 2014-08-11 21:05:03 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:05:03 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:05:03 --> Final output sent to browser
DEBUG - 2014-08-11 21:05:03 --> Total execution time: 0.0484
DEBUG - 2014-08-11 21:05:05 --> Config Class Initialized
DEBUG - 2014-08-11 21:05:05 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:05:05 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:05:05 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:05:05 --> URI Class Initialized
DEBUG - 2014-08-11 21:05:05 --> Router Class Initialized
DEBUG - 2014-08-11 21:05:05 --> Output Class Initialized
DEBUG - 2014-08-11 21:05:05 --> Security Class Initialized
DEBUG - 2014-08-11 21:05:05 --> Input Class Initialized
DEBUG - 2014-08-11 21:05:05 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:05 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:05 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:05 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:05 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:05 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:05 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:05 --> CRSF cookie Set
DEBUG - 2014-08-11 21:05:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:05:05 --> Language Class Initialized
DEBUG - 2014-08-11 21:05:05 --> Loader Class Initialized
DEBUG - 2014-08-11 21:05:05 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:05:05 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:05:05 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:05:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:05:05 --> Session Class Initialized
DEBUG - 2014-08-11 21:05:05 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:05:05 --> Session routines successfully run
DEBUG - 2014-08-11 21:05:05 --> Controller Class Initialized
DEBUG - 2014-08-11 21:05:05 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:05:05 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-11 21:05:05 --> Model Class Initialized
DEBUG - 2014-08-11 21:05:05 --> Model Class Initialized
DEBUG - 2014-08-11 21:05:05 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-11 21:05:05 --> File loaded: application/views/placement_under_construction_in.php
DEBUG - 2014-08-11 21:05:05 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:05:05 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:05:05 --> Final output sent to browser
DEBUG - 2014-08-11 21:05:05 --> Total execution time: 0.0480
DEBUG - 2014-08-11 21:05:07 --> Config Class Initialized
DEBUG - 2014-08-11 21:05:07 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:05:07 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:05:07 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:05:07 --> URI Class Initialized
DEBUG - 2014-08-11 21:05:07 --> Router Class Initialized
DEBUG - 2014-08-11 21:05:07 --> Output Class Initialized
DEBUG - 2014-08-11 21:05:07 --> Security Class Initialized
DEBUG - 2014-08-11 21:05:07 --> Input Class Initialized
DEBUG - 2014-08-11 21:05:07 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:07 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:07 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:07 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:07 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:07 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:07 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:07 --> CRSF cookie Set
DEBUG - 2014-08-11 21:05:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:05:07 --> Language Class Initialized
DEBUG - 2014-08-11 21:05:07 --> Loader Class Initialized
DEBUG - 2014-08-11 21:05:07 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:05:07 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:05:07 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:05:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:05:07 --> Session Class Initialized
DEBUG - 2014-08-11 21:05:07 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:05:07 --> Session routines successfully run
DEBUG - 2014-08-11 21:05:07 --> Controller Class Initialized
DEBUG - 2014-08-11 21:05:07 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:05:07 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-11 21:05:07 --> Model Class Initialized
DEBUG - 2014-08-11 21:05:07 --> Model Class Initialized
DEBUG - 2014-08-11 21:05:07 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-11 21:05:07 --> File loaded: application/views/placement_under_construction_in.php
DEBUG - 2014-08-11 21:05:07 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:05:07 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:05:07 --> Final output sent to browser
DEBUG - 2014-08-11 21:05:07 --> Total execution time: 0.0462
DEBUG - 2014-08-11 21:05:08 --> Config Class Initialized
DEBUG - 2014-08-11 21:05:08 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:05:08 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:05:08 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:05:08 --> URI Class Initialized
DEBUG - 2014-08-11 21:05:08 --> Router Class Initialized
DEBUG - 2014-08-11 21:05:08 --> Output Class Initialized
DEBUG - 2014-08-11 21:05:08 --> Security Class Initialized
DEBUG - 2014-08-11 21:05:08 --> Input Class Initialized
DEBUG - 2014-08-11 21:05:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:08 --> CRSF cookie Set
DEBUG - 2014-08-11 21:05:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:05:08 --> Language Class Initialized
DEBUG - 2014-08-11 21:05:08 --> Loader Class Initialized
DEBUG - 2014-08-11 21:05:08 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:05:08 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:05:08 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:05:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:05:08 --> Session Class Initialized
DEBUG - 2014-08-11 21:05:08 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:05:08 --> Session routines successfully run
DEBUG - 2014-08-11 21:05:08 --> Controller Class Initialized
DEBUG - 2014-08-11 21:05:08 --> File loaded: application/views/logout.php
DEBUG - 2014-08-11 21:05:08 --> Final output sent to browser
DEBUG - 2014-08-11 21:05:08 --> Total execution time: 0.0429
DEBUG - 2014-08-11 21:05:08 --> Config Class Initialized
DEBUG - 2014-08-11 21:05:08 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:05:08 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:05:08 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:05:08 --> URI Class Initialized
DEBUG - 2014-08-11 21:05:08 --> Router Class Initialized
DEBUG - 2014-08-11 21:05:08 --> No URI present. Default controller set.
DEBUG - 2014-08-11 21:05:08 --> Output Class Initialized
DEBUG - 2014-08-11 21:05:08 --> Security Class Initialized
DEBUG - 2014-08-11 21:05:08 --> Input Class Initialized
DEBUG - 2014-08-11 21:05:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:08 --> CRSF cookie Set
DEBUG - 2014-08-11 21:05:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:05:08 --> Language Class Initialized
DEBUG - 2014-08-11 21:05:08 --> Loader Class Initialized
DEBUG - 2014-08-11 21:05:08 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:05:08 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:05:08 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:05:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:05:08 --> Session Class Initialized
DEBUG - 2014-08-11 21:05:08 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:05:08 --> A session cookie was not found.
DEBUG - 2014-08-11 21:05:08 --> Session routines successfully run
DEBUG - 2014-08-11 21:05:08 --> Controller Class Initialized
DEBUG - 2014-08-11 21:05:08 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:05:08 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-11 21:05:08 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-11 21:05:08 --> Helper loaded: form_helper
DEBUG - 2014-08-11 21:05:08 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-11 21:05:08 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-11 21:05:08 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:05:08 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:05:08 --> Final output sent to browser
DEBUG - 2014-08-11 21:05:08 --> Total execution time: 0.0679
DEBUG - 2014-08-11 21:05:25 --> Config Class Initialized
DEBUG - 2014-08-11 21:05:25 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:05:25 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:05:25 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:05:25 --> URI Class Initialized
DEBUG - 2014-08-11 21:05:25 --> Router Class Initialized
DEBUG - 2014-08-11 21:05:25 --> Output Class Initialized
DEBUG - 2014-08-11 21:05:25 --> Security Class Initialized
DEBUG - 2014-08-11 21:05:25 --> Input Class Initialized
DEBUG - 2014-08-11 21:05:25 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:25 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:25 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:25 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:25 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:25 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:25 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:25 --> CRSF cookie Set
DEBUG - 2014-08-11 21:05:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:05:25 --> Language Class Initialized
DEBUG - 2014-08-11 21:05:25 --> Loader Class Initialized
DEBUG - 2014-08-11 21:05:25 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:05:25 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:05:25 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:05:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:05:25 --> Session Class Initialized
DEBUG - 2014-08-11 21:05:25 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:05:25 --> Session routines successfully run
DEBUG - 2014-08-11 21:05:25 --> Controller Class Initialized
DEBUG - 2014-08-11 21:05:25 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:05:25 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-11 21:05:25 --> Model Class Initialized
DEBUG - 2014-08-11 21:05:25 --> Model Class Initialized
DEBUG - 2014-08-11 21:05:25 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-11 21:05:25 --> File loaded: application/views/placement_under_construction_in.php
DEBUG - 2014-08-11 21:05:25 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:05:25 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:05:25 --> Final output sent to browser
DEBUG - 2014-08-11 21:05:25 --> Total execution time: 0.0498
DEBUG - 2014-08-11 21:05:25 --> Config Class Initialized
DEBUG - 2014-08-11 21:05:25 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:05:25 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:05:25 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:05:25 --> URI Class Initialized
DEBUG - 2014-08-11 21:05:25 --> Router Class Initialized
DEBUG - 2014-08-11 21:05:25 --> Output Class Initialized
DEBUG - 2014-08-11 21:05:25 --> Security Class Initialized
DEBUG - 2014-08-11 21:05:25 --> Input Class Initialized
DEBUG - 2014-08-11 21:05:25 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:25 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:25 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:25 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:25 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:25 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:25 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:25 --> CRSF cookie Set
DEBUG - 2014-08-11 21:05:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:05:25 --> Language Class Initialized
DEBUG - 2014-08-11 21:05:25 --> Loader Class Initialized
DEBUG - 2014-08-11 21:05:25 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:05:25 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:05:25 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:05:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:05:25 --> Session Class Initialized
DEBUG - 2014-08-11 21:05:25 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:05:25 --> Session routines successfully run
DEBUG - 2014-08-11 21:05:25 --> Controller Class Initialized
DEBUG - 2014-08-11 21:05:25 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:05:25 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-11 21:05:25 --> Model Class Initialized
DEBUG - 2014-08-11 21:05:25 --> Model Class Initialized
DEBUG - 2014-08-11 21:05:25 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-11 21:05:25 --> File loaded: application/views/placement_under_construction_in.php
DEBUG - 2014-08-11 21:05:25 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:05:25 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:05:25 --> Final output sent to browser
DEBUG - 2014-08-11 21:05:25 --> Total execution time: 0.0772
DEBUG - 2014-08-11 21:05:30 --> Config Class Initialized
DEBUG - 2014-08-11 21:05:30 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:05:30 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:05:30 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:05:30 --> URI Class Initialized
DEBUG - 2014-08-11 21:05:30 --> Router Class Initialized
DEBUG - 2014-08-11 21:05:30 --> Output Class Initialized
DEBUG - 2014-08-11 21:05:30 --> Security Class Initialized
DEBUG - 2014-08-11 21:05:30 --> Input Class Initialized
DEBUG - 2014-08-11 21:05:30 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:30 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:30 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:30 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:30 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:30 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:30 --> XSS Filtering completed
DEBUG - 2014-08-11 21:05:30 --> CRSF cookie Set
DEBUG - 2014-08-11 21:05:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:05:30 --> Language Class Initialized
DEBUG - 2014-08-11 21:05:30 --> Loader Class Initialized
DEBUG - 2014-08-11 21:05:30 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:05:30 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:05:30 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:05:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:05:30 --> Session Class Initialized
DEBUG - 2014-08-11 21:05:30 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:05:30 --> Session routines successfully run
DEBUG - 2014-08-11 21:05:30 --> Controller Class Initialized
DEBUG - 2014-08-11 21:05:30 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:05:30 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-11 21:05:30 --> Model Class Initialized
DEBUG - 2014-08-11 21:05:30 --> Model Class Initialized
DEBUG - 2014-08-11 21:05:30 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-11 21:05:30 --> File loaded: application/views/placement_under_construction_in.php
DEBUG - 2014-08-11 21:05:30 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:05:30 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:05:30 --> Final output sent to browser
DEBUG - 2014-08-11 21:05:30 --> Total execution time: 0.0684
DEBUG - 2014-08-11 21:06:06 --> Config Class Initialized
DEBUG - 2014-08-11 21:06:06 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:06:06 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:06:06 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:06:06 --> URI Class Initialized
DEBUG - 2014-08-11 21:06:06 --> Router Class Initialized
DEBUG - 2014-08-11 21:06:06 --> Output Class Initialized
DEBUG - 2014-08-11 21:06:06 --> Security Class Initialized
DEBUG - 2014-08-11 21:06:06 --> Input Class Initialized
DEBUG - 2014-08-11 21:06:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:06:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:06:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:06:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:06:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:06:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:06:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:06:06 --> CRSF cookie Set
DEBUG - 2014-08-11 21:06:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:06:06 --> Language Class Initialized
DEBUG - 2014-08-11 21:06:06 --> Loader Class Initialized
DEBUG - 2014-08-11 21:06:06 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:06:06 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:06:06 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:06:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:06:06 --> Session Class Initialized
DEBUG - 2014-08-11 21:06:06 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:06:06 --> Session routines successfully run
DEBUG - 2014-08-11 21:06:06 --> Controller Class Initialized
DEBUG - 2014-08-11 21:06:06 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:06:06 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-11 21:06:06 --> Model Class Initialized
DEBUG - 2014-08-11 21:06:06 --> Model Class Initialized
DEBUG - 2014-08-11 21:06:06 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-11 21:06:06 --> File loaded: application/views/placement_under_construction_in.php
DEBUG - 2014-08-11 21:06:06 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:06:06 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:06:06 --> Final output sent to browser
DEBUG - 2014-08-11 21:06:06 --> Total execution time: 0.0474
DEBUG - 2014-08-11 21:06:06 --> Config Class Initialized
DEBUG - 2014-08-11 21:06:06 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:06:06 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:06:06 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:06:06 --> URI Class Initialized
DEBUG - 2014-08-11 21:06:06 --> Router Class Initialized
DEBUG - 2014-08-11 21:06:06 --> Output Class Initialized
DEBUG - 2014-08-11 21:06:06 --> Security Class Initialized
DEBUG - 2014-08-11 21:06:06 --> Input Class Initialized
DEBUG - 2014-08-11 21:06:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:06:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:06:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:06:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:06:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:06:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:06:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:06:06 --> CRSF cookie Set
DEBUG - 2014-08-11 21:06:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:06:06 --> Language Class Initialized
DEBUG - 2014-08-11 21:06:06 --> Loader Class Initialized
DEBUG - 2014-08-11 21:06:06 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:06:06 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:06:06 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:06:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:06:06 --> Session Class Initialized
DEBUG - 2014-08-11 21:06:06 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:06:06 --> Session routines successfully run
DEBUG - 2014-08-11 21:06:06 --> Controller Class Initialized
DEBUG - 2014-08-11 21:06:06 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:06:06 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-11 21:06:06 --> Model Class Initialized
DEBUG - 2014-08-11 21:06:06 --> Model Class Initialized
DEBUG - 2014-08-11 21:06:06 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-11 21:06:06 --> File loaded: application/views/placement_under_construction_in.php
DEBUG - 2014-08-11 21:06:06 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:06:06 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:06:06 --> Final output sent to browser
DEBUG - 2014-08-11 21:06:06 --> Total execution time: 0.0834
DEBUG - 2014-08-11 21:06:11 --> Config Class Initialized
DEBUG - 2014-08-11 21:06:11 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:06:11 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:06:11 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:06:11 --> URI Class Initialized
DEBUG - 2014-08-11 21:06:11 --> Router Class Initialized
DEBUG - 2014-08-11 21:06:11 --> Output Class Initialized
DEBUG - 2014-08-11 21:06:11 --> Security Class Initialized
DEBUG - 2014-08-11 21:06:11 --> Input Class Initialized
DEBUG - 2014-08-11 21:06:11 --> XSS Filtering completed
DEBUG - 2014-08-11 21:06:11 --> XSS Filtering completed
DEBUG - 2014-08-11 21:06:11 --> XSS Filtering completed
DEBUG - 2014-08-11 21:06:11 --> XSS Filtering completed
DEBUG - 2014-08-11 21:06:11 --> XSS Filtering completed
DEBUG - 2014-08-11 21:06:11 --> XSS Filtering completed
DEBUG - 2014-08-11 21:06:11 --> XSS Filtering completed
DEBUG - 2014-08-11 21:06:11 --> CRSF cookie Set
DEBUG - 2014-08-11 21:06:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:06:11 --> Language Class Initialized
DEBUG - 2014-08-11 21:06:11 --> Loader Class Initialized
DEBUG - 2014-08-11 21:06:11 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:06:11 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:06:11 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:06:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:06:11 --> Session Class Initialized
DEBUG - 2014-08-11 21:06:11 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:06:11 --> Session routines successfully run
DEBUG - 2014-08-11 21:06:11 --> Controller Class Initialized
DEBUG - 2014-08-11 21:06:11 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:06:11 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-11 21:06:11 --> Model Class Initialized
DEBUG - 2014-08-11 21:06:11 --> Model Class Initialized
DEBUG - 2014-08-11 21:06:11 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-11 21:06:11 --> File loaded: application/views/placement_under_construction_in.php
DEBUG - 2014-08-11 21:06:11 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:06:11 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:06:11 --> Final output sent to browser
DEBUG - 2014-08-11 21:06:11 --> Total execution time: 0.0610
DEBUG - 2014-08-11 21:06:41 --> Config Class Initialized
DEBUG - 2014-08-11 21:06:41 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:06:41 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:06:41 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:06:41 --> URI Class Initialized
DEBUG - 2014-08-11 21:06:41 --> Router Class Initialized
DEBUG - 2014-08-11 21:06:41 --> Output Class Initialized
DEBUG - 2014-08-11 21:06:41 --> Security Class Initialized
DEBUG - 2014-08-11 21:06:41 --> Input Class Initialized
DEBUG - 2014-08-11 21:06:41 --> XSS Filtering completed
DEBUG - 2014-08-11 21:06:41 --> XSS Filtering completed
DEBUG - 2014-08-11 21:06:41 --> XSS Filtering completed
DEBUG - 2014-08-11 21:06:41 --> XSS Filtering completed
DEBUG - 2014-08-11 21:06:41 --> XSS Filtering completed
DEBUG - 2014-08-11 21:06:41 --> XSS Filtering completed
DEBUG - 2014-08-11 21:06:41 --> XSS Filtering completed
DEBUG - 2014-08-11 21:06:41 --> CRSF cookie Set
DEBUG - 2014-08-11 21:06:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:06:41 --> Language Class Initialized
DEBUG - 2014-08-11 21:06:41 --> Loader Class Initialized
DEBUG - 2014-08-11 21:06:41 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:06:41 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:06:41 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:06:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:06:41 --> Session Class Initialized
DEBUG - 2014-08-11 21:06:41 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:06:41 --> Session routines successfully run
DEBUG - 2014-08-11 21:06:41 --> Controller Class Initialized
DEBUG - 2014-08-11 21:06:41 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:06:41 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-11 21:06:41 --> Model Class Initialized
DEBUG - 2014-08-11 21:06:41 --> Model Class Initialized
DEBUG - 2014-08-11 21:06:41 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-11 21:06:41 --> File loaded: application/views/placement_under_construction_in.php
DEBUG - 2014-08-11 21:06:41 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:06:41 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:06:41 --> Final output sent to browser
DEBUG - 2014-08-11 21:06:41 --> Total execution time: 0.0680
DEBUG - 2014-08-11 21:07:04 --> Config Class Initialized
DEBUG - 2014-08-11 21:07:04 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:07:04 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:07:04 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:07:04 --> URI Class Initialized
DEBUG - 2014-08-11 21:07:04 --> Router Class Initialized
DEBUG - 2014-08-11 21:07:04 --> Output Class Initialized
DEBUG - 2014-08-11 21:07:04 --> Security Class Initialized
DEBUG - 2014-08-11 21:07:04 --> Input Class Initialized
DEBUG - 2014-08-11 21:07:04 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:04 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:04 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:04 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:04 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:04 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:04 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:04 --> CRSF cookie Set
DEBUG - 2014-08-11 21:07:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:07:04 --> Language Class Initialized
DEBUG - 2014-08-11 21:07:04 --> Loader Class Initialized
DEBUG - 2014-08-11 21:07:04 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:07:04 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:07:04 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:07:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:07:04 --> Session Class Initialized
DEBUG - 2014-08-11 21:07:04 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:07:04 --> Session routines successfully run
DEBUG - 2014-08-11 21:07:04 --> Controller Class Initialized
DEBUG - 2014-08-11 21:07:04 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:07:04 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-11 21:07:04 --> Model Class Initialized
DEBUG - 2014-08-11 21:07:04 --> Model Class Initialized
DEBUG - 2014-08-11 21:07:04 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-11 21:07:04 --> File loaded: application/views/placement_under_construction_in.php
DEBUG - 2014-08-11 21:07:04 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:07:04 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:07:04 --> Final output sent to browser
DEBUG - 2014-08-11 21:07:04 --> Total execution time: 0.0519
DEBUG - 2014-08-11 21:07:06 --> Config Class Initialized
DEBUG - 2014-08-11 21:07:06 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:07:06 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:07:06 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:07:06 --> URI Class Initialized
DEBUG - 2014-08-11 21:07:06 --> Router Class Initialized
DEBUG - 2014-08-11 21:07:06 --> Output Class Initialized
DEBUG - 2014-08-11 21:07:06 --> Security Class Initialized
DEBUG - 2014-08-11 21:07:06 --> Input Class Initialized
DEBUG - 2014-08-11 21:07:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:06 --> CRSF cookie Set
DEBUG - 2014-08-11 21:07:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:07:06 --> Language Class Initialized
DEBUG - 2014-08-11 21:07:06 --> Loader Class Initialized
DEBUG - 2014-08-11 21:07:06 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:07:06 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:07:06 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:07:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:07:06 --> Session Class Initialized
DEBUG - 2014-08-11 21:07:06 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:07:06 --> Session routines successfully run
DEBUG - 2014-08-11 21:07:06 --> Controller Class Initialized
DEBUG - 2014-08-11 21:07:06 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:07:06 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-11 21:07:06 --> Model Class Initialized
DEBUG - 2014-08-11 21:07:06 --> Model Class Initialized
DEBUG - 2014-08-11 21:07:06 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-11 21:07:06 --> File loaded: application/views/placement_under_construction_in.php
DEBUG - 2014-08-11 21:07:06 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:07:06 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:07:06 --> Final output sent to browser
DEBUG - 2014-08-11 21:07:06 --> Total execution time: 0.0540
DEBUG - 2014-08-11 21:07:08 --> Config Class Initialized
DEBUG - 2014-08-11 21:07:08 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:07:08 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:07:08 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:07:08 --> URI Class Initialized
DEBUG - 2014-08-11 21:07:08 --> Router Class Initialized
DEBUG - 2014-08-11 21:07:08 --> Output Class Initialized
DEBUG - 2014-08-11 21:07:08 --> Security Class Initialized
DEBUG - 2014-08-11 21:07:08 --> Input Class Initialized
DEBUG - 2014-08-11 21:07:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:08 --> CRSF cookie Set
DEBUG - 2014-08-11 21:07:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:07:08 --> Language Class Initialized
DEBUG - 2014-08-11 21:07:08 --> Loader Class Initialized
DEBUG - 2014-08-11 21:07:08 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:07:08 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:07:08 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:07:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:07:08 --> Session Class Initialized
DEBUG - 2014-08-11 21:07:08 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:07:08 --> Session routines successfully run
DEBUG - 2014-08-11 21:07:08 --> Controller Class Initialized
DEBUG - 2014-08-11 21:07:08 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:07:08 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-11 21:07:08 --> Model Class Initialized
DEBUG - 2014-08-11 21:07:08 --> Model Class Initialized
DEBUG - 2014-08-11 21:07:08 --> Helper loaded: form_helper
DEBUG - 2014-08-11 21:07:08 --> Helper loaded: array_helper
ERROR - 2014-08-11 21:07:08 --> Severity: Notice  --> Undefined variable: error C:\wamp\www\cep\placement\application\views\placement_students_update.php 44
ERROR - 2014-08-11 21:07:08 --> Severity: Notice  --> Undefined variable: error C:\wamp\www\cep\placement\application\views\placement_students_update.php 53
ERROR - 2014-08-11 21:07:08 --> Severity: Notice  --> Undefined variable: error C:\wamp\www\cep\placement\application\views\placement_students_update.php 61
ERROR - 2014-08-11 21:07:08 --> Severity: Notice  --> Undefined variable: error C:\wamp\www\cep\placement\application\views\placement_students_update.php 74
ERROR - 2014-08-11 21:07:08 --> Severity: Notice  --> Undefined variable: error C:\wamp\www\cep\placement\application\views\placement_students_update.php 82
ERROR - 2014-08-11 21:07:08 --> Severity: Notice  --> Undefined variable: error C:\wamp\www\cep\placement\application\views\placement_students_update.php 90
ERROR - 2014-08-11 21:07:08 --> Severity: Notice  --> Undefined variable: paddr C:\wamp\www\cep\placement\application\views\placement_students_update.php 90
ERROR - 2014-08-11 21:07:08 --> Severity: Notice  --> Undefined variable: error C:\wamp\www\cep\placement\application\views\placement_students_update.php 98
ERROR - 2014-08-11 21:07:08 --> Severity: Notice  --> Undefined variable: caddr C:\wamp\www\cep\placement\application\views\placement_students_update.php 98
ERROR - 2014-08-11 21:07:08 --> Severity: Notice  --> Undefined variable: error C:\wamp\www\cep\placement\application\views\placement_students_update.php 106
ERROR - 2014-08-11 21:07:08 --> Severity: Notice  --> Undefined variable: error C:\wamp\www\cep\placement\application\views\placement_students_update.php 114
ERROR - 2014-08-11 21:07:08 --> Severity: Notice  --> Undefined variable: error C:\wamp\www\cep\placement\application\views\placement_students_update.php 122
ERROR - 2014-08-11 21:07:08 --> Severity: Notice  --> Undefined variable: error C:\wamp\www\cep\placement\application\views\placement_students_update.php 130
ERROR - 2014-08-11 21:07:08 --> Severity: Notice  --> Undefined variable: error C:\wamp\www\cep\placement\application\views\placement_students_update.php 138
ERROR - 2014-08-11 21:07:08 --> Severity: Notice  --> Undefined variable: error C:\wamp\www\cep\placement\application\views\placement_students_update.php 146
ERROR - 2014-08-11 21:07:08 --> Severity: Notice  --> Undefined variable: error C:\wamp\www\cep\placement\application\views\placement_students_update.php 154
DEBUG - 2014-08-11 21:07:08 --> File loaded: application/views/placement_students_update.php
DEBUG - 2014-08-11 21:07:08 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:07:08 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:07:08 --> Final output sent to browser
DEBUG - 2014-08-11 21:07:08 --> Total execution time: 0.0575
DEBUG - 2014-08-11 21:07:09 --> Config Class Initialized
DEBUG - 2014-08-11 21:07:09 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:07:09 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:07:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:07:09 --> URI Class Initialized
DEBUG - 2014-08-11 21:07:09 --> Router Class Initialized
DEBUG - 2014-08-11 21:07:09 --> Output Class Initialized
DEBUG - 2014-08-11 21:07:09 --> Security Class Initialized
DEBUG - 2014-08-11 21:07:09 --> Input Class Initialized
DEBUG - 2014-08-11 21:07:09 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:09 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:09 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:09 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:09 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:09 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:09 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:09 --> CRSF cookie Set
DEBUG - 2014-08-11 21:07:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:07:09 --> Language Class Initialized
DEBUG - 2014-08-11 21:07:09 --> Loader Class Initialized
DEBUG - 2014-08-11 21:07:09 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:07:09 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:07:09 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:07:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:07:09 --> Session Class Initialized
DEBUG - 2014-08-11 21:07:09 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:07:09 --> Session routines successfully run
DEBUG - 2014-08-11 21:07:09 --> Controller Class Initialized
DEBUG - 2014-08-11 21:07:09 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:07:09 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-11 21:07:09 --> Model Class Initialized
DEBUG - 2014-08-11 21:07:09 --> Model Class Initialized
DEBUG - 2014-08-11 21:07:09 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-11 21:07:09 --> File loaded: application/views/placement_under_construction_in.php
DEBUG - 2014-08-11 21:07:09 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:07:09 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:07:09 --> Final output sent to browser
DEBUG - 2014-08-11 21:07:09 --> Total execution time: 0.0521
DEBUG - 2014-08-11 21:07:10 --> Config Class Initialized
DEBUG - 2014-08-11 21:07:10 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:07:10 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:07:10 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:07:10 --> URI Class Initialized
DEBUG - 2014-08-11 21:07:10 --> Router Class Initialized
DEBUG - 2014-08-11 21:07:10 --> Output Class Initialized
DEBUG - 2014-08-11 21:07:10 --> Security Class Initialized
DEBUG - 2014-08-11 21:07:10 --> Input Class Initialized
DEBUG - 2014-08-11 21:07:10 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:10 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:10 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:10 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:10 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:10 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:10 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:10 --> CRSF cookie Set
DEBUG - 2014-08-11 21:07:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:07:10 --> Language Class Initialized
DEBUG - 2014-08-11 21:07:10 --> Loader Class Initialized
DEBUG - 2014-08-11 21:07:10 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:07:10 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:07:10 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:07:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:07:10 --> Session Class Initialized
DEBUG - 2014-08-11 21:07:10 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:07:10 --> Session routines successfully run
DEBUG - 2014-08-11 21:07:10 --> Controller Class Initialized
DEBUG - 2014-08-11 21:07:10 --> File loaded: application/views/logout.php
DEBUG - 2014-08-11 21:07:10 --> Final output sent to browser
DEBUG - 2014-08-11 21:07:10 --> Total execution time: 0.0387
DEBUG - 2014-08-11 21:07:11 --> Config Class Initialized
DEBUG - 2014-08-11 21:07:11 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:07:11 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:07:11 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:07:11 --> URI Class Initialized
DEBUG - 2014-08-11 21:07:11 --> Router Class Initialized
DEBUG - 2014-08-11 21:07:11 --> No URI present. Default controller set.
DEBUG - 2014-08-11 21:07:11 --> Output Class Initialized
DEBUG - 2014-08-11 21:07:11 --> Security Class Initialized
DEBUG - 2014-08-11 21:07:11 --> Input Class Initialized
DEBUG - 2014-08-11 21:07:11 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:11 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:11 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:11 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:11 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:11 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:11 --> CRSF cookie Set
DEBUG - 2014-08-11 21:07:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:07:11 --> Language Class Initialized
DEBUG - 2014-08-11 21:07:11 --> Loader Class Initialized
DEBUG - 2014-08-11 21:07:11 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:07:11 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:07:11 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:07:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:07:11 --> Session Class Initialized
DEBUG - 2014-08-11 21:07:11 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:07:11 --> A session cookie was not found.
DEBUG - 2014-08-11 21:07:11 --> Session routines successfully run
DEBUG - 2014-08-11 21:07:11 --> Controller Class Initialized
DEBUG - 2014-08-11 21:07:11 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:07:11 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-11 21:07:11 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-11 21:07:11 --> Helper loaded: form_helper
DEBUG - 2014-08-11 21:07:11 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-11 21:07:11 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-11 21:07:11 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:07:11 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:07:11 --> Final output sent to browser
DEBUG - 2014-08-11 21:07:11 --> Total execution time: 0.0633
DEBUG - 2014-08-11 21:07:18 --> Config Class Initialized
DEBUG - 2014-08-11 21:07:18 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:07:18 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:07:18 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:07:18 --> URI Class Initialized
DEBUG - 2014-08-11 21:07:18 --> Router Class Initialized
DEBUG - 2014-08-11 21:07:18 --> Output Class Initialized
DEBUG - 2014-08-11 21:07:18 --> Security Class Initialized
DEBUG - 2014-08-11 21:07:18 --> Input Class Initialized
DEBUG - 2014-08-11 21:07:18 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:18 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:18 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:18 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:18 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:18 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:18 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:18 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:18 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:18 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:18 --> CRSF cookie Set
DEBUG - 2014-08-11 21:07:18 --> CSRF token verified
DEBUG - 2014-08-11 21:07:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:07:18 --> Language Class Initialized
DEBUG - 2014-08-11 21:07:18 --> Loader Class Initialized
DEBUG - 2014-08-11 21:07:18 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:07:18 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:07:18 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:07:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:07:18 --> Session Class Initialized
DEBUG - 2014-08-11 21:07:18 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:07:18 --> Session routines successfully run
DEBUG - 2014-08-11 21:07:18 --> Controller Class Initialized
DEBUG - 2014-08-11 21:07:18 --> Helper loaded: form_helper
DEBUG - 2014-08-11 21:07:18 --> Form Validation Class Initialized
DEBUG - 2014-08-11 21:07:18 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-11 21:07:19 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:19 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:19 --> Model Class Initialized
DEBUG - 2014-08-11 21:07:19 --> Model Class Initialized
DEBUG - 2014-08-11 21:07:19 --> Encrypt Class Initialized
DEBUG - 2014-08-11 21:07:19 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:19 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:19 --> Model Class Initialized
DEBUG - 2014-08-11 21:07:19 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-11 21:07:19 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:19 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:19 --> Config Class Initialized
DEBUG - 2014-08-11 21:07:19 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:07:19 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:07:19 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:07:19 --> URI Class Initialized
DEBUG - 2014-08-11 21:07:19 --> Router Class Initialized
DEBUG - 2014-08-11 21:07:19 --> Output Class Initialized
DEBUG - 2014-08-11 21:07:19 --> Security Class Initialized
DEBUG - 2014-08-11 21:07:19 --> Input Class Initialized
DEBUG - 2014-08-11 21:07:19 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:19 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:19 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:19 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:19 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:19 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:19 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:19 --> CRSF cookie Set
DEBUG - 2014-08-11 21:07:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:07:19 --> Language Class Initialized
DEBUG - 2014-08-11 21:07:19 --> Loader Class Initialized
DEBUG - 2014-08-11 21:07:19 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:07:19 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:07:19 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:07:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:07:19 --> Session Class Initialized
DEBUG - 2014-08-11 21:07:19 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:07:19 --> Session routines successfully run
DEBUG - 2014-08-11 21:07:19 --> Controller Class Initialized
DEBUG - 2014-08-11 21:07:19 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:07:19 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-11 21:07:19 --> Model Class Initialized
DEBUG - 2014-08-11 21:07:19 --> Model Class Initialized
DEBUG - 2014-08-11 21:07:19 --> Helper loaded: array_helper
DEBUG - 2014-08-11 21:07:19 --> File loaded: application/views/placement_students_home.php
DEBUG - 2014-08-11 21:07:19 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:07:19 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:07:19 --> Final output sent to browser
DEBUG - 2014-08-11 21:07:19 --> Total execution time: 0.0637
DEBUG - 2014-08-11 21:07:20 --> Config Class Initialized
DEBUG - 2014-08-11 21:07:20 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:07:20 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:07:20 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:07:20 --> URI Class Initialized
DEBUG - 2014-08-11 21:07:20 --> Router Class Initialized
DEBUG - 2014-08-11 21:07:20 --> Output Class Initialized
DEBUG - 2014-08-11 21:07:20 --> Security Class Initialized
DEBUG - 2014-08-11 21:07:20 --> Input Class Initialized
DEBUG - 2014-08-11 21:07:20 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:20 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:20 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:20 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:20 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:20 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:20 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:20 --> CRSF cookie Set
DEBUG - 2014-08-11 21:07:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:07:20 --> Language Class Initialized
DEBUG - 2014-08-11 21:07:20 --> Loader Class Initialized
DEBUG - 2014-08-11 21:07:20 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:07:20 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:07:20 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:07:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:07:20 --> Session Class Initialized
DEBUG - 2014-08-11 21:07:20 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:07:20 --> Session routines successfully run
DEBUG - 2014-08-11 21:07:20 --> Controller Class Initialized
DEBUG - 2014-08-11 21:07:20 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:07:20 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-11 21:07:20 --> Model Class Initialized
DEBUG - 2014-08-11 21:07:20 --> Model Class Initialized
DEBUG - 2014-08-11 21:07:20 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-11 21:07:20 --> File loaded: application/views/placement_under_construction_in.php
DEBUG - 2014-08-11 21:07:20 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:07:20 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:07:20 --> Final output sent to browser
DEBUG - 2014-08-11 21:07:20 --> Total execution time: 0.0518
DEBUG - 2014-08-11 21:07:22 --> Config Class Initialized
DEBUG - 2014-08-11 21:07:22 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:07:22 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:07:22 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:07:22 --> URI Class Initialized
DEBUG - 2014-08-11 21:07:22 --> Router Class Initialized
DEBUG - 2014-08-11 21:07:22 --> Output Class Initialized
DEBUG - 2014-08-11 21:07:22 --> Security Class Initialized
DEBUG - 2014-08-11 21:07:22 --> Input Class Initialized
DEBUG - 2014-08-11 21:07:22 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:22 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:22 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:22 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:22 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:22 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:22 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:22 --> CRSF cookie Set
DEBUG - 2014-08-11 21:07:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:07:22 --> Language Class Initialized
DEBUG - 2014-08-11 21:07:22 --> Loader Class Initialized
DEBUG - 2014-08-11 21:07:22 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:07:22 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:07:22 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:07:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:07:22 --> Session Class Initialized
DEBUG - 2014-08-11 21:07:22 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:07:22 --> Session routines successfully run
DEBUG - 2014-08-11 21:07:22 --> Controller Class Initialized
DEBUG - 2014-08-11 21:07:22 --> File loaded: application/views/logout.php
DEBUG - 2014-08-11 21:07:22 --> Final output sent to browser
DEBUG - 2014-08-11 21:07:22 --> Total execution time: 0.0433
DEBUG - 2014-08-11 21:07:22 --> Config Class Initialized
DEBUG - 2014-08-11 21:07:22 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:07:22 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:07:22 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:07:22 --> URI Class Initialized
DEBUG - 2014-08-11 21:07:22 --> Router Class Initialized
DEBUG - 2014-08-11 21:07:22 --> No URI present. Default controller set.
DEBUG - 2014-08-11 21:07:22 --> Output Class Initialized
DEBUG - 2014-08-11 21:07:22 --> Security Class Initialized
DEBUG - 2014-08-11 21:07:22 --> Input Class Initialized
DEBUG - 2014-08-11 21:07:22 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:22 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:22 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:22 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:22 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:22 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:22 --> CRSF cookie Set
DEBUG - 2014-08-11 21:07:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:07:22 --> Language Class Initialized
DEBUG - 2014-08-11 21:07:22 --> Loader Class Initialized
DEBUG - 2014-08-11 21:07:22 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:07:22 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:07:22 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:07:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:07:22 --> Session Class Initialized
DEBUG - 2014-08-11 21:07:22 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:07:22 --> A session cookie was not found.
DEBUG - 2014-08-11 21:07:22 --> Session routines successfully run
DEBUG - 2014-08-11 21:07:22 --> Controller Class Initialized
DEBUG - 2014-08-11 21:07:22 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:07:22 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-11 21:07:22 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-11 21:07:22 --> Helper loaded: form_helper
DEBUG - 2014-08-11 21:07:22 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-11 21:07:22 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-11 21:07:22 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:07:22 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:07:22 --> Final output sent to browser
DEBUG - 2014-08-11 21:07:22 --> Total execution time: 0.0685
DEBUG - 2014-08-11 21:07:26 --> Config Class Initialized
DEBUG - 2014-08-11 21:07:26 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:07:26 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:07:26 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:07:26 --> URI Class Initialized
DEBUG - 2014-08-11 21:07:26 --> Router Class Initialized
DEBUG - 2014-08-11 21:07:26 --> Output Class Initialized
DEBUG - 2014-08-11 21:07:26 --> Security Class Initialized
DEBUG - 2014-08-11 21:07:26 --> Input Class Initialized
DEBUG - 2014-08-11 21:07:26 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:26 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:26 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:26 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:26 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:26 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:26 --> XSS Filtering completed
DEBUG - 2014-08-11 21:07:26 --> CRSF cookie Set
DEBUG - 2014-08-11 21:07:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:07:26 --> Language Class Initialized
DEBUG - 2014-08-11 21:07:26 --> Loader Class Initialized
DEBUG - 2014-08-11 21:07:26 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:07:26 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:07:26 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:07:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:07:26 --> Session Class Initialized
DEBUG - 2014-08-11 21:07:26 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:07:26 --> Session routines successfully run
DEBUG - 2014-08-11 21:07:26 --> Controller Class Initialized
DEBUG - 2014-08-11 21:07:26 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:07:26 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-11 21:07:26 --> Model Class Initialized
DEBUG - 2014-08-11 21:07:26 --> Model Class Initialized
DEBUG - 2014-08-11 21:07:26 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-11 21:07:26 --> File loaded: application/views/placement_under_construction_in.php
DEBUG - 2014-08-11 21:07:26 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:07:26 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:07:26 --> Final output sent to browser
DEBUG - 2014-08-11 21:07:26 --> Total execution time: 0.0525
DEBUG - 2014-08-11 21:08:53 --> Config Class Initialized
DEBUG - 2014-08-11 21:08:53 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:08:53 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:08:53 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:08:53 --> URI Class Initialized
DEBUG - 2014-08-11 21:08:53 --> Router Class Initialized
DEBUG - 2014-08-11 21:08:53 --> Output Class Initialized
DEBUG - 2014-08-11 21:08:53 --> Security Class Initialized
DEBUG - 2014-08-11 21:08:53 --> Input Class Initialized
DEBUG - 2014-08-11 21:08:53 --> XSS Filtering completed
DEBUG - 2014-08-11 21:08:53 --> XSS Filtering completed
DEBUG - 2014-08-11 21:08:53 --> XSS Filtering completed
DEBUG - 2014-08-11 21:08:53 --> XSS Filtering completed
DEBUG - 2014-08-11 21:08:53 --> XSS Filtering completed
DEBUG - 2014-08-11 21:08:53 --> XSS Filtering completed
DEBUG - 2014-08-11 21:08:53 --> XSS Filtering completed
DEBUG - 2014-08-11 21:08:53 --> CRSF cookie Set
DEBUG - 2014-08-11 21:08:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:08:53 --> Language Class Initialized
DEBUG - 2014-08-11 21:08:53 --> Loader Class Initialized
DEBUG - 2014-08-11 21:08:53 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:08:53 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:08:53 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:08:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:08:53 --> Session Class Initialized
DEBUG - 2014-08-11 21:08:53 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:08:53 --> Session routines successfully run
DEBUG - 2014-08-11 21:08:53 --> Controller Class Initialized
DEBUG - 2014-08-11 21:08:53 --> File loaded: application/views/login_to_continue.php
DEBUG - 2014-08-11 21:08:53 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:08:53 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-11 21:08:53 --> Model Class Initialized
DEBUG - 2014-08-11 21:08:53 --> Model Class Initialized
DEBUG - 2014-08-11 21:08:53 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-11 21:08:53 --> File loaded: application/views/placement_under_construction_in.php
DEBUG - 2014-08-11 21:08:53 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:08:53 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:08:53 --> Final output sent to browser
DEBUG - 2014-08-11 21:08:53 --> Total execution time: 0.0511
DEBUG - 2014-08-11 21:08:54 --> Config Class Initialized
DEBUG - 2014-08-11 21:08:54 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:08:54 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:08:54 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:08:54 --> URI Class Initialized
DEBUG - 2014-08-11 21:08:54 --> Router Class Initialized
DEBUG - 2014-08-11 21:08:54 --> No URI present. Default controller set.
DEBUG - 2014-08-11 21:08:54 --> Output Class Initialized
DEBUG - 2014-08-11 21:08:54 --> Security Class Initialized
DEBUG - 2014-08-11 21:08:54 --> Input Class Initialized
DEBUG - 2014-08-11 21:08:54 --> XSS Filtering completed
DEBUG - 2014-08-11 21:08:54 --> XSS Filtering completed
DEBUG - 2014-08-11 21:08:54 --> XSS Filtering completed
DEBUG - 2014-08-11 21:08:54 --> XSS Filtering completed
DEBUG - 2014-08-11 21:08:54 --> XSS Filtering completed
DEBUG - 2014-08-11 21:08:54 --> XSS Filtering completed
DEBUG - 2014-08-11 21:08:54 --> XSS Filtering completed
DEBUG - 2014-08-11 21:08:54 --> CRSF cookie Set
DEBUG - 2014-08-11 21:08:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:08:54 --> Language Class Initialized
DEBUG - 2014-08-11 21:08:54 --> Loader Class Initialized
DEBUG - 2014-08-11 21:08:54 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:08:54 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:08:54 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:08:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:08:54 --> Session Class Initialized
DEBUG - 2014-08-11 21:08:54 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:08:54 --> Session routines successfully run
DEBUG - 2014-08-11 21:08:54 --> Controller Class Initialized
DEBUG - 2014-08-11 21:08:54 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:08:54 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-11 21:08:54 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-11 21:08:54 --> Helper loaded: form_helper
DEBUG - 2014-08-11 21:08:54 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-11 21:08:54 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-11 21:08:54 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:08:54 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:08:54 --> Final output sent to browser
DEBUG - 2014-08-11 21:08:54 --> Total execution time: 0.0836
DEBUG - 2014-08-11 21:09:06 --> Config Class Initialized
DEBUG - 2014-08-11 21:09:06 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:09:06 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:09:06 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:09:06 --> URI Class Initialized
DEBUG - 2014-08-11 21:09:06 --> Router Class Initialized
DEBUG - 2014-08-11 21:09:06 --> Output Class Initialized
DEBUG - 2014-08-11 21:09:06 --> Security Class Initialized
DEBUG - 2014-08-11 21:09:06 --> Input Class Initialized
DEBUG - 2014-08-11 21:09:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:06 --> CRSF cookie Set
DEBUG - 2014-08-11 21:09:06 --> CSRF token verified
DEBUG - 2014-08-11 21:09:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:09:06 --> Language Class Initialized
DEBUG - 2014-08-11 21:09:06 --> Loader Class Initialized
DEBUG - 2014-08-11 21:09:06 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:09:06 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:09:06 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:09:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:09:06 --> Session Class Initialized
DEBUG - 2014-08-11 21:09:06 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:09:06 --> Session routines successfully run
DEBUG - 2014-08-11 21:09:06 --> Controller Class Initialized
DEBUG - 2014-08-11 21:09:06 --> Helper loaded: form_helper
DEBUG - 2014-08-11 21:09:06 --> Form Validation Class Initialized
DEBUG - 2014-08-11 21:09:06 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-11 21:09:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:06 --> Model Class Initialized
DEBUG - 2014-08-11 21:09:06 --> Model Class Initialized
DEBUG - 2014-08-11 21:09:06 --> Encrypt Class Initialized
DEBUG - 2014-08-11 21:09:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:06 --> Model Class Initialized
DEBUG - 2014-08-11 21:09:06 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-11 21:09:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:06 --> Config Class Initialized
DEBUG - 2014-08-11 21:09:06 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:09:06 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:09:06 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:09:06 --> URI Class Initialized
DEBUG - 2014-08-11 21:09:06 --> Router Class Initialized
DEBUG - 2014-08-11 21:09:06 --> Output Class Initialized
DEBUG - 2014-08-11 21:09:06 --> Security Class Initialized
DEBUG - 2014-08-11 21:09:06 --> Input Class Initialized
DEBUG - 2014-08-11 21:09:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:06 --> CRSF cookie Set
DEBUG - 2014-08-11 21:09:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:09:06 --> Language Class Initialized
DEBUG - 2014-08-11 21:09:06 --> Loader Class Initialized
DEBUG - 2014-08-11 21:09:06 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:09:06 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:09:06 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:09:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:09:06 --> Session Class Initialized
DEBUG - 2014-08-11 21:09:06 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:09:06 --> Session routines successfully run
DEBUG - 2014-08-11 21:09:06 --> Controller Class Initialized
DEBUG - 2014-08-11 21:09:06 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:09:06 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-11 21:09:06 --> Model Class Initialized
DEBUG - 2014-08-11 21:09:06 --> Model Class Initialized
DEBUG - 2014-08-11 21:09:06 --> Helper loaded: array_helper
DEBUG - 2014-08-11 21:09:06 --> File loaded: application/views/placement_students_home.php
DEBUG - 2014-08-11 21:09:06 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:09:06 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:09:06 --> Final output sent to browser
DEBUG - 2014-08-11 21:09:06 --> Total execution time: 0.0644
DEBUG - 2014-08-11 21:09:09 --> Config Class Initialized
DEBUG - 2014-08-11 21:09:09 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:09:09 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:09:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:09:09 --> URI Class Initialized
DEBUG - 2014-08-11 21:09:09 --> Router Class Initialized
DEBUG - 2014-08-11 21:09:09 --> Output Class Initialized
DEBUG - 2014-08-11 21:09:09 --> Security Class Initialized
DEBUG - 2014-08-11 21:09:09 --> Input Class Initialized
DEBUG - 2014-08-11 21:09:09 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:09 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:09 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:09 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:09 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:09 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:09 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:09 --> CRSF cookie Set
DEBUG - 2014-08-11 21:09:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:09:09 --> Language Class Initialized
DEBUG - 2014-08-11 21:09:09 --> Loader Class Initialized
DEBUG - 2014-08-11 21:09:09 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:09:09 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:09:09 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:09:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:09:09 --> Session Class Initialized
DEBUG - 2014-08-11 21:09:09 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:09:09 --> Session routines successfully run
DEBUG - 2014-08-11 21:09:09 --> Controller Class Initialized
DEBUG - 2014-08-11 21:09:09 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:09:09 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-11 21:09:09 --> Model Class Initialized
DEBUG - 2014-08-11 21:09:09 --> Model Class Initialized
DEBUG - 2014-08-11 21:09:09 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-11 21:09:09 --> File loaded: application/views/placement_under_construction_in.php
DEBUG - 2014-08-11 21:09:09 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:09:09 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:09:09 --> Final output sent to browser
DEBUG - 2014-08-11 21:09:09 --> Total execution time: 0.0507
DEBUG - 2014-08-11 21:09:10 --> Config Class Initialized
DEBUG - 2014-08-11 21:09:10 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:09:10 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:09:10 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:09:10 --> URI Class Initialized
DEBUG - 2014-08-11 21:09:10 --> Router Class Initialized
DEBUG - 2014-08-11 21:09:10 --> Output Class Initialized
DEBUG - 2014-08-11 21:09:10 --> Security Class Initialized
DEBUG - 2014-08-11 21:09:10 --> Input Class Initialized
DEBUG - 2014-08-11 21:09:10 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:10 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:10 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:10 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:10 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:10 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:10 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:10 --> CRSF cookie Set
DEBUG - 2014-08-11 21:09:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:09:10 --> Language Class Initialized
DEBUG - 2014-08-11 21:09:10 --> Loader Class Initialized
DEBUG - 2014-08-11 21:09:10 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:09:10 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:09:10 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:09:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:09:10 --> Session Class Initialized
DEBUG - 2014-08-11 21:09:10 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:09:10 --> Session routines successfully run
DEBUG - 2014-08-11 21:09:10 --> Controller Class Initialized
DEBUG - 2014-08-11 21:09:10 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:09:10 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-11 21:09:10 --> Model Class Initialized
DEBUG - 2014-08-11 21:09:10 --> Model Class Initialized
DEBUG - 2014-08-11 21:09:10 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-11 21:09:10 --> File loaded: application/views/placement_under_construction_in.php
DEBUG - 2014-08-11 21:09:10 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:09:10 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:09:10 --> Final output sent to browser
DEBUG - 2014-08-11 21:09:10 --> Total execution time: 0.0622
DEBUG - 2014-08-11 21:09:11 --> Config Class Initialized
DEBUG - 2014-08-11 21:09:11 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:09:11 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:09:11 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:09:11 --> URI Class Initialized
DEBUG - 2014-08-11 21:09:11 --> Router Class Initialized
DEBUG - 2014-08-11 21:09:11 --> Output Class Initialized
DEBUG - 2014-08-11 21:09:11 --> Security Class Initialized
DEBUG - 2014-08-11 21:09:11 --> Input Class Initialized
DEBUG - 2014-08-11 21:09:11 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:11 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:11 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:11 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:11 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:11 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:11 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:11 --> CRSF cookie Set
DEBUG - 2014-08-11 21:09:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:09:11 --> Language Class Initialized
DEBUG - 2014-08-11 21:09:11 --> Loader Class Initialized
DEBUG - 2014-08-11 21:09:11 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:09:11 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:09:11 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:09:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:09:11 --> Session Class Initialized
DEBUG - 2014-08-11 21:09:11 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:09:11 --> Session routines successfully run
DEBUG - 2014-08-11 21:09:11 --> Controller Class Initialized
DEBUG - 2014-08-11 21:09:11 --> File loaded: application/views/logout.php
DEBUG - 2014-08-11 21:09:11 --> Final output sent to browser
DEBUG - 2014-08-11 21:09:11 --> Total execution time: 0.0413
DEBUG - 2014-08-11 21:09:11 --> Config Class Initialized
DEBUG - 2014-08-11 21:09:11 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:09:11 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:09:11 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:09:11 --> URI Class Initialized
DEBUG - 2014-08-11 21:09:11 --> Router Class Initialized
DEBUG - 2014-08-11 21:09:11 --> No URI present. Default controller set.
DEBUG - 2014-08-11 21:09:11 --> Output Class Initialized
DEBUG - 2014-08-11 21:09:11 --> Security Class Initialized
DEBUG - 2014-08-11 21:09:11 --> Input Class Initialized
DEBUG - 2014-08-11 21:09:11 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:11 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:11 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:11 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:11 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:11 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:11 --> CRSF cookie Set
DEBUG - 2014-08-11 21:09:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:09:11 --> Language Class Initialized
DEBUG - 2014-08-11 21:09:11 --> Loader Class Initialized
DEBUG - 2014-08-11 21:09:11 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:09:11 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:09:11 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:09:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:09:11 --> Session Class Initialized
DEBUG - 2014-08-11 21:09:11 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:09:11 --> A session cookie was not found.
DEBUG - 2014-08-11 21:09:11 --> Session routines successfully run
DEBUG - 2014-08-11 21:09:11 --> Controller Class Initialized
DEBUG - 2014-08-11 21:09:11 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:09:11 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-11 21:09:11 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-11 21:09:11 --> Helper loaded: form_helper
DEBUG - 2014-08-11 21:09:11 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-11 21:09:11 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-11 21:09:11 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:09:11 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:09:11 --> Final output sent to browser
DEBUG - 2014-08-11 21:09:11 --> Total execution time: 0.0679
DEBUG - 2014-08-11 21:09:18 --> Config Class Initialized
DEBUG - 2014-08-11 21:09:18 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:09:18 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:09:18 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:09:18 --> URI Class Initialized
DEBUG - 2014-08-11 21:09:18 --> Router Class Initialized
DEBUG - 2014-08-11 21:09:18 --> Output Class Initialized
DEBUG - 2014-08-11 21:09:18 --> Security Class Initialized
DEBUG - 2014-08-11 21:09:18 --> Input Class Initialized
DEBUG - 2014-08-11 21:09:18 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:18 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:18 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:18 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:18 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:18 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:18 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:18 --> CRSF cookie Set
DEBUG - 2014-08-11 21:09:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:09:18 --> Language Class Initialized
DEBUG - 2014-08-11 21:09:18 --> Loader Class Initialized
DEBUG - 2014-08-11 21:09:18 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:09:18 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:09:18 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:09:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:09:18 --> Session Class Initialized
DEBUG - 2014-08-11 21:09:18 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:09:18 --> Session routines successfully run
DEBUG - 2014-08-11 21:09:18 --> Controller Class Initialized
DEBUG - 2014-08-11 21:09:18 --> File loaded: application/views/login_to_continue.php
DEBUG - 2014-08-11 21:09:18 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:09:18 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-11 21:09:18 --> Model Class Initialized
DEBUG - 2014-08-11 21:09:18 --> Model Class Initialized
DEBUG - 2014-08-11 21:09:18 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-11 21:09:18 --> File loaded: application/views/placement_under_construction_in.php
DEBUG - 2014-08-11 21:09:18 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:09:18 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:09:18 --> Final output sent to browser
DEBUG - 2014-08-11 21:09:18 --> Total execution time: 0.0500
DEBUG - 2014-08-11 21:09:19 --> Config Class Initialized
DEBUG - 2014-08-11 21:09:19 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:09:19 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:09:19 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:09:19 --> URI Class Initialized
DEBUG - 2014-08-11 21:09:19 --> Router Class Initialized
DEBUG - 2014-08-11 21:09:19 --> No URI present. Default controller set.
DEBUG - 2014-08-11 21:09:19 --> Output Class Initialized
DEBUG - 2014-08-11 21:09:19 --> Security Class Initialized
DEBUG - 2014-08-11 21:09:19 --> Input Class Initialized
DEBUG - 2014-08-11 21:09:19 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:19 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:19 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:19 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:19 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:19 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:19 --> XSS Filtering completed
DEBUG - 2014-08-11 21:09:19 --> CRSF cookie Set
DEBUG - 2014-08-11 21:09:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:09:19 --> Language Class Initialized
DEBUG - 2014-08-11 21:09:19 --> Loader Class Initialized
DEBUG - 2014-08-11 21:09:19 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:09:19 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:09:19 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:09:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:09:19 --> Session Class Initialized
DEBUG - 2014-08-11 21:09:19 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:09:19 --> Session routines successfully run
DEBUG - 2014-08-11 21:09:19 --> Controller Class Initialized
DEBUG - 2014-08-11 21:09:19 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:09:19 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-11 21:09:19 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-11 21:09:19 --> Helper loaded: form_helper
DEBUG - 2014-08-11 21:09:19 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-11 21:09:19 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-11 21:09:19 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:09:19 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:09:19 --> Final output sent to browser
DEBUG - 2014-08-11 21:09:19 --> Total execution time: 0.0690
DEBUG - 2014-08-11 21:11:07 --> Config Class Initialized
DEBUG - 2014-08-11 21:11:07 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:11:07 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:11:07 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:11:07 --> URI Class Initialized
DEBUG - 2014-08-11 21:11:07 --> Router Class Initialized
DEBUG - 2014-08-11 21:11:07 --> Output Class Initialized
DEBUG - 2014-08-11 21:11:07 --> Security Class Initialized
DEBUG - 2014-08-11 21:11:07 --> Input Class Initialized
DEBUG - 2014-08-11 21:11:07 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:07 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:07 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:07 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:07 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:07 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:07 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:07 --> CRSF cookie Set
DEBUG - 2014-08-11 21:11:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:11:07 --> Language Class Initialized
DEBUG - 2014-08-11 21:11:07 --> Loader Class Initialized
DEBUG - 2014-08-11 21:11:07 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:11:07 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:11:07 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:11:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:11:07 --> Session Class Initialized
DEBUG - 2014-08-11 21:11:07 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:11:07 --> Session routines successfully run
DEBUG - 2014-08-11 21:11:07 --> Controller Class Initialized
DEBUG - 2014-08-11 21:11:07 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:11:07 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-11 21:11:07 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-11 21:11:07 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-11 21:11:07 --> Helper loaded: form_helper
DEBUG - 2014-08-11 21:11:07 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-11 21:11:07 --> File loaded: application/views/placement_history.php
DEBUG - 2014-08-11 21:11:07 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:11:07 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:11:07 --> Final output sent to browser
DEBUG - 2014-08-11 21:11:07 --> Total execution time: 0.0504
DEBUG - 2014-08-11 21:11:09 --> Config Class Initialized
DEBUG - 2014-08-11 21:11:09 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:11:09 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:11:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:11:09 --> URI Class Initialized
DEBUG - 2014-08-11 21:11:09 --> Router Class Initialized
DEBUG - 2014-08-11 21:11:09 --> Output Class Initialized
DEBUG - 2014-08-11 21:11:09 --> Security Class Initialized
DEBUG - 2014-08-11 21:11:09 --> Input Class Initialized
DEBUG - 2014-08-11 21:11:09 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:09 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:09 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:09 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:09 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:09 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:09 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:09 --> CRSF cookie Set
DEBUG - 2014-08-11 21:11:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:11:09 --> Language Class Initialized
DEBUG - 2014-08-11 21:11:09 --> Loader Class Initialized
DEBUG - 2014-08-11 21:11:09 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:11:09 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:11:09 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:11:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:11:09 --> Session Class Initialized
DEBUG - 2014-08-11 21:11:09 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:11:09 --> Session routines successfully run
DEBUG - 2014-08-11 21:11:09 --> Controller Class Initialized
DEBUG - 2014-08-11 21:11:09 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:11:09 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-11 21:11:09 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-11 21:11:09 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-11 21:11:09 --> Helper loaded: form_helper
DEBUG - 2014-08-11 21:11:09 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-11 21:11:09 --> File loaded: application/views/placement_contact.php
DEBUG - 2014-08-11 21:11:09 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:11:09 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:11:09 --> Final output sent to browser
DEBUG - 2014-08-11 21:11:09 --> Total execution time: 0.0506
DEBUG - 2014-08-11 21:11:11 --> Config Class Initialized
DEBUG - 2014-08-11 21:11:11 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:11:11 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:11:11 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:11:11 --> URI Class Initialized
DEBUG - 2014-08-11 21:11:11 --> Router Class Initialized
DEBUG - 2014-08-11 21:11:11 --> Output Class Initialized
DEBUG - 2014-08-11 21:11:11 --> Security Class Initialized
DEBUG - 2014-08-11 21:11:11 --> Input Class Initialized
DEBUG - 2014-08-11 21:11:11 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:11 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:11 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:11 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:11 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:11 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:11 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:11 --> CRSF cookie Set
DEBUG - 2014-08-11 21:11:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:11:11 --> Language Class Initialized
DEBUG - 2014-08-11 21:11:11 --> Loader Class Initialized
DEBUG - 2014-08-11 21:11:11 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:11:11 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:11:11 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:11:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:11:11 --> Session Class Initialized
DEBUG - 2014-08-11 21:11:11 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:11:11 --> Session routines successfully run
DEBUG - 2014-08-11 21:11:11 --> Controller Class Initialized
DEBUG - 2014-08-11 21:11:11 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:11:11 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-11 21:11:11 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-11 21:11:11 --> Helper loaded: form_helper
DEBUG - 2014-08-11 21:11:11 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-11 21:11:11 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-11 21:11:11 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:11:11 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:11:11 --> Final output sent to browser
DEBUG - 2014-08-11 21:11:11 --> Total execution time: 0.0487
DEBUG - 2014-08-11 21:11:13 --> Config Class Initialized
DEBUG - 2014-08-11 21:11:13 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:11:13 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:11:13 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:11:13 --> URI Class Initialized
DEBUG - 2014-08-11 21:11:13 --> Router Class Initialized
DEBUG - 2014-08-11 21:11:13 --> Output Class Initialized
DEBUG - 2014-08-11 21:11:13 --> Security Class Initialized
DEBUG - 2014-08-11 21:11:13 --> Input Class Initialized
DEBUG - 2014-08-11 21:11:13 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:13 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:13 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:13 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:13 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:13 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:13 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:13 --> CRSF cookie Set
DEBUG - 2014-08-11 21:11:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:11:13 --> Language Class Initialized
DEBUG - 2014-08-11 21:11:13 --> Loader Class Initialized
DEBUG - 2014-08-11 21:11:13 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:11:13 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:11:13 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:11:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:11:13 --> Session Class Initialized
DEBUG - 2014-08-11 21:11:13 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:11:13 --> Session routines successfully run
DEBUG - 2014-08-11 21:11:13 --> Controller Class Initialized
DEBUG - 2014-08-11 21:11:13 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:11:13 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-11 21:11:13 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-11 21:11:13 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-11 21:11:13 --> Helper loaded: form_helper
DEBUG - 2014-08-11 21:11:13 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-11 21:11:13 --> File loaded: application/views/placement_history.php
DEBUG - 2014-08-11 21:11:13 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:11:13 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:11:13 --> Final output sent to browser
DEBUG - 2014-08-11 21:11:13 --> Total execution time: 0.0530
DEBUG - 2014-08-11 21:11:15 --> Config Class Initialized
DEBUG - 2014-08-11 21:11:15 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:11:15 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:11:15 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:11:15 --> URI Class Initialized
DEBUG - 2014-08-11 21:11:15 --> Router Class Initialized
DEBUG - 2014-08-11 21:11:15 --> Output Class Initialized
DEBUG - 2014-08-11 21:11:15 --> Security Class Initialized
DEBUG - 2014-08-11 21:11:15 --> Input Class Initialized
DEBUG - 2014-08-11 21:11:15 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:15 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:15 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:15 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:15 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:15 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:15 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:15 --> CRSF cookie Set
DEBUG - 2014-08-11 21:11:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:11:15 --> Language Class Initialized
DEBUG - 2014-08-11 21:11:15 --> Loader Class Initialized
DEBUG - 2014-08-11 21:11:15 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:11:15 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:11:15 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:11:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:11:15 --> Session Class Initialized
DEBUG - 2014-08-11 21:11:15 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:11:15 --> Session routines successfully run
DEBUG - 2014-08-11 21:11:15 --> Controller Class Initialized
DEBUG - 2014-08-11 21:11:15 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:11:15 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-11 21:11:15 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-11 21:11:15 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-11 21:11:15 --> Helper loaded: form_helper
DEBUG - 2014-08-11 21:11:15 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-11 21:11:15 --> File loaded: application/views/placement_contact.php
DEBUG - 2014-08-11 21:11:15 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:11:15 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:11:15 --> Final output sent to browser
DEBUG - 2014-08-11 21:11:15 --> Total execution time: 0.0511
DEBUG - 2014-08-11 21:11:16 --> Config Class Initialized
DEBUG - 2014-08-11 21:11:16 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:11:16 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:11:16 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:11:16 --> URI Class Initialized
DEBUG - 2014-08-11 21:11:16 --> Router Class Initialized
DEBUG - 2014-08-11 21:11:16 --> Output Class Initialized
DEBUG - 2014-08-11 21:11:16 --> Security Class Initialized
DEBUG - 2014-08-11 21:11:16 --> Input Class Initialized
DEBUG - 2014-08-11 21:11:16 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:16 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:16 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:16 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:16 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:16 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:16 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:16 --> CRSF cookie Set
DEBUG - 2014-08-11 21:11:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:11:16 --> Language Class Initialized
DEBUG - 2014-08-11 21:11:16 --> Loader Class Initialized
DEBUG - 2014-08-11 21:11:16 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:11:16 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:11:16 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:11:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:11:16 --> Session Class Initialized
DEBUG - 2014-08-11 21:11:16 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:11:16 --> Session routines successfully run
DEBUG - 2014-08-11 21:11:16 --> Controller Class Initialized
DEBUG - 2014-08-11 21:11:16 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:11:16 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-11 21:11:16 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-11 21:11:16 --> Helper loaded: form_helper
DEBUG - 2014-08-11 21:11:16 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-11 21:11:16 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-11 21:11:16 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:11:16 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:11:16 --> Final output sent to browser
DEBUG - 2014-08-11 21:11:16 --> Total execution time: 0.0509
DEBUG - 2014-08-11 21:11:17 --> Config Class Initialized
DEBUG - 2014-08-11 21:11:17 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:11:17 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:11:17 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:11:17 --> URI Class Initialized
DEBUG - 2014-08-11 21:11:17 --> Router Class Initialized
DEBUG - 2014-08-11 21:11:17 --> Output Class Initialized
DEBUG - 2014-08-11 21:11:17 --> Security Class Initialized
DEBUG - 2014-08-11 21:11:17 --> Input Class Initialized
DEBUG - 2014-08-11 21:11:17 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:17 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:17 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:17 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:17 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:17 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:17 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:17 --> CRSF cookie Set
DEBUG - 2014-08-11 21:11:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:11:17 --> Language Class Initialized
DEBUG - 2014-08-11 21:11:17 --> Loader Class Initialized
DEBUG - 2014-08-11 21:11:17 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:11:17 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:11:17 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:11:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:11:17 --> Session Class Initialized
DEBUG - 2014-08-11 21:11:17 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:11:17 --> Session routines successfully run
DEBUG - 2014-08-11 21:11:17 --> Controller Class Initialized
DEBUG - 2014-08-11 21:11:17 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:11:17 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-11 21:11:17 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-11 21:11:17 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-11 21:11:17 --> Helper loaded: form_helper
DEBUG - 2014-08-11 21:11:17 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-11 21:11:17 --> File loaded: application/views/placement_history.php
DEBUG - 2014-08-11 21:11:17 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:11:17 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:11:17 --> Final output sent to browser
DEBUG - 2014-08-11 21:11:17 --> Total execution time: 0.0544
DEBUG - 2014-08-11 21:11:18 --> Config Class Initialized
DEBUG - 2014-08-11 21:11:18 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:11:18 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:11:18 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:11:18 --> URI Class Initialized
DEBUG - 2014-08-11 21:11:18 --> Router Class Initialized
DEBUG - 2014-08-11 21:11:18 --> Output Class Initialized
DEBUG - 2014-08-11 21:11:18 --> Security Class Initialized
DEBUG - 2014-08-11 21:11:18 --> Input Class Initialized
DEBUG - 2014-08-11 21:11:18 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:18 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:18 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:18 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:18 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:18 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:18 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:18 --> CRSF cookie Set
DEBUG - 2014-08-11 21:11:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:11:18 --> Language Class Initialized
DEBUG - 2014-08-11 21:11:18 --> Loader Class Initialized
DEBUG - 2014-08-11 21:11:18 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:11:18 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:11:18 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:11:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:11:18 --> Session Class Initialized
DEBUG - 2014-08-11 21:11:18 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:11:18 --> Session routines successfully run
DEBUG - 2014-08-11 21:11:18 --> Controller Class Initialized
DEBUG - 2014-08-11 21:11:18 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:11:18 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-11 21:11:18 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-11 21:11:18 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-11 21:11:18 --> Helper loaded: form_helper
DEBUG - 2014-08-11 21:11:18 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-11 21:11:18 --> File loaded: application/views/placement_contact.php
DEBUG - 2014-08-11 21:11:18 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:11:18 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:11:18 --> Final output sent to browser
DEBUG - 2014-08-11 21:11:18 --> Total execution time: 0.0590
DEBUG - 2014-08-11 21:11:33 --> Config Class Initialized
DEBUG - 2014-08-11 21:11:33 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:11:33 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:11:33 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:11:33 --> URI Class Initialized
DEBUG - 2014-08-11 21:11:33 --> Router Class Initialized
DEBUG - 2014-08-11 21:11:33 --> Output Class Initialized
DEBUG - 2014-08-11 21:11:33 --> Security Class Initialized
DEBUG - 2014-08-11 21:11:33 --> Input Class Initialized
DEBUG - 2014-08-11 21:11:33 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:33 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:33 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:33 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:33 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:33 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:33 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:33 --> CRSF cookie Set
DEBUG - 2014-08-11 21:11:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:11:33 --> Language Class Initialized
DEBUG - 2014-08-11 21:11:33 --> Loader Class Initialized
DEBUG - 2014-08-11 21:11:33 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:11:33 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:11:33 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:11:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:11:33 --> Session Class Initialized
DEBUG - 2014-08-11 21:11:33 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:11:33 --> Session routines successfully run
DEBUG - 2014-08-11 21:11:33 --> Controller Class Initialized
DEBUG - 2014-08-11 21:11:33 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:11:33 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-11 21:11:33 --> File loaded: application/views/404.php
DEBUG - 2014-08-11 21:11:33 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:11:33 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:11:33 --> Final output sent to browser
DEBUG - 2014-08-11 21:11:33 --> Total execution time: 0.0463
DEBUG - 2014-08-11 21:11:36 --> Config Class Initialized
DEBUG - 2014-08-11 21:11:36 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:11:36 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:11:36 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:11:36 --> URI Class Initialized
DEBUG - 2014-08-11 21:11:36 --> Router Class Initialized
DEBUG - 2014-08-11 21:11:36 --> Output Class Initialized
DEBUG - 2014-08-11 21:11:36 --> Security Class Initialized
DEBUG - 2014-08-11 21:11:36 --> Input Class Initialized
DEBUG - 2014-08-11 21:11:36 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:36 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:36 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:36 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:36 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:36 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:36 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:36 --> CRSF cookie Set
DEBUG - 2014-08-11 21:11:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:11:36 --> Language Class Initialized
DEBUG - 2014-08-11 21:11:36 --> Loader Class Initialized
DEBUG - 2014-08-11 21:11:36 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:11:36 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:11:36 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:11:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:11:36 --> Session Class Initialized
DEBUG - 2014-08-11 21:11:36 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:11:36 --> Session routines successfully run
DEBUG - 2014-08-11 21:11:36 --> Controller Class Initialized
DEBUG - 2014-08-11 21:11:36 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:11:36 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-11 21:11:36 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-11 21:11:36 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-11 21:11:36 --> Helper loaded: form_helper
DEBUG - 2014-08-11 21:11:36 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-11 21:11:36 --> File loaded: application/views/placement_history.php
DEBUG - 2014-08-11 21:11:36 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:11:36 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:11:36 --> Final output sent to browser
DEBUG - 2014-08-11 21:11:36 --> Total execution time: 0.0518
DEBUG - 2014-08-11 21:11:37 --> Config Class Initialized
DEBUG - 2014-08-11 21:11:37 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:11:37 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:11:37 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:11:37 --> URI Class Initialized
DEBUG - 2014-08-11 21:11:37 --> Router Class Initialized
DEBUG - 2014-08-11 21:11:37 --> Output Class Initialized
DEBUG - 2014-08-11 21:11:37 --> Security Class Initialized
DEBUG - 2014-08-11 21:11:37 --> Input Class Initialized
DEBUG - 2014-08-11 21:11:37 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:37 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:37 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:37 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:37 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:37 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:37 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:37 --> CRSF cookie Set
DEBUG - 2014-08-11 21:11:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:11:37 --> Language Class Initialized
DEBUG - 2014-08-11 21:11:37 --> Loader Class Initialized
DEBUG - 2014-08-11 21:11:37 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:11:37 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:11:37 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:11:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:11:37 --> Session Class Initialized
DEBUG - 2014-08-11 21:11:37 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:11:37 --> Session routines successfully run
DEBUG - 2014-08-11 21:11:37 --> Controller Class Initialized
DEBUG - 2014-08-11 21:11:37 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:11:37 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-11 21:11:37 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-11 21:11:37 --> Helper loaded: form_helper
DEBUG - 2014-08-11 21:11:37 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-11 21:11:38 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-11 21:11:38 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:11:38 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:11:38 --> Final output sent to browser
DEBUG - 2014-08-11 21:11:38 --> Total execution time: 0.0547
DEBUG - 2014-08-11 21:11:50 --> Config Class Initialized
DEBUG - 2014-08-11 21:11:50 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:11:50 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:11:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:11:50 --> URI Class Initialized
DEBUG - 2014-08-11 21:11:50 --> Router Class Initialized
DEBUG - 2014-08-11 21:11:50 --> Output Class Initialized
DEBUG - 2014-08-11 21:11:50 --> Security Class Initialized
DEBUG - 2014-08-11 21:11:50 --> Input Class Initialized
DEBUG - 2014-08-11 21:11:50 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:50 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:50 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:50 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:50 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:50 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:50 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:50 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:50 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:50 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:50 --> CRSF cookie Set
DEBUG - 2014-08-11 21:11:50 --> CSRF token verified
DEBUG - 2014-08-11 21:11:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:11:50 --> Language Class Initialized
DEBUG - 2014-08-11 21:11:50 --> Loader Class Initialized
DEBUG - 2014-08-11 21:11:50 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:11:50 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:11:50 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:11:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:11:50 --> Session Class Initialized
DEBUG - 2014-08-11 21:11:50 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:11:50 --> Session routines successfully run
DEBUG - 2014-08-11 21:11:50 --> Controller Class Initialized
DEBUG - 2014-08-11 21:11:50 --> Helper loaded: form_helper
DEBUG - 2014-08-11 21:11:50 --> Form Validation Class Initialized
DEBUG - 2014-08-11 21:11:50 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-11 21:11:50 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:50 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:50 --> Model Class Initialized
DEBUG - 2014-08-11 21:11:50 --> Model Class Initialized
DEBUG - 2014-08-11 21:11:50 --> Encrypt Class Initialized
DEBUG - 2014-08-11 21:11:50 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:50 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:50 --> Model Class Initialized
DEBUG - 2014-08-11 21:11:50 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-11 21:11:50 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:50 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:51 --> Config Class Initialized
DEBUG - 2014-08-11 21:11:51 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:11:51 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:11:51 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:11:51 --> URI Class Initialized
DEBUG - 2014-08-11 21:11:51 --> Router Class Initialized
DEBUG - 2014-08-11 21:11:51 --> Output Class Initialized
DEBUG - 2014-08-11 21:11:51 --> Security Class Initialized
DEBUG - 2014-08-11 21:11:51 --> Input Class Initialized
DEBUG - 2014-08-11 21:11:51 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:51 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:51 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:51 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:51 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:51 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:51 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:51 --> CRSF cookie Set
DEBUG - 2014-08-11 21:11:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:11:51 --> Language Class Initialized
DEBUG - 2014-08-11 21:11:51 --> Loader Class Initialized
DEBUG - 2014-08-11 21:11:51 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:11:51 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:11:51 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:11:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:11:51 --> Session Class Initialized
DEBUG - 2014-08-11 21:11:51 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:11:51 --> Session routines successfully run
DEBUG - 2014-08-11 21:11:51 --> Controller Class Initialized
DEBUG - 2014-08-11 21:11:51 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:11:51 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-11 21:11:51 --> Model Class Initialized
DEBUG - 2014-08-11 21:11:51 --> Model Class Initialized
DEBUG - 2014-08-11 21:11:51 --> Helper loaded: array_helper
DEBUG - 2014-08-11 21:11:51 --> File loaded: application/views/placement_students_home.php
DEBUG - 2014-08-11 21:11:51 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:11:51 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:11:51 --> Final output sent to browser
DEBUG - 2014-08-11 21:11:51 --> Total execution time: 0.0623
DEBUG - 2014-08-11 21:11:57 --> Config Class Initialized
DEBUG - 2014-08-11 21:11:57 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:11:57 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:11:57 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:11:57 --> URI Class Initialized
DEBUG - 2014-08-11 21:11:57 --> Router Class Initialized
DEBUG - 2014-08-11 21:11:57 --> Output Class Initialized
DEBUG - 2014-08-11 21:11:57 --> Security Class Initialized
DEBUG - 2014-08-11 21:11:57 --> Input Class Initialized
DEBUG - 2014-08-11 21:11:57 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:57 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:57 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:57 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:57 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:57 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:57 --> XSS Filtering completed
DEBUG - 2014-08-11 21:11:57 --> CRSF cookie Set
DEBUG - 2014-08-11 21:11:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:11:57 --> Language Class Initialized
DEBUG - 2014-08-11 21:11:57 --> Loader Class Initialized
DEBUG - 2014-08-11 21:11:57 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:11:57 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:11:57 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:11:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:11:57 --> Session Class Initialized
DEBUG - 2014-08-11 21:11:57 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:11:57 --> Session routines successfully run
DEBUG - 2014-08-11 21:11:57 --> Controller Class Initialized
DEBUG - 2014-08-11 21:11:57 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:11:57 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-11 21:11:57 --> Model Class Initialized
DEBUG - 2014-08-11 21:11:57 --> Model Class Initialized
DEBUG - 2014-08-11 21:11:57 --> Helper loaded: form_helper
DEBUG - 2014-08-11 21:11:57 --> Helper loaded: array_helper
ERROR - 2014-08-11 21:11:57 --> Severity: Notice  --> Undefined variable: error C:\wamp\www\cep\placement\application\views\placement_students_update.php 44
ERROR - 2014-08-11 21:11:57 --> Severity: Notice  --> Undefined variable: error C:\wamp\www\cep\placement\application\views\placement_students_update.php 53
ERROR - 2014-08-11 21:11:57 --> Severity: Notice  --> Undefined variable: error C:\wamp\www\cep\placement\application\views\placement_students_update.php 61
ERROR - 2014-08-11 21:11:57 --> Severity: Notice  --> Undefined variable: error C:\wamp\www\cep\placement\application\views\placement_students_update.php 74
ERROR - 2014-08-11 21:11:57 --> Severity: Notice  --> Undefined variable: error C:\wamp\www\cep\placement\application\views\placement_students_update.php 82
ERROR - 2014-08-11 21:11:57 --> Severity: Notice  --> Undefined variable: error C:\wamp\www\cep\placement\application\views\placement_students_update.php 90
ERROR - 2014-08-11 21:11:57 --> Severity: Notice  --> Undefined variable: paddr C:\wamp\www\cep\placement\application\views\placement_students_update.php 90
ERROR - 2014-08-11 21:11:57 --> Severity: Notice  --> Undefined variable: error C:\wamp\www\cep\placement\application\views\placement_students_update.php 98
ERROR - 2014-08-11 21:11:57 --> Severity: Notice  --> Undefined variable: caddr C:\wamp\www\cep\placement\application\views\placement_students_update.php 98
ERROR - 2014-08-11 21:11:57 --> Severity: Notice  --> Undefined variable: error C:\wamp\www\cep\placement\application\views\placement_students_update.php 106
ERROR - 2014-08-11 21:11:57 --> Severity: Notice  --> Undefined variable: error C:\wamp\www\cep\placement\application\views\placement_students_update.php 114
ERROR - 2014-08-11 21:11:57 --> Severity: Notice  --> Undefined variable: error C:\wamp\www\cep\placement\application\views\placement_students_update.php 122
ERROR - 2014-08-11 21:11:57 --> Severity: Notice  --> Undefined variable: error C:\wamp\www\cep\placement\application\views\placement_students_update.php 130
ERROR - 2014-08-11 21:11:57 --> Severity: Notice  --> Undefined variable: error C:\wamp\www\cep\placement\application\views\placement_students_update.php 138
ERROR - 2014-08-11 21:11:57 --> Severity: Notice  --> Undefined variable: error C:\wamp\www\cep\placement\application\views\placement_students_update.php 146
ERROR - 2014-08-11 21:11:57 --> Severity: Notice  --> Undefined variable: error C:\wamp\www\cep\placement\application\views\placement_students_update.php 154
DEBUG - 2014-08-11 21:11:57 --> File loaded: application/views/placement_students_update.php
DEBUG - 2014-08-11 21:11:57 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:11:57 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:11:57 --> Final output sent to browser
DEBUG - 2014-08-11 21:11:57 --> Total execution time: 0.0612
DEBUG - 2014-08-11 21:19:41 --> Config Class Initialized
DEBUG - 2014-08-11 21:19:41 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:19:41 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:19:41 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:19:41 --> URI Class Initialized
DEBUG - 2014-08-11 21:19:41 --> Router Class Initialized
DEBUG - 2014-08-11 21:19:41 --> Output Class Initialized
DEBUG - 2014-08-11 21:19:41 --> Security Class Initialized
DEBUG - 2014-08-11 21:19:41 --> Input Class Initialized
DEBUG - 2014-08-11 21:19:41 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:41 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:41 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:41 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:41 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:41 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:41 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:41 --> CRSF cookie Set
DEBUG - 2014-08-11 21:19:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:19:41 --> Language Class Initialized
DEBUG - 2014-08-11 21:19:41 --> Loader Class Initialized
DEBUG - 2014-08-11 21:19:41 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:19:41 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:19:41 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:19:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:19:41 --> Session Class Initialized
DEBUG - 2014-08-11 21:19:41 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:19:41 --> Session routines successfully run
DEBUG - 2014-08-11 21:19:41 --> Controller Class Initialized
DEBUG - 2014-08-11 21:19:41 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:19:41 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-11 21:19:41 --> Model Class Initialized
DEBUG - 2014-08-11 21:19:41 --> Model Class Initialized
DEBUG - 2014-08-11 21:19:41 --> Helper loaded: form_helper
DEBUG - 2014-08-11 21:19:41 --> Helper loaded: array_helper
DEBUG - 2014-08-11 21:19:41 --> File loaded: application/views/placement_students_update.php
DEBUG - 2014-08-11 21:19:41 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:19:41 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:19:41 --> Final output sent to browser
DEBUG - 2014-08-11 21:19:41 --> Total execution time: 0.0519
DEBUG - 2014-08-11 21:19:50 --> Config Class Initialized
DEBUG - 2014-08-11 21:19:50 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:19:50 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:19:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:19:50 --> URI Class Initialized
DEBUG - 2014-08-11 21:19:50 --> Router Class Initialized
DEBUG - 2014-08-11 21:19:50 --> Output Class Initialized
DEBUG - 2014-08-11 21:19:50 --> Security Class Initialized
DEBUG - 2014-08-11 21:19:50 --> Input Class Initialized
DEBUG - 2014-08-11 21:19:50 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:50 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:50 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:50 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:50 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:50 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:50 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:50 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:50 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:50 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:50 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:50 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:50 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:50 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:50 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:50 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:50 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:50 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:50 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:50 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:50 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:50 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:50 --> CRSF cookie Set
DEBUG - 2014-08-11 21:19:50 --> CSRF token verified
DEBUG - 2014-08-11 21:19:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:19:50 --> Language Class Initialized
DEBUG - 2014-08-11 21:19:50 --> Loader Class Initialized
DEBUG - 2014-08-11 21:19:50 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:19:50 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:19:50 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:19:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:19:50 --> Session Class Initialized
DEBUG - 2014-08-11 21:19:50 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:19:50 --> Session routines successfully run
DEBUG - 2014-08-11 21:19:50 --> Controller Class Initialized
DEBUG - 2014-08-11 21:19:50 --> Helper loaded: form_helper
DEBUG - 2014-08-11 21:19:50 --> Form Validation Class Initialized
DEBUG - 2014-08-11 21:19:50 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-11 21:19:50 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:50 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:50 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:19:50 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-11 21:19:50 --> Model Class Initialized
DEBUG - 2014-08-11 21:19:50 --> Model Class Initialized
DEBUG - 2014-08-11 21:19:50 --> Helper loaded: array_helper
DEBUG - 2014-08-11 21:19:50 --> File loaded: application/views/placement_students_update.php
DEBUG - 2014-08-11 21:19:50 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:19:50 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:19:50 --> Final output sent to browser
DEBUG - 2014-08-11 21:19:50 --> Total execution time: 0.0807
DEBUG - 2014-08-11 21:19:58 --> Config Class Initialized
DEBUG - 2014-08-11 21:19:58 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:19:58 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:19:58 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:19:58 --> URI Class Initialized
DEBUG - 2014-08-11 21:19:58 --> Router Class Initialized
DEBUG - 2014-08-11 21:19:58 --> Output Class Initialized
DEBUG - 2014-08-11 21:19:58 --> Security Class Initialized
DEBUG - 2014-08-11 21:19:58 --> Input Class Initialized
DEBUG - 2014-08-11 21:19:58 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:58 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:58 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:58 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:58 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:58 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:58 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:58 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:58 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:58 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:58 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:58 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:58 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:58 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:58 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:58 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:58 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:58 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:58 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:58 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:58 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:58 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:58 --> CRSF cookie Set
DEBUG - 2014-08-11 21:19:58 --> CSRF token verified
DEBUG - 2014-08-11 21:19:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:19:58 --> Language Class Initialized
DEBUG - 2014-08-11 21:19:58 --> Loader Class Initialized
DEBUG - 2014-08-11 21:19:58 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:19:58 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:19:58 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:19:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:19:58 --> Session Class Initialized
DEBUG - 2014-08-11 21:19:58 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:19:58 --> Session routines successfully run
DEBUG - 2014-08-11 21:19:58 --> Controller Class Initialized
DEBUG - 2014-08-11 21:19:58 --> Helper loaded: form_helper
DEBUG - 2014-08-11 21:19:58 --> Form Validation Class Initialized
DEBUG - 2014-08-11 21:19:58 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-11 21:19:58 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:58 --> XSS Filtering completed
DEBUG - 2014-08-11 21:19:58 --> Model Class Initialized
DEBUG - 2014-08-11 21:19:58 --> Model Class Initialized
DEBUG - 2014-08-11 21:20:08 --> Config Class Initialized
DEBUG - 2014-08-11 21:20:08 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:20:08 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:20:08 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:20:08 --> URI Class Initialized
DEBUG - 2014-08-11 21:20:08 --> Router Class Initialized
DEBUG - 2014-08-11 21:20:08 --> Output Class Initialized
DEBUG - 2014-08-11 21:20:08 --> Security Class Initialized
DEBUG - 2014-08-11 21:20:08 --> Input Class Initialized
DEBUG - 2014-08-11 21:20:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:08 --> CRSF cookie Set
DEBUG - 2014-08-11 21:20:08 --> CSRF token verified
DEBUG - 2014-08-11 21:20:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:20:08 --> Language Class Initialized
DEBUG - 2014-08-11 21:20:08 --> Loader Class Initialized
DEBUG - 2014-08-11 21:20:08 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:20:08 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:20:08 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:20:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:20:08 --> Session Class Initialized
DEBUG - 2014-08-11 21:20:08 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:20:08 --> Session routines successfully run
DEBUG - 2014-08-11 21:20:08 --> Controller Class Initialized
DEBUG - 2014-08-11 21:20:08 --> Helper loaded: form_helper
DEBUG - 2014-08-11 21:20:08 --> Form Validation Class Initialized
DEBUG - 2014-08-11 21:20:08 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-11 21:20:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:08 --> Model Class Initialized
DEBUG - 2014-08-11 21:20:08 --> Model Class Initialized
DEBUG - 2014-08-11 21:20:14 --> Config Class Initialized
DEBUG - 2014-08-11 21:20:14 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:20:14 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:20:14 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:20:14 --> URI Class Initialized
DEBUG - 2014-08-11 21:20:14 --> Router Class Initialized
DEBUG - 2014-08-11 21:20:14 --> Output Class Initialized
DEBUG - 2014-08-11 21:20:14 --> Security Class Initialized
DEBUG - 2014-08-11 21:20:14 --> Input Class Initialized
DEBUG - 2014-08-11 21:20:14 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:14 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:14 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:14 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:14 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:14 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:14 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:14 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:14 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:14 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:14 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:14 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:14 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:14 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:14 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:14 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:14 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:14 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:14 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:14 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:14 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:14 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:14 --> CRSF cookie Set
DEBUG - 2014-08-11 21:20:14 --> CSRF token verified
DEBUG - 2014-08-11 21:20:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:20:14 --> Language Class Initialized
DEBUG - 2014-08-11 21:20:14 --> Loader Class Initialized
DEBUG - 2014-08-11 21:20:14 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:20:14 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:20:14 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:20:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:20:14 --> Session Class Initialized
DEBUG - 2014-08-11 21:20:14 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:20:14 --> Session routines successfully run
DEBUG - 2014-08-11 21:20:14 --> Controller Class Initialized
DEBUG - 2014-08-11 21:20:14 --> Helper loaded: form_helper
DEBUG - 2014-08-11 21:20:14 --> Form Validation Class Initialized
DEBUG - 2014-08-11 21:20:14 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-11 21:20:14 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:14 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:14 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:20:14 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-11 21:20:14 --> Model Class Initialized
DEBUG - 2014-08-11 21:20:14 --> Model Class Initialized
DEBUG - 2014-08-11 21:20:14 --> Helper loaded: array_helper
DEBUG - 2014-08-11 21:20:14 --> File loaded: application/views/placement_students_update.php
DEBUG - 2014-08-11 21:20:14 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:20:14 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:20:14 --> Final output sent to browser
DEBUG - 2014-08-11 21:20:14 --> Total execution time: 0.0754
DEBUG - 2014-08-11 21:20:24 --> Config Class Initialized
DEBUG - 2014-08-11 21:20:24 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:20:24 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:20:24 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:20:24 --> URI Class Initialized
DEBUG - 2014-08-11 21:20:24 --> Router Class Initialized
DEBUG - 2014-08-11 21:20:24 --> Output Class Initialized
DEBUG - 2014-08-11 21:20:24 --> Security Class Initialized
DEBUG - 2014-08-11 21:20:24 --> Input Class Initialized
DEBUG - 2014-08-11 21:20:24 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:24 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:24 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:24 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:24 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:24 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:24 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:24 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:24 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:24 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:24 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:24 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:24 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:24 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:24 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:24 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:24 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:24 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:24 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:24 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:24 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:24 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:24 --> CRSF cookie Set
DEBUG - 2014-08-11 21:20:24 --> CSRF token verified
DEBUG - 2014-08-11 21:20:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:20:24 --> Language Class Initialized
DEBUG - 2014-08-11 21:20:24 --> Loader Class Initialized
DEBUG - 2014-08-11 21:20:24 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:20:24 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:20:24 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:20:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:20:24 --> Session Class Initialized
DEBUG - 2014-08-11 21:20:24 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:20:24 --> Session routines successfully run
DEBUG - 2014-08-11 21:20:24 --> Controller Class Initialized
DEBUG - 2014-08-11 21:20:24 --> Helper loaded: form_helper
DEBUG - 2014-08-11 21:20:24 --> Form Validation Class Initialized
DEBUG - 2014-08-11 21:20:24 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-11 21:20:24 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:24 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:24 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:20:24 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-11 21:20:24 --> Model Class Initialized
DEBUG - 2014-08-11 21:20:24 --> Model Class Initialized
DEBUG - 2014-08-11 21:20:24 --> Helper loaded: array_helper
DEBUG - 2014-08-11 21:20:24 --> File loaded: application/views/placement_students_update.php
DEBUG - 2014-08-11 21:20:24 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:20:24 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:20:24 --> Final output sent to browser
DEBUG - 2014-08-11 21:20:24 --> Total execution time: 0.0719
DEBUG - 2014-08-11 21:20:34 --> Config Class Initialized
DEBUG - 2014-08-11 21:20:34 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:20:34 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:20:34 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:20:34 --> URI Class Initialized
DEBUG - 2014-08-11 21:20:34 --> Router Class Initialized
DEBUG - 2014-08-11 21:20:34 --> Output Class Initialized
DEBUG - 2014-08-11 21:20:34 --> Security Class Initialized
DEBUG - 2014-08-11 21:20:34 --> Input Class Initialized
DEBUG - 2014-08-11 21:20:34 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:34 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:34 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:34 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:34 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:34 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:34 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:34 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:34 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:34 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:34 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:34 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:34 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:34 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:34 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:34 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:34 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:34 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:34 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:34 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:34 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:34 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:34 --> CRSF cookie Set
DEBUG - 2014-08-11 21:20:34 --> CSRF token verified
DEBUG - 2014-08-11 21:20:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:20:34 --> Language Class Initialized
DEBUG - 2014-08-11 21:20:34 --> Loader Class Initialized
DEBUG - 2014-08-11 21:20:34 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:20:34 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:20:34 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:20:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:20:34 --> Session Class Initialized
DEBUG - 2014-08-11 21:20:34 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:20:34 --> Session routines successfully run
DEBUG - 2014-08-11 21:20:34 --> Controller Class Initialized
DEBUG - 2014-08-11 21:20:34 --> Helper loaded: form_helper
DEBUG - 2014-08-11 21:20:34 --> Form Validation Class Initialized
DEBUG - 2014-08-11 21:20:34 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-11 21:20:34 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:34 --> XSS Filtering completed
DEBUG - 2014-08-11 21:20:34 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:20:34 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-11 21:20:34 --> Model Class Initialized
DEBUG - 2014-08-11 21:20:34 --> Model Class Initialized
DEBUG - 2014-08-11 21:20:34 --> Helper loaded: array_helper
DEBUG - 2014-08-11 21:20:34 --> File loaded: application/views/placement_students_update.php
DEBUG - 2014-08-11 21:20:34 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:20:34 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:20:34 --> Final output sent to browser
DEBUG - 2014-08-11 21:20:34 --> Total execution time: 0.0771
DEBUG - 2014-08-11 21:26:06 --> Config Class Initialized
DEBUG - 2014-08-11 21:26:06 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:26:06 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:26:06 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:26:06 --> URI Class Initialized
DEBUG - 2014-08-11 21:26:06 --> Router Class Initialized
DEBUG - 2014-08-11 21:26:06 --> Output Class Initialized
DEBUG - 2014-08-11 21:26:06 --> Security Class Initialized
DEBUG - 2014-08-11 21:26:06 --> Input Class Initialized
DEBUG - 2014-08-11 21:26:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:26:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:26:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:26:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:26:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:26:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:26:06 --> XSS Filtering completed
DEBUG - 2014-08-11 21:26:06 --> CRSF cookie Set
DEBUG - 2014-08-11 21:26:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:26:06 --> Language Class Initialized
DEBUG - 2014-08-11 21:26:06 --> Loader Class Initialized
DEBUG - 2014-08-11 21:26:06 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:26:06 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:26:06 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:26:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:26:06 --> Session Class Initialized
DEBUG - 2014-08-11 21:26:06 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:26:06 --> Session routines successfully run
DEBUG - 2014-08-11 21:26:06 --> Controller Class Initialized
DEBUG - 2014-08-11 21:26:06 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:26:06 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-11 21:26:06 --> Model Class Initialized
DEBUG - 2014-08-11 21:26:06 --> Model Class Initialized
DEBUG - 2014-08-11 21:26:06 --> Helper loaded: form_helper
DEBUG - 2014-08-11 21:26:06 --> Helper loaded: array_helper
DEBUG - 2014-08-11 21:26:06 --> File loaded: application/views/placement_students_update.php
DEBUG - 2014-08-11 21:26:06 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:26:06 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:26:06 --> Final output sent to browser
DEBUG - 2014-08-11 21:26:06 --> Total execution time: 0.0583
DEBUG - 2014-08-11 21:26:08 --> Config Class Initialized
DEBUG - 2014-08-11 21:26:08 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:26:08 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:26:08 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:26:08 --> URI Class Initialized
DEBUG - 2014-08-11 21:26:08 --> Router Class Initialized
DEBUG - 2014-08-11 21:26:08 --> Output Class Initialized
DEBUG - 2014-08-11 21:26:08 --> Security Class Initialized
DEBUG - 2014-08-11 21:26:08 --> Input Class Initialized
DEBUG - 2014-08-11 21:26:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:26:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:26:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:26:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:26:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:26:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:26:08 --> XSS Filtering completed
DEBUG - 2014-08-11 21:26:08 --> CRSF cookie Set
DEBUG - 2014-08-11 21:26:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:26:08 --> Language Class Initialized
DEBUG - 2014-08-11 21:26:08 --> Loader Class Initialized
DEBUG - 2014-08-11 21:26:08 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:26:08 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:26:08 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:26:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:26:08 --> Session Class Initialized
DEBUG - 2014-08-11 21:26:08 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:26:08 --> Session routines successfully run
DEBUG - 2014-08-11 21:26:08 --> Controller Class Initialized
DEBUG - 2014-08-11 21:26:08 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:26:08 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-11 21:26:08 --> Model Class Initialized
DEBUG - 2014-08-11 21:26:08 --> Model Class Initialized
DEBUG - 2014-08-11 21:26:08 --> Helper loaded: array_helper
DEBUG - 2014-08-11 21:26:08 --> File loaded: application/views/placement_students_home.php
DEBUG - 2014-08-11 21:26:08 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:26:08 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:26:08 --> Final output sent to browser
DEBUG - 2014-08-11 21:26:08 --> Total execution time: 0.0511
DEBUG - 2014-08-11 21:26:23 --> Config Class Initialized
DEBUG - 2014-08-11 21:26:23 --> Hooks Class Initialized
DEBUG - 2014-08-11 21:26:23 --> Utf8 Class Initialized
DEBUG - 2014-08-11 21:26:23 --> UTF-8 Support Enabled
DEBUG - 2014-08-11 21:26:23 --> URI Class Initialized
DEBUG - 2014-08-11 21:26:23 --> Router Class Initialized
DEBUG - 2014-08-11 21:26:23 --> Output Class Initialized
DEBUG - 2014-08-11 21:26:23 --> Security Class Initialized
DEBUG - 2014-08-11 21:26:23 --> Input Class Initialized
DEBUG - 2014-08-11 21:26:23 --> XSS Filtering completed
DEBUG - 2014-08-11 21:26:23 --> XSS Filtering completed
DEBUG - 2014-08-11 21:26:23 --> XSS Filtering completed
DEBUG - 2014-08-11 21:26:23 --> XSS Filtering completed
DEBUG - 2014-08-11 21:26:23 --> XSS Filtering completed
DEBUG - 2014-08-11 21:26:23 --> XSS Filtering completed
DEBUG - 2014-08-11 21:26:23 --> XSS Filtering completed
DEBUG - 2014-08-11 21:26:23 --> CRSF cookie Set
DEBUG - 2014-08-11 21:26:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-11 21:26:23 --> Language Class Initialized
DEBUG - 2014-08-11 21:26:23 --> Loader Class Initialized
DEBUG - 2014-08-11 21:26:23 --> Helper loaded: functions_helper
DEBUG - 2014-08-11 21:26:23 --> Helper loaded: url_helper
DEBUG - 2014-08-11 21:26:23 --> Database Driver Class Initialized
ERROR - 2014-08-11 21:26:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-11 21:26:23 --> Session Class Initialized
DEBUG - 2014-08-11 21:26:23 --> Helper loaded: string_helper
DEBUG - 2014-08-11 21:26:23 --> Session routines successfully run
DEBUG - 2014-08-11 21:26:23 --> Controller Class Initialized
DEBUG - 2014-08-11 21:26:23 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-11 21:26:23 --> File loaded: application/views/bootstrap/placement_students_nav.php
DEBUG - 2014-08-11 21:26:23 --> Model Class Initialized
DEBUG - 2014-08-11 21:26:23 --> Model Class Initialized
DEBUG - 2014-08-11 21:26:23 --> Helper loaded: form_helper
DEBUG - 2014-08-11 21:26:23 --> Helper loaded: array_helper
DEBUG - 2014-08-11 21:26:23 --> File loaded: application/views/placement_students_update.php
DEBUG - 2014-08-11 21:26:23 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-11 21:26:23 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-11 21:26:23 --> Final output sent to browser
DEBUG - 2014-08-11 21:26:23 --> Total execution time: 0.0545
