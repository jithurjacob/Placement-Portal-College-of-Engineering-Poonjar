<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-08-20 16:15:43 --> Config Class Initialized
DEBUG - 2014-08-20 16:15:43 --> Hooks Class Initialized
DEBUG - 2014-08-20 16:15:43 --> Utf8 Class Initialized
DEBUG - 2014-08-20 16:15:43 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 16:15:43 --> URI Class Initialized
DEBUG - 2014-08-20 16:15:43 --> Router Class Initialized
DEBUG - 2014-08-20 16:15:43 --> No URI present. Default controller set.
DEBUG - 2014-08-20 16:15:43 --> Output Class Initialized
DEBUG - 2014-08-20 16:15:43 --> Security Class Initialized
DEBUG - 2014-08-20 16:15:43 --> Input Class Initialized
DEBUG - 2014-08-20 16:15:43 --> XSS Filtering completed
DEBUG - 2014-08-20 16:15:43 --> XSS Filtering completed
DEBUG - 2014-08-20 16:15:43 --> XSS Filtering completed
DEBUG - 2014-08-20 16:15:43 --> XSS Filtering completed
DEBUG - 2014-08-20 16:15:43 --> CRSF cookie Set
DEBUG - 2014-08-20 16:15:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 16:15:43 --> Language Class Initialized
DEBUG - 2014-08-20 16:15:43 --> Loader Class Initialized
DEBUG - 2014-08-20 16:15:43 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 16:15:43 --> Helper loaded: url_helper
DEBUG - 2014-08-20 16:15:43 --> Database Driver Class Initialized
ERROR - 2014-08-20 16:15:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 16:15:43 --> Session Class Initialized
DEBUG - 2014-08-20 16:15:43 --> Helper loaded: string_helper
DEBUG - 2014-08-20 16:15:43 --> A session cookie was not found.
DEBUG - 2014-08-20 16:15:43 --> Session routines successfully run
DEBUG - 2014-08-20 16:15:43 --> Controller Class Initialized
DEBUG - 2014-08-20 16:15:43 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 16:15:43 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 16:15:43 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 16:15:43 --> Helper loaded: form_helper
DEBUG - 2014-08-20 16:15:43 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 16:15:43 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-20 16:15:43 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 16:15:43 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 16:15:43 --> Final output sent to browser
DEBUG - 2014-08-20 16:15:43 --> Total execution time: 0.4192
DEBUG - 2014-08-20 16:15:56 --> Config Class Initialized
DEBUG - 2014-08-20 16:15:56 --> Hooks Class Initialized
DEBUG - 2014-08-20 16:15:56 --> Utf8 Class Initialized
DEBUG - 2014-08-20 16:15:56 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 16:15:56 --> URI Class Initialized
DEBUG - 2014-08-20 16:15:56 --> Router Class Initialized
DEBUG - 2014-08-20 16:15:56 --> Output Class Initialized
DEBUG - 2014-08-20 16:15:56 --> Security Class Initialized
DEBUG - 2014-08-20 16:15:56 --> Input Class Initialized
DEBUG - 2014-08-20 16:15:56 --> XSS Filtering completed
DEBUG - 2014-08-20 16:15:56 --> XSS Filtering completed
DEBUG - 2014-08-20 16:15:56 --> XSS Filtering completed
DEBUG - 2014-08-20 16:15:56 --> XSS Filtering completed
DEBUG - 2014-08-20 16:15:56 --> XSS Filtering completed
DEBUG - 2014-08-20 16:15:56 --> XSS Filtering completed
DEBUG - 2014-08-20 16:15:56 --> XSS Filtering completed
DEBUG - 2014-08-20 16:15:56 --> XSS Filtering completed
DEBUG - 2014-08-20 16:15:56 --> XSS Filtering completed
DEBUG - 2014-08-20 16:15:56 --> CRSF cookie Set
DEBUG - 2014-08-20 16:15:56 --> CSRF token verified
DEBUG - 2014-08-20 16:15:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 16:15:56 --> Language Class Initialized
DEBUG - 2014-08-20 16:15:56 --> Loader Class Initialized
DEBUG - 2014-08-20 16:15:56 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 16:15:56 --> Helper loaded: url_helper
DEBUG - 2014-08-20 16:15:56 --> Database Driver Class Initialized
ERROR - 2014-08-20 16:15:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 16:15:56 --> Session Class Initialized
DEBUG - 2014-08-20 16:15:56 --> Helper loaded: string_helper
DEBUG - 2014-08-20 16:15:56 --> Session routines successfully run
DEBUG - 2014-08-20 16:15:56 --> Controller Class Initialized
DEBUG - 2014-08-20 16:15:57 --> Helper loaded: form_helper
DEBUG - 2014-08-20 16:15:57 --> Form Validation Class Initialized
DEBUG - 2014-08-20 16:15:57 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-20 16:15:57 --> XSS Filtering completed
DEBUG - 2014-08-20 16:15:57 --> XSS Filtering completed
DEBUG - 2014-08-20 16:15:57 --> Model Class Initialized
DEBUG - 2014-08-20 16:15:57 --> Model Class Initialized
DEBUG - 2014-08-20 16:15:57 --> Model Class Initialized
DEBUG - 2014-08-20 16:15:57 --> Model Class Initialized
DEBUG - 2014-08-20 16:15:57 --> Encrypt Class Initialized
DEBUG - 2014-08-20 16:15:57 --> XSS Filtering completed
DEBUG - 2014-08-20 16:15:57 --> XSS Filtering completed
DEBUG - 2014-08-20 16:15:58 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-20 16:15:58 --> XSS Filtering completed
DEBUG - 2014-08-20 16:15:58 --> XSS Filtering completed
DEBUG - 2014-08-20 16:15:58 --> Encrypt class already loaded. Second attempt ignored.
DEBUG - 2014-08-20 16:15:58 --> XSS Filtering completed
DEBUG - 2014-08-20 16:15:58 --> XSS Filtering completed
DEBUG - 2014-08-20 16:15:58 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 16:15:58 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 16:15:58 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 16:15:58 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 16:15:58 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-20 16:15:58 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 16:15:58 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 16:15:58 --> Final output sent to browser
DEBUG - 2014-08-20 16:15:58 --> Total execution time: 1.9645
DEBUG - 2014-08-20 16:16:18 --> Config Class Initialized
DEBUG - 2014-08-20 16:16:18 --> Hooks Class Initialized
DEBUG - 2014-08-20 16:16:18 --> Utf8 Class Initialized
DEBUG - 2014-08-20 16:16:18 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 16:16:18 --> URI Class Initialized
DEBUG - 2014-08-20 16:16:18 --> Router Class Initialized
DEBUG - 2014-08-20 16:16:18 --> Output Class Initialized
DEBUG - 2014-08-20 16:16:18 --> Security Class Initialized
DEBUG - 2014-08-20 16:16:18 --> Input Class Initialized
DEBUG - 2014-08-20 16:16:18 --> XSS Filtering completed
DEBUG - 2014-08-20 16:16:18 --> XSS Filtering completed
DEBUG - 2014-08-20 16:16:18 --> XSS Filtering completed
DEBUG - 2014-08-20 16:16:18 --> XSS Filtering completed
DEBUG - 2014-08-20 16:16:18 --> XSS Filtering completed
DEBUG - 2014-08-20 16:16:18 --> XSS Filtering completed
DEBUG - 2014-08-20 16:16:18 --> XSS Filtering completed
DEBUG - 2014-08-20 16:16:18 --> XSS Filtering completed
DEBUG - 2014-08-20 16:16:18 --> XSS Filtering completed
DEBUG - 2014-08-20 16:16:18 --> CRSF cookie Set
DEBUG - 2014-08-20 16:16:18 --> CSRF token verified
DEBUG - 2014-08-20 16:16:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 16:16:18 --> Language Class Initialized
DEBUG - 2014-08-20 16:16:18 --> Loader Class Initialized
DEBUG - 2014-08-20 16:16:18 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 16:16:18 --> Helper loaded: url_helper
DEBUG - 2014-08-20 16:16:18 --> Database Driver Class Initialized
ERROR - 2014-08-20 16:16:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 16:16:18 --> Session Class Initialized
DEBUG - 2014-08-20 16:16:18 --> Helper loaded: string_helper
DEBUG - 2014-08-20 16:16:18 --> Session routines successfully run
DEBUG - 2014-08-20 16:16:18 --> Controller Class Initialized
DEBUG - 2014-08-20 16:16:18 --> Helper loaded: form_helper
DEBUG - 2014-08-20 16:16:18 --> Form Validation Class Initialized
DEBUG - 2014-08-20 16:16:18 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-20 16:16:18 --> XSS Filtering completed
DEBUG - 2014-08-20 16:16:18 --> XSS Filtering completed
DEBUG - 2014-08-20 16:16:18 --> Model Class Initialized
DEBUG - 2014-08-20 16:16:18 --> Model Class Initialized
DEBUG - 2014-08-20 16:16:18 --> Model Class Initialized
DEBUG - 2014-08-20 16:16:18 --> Model Class Initialized
DEBUG - 2014-08-20 16:16:18 --> Encrypt Class Initialized
DEBUG - 2014-08-20 16:16:18 --> XSS Filtering completed
DEBUG - 2014-08-20 16:16:18 --> XSS Filtering completed
DEBUG - 2014-08-20 16:16:18 --> Config Class Initialized
DEBUG - 2014-08-20 16:16:18 --> Hooks Class Initialized
DEBUG - 2014-08-20 16:16:18 --> Utf8 Class Initialized
DEBUG - 2014-08-20 16:16:18 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 16:16:18 --> URI Class Initialized
DEBUG - 2014-08-20 16:16:18 --> Router Class Initialized
DEBUG - 2014-08-20 16:16:18 --> Output Class Initialized
DEBUG - 2014-08-20 16:16:18 --> Security Class Initialized
DEBUG - 2014-08-20 16:16:18 --> Input Class Initialized
DEBUG - 2014-08-20 16:16:18 --> XSS Filtering completed
DEBUG - 2014-08-20 16:16:18 --> XSS Filtering completed
DEBUG - 2014-08-20 16:16:18 --> XSS Filtering completed
DEBUG - 2014-08-20 16:16:18 --> XSS Filtering completed
DEBUG - 2014-08-20 16:16:18 --> XSS Filtering completed
DEBUG - 2014-08-20 16:16:18 --> XSS Filtering completed
DEBUG - 2014-08-20 16:16:18 --> CRSF cookie Set
DEBUG - 2014-08-20 16:16:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 16:16:18 --> Language Class Initialized
DEBUG - 2014-08-20 16:16:18 --> Loader Class Initialized
DEBUG - 2014-08-20 16:16:18 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 16:16:18 --> Helper loaded: url_helper
DEBUG - 2014-08-20 16:16:18 --> Database Driver Class Initialized
ERROR - 2014-08-20 16:16:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 16:16:18 --> Session Class Initialized
DEBUG - 2014-08-20 16:16:18 --> Helper loaded: string_helper
DEBUG - 2014-08-20 16:16:18 --> Session routines successfully run
DEBUG - 2014-08-20 16:16:18 --> Controller Class Initialized
DEBUG - 2014-08-20 16:16:18 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 16:16:18 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-20 16:16:18 --> Encrypt Class Initialized
DEBUG - 2014-08-20 16:16:18 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-20 16:16:18 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 16:16:18 --> File loaded: application/views/placement_admin_home.php
DEBUG - 2014-08-20 16:16:18 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 16:16:18 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 16:16:18 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-20 16:16:18 --> Final output sent to browser
DEBUG - 2014-08-20 16:16:18 --> Total execution time: 0.2108
DEBUG - 2014-08-20 16:16:23 --> Config Class Initialized
DEBUG - 2014-08-20 16:16:23 --> Hooks Class Initialized
DEBUG - 2014-08-20 16:16:23 --> Utf8 Class Initialized
DEBUG - 2014-08-20 16:16:23 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 16:16:23 --> URI Class Initialized
DEBUG - 2014-08-20 16:16:23 --> Router Class Initialized
DEBUG - 2014-08-20 16:16:23 --> Output Class Initialized
DEBUG - 2014-08-20 16:16:23 --> Security Class Initialized
DEBUG - 2014-08-20 16:16:23 --> Input Class Initialized
DEBUG - 2014-08-20 16:16:23 --> XSS Filtering completed
DEBUG - 2014-08-20 16:16:23 --> XSS Filtering completed
DEBUG - 2014-08-20 16:16:23 --> XSS Filtering completed
DEBUG - 2014-08-20 16:16:23 --> XSS Filtering completed
DEBUG - 2014-08-20 16:16:23 --> XSS Filtering completed
DEBUG - 2014-08-20 16:16:23 --> XSS Filtering completed
DEBUG - 2014-08-20 16:16:23 --> CRSF cookie Set
DEBUG - 2014-08-20 16:16:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 16:16:23 --> Language Class Initialized
DEBUG - 2014-08-20 16:16:23 --> Loader Class Initialized
DEBUG - 2014-08-20 16:16:23 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 16:16:23 --> Helper loaded: url_helper
DEBUG - 2014-08-20 16:16:23 --> Database Driver Class Initialized
ERROR - 2014-08-20 16:16:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 16:16:23 --> Session Class Initialized
DEBUG - 2014-08-20 16:16:23 --> Helper loaded: string_helper
DEBUG - 2014-08-20 16:16:23 --> Session routines successfully run
DEBUG - 2014-08-20 16:16:23 --> Controller Class Initialized
DEBUG - 2014-08-20 16:16:23 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 16:16:23 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-20 16:16:23 --> Encrypt Class Initialized
DEBUG - 2014-08-20 16:16:23 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-20 16:16:23 --> File loaded: application/views/placement_admin_history.php
DEBUG - 2014-08-20 16:16:23 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 16:16:23 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 16:16:23 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-20 16:16:23 --> Final output sent to browser
DEBUG - 2014-08-20 16:16:23 --> Total execution time: 0.1411
DEBUG - 2014-08-20 16:16:25 --> Config Class Initialized
DEBUG - 2014-08-20 16:16:25 --> Hooks Class Initialized
DEBUG - 2014-08-20 16:16:25 --> Utf8 Class Initialized
DEBUG - 2014-08-20 16:16:25 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 16:16:25 --> URI Class Initialized
DEBUG - 2014-08-20 16:16:25 --> Router Class Initialized
DEBUG - 2014-08-20 16:16:25 --> Output Class Initialized
DEBUG - 2014-08-20 16:16:25 --> Security Class Initialized
DEBUG - 2014-08-20 16:16:25 --> Input Class Initialized
DEBUG - 2014-08-20 16:16:25 --> XSS Filtering completed
DEBUG - 2014-08-20 16:16:25 --> XSS Filtering completed
DEBUG - 2014-08-20 16:16:25 --> XSS Filtering completed
DEBUG - 2014-08-20 16:16:25 --> XSS Filtering completed
DEBUG - 2014-08-20 16:16:25 --> XSS Filtering completed
DEBUG - 2014-08-20 16:16:25 --> XSS Filtering completed
DEBUG - 2014-08-20 16:16:25 --> CRSF cookie Set
DEBUG - 2014-08-20 16:16:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 16:16:25 --> Language Class Initialized
DEBUG - 2014-08-20 16:16:25 --> Loader Class Initialized
DEBUG - 2014-08-20 16:16:25 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 16:16:25 --> Helper loaded: url_helper
DEBUG - 2014-08-20 16:16:25 --> Database Driver Class Initialized
ERROR - 2014-08-20 16:16:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 16:16:25 --> Session Class Initialized
DEBUG - 2014-08-20 16:16:25 --> Helper loaded: string_helper
DEBUG - 2014-08-20 16:16:25 --> Session routines successfully run
DEBUG - 2014-08-20 16:16:25 --> Controller Class Initialized
DEBUG - 2014-08-20 16:16:25 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 16:16:25 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-20 16:16:25 --> Encrypt Class Initialized
DEBUG - 2014-08-20 16:16:25 --> Model Class Initialized
DEBUG - 2014-08-20 16:16:25 --> Model Class Initialized
DEBUG - 2014-08-20 16:16:25 --> Model Class Initialized
DEBUG - 2014-08-20 16:16:25 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-20 16:16:25 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 16:16:25 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 16:16:25 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-20 16:16:25 --> Final output sent to browser
DEBUG - 2014-08-20 16:16:25 --> Total execution time: 0.2146
DEBUG - 2014-08-20 16:17:25 --> Config Class Initialized
DEBUG - 2014-08-20 16:17:25 --> Hooks Class Initialized
DEBUG - 2014-08-20 16:17:25 --> Utf8 Class Initialized
DEBUG - 2014-08-20 16:17:25 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 16:17:25 --> URI Class Initialized
DEBUG - 2014-08-20 16:17:25 --> Router Class Initialized
DEBUG - 2014-08-20 16:17:25 --> Output Class Initialized
DEBUG - 2014-08-20 16:17:25 --> Security Class Initialized
DEBUG - 2014-08-20 16:17:25 --> Input Class Initialized
DEBUG - 2014-08-20 16:17:25 --> XSS Filtering completed
DEBUG - 2014-08-20 16:17:25 --> XSS Filtering completed
DEBUG - 2014-08-20 16:17:25 --> XSS Filtering completed
DEBUG - 2014-08-20 16:17:25 --> XSS Filtering completed
DEBUG - 2014-08-20 16:17:25 --> XSS Filtering completed
DEBUG - 2014-08-20 16:17:25 --> XSS Filtering completed
DEBUG - 2014-08-20 16:17:25 --> CRSF cookie Set
DEBUG - 2014-08-20 16:17:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 16:17:25 --> Language Class Initialized
DEBUG - 2014-08-20 16:17:25 --> Loader Class Initialized
DEBUG - 2014-08-20 16:17:25 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 16:17:25 --> Helper loaded: url_helper
DEBUG - 2014-08-20 16:17:25 --> Database Driver Class Initialized
ERROR - 2014-08-20 16:17:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 16:17:25 --> Session Class Initialized
DEBUG - 2014-08-20 16:17:25 --> Helper loaded: string_helper
DEBUG - 2014-08-20 16:17:25 --> Session routines successfully run
DEBUG - 2014-08-20 16:17:25 --> Controller Class Initialized
DEBUG - 2014-08-20 16:17:25 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 16:17:25 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-20 16:17:25 --> Encrypt Class Initialized
DEBUG - 2014-08-20 16:17:25 --> Model Class Initialized
DEBUG - 2014-08-20 16:17:25 --> Model Class Initialized
DEBUG - 2014-08-20 16:17:25 --> Model Class Initialized
DEBUG - 2014-08-20 16:17:25 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-20 16:17:25 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 16:17:25 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 16:17:25 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-20 16:17:25 --> Final output sent to browser
DEBUG - 2014-08-20 16:17:25 --> Total execution time: 0.1473
DEBUG - 2014-08-20 16:18:08 --> Config Class Initialized
DEBUG - 2014-08-20 16:18:08 --> Hooks Class Initialized
DEBUG - 2014-08-20 16:18:08 --> Utf8 Class Initialized
DEBUG - 2014-08-20 16:18:08 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 16:18:08 --> URI Class Initialized
DEBUG - 2014-08-20 16:18:08 --> Router Class Initialized
DEBUG - 2014-08-20 16:18:08 --> Output Class Initialized
DEBUG - 2014-08-20 16:18:08 --> Security Class Initialized
DEBUG - 2014-08-20 16:18:08 --> Input Class Initialized
DEBUG - 2014-08-20 16:18:08 --> XSS Filtering completed
DEBUG - 2014-08-20 16:18:08 --> XSS Filtering completed
DEBUG - 2014-08-20 16:18:08 --> XSS Filtering completed
DEBUG - 2014-08-20 16:18:08 --> XSS Filtering completed
DEBUG - 2014-08-20 16:18:08 --> XSS Filtering completed
DEBUG - 2014-08-20 16:18:08 --> XSS Filtering completed
DEBUG - 2014-08-20 16:18:08 --> CRSF cookie Set
DEBUG - 2014-08-20 16:18:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 16:18:08 --> Language Class Initialized
DEBUG - 2014-08-20 16:18:08 --> Loader Class Initialized
DEBUG - 2014-08-20 16:18:08 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 16:18:08 --> Helper loaded: url_helper
DEBUG - 2014-08-20 16:18:08 --> Database Driver Class Initialized
ERROR - 2014-08-20 16:18:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 16:18:08 --> Session Class Initialized
DEBUG - 2014-08-20 16:18:08 --> Helper loaded: string_helper
DEBUG - 2014-08-20 16:18:08 --> Session routines successfully run
DEBUG - 2014-08-20 16:18:08 --> Controller Class Initialized
DEBUG - 2014-08-20 16:18:08 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 16:18:08 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-20 16:18:08 --> Encrypt Class Initialized
DEBUG - 2014-08-20 16:18:08 --> Model Class Initialized
DEBUG - 2014-08-20 16:18:08 --> Model Class Initialized
DEBUG - 2014-08-20 16:18:08 --> Model Class Initialized
DEBUG - 2014-08-20 16:18:08 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-20 16:18:08 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 16:18:08 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 16:18:08 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-20 16:18:08 --> Final output sent to browser
DEBUG - 2014-08-20 16:18:08 --> Total execution time: 0.1633
DEBUG - 2014-08-20 16:18:23 --> Config Class Initialized
DEBUG - 2014-08-20 16:18:23 --> Hooks Class Initialized
DEBUG - 2014-08-20 16:18:23 --> Utf8 Class Initialized
DEBUG - 2014-08-20 16:18:23 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 16:18:23 --> URI Class Initialized
DEBUG - 2014-08-20 16:18:23 --> Router Class Initialized
DEBUG - 2014-08-20 16:18:23 --> Output Class Initialized
DEBUG - 2014-08-20 16:18:23 --> Security Class Initialized
DEBUG - 2014-08-20 16:18:23 --> Input Class Initialized
DEBUG - 2014-08-20 16:18:23 --> XSS Filtering completed
DEBUG - 2014-08-20 16:18:23 --> XSS Filtering completed
DEBUG - 2014-08-20 16:18:23 --> XSS Filtering completed
DEBUG - 2014-08-20 16:18:23 --> XSS Filtering completed
DEBUG - 2014-08-20 16:18:23 --> XSS Filtering completed
DEBUG - 2014-08-20 16:18:23 --> XSS Filtering completed
DEBUG - 2014-08-20 16:18:23 --> CRSF cookie Set
DEBUG - 2014-08-20 16:18:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 16:18:23 --> Language Class Initialized
DEBUG - 2014-08-20 16:18:23 --> Loader Class Initialized
DEBUG - 2014-08-20 16:18:23 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 16:18:23 --> Helper loaded: url_helper
DEBUG - 2014-08-20 16:18:23 --> Database Driver Class Initialized
ERROR - 2014-08-20 16:18:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 16:18:23 --> Session Class Initialized
DEBUG - 2014-08-20 16:18:23 --> Helper loaded: string_helper
DEBUG - 2014-08-20 16:18:23 --> Session routines successfully run
DEBUG - 2014-08-20 16:18:23 --> Controller Class Initialized
DEBUG - 2014-08-20 16:18:23 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 16:18:23 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-20 16:18:23 --> Encrypt Class Initialized
DEBUG - 2014-08-20 16:18:23 --> Model Class Initialized
DEBUG - 2014-08-20 16:18:23 --> Model Class Initialized
DEBUG - 2014-08-20 16:18:23 --> Model Class Initialized
DEBUG - 2014-08-20 16:18:23 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-20 16:18:23 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 16:18:23 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 16:18:23 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-20 16:18:23 --> Final output sent to browser
DEBUG - 2014-08-20 16:18:23 --> Total execution time: 0.1523
DEBUG - 2014-08-20 16:20:33 --> Config Class Initialized
DEBUG - 2014-08-20 16:20:33 --> Hooks Class Initialized
DEBUG - 2014-08-20 16:20:33 --> Utf8 Class Initialized
DEBUG - 2014-08-20 16:20:33 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 16:20:33 --> URI Class Initialized
DEBUG - 2014-08-20 16:20:33 --> Router Class Initialized
DEBUG - 2014-08-20 16:20:33 --> Output Class Initialized
DEBUG - 2014-08-20 16:20:34 --> Security Class Initialized
DEBUG - 2014-08-20 16:20:34 --> Input Class Initialized
DEBUG - 2014-08-20 16:20:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:20:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:20:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:20:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:20:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:20:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:20:34 --> CRSF cookie Set
DEBUG - 2014-08-20 16:20:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 16:20:34 --> Language Class Initialized
DEBUG - 2014-08-20 16:20:34 --> Loader Class Initialized
DEBUG - 2014-08-20 16:20:34 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 16:20:34 --> Helper loaded: url_helper
DEBUG - 2014-08-20 16:20:34 --> Database Driver Class Initialized
ERROR - 2014-08-20 16:20:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 16:20:34 --> Session Class Initialized
DEBUG - 2014-08-20 16:20:34 --> Helper loaded: string_helper
DEBUG - 2014-08-20 16:20:34 --> Session routines successfully run
DEBUG - 2014-08-20 16:20:34 --> Controller Class Initialized
DEBUG - 2014-08-20 16:20:34 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 16:20:34 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-20 16:20:34 --> Encrypt Class Initialized
DEBUG - 2014-08-20 16:20:34 --> Model Class Initialized
DEBUG - 2014-08-20 16:20:34 --> Model Class Initialized
DEBUG - 2014-08-20 16:20:34 --> Model Class Initialized
DEBUG - 2014-08-20 16:20:34 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-20 16:20:34 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 16:20:34 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 16:20:34 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-20 16:20:34 --> Final output sent to browser
DEBUG - 2014-08-20 16:20:34 --> Total execution time: 0.1489
DEBUG - 2014-08-20 16:20:42 --> Config Class Initialized
DEBUG - 2014-08-20 16:20:42 --> Hooks Class Initialized
DEBUG - 2014-08-20 16:20:42 --> Utf8 Class Initialized
DEBUG - 2014-08-20 16:20:42 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 16:20:42 --> URI Class Initialized
DEBUG - 2014-08-20 16:20:42 --> Router Class Initialized
DEBUG - 2014-08-20 16:20:42 --> Output Class Initialized
DEBUG - 2014-08-20 16:20:42 --> Security Class Initialized
DEBUG - 2014-08-20 16:20:42 --> Input Class Initialized
DEBUG - 2014-08-20 16:20:42 --> XSS Filtering completed
DEBUG - 2014-08-20 16:20:42 --> XSS Filtering completed
DEBUG - 2014-08-20 16:20:42 --> XSS Filtering completed
DEBUG - 2014-08-20 16:20:42 --> XSS Filtering completed
DEBUG - 2014-08-20 16:20:42 --> XSS Filtering completed
DEBUG - 2014-08-20 16:20:42 --> XSS Filtering completed
DEBUG - 2014-08-20 16:20:42 --> CRSF cookie Set
DEBUG - 2014-08-20 16:20:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 16:20:42 --> Language Class Initialized
DEBUG - 2014-08-20 16:20:42 --> Loader Class Initialized
DEBUG - 2014-08-20 16:20:42 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 16:20:42 --> Helper loaded: url_helper
DEBUG - 2014-08-20 16:20:42 --> Database Driver Class Initialized
ERROR - 2014-08-20 16:20:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 16:20:42 --> Session Class Initialized
DEBUG - 2014-08-20 16:20:42 --> Helper loaded: string_helper
DEBUG - 2014-08-20 16:20:42 --> Session routines successfully run
DEBUG - 2014-08-20 16:20:42 --> Controller Class Initialized
DEBUG - 2014-08-20 16:20:42 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 16:20:42 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-20 16:20:42 --> Encrypt Class Initialized
DEBUG - 2014-08-20 16:20:42 --> Model Class Initialized
DEBUG - 2014-08-20 16:20:42 --> Model Class Initialized
DEBUG - 2014-08-20 16:20:42 --> Model Class Initialized
DEBUG - 2014-08-20 16:20:42 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-20 16:20:42 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 16:20:42 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 16:20:42 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-20 16:20:42 --> Final output sent to browser
DEBUG - 2014-08-20 16:20:42 --> Total execution time: 0.2446
DEBUG - 2014-08-20 16:21:03 --> Config Class Initialized
DEBUG - 2014-08-20 16:21:03 --> Hooks Class Initialized
DEBUG - 2014-08-20 16:21:03 --> Utf8 Class Initialized
DEBUG - 2014-08-20 16:21:03 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 16:21:03 --> URI Class Initialized
DEBUG - 2014-08-20 16:21:03 --> Router Class Initialized
DEBUG - 2014-08-20 16:21:03 --> Output Class Initialized
DEBUG - 2014-08-20 16:21:03 --> Security Class Initialized
DEBUG - 2014-08-20 16:21:03 --> Input Class Initialized
DEBUG - 2014-08-20 16:21:03 --> XSS Filtering completed
DEBUG - 2014-08-20 16:21:03 --> XSS Filtering completed
DEBUG - 2014-08-20 16:21:03 --> XSS Filtering completed
DEBUG - 2014-08-20 16:21:03 --> XSS Filtering completed
DEBUG - 2014-08-20 16:21:03 --> XSS Filtering completed
DEBUG - 2014-08-20 16:21:03 --> XSS Filtering completed
DEBUG - 2014-08-20 16:21:03 --> CRSF cookie Set
DEBUG - 2014-08-20 16:21:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 16:21:03 --> Language Class Initialized
DEBUG - 2014-08-20 16:21:03 --> Loader Class Initialized
DEBUG - 2014-08-20 16:21:03 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 16:21:03 --> Helper loaded: url_helper
DEBUG - 2014-08-20 16:21:03 --> Database Driver Class Initialized
ERROR - 2014-08-20 16:21:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 16:21:03 --> Session Class Initialized
DEBUG - 2014-08-20 16:21:03 --> Helper loaded: string_helper
DEBUG - 2014-08-20 16:21:03 --> Session routines successfully run
DEBUG - 2014-08-20 16:21:03 --> Controller Class Initialized
DEBUG - 2014-08-20 16:21:03 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 16:21:03 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-20 16:21:03 --> Encrypt Class Initialized
DEBUG - 2014-08-20 16:21:03 --> Model Class Initialized
DEBUG - 2014-08-20 16:21:03 --> Model Class Initialized
DEBUG - 2014-08-20 16:21:03 --> Model Class Initialized
DEBUG - 2014-08-20 16:21:03 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-20 16:21:03 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 16:21:03 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 16:21:03 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-20 16:21:03 --> Final output sent to browser
DEBUG - 2014-08-20 16:21:03 --> Total execution time: 0.1780
DEBUG - 2014-08-20 16:21:24 --> Config Class Initialized
DEBUG - 2014-08-20 16:21:24 --> Hooks Class Initialized
DEBUG - 2014-08-20 16:21:24 --> Utf8 Class Initialized
DEBUG - 2014-08-20 16:21:24 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 16:21:24 --> URI Class Initialized
DEBUG - 2014-08-20 16:21:24 --> Router Class Initialized
DEBUG - 2014-08-20 16:21:24 --> Output Class Initialized
DEBUG - 2014-08-20 16:21:24 --> Security Class Initialized
DEBUG - 2014-08-20 16:21:24 --> Input Class Initialized
DEBUG - 2014-08-20 16:21:24 --> XSS Filtering completed
DEBUG - 2014-08-20 16:21:24 --> XSS Filtering completed
DEBUG - 2014-08-20 16:21:24 --> XSS Filtering completed
DEBUG - 2014-08-20 16:21:24 --> XSS Filtering completed
DEBUG - 2014-08-20 16:21:24 --> XSS Filtering completed
DEBUG - 2014-08-20 16:21:24 --> XSS Filtering completed
DEBUG - 2014-08-20 16:21:24 --> XSS Filtering completed
DEBUG - 2014-08-20 16:21:28 --> Config Class Initialized
DEBUG - 2014-08-20 16:21:28 --> Hooks Class Initialized
DEBUG - 2014-08-20 16:21:28 --> Utf8 Class Initialized
DEBUG - 2014-08-20 16:21:28 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 16:21:28 --> URI Class Initialized
DEBUG - 2014-08-20 16:21:28 --> Router Class Initialized
DEBUG - 2014-08-20 16:21:28 --> Output Class Initialized
DEBUG - 2014-08-20 16:21:28 --> Security Class Initialized
DEBUG - 2014-08-20 16:21:28 --> Input Class Initialized
DEBUG - 2014-08-20 16:21:28 --> XSS Filtering completed
DEBUG - 2014-08-20 16:21:28 --> XSS Filtering completed
DEBUG - 2014-08-20 16:21:28 --> XSS Filtering completed
DEBUG - 2014-08-20 16:21:28 --> XSS Filtering completed
DEBUG - 2014-08-20 16:21:28 --> XSS Filtering completed
DEBUG - 2014-08-20 16:21:28 --> XSS Filtering completed
DEBUG - 2014-08-20 16:21:28 --> CRSF cookie Set
DEBUG - 2014-08-20 16:21:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 16:21:28 --> Language Class Initialized
DEBUG - 2014-08-20 16:21:28 --> Loader Class Initialized
DEBUG - 2014-08-20 16:21:28 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 16:21:28 --> Helper loaded: url_helper
DEBUG - 2014-08-20 16:21:28 --> Database Driver Class Initialized
ERROR - 2014-08-20 16:21:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 16:21:28 --> Session Class Initialized
DEBUG - 2014-08-20 16:21:28 --> Helper loaded: string_helper
DEBUG - 2014-08-20 16:21:28 --> Session routines successfully run
DEBUG - 2014-08-20 16:21:28 --> Controller Class Initialized
DEBUG - 2014-08-20 16:21:28 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 16:21:28 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-20 16:21:28 --> Encrypt Class Initialized
DEBUG - 2014-08-20 16:21:28 --> Model Class Initialized
DEBUG - 2014-08-20 16:21:28 --> Model Class Initialized
DEBUG - 2014-08-20 16:21:28 --> Model Class Initialized
DEBUG - 2014-08-20 16:21:28 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-20 16:21:28 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 16:21:28 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 16:21:28 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-20 16:21:28 --> Final output sent to browser
DEBUG - 2014-08-20 16:21:28 --> Total execution time: 0.2160
DEBUG - 2014-08-20 16:23:05 --> Config Class Initialized
DEBUG - 2014-08-20 16:23:05 --> Hooks Class Initialized
DEBUG - 2014-08-20 16:23:05 --> Utf8 Class Initialized
DEBUG - 2014-08-20 16:23:05 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 16:23:05 --> URI Class Initialized
DEBUG - 2014-08-20 16:23:05 --> Router Class Initialized
DEBUG - 2014-08-20 16:23:05 --> Output Class Initialized
DEBUG - 2014-08-20 16:23:05 --> Security Class Initialized
DEBUG - 2014-08-20 16:23:05 --> Input Class Initialized
DEBUG - 2014-08-20 16:23:05 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:05 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:05 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:05 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:05 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:05 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:05 --> CRSF cookie Set
DEBUG - 2014-08-20 16:23:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 16:23:05 --> Language Class Initialized
DEBUG - 2014-08-20 16:23:05 --> Loader Class Initialized
DEBUG - 2014-08-20 16:23:05 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 16:23:05 --> Helper loaded: url_helper
DEBUG - 2014-08-20 16:23:05 --> Database Driver Class Initialized
ERROR - 2014-08-20 16:23:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 16:23:05 --> Session Class Initialized
DEBUG - 2014-08-20 16:23:05 --> Helper loaded: string_helper
DEBUG - 2014-08-20 16:23:05 --> Session routines successfully run
DEBUG - 2014-08-20 16:23:05 --> Controller Class Initialized
DEBUG - 2014-08-20 16:23:05 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 16:23:05 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-20 16:23:05 --> Encrypt Class Initialized
DEBUG - 2014-08-20 16:23:05 --> Model Class Initialized
DEBUG - 2014-08-20 16:23:05 --> Model Class Initialized
DEBUG - 2014-08-20 16:23:05 --> Model Class Initialized
DEBUG - 2014-08-20 16:23:05 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-20 16:23:05 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 16:23:05 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 16:23:05 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-20 16:23:05 --> Final output sent to browser
DEBUG - 2014-08-20 16:23:05 --> Total execution time: 0.1572
DEBUG - 2014-08-20 16:23:34 --> Config Class Initialized
DEBUG - 2014-08-20 16:23:34 --> Hooks Class Initialized
DEBUG - 2014-08-20 16:23:34 --> Utf8 Class Initialized
DEBUG - 2014-08-20 16:23:34 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 16:23:34 --> URI Class Initialized
DEBUG - 2014-08-20 16:23:34 --> Config Class Initialized
DEBUG - 2014-08-20 16:23:34 --> Hooks Class Initialized
DEBUG - 2014-08-20 16:23:34 --> Router Class Initialized
DEBUG - 2014-08-20 16:23:34 --> Utf8 Class Initialized
DEBUG - 2014-08-20 16:23:34 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 16:23:34 --> No URI present. Default controller set.
DEBUG - 2014-08-20 16:23:34 --> URI Class Initialized
DEBUG - 2014-08-20 16:23:34 --> Output Class Initialized
DEBUG - 2014-08-20 16:23:34 --> Router Class Initialized
DEBUG - 2014-08-20 16:23:34 --> No URI present. Default controller set.
DEBUG - 2014-08-20 16:23:34 --> Security Class Initialized
DEBUG - 2014-08-20 16:23:34 --> Output Class Initialized
DEBUG - 2014-08-20 16:23:34 --> Input Class Initialized
DEBUG - 2014-08-20 16:23:34 --> Security Class Initialized
DEBUG - 2014-08-20 16:23:34 --> Input Class Initialized
DEBUG - 2014-08-20 16:23:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:34 --> Config Class Initialized
DEBUG - 2014-08-20 16:23:34 --> Hooks Class Initialized
DEBUG - 2014-08-20 16:23:34 --> Utf8 Class Initialized
DEBUG - 2014-08-20 16:23:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:34 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 16:23:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:34 --> URI Class Initialized
DEBUG - 2014-08-20 16:23:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:34 --> Router Class Initialized
DEBUG - 2014-08-20 16:23:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:34 --> No URI present. Default controller set.
DEBUG - 2014-08-20 16:23:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:34 --> Output Class Initialized
DEBUG - 2014-08-20 16:23:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:34 --> Security Class Initialized
DEBUG - 2014-08-20 16:23:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:34 --> Input Class Initialized
DEBUG - 2014-08-20 16:23:34 --> CRSF cookie Set
DEBUG - 2014-08-20 16:23:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 16:23:34 --> Language Class Initialized
DEBUG - 2014-08-20 16:23:34 --> Config Class Initialized
DEBUG - 2014-08-20 16:23:34 --> Hooks Class Initialized
DEBUG - 2014-08-20 16:23:34 --> Utf8 Class Initialized
DEBUG - 2014-08-20 16:23:34 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 16:23:34 --> Loader Class Initialized
DEBUG - 2014-08-20 16:23:34 --> URI Class Initialized
DEBUG - 2014-08-20 16:23:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:34 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 16:23:34 --> Router Class Initialized
DEBUG - 2014-08-20 16:23:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:34 --> No URI present. Default controller set.
DEBUG - 2014-08-20 16:23:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:34 --> Output Class Initialized
DEBUG - 2014-08-20 16:23:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:34 --> Security Class Initialized
DEBUG - 2014-08-20 16:23:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:34 --> Input Class Initialized
DEBUG - 2014-08-20 16:23:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:34 --> CRSF cookie Set
DEBUG - 2014-08-20 16:23:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 16:23:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:34 --> Config Class Initialized
DEBUG - 2014-08-20 16:23:34 --> Hooks Class Initialized
DEBUG - 2014-08-20 16:23:34 --> Language Class Initialized
DEBUG - 2014-08-20 16:23:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:34 --> Utf8 Class Initialized
DEBUG - 2014-08-20 16:23:34 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 16:23:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:34 --> URI Class Initialized
DEBUG - 2014-08-20 16:23:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:34 --> Helper loaded: url_helper
DEBUG - 2014-08-20 16:23:34 --> Router Class Initialized
DEBUG - 2014-08-20 16:23:34 --> Loader Class Initialized
DEBUG - 2014-08-20 16:23:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:34 --> No URI present. Default controller set.
DEBUG - 2014-08-20 16:23:34 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 16:23:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:34 --> CRSF cookie Set
DEBUG - 2014-08-20 16:23:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 16:23:34 --> Output Class Initialized
DEBUG - 2014-08-20 16:23:34 --> Helper loaded: url_helper
DEBUG - 2014-08-20 16:23:34 --> Language Class Initialized
DEBUG - 2014-08-20 16:23:34 --> Security Class Initialized
DEBUG - 2014-08-20 16:23:34 --> Database Driver Class Initialized
DEBUG - 2014-08-20 16:23:34 --> Input Class Initialized
ERROR - 2014-08-20 16:23:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 16:23:34 --> Loader Class Initialized
DEBUG - 2014-08-20 16:23:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:34 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 16:23:34 --> Session Class Initialized
DEBUG - 2014-08-20 16:23:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:34 --> Helper loaded: string_helper
DEBUG - 2014-08-20 16:23:34 --> Helper loaded: url_helper
DEBUG - 2014-08-20 16:23:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:34 --> Session routines successfully run
DEBUG - 2014-08-20 16:23:34 --> Controller Class Initialized
DEBUG - 2014-08-20 16:23:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:34 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 16:23:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:34 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 16:23:34 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 16:23:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:34 --> CRSF cookie Set
DEBUG - 2014-08-20 16:23:34 --> Helper loaded: form_helper
DEBUG - 2014-08-20 16:23:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 16:23:34 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 16:23:34 --> Language Class Initialized
DEBUG - 2014-08-20 16:23:34 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-20 16:23:34 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 16:23:34 --> Database Driver Class Initialized
DEBUG - 2014-08-20 16:23:34 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 16:23:34 --> Final output sent to browser
DEBUG - 2014-08-20 16:23:34 --> Total execution time: 0.2356
DEBUG - 2014-08-20 16:23:34 --> Database Driver Class Initialized
DEBUG - 2014-08-20 16:23:34 --> Loader Class Initialized
ERROR - 2014-08-20 16:23:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 16:23:34 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 16:23:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:34 --> CRSF cookie Set
DEBUG - 2014-08-20 16:23:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 16:23:34 --> Helper loaded: url_helper
DEBUG - 2014-08-20 16:23:34 --> Language Class Initialized
DEBUG - 2014-08-20 16:23:34 --> Session Class Initialized
DEBUG - 2014-08-20 16:23:34 --> Helper loaded: string_helper
DEBUG - 2014-08-20 16:23:34 --> Session routines successfully run
DEBUG - 2014-08-20 16:23:34 --> Loader Class Initialized
DEBUG - 2014-08-20 16:23:34 --> Controller Class Initialized
ERROR - 2014-08-20 16:23:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 16:23:34 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 16:23:34 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 16:23:34 --> Database Driver Class Initialized
DEBUG - 2014-08-20 16:23:34 --> Helper loaded: url_helper
DEBUG - 2014-08-20 16:23:34 --> File loaded: application/views/bootstrap/placement_nav.php
ERROR - 2014-08-20 16:23:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 16:23:34 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 16:23:34 --> Session Class Initialized
DEBUG - 2014-08-20 16:23:34 --> Session Class Initialized
DEBUG - 2014-08-20 16:23:34 --> Helper loaded: string_helper
DEBUG - 2014-08-20 16:23:34 --> Helper loaded: form_helper
DEBUG - 2014-08-20 16:23:34 --> Session routines successfully run
DEBUG - 2014-08-20 16:23:34 --> Controller Class Initialized
DEBUG - 2014-08-20 16:23:34 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 16:23:34 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-20 16:23:34 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 16:23:34 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 16:23:34 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 16:23:34 --> Database Driver Class Initialized
DEBUG - 2014-08-20 16:23:34 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 16:23:34 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 16:23:34 --> Final output sent to browser
DEBUG - 2014-08-20 16:23:34 --> Total execution time: 0.2432
DEBUG - 2014-08-20 16:23:34 --> Helper loaded: string_helper
DEBUG - 2014-08-20 16:23:34 --> Helper loaded: form_helper
ERROR - 2014-08-20 16:23:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 16:23:34 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 16:23:34 --> Session routines successfully run
DEBUG - 2014-08-20 16:23:34 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-20 16:23:34 --> Controller Class Initialized
DEBUG - 2014-08-20 16:23:34 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 16:23:34 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 16:23:34 --> Session Class Initialized
DEBUG - 2014-08-20 16:23:34 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 16:23:34 --> Helper loaded: string_helper
DEBUG - 2014-08-20 16:23:34 --> Final output sent to browser
DEBUG - 2014-08-20 16:23:34 --> Total execution time: 0.2183
DEBUG - 2014-08-20 16:23:34 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 16:23:34 --> Session routines successfully run
DEBUG - 2014-08-20 16:23:34 --> Controller Class Initialized
DEBUG - 2014-08-20 16:23:34 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 16:23:34 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 16:23:34 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 16:23:34 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 16:23:34 --> Helper loaded: form_helper
DEBUG - 2014-08-20 16:23:34 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 16:23:34 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-20 16:23:34 --> Helper loaded: form_helper
DEBUG - 2014-08-20 16:23:34 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 16:23:34 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 16:23:34 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 16:23:34 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-20 16:23:34 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 16:23:34 --> Final output sent to browser
DEBUG - 2014-08-20 16:23:34 --> Total execution time: 0.1981
DEBUG - 2014-08-20 16:23:34 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 16:23:34 --> Final output sent to browser
DEBUG - 2014-08-20 16:23:34 --> Total execution time: 0.3389
DEBUG - 2014-08-20 16:23:34 --> Config Class Initialized
DEBUG - 2014-08-20 16:23:34 --> Hooks Class Initialized
DEBUG - 2014-08-20 16:23:34 --> Utf8 Class Initialized
DEBUG - 2014-08-20 16:23:34 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 16:23:34 --> URI Class Initialized
DEBUG - 2014-08-20 16:23:34 --> Router Class Initialized
DEBUG - 2014-08-20 16:23:34 --> No URI present. Default controller set.
DEBUG - 2014-08-20 16:23:34 --> Output Class Initialized
DEBUG - 2014-08-20 16:23:34 --> Security Class Initialized
DEBUG - 2014-08-20 16:23:34 --> Input Class Initialized
DEBUG - 2014-08-20 16:23:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:34 --> XSS Filtering completed
DEBUG - 2014-08-20 16:23:34 --> CRSF cookie Set
DEBUG - 2014-08-20 16:23:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 16:23:34 --> Language Class Initialized
DEBUG - 2014-08-20 16:23:34 --> Loader Class Initialized
DEBUG - 2014-08-20 16:23:34 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 16:23:34 --> Helper loaded: url_helper
DEBUG - 2014-08-20 16:23:34 --> Database Driver Class Initialized
ERROR - 2014-08-20 16:23:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 16:23:34 --> Session Class Initialized
DEBUG - 2014-08-20 16:23:34 --> Helper loaded: string_helper
DEBUG - 2014-08-20 16:23:34 --> Session routines successfully run
DEBUG - 2014-08-20 16:23:34 --> Controller Class Initialized
DEBUG - 2014-08-20 16:23:34 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 16:23:34 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 16:23:34 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 16:23:34 --> Helper loaded: form_helper
DEBUG - 2014-08-20 16:23:34 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 16:23:34 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-20 16:23:34 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 16:23:34 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 16:23:34 --> Final output sent to browser
DEBUG - 2014-08-20 16:23:34 --> Total execution time: 0.1185
DEBUG - 2014-08-20 16:25:38 --> Config Class Initialized
DEBUG - 2014-08-20 16:25:38 --> Hooks Class Initialized
DEBUG - 2014-08-20 16:25:38 --> Utf8 Class Initialized
DEBUG - 2014-08-20 16:25:38 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 16:25:38 --> URI Class Initialized
DEBUG - 2014-08-20 16:25:38 --> Router Class Initialized
DEBUG - 2014-08-20 16:25:38 --> No URI present. Default controller set.
DEBUG - 2014-08-20 16:25:38 --> Output Class Initialized
DEBUG - 2014-08-20 16:25:38 --> Security Class Initialized
DEBUG - 2014-08-20 16:25:38 --> Input Class Initialized
DEBUG - 2014-08-20 16:25:38 --> XSS Filtering completed
DEBUG - 2014-08-20 16:25:38 --> XSS Filtering completed
DEBUG - 2014-08-20 16:25:38 --> XSS Filtering completed
DEBUG - 2014-08-20 16:25:38 --> XSS Filtering completed
DEBUG - 2014-08-20 16:25:38 --> XSS Filtering completed
DEBUG - 2014-08-20 16:25:38 --> XSS Filtering completed
DEBUG - 2014-08-20 16:25:38 --> CRSF cookie Set
DEBUG - 2014-08-20 16:25:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 16:25:38 --> Language Class Initialized
DEBUG - 2014-08-20 16:25:38 --> Loader Class Initialized
DEBUG - 2014-08-20 16:25:38 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 16:25:38 --> Helper loaded: url_helper
DEBUG - 2014-08-20 16:25:38 --> Database Driver Class Initialized
ERROR - 2014-08-20 16:25:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 16:25:38 --> Session Class Initialized
DEBUG - 2014-08-20 16:25:38 --> Helper loaded: string_helper
DEBUG - 2014-08-20 16:25:38 --> Session routines successfully run
DEBUG - 2014-08-20 16:25:38 --> Controller Class Initialized
DEBUG - 2014-08-20 16:25:38 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 16:25:38 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 16:25:38 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 16:25:38 --> Helper loaded: form_helper
DEBUG - 2014-08-20 16:25:38 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 16:25:38 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-20 16:25:38 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 16:25:38 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 16:25:38 --> Final output sent to browser
DEBUG - 2014-08-20 16:25:38 --> Total execution time: 0.0989
DEBUG - 2014-08-20 16:25:53 --> Config Class Initialized
DEBUG - 2014-08-20 16:25:53 --> Hooks Class Initialized
DEBUG - 2014-08-20 16:25:53 --> Utf8 Class Initialized
DEBUG - 2014-08-20 16:25:53 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 16:25:53 --> URI Class Initialized
DEBUG - 2014-08-20 16:25:53 --> Router Class Initialized
DEBUG - 2014-08-20 16:25:53 --> Output Class Initialized
DEBUG - 2014-08-20 16:25:53 --> Security Class Initialized
DEBUG - 2014-08-20 16:25:53 --> Input Class Initialized
DEBUG - 2014-08-20 16:25:53 --> XSS Filtering completed
DEBUG - 2014-08-20 16:25:53 --> XSS Filtering completed
DEBUG - 2014-08-20 16:25:53 --> XSS Filtering completed
DEBUG - 2014-08-20 16:25:53 --> XSS Filtering completed
DEBUG - 2014-08-20 16:25:53 --> XSS Filtering completed
DEBUG - 2014-08-20 16:25:53 --> XSS Filtering completed
DEBUG - 2014-08-20 16:25:53 --> CRSF cookie Set
DEBUG - 2014-08-20 16:25:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 16:25:53 --> Language Class Initialized
DEBUG - 2014-08-20 16:25:53 --> Loader Class Initialized
DEBUG - 2014-08-20 16:25:53 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 16:25:53 --> Helper loaded: url_helper
DEBUG - 2014-08-20 16:25:53 --> Database Driver Class Initialized
ERROR - 2014-08-20 16:25:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 16:25:53 --> Session Class Initialized
DEBUG - 2014-08-20 16:25:53 --> Helper loaded: string_helper
DEBUG - 2014-08-20 16:25:53 --> Session routines successfully run
DEBUG - 2014-08-20 16:25:53 --> Controller Class Initialized
DEBUG - 2014-08-20 16:25:53 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 16:25:53 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 16:25:53 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-20 16:25:53 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 16:25:53 --> Helper loaded: form_helper
DEBUG - 2014-08-20 16:25:53 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 16:25:53 --> File loaded: application/views/placement_history.php
DEBUG - 2014-08-20 16:25:53 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 16:25:53 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 16:25:53 --> Final output sent to browser
DEBUG - 2014-08-20 16:25:53 --> Total execution time: 0.1281
DEBUG - 2014-08-20 16:26:24 --> Config Class Initialized
DEBUG - 2014-08-20 16:26:24 --> Hooks Class Initialized
DEBUG - 2014-08-20 16:26:24 --> Utf8 Class Initialized
DEBUG - 2014-08-20 16:26:24 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 16:26:24 --> URI Class Initialized
DEBUG - 2014-08-20 16:26:24 --> Router Class Initialized
DEBUG - 2014-08-20 16:26:24 --> Output Class Initialized
DEBUG - 2014-08-20 16:26:24 --> Security Class Initialized
DEBUG - 2014-08-20 16:26:24 --> Input Class Initialized
DEBUG - 2014-08-20 16:26:24 --> XSS Filtering completed
DEBUG - 2014-08-20 16:26:24 --> XSS Filtering completed
DEBUG - 2014-08-20 16:26:24 --> XSS Filtering completed
DEBUG - 2014-08-20 16:26:24 --> XSS Filtering completed
DEBUG - 2014-08-20 16:26:24 --> XSS Filtering completed
DEBUG - 2014-08-20 16:26:24 --> XSS Filtering completed
DEBUG - 2014-08-20 16:26:24 --> CRSF cookie Set
DEBUG - 2014-08-20 16:26:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 16:26:24 --> Language Class Initialized
DEBUG - 2014-08-20 16:26:24 --> Loader Class Initialized
DEBUG - 2014-08-20 16:26:24 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 16:26:24 --> Helper loaded: url_helper
DEBUG - 2014-08-20 16:26:24 --> Database Driver Class Initialized
ERROR - 2014-08-20 16:26:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 16:26:24 --> Session Class Initialized
DEBUG - 2014-08-20 16:26:24 --> Helper loaded: string_helper
DEBUG - 2014-08-20 16:26:24 --> Session routines successfully run
DEBUG - 2014-08-20 16:26:24 --> Controller Class Initialized
DEBUG - 2014-08-20 16:26:24 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 16:26:24 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 16:26:24 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-20 16:26:24 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 16:26:24 --> Helper loaded: form_helper
DEBUG - 2014-08-20 16:26:24 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 16:26:24 --> File loaded: application/views/placement_history.php
DEBUG - 2014-08-20 16:26:24 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 16:26:24 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 16:26:24 --> Final output sent to browser
DEBUG - 2014-08-20 16:26:24 --> Total execution time: 0.1064
DEBUG - 2014-08-20 16:27:01 --> Config Class Initialized
DEBUG - 2014-08-20 16:27:01 --> Hooks Class Initialized
DEBUG - 2014-08-20 16:27:01 --> Utf8 Class Initialized
DEBUG - 2014-08-20 16:27:01 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 16:27:01 --> URI Class Initialized
DEBUG - 2014-08-20 16:27:01 --> Router Class Initialized
DEBUG - 2014-08-20 16:27:01 --> Output Class Initialized
DEBUG - 2014-08-20 16:27:01 --> Security Class Initialized
DEBUG - 2014-08-20 16:27:01 --> Input Class Initialized
DEBUG - 2014-08-20 16:27:01 --> XSS Filtering completed
DEBUG - 2014-08-20 16:27:01 --> XSS Filtering completed
DEBUG - 2014-08-20 16:27:01 --> XSS Filtering completed
DEBUG - 2014-08-20 16:27:01 --> XSS Filtering completed
DEBUG - 2014-08-20 16:27:01 --> XSS Filtering completed
DEBUG - 2014-08-20 16:27:01 --> XSS Filtering completed
DEBUG - 2014-08-20 16:27:01 --> CRSF cookie Set
DEBUG - 2014-08-20 16:27:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 16:27:01 --> Language Class Initialized
DEBUG - 2014-08-20 16:27:01 --> Loader Class Initialized
DEBUG - 2014-08-20 16:27:01 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 16:27:01 --> Helper loaded: url_helper
DEBUG - 2014-08-20 16:27:01 --> Database Driver Class Initialized
ERROR - 2014-08-20 16:27:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 16:27:01 --> Session Class Initialized
DEBUG - 2014-08-20 16:27:01 --> Helper loaded: string_helper
DEBUG - 2014-08-20 16:27:01 --> Session routines successfully run
DEBUG - 2014-08-20 16:27:01 --> Controller Class Initialized
DEBUG - 2014-08-20 16:27:01 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 16:27:01 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 16:27:01 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-20 16:27:01 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 16:27:01 --> Helper loaded: form_helper
DEBUG - 2014-08-20 16:27:01 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 16:27:01 --> File loaded: application/views/placement_history.php
DEBUG - 2014-08-20 16:27:01 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 16:27:01 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 16:27:01 --> Final output sent to browser
DEBUG - 2014-08-20 16:27:01 --> Total execution time: 0.1039
DEBUG - 2014-08-20 16:27:10 --> Config Class Initialized
DEBUG - 2014-08-20 16:27:10 --> Hooks Class Initialized
DEBUG - 2014-08-20 16:27:10 --> Utf8 Class Initialized
DEBUG - 2014-08-20 16:27:10 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 16:27:10 --> URI Class Initialized
DEBUG - 2014-08-20 16:27:10 --> Router Class Initialized
DEBUG - 2014-08-20 16:27:10 --> Output Class Initialized
DEBUG - 2014-08-20 16:27:10 --> Security Class Initialized
DEBUG - 2014-08-20 16:27:10 --> Input Class Initialized
DEBUG - 2014-08-20 16:27:10 --> XSS Filtering completed
DEBUG - 2014-08-20 16:27:10 --> XSS Filtering completed
DEBUG - 2014-08-20 16:27:10 --> XSS Filtering completed
DEBUG - 2014-08-20 16:27:10 --> XSS Filtering completed
DEBUG - 2014-08-20 16:27:10 --> XSS Filtering completed
DEBUG - 2014-08-20 16:27:10 --> XSS Filtering completed
DEBUG - 2014-08-20 16:27:10 --> CRSF cookie Set
DEBUG - 2014-08-20 16:27:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 16:27:10 --> Language Class Initialized
DEBUG - 2014-08-20 16:27:10 --> Loader Class Initialized
DEBUG - 2014-08-20 16:27:10 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 16:27:10 --> Helper loaded: url_helper
DEBUG - 2014-08-20 16:27:10 --> Database Driver Class Initialized
ERROR - 2014-08-20 16:27:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 16:27:10 --> Session Class Initialized
DEBUG - 2014-08-20 16:27:10 --> Helper loaded: string_helper
DEBUG - 2014-08-20 16:27:10 --> Session routines successfully run
DEBUG - 2014-08-20 16:27:10 --> Controller Class Initialized
DEBUG - 2014-08-20 16:27:10 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 16:27:10 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 16:27:10 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-20 16:27:10 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 16:27:10 --> Helper loaded: form_helper
DEBUG - 2014-08-20 16:27:10 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 16:27:10 --> File loaded: application/views/placement_history.php
DEBUG - 2014-08-20 16:27:10 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 16:27:10 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 16:27:10 --> Final output sent to browser
DEBUG - 2014-08-20 16:27:10 --> Total execution time: 0.1018
DEBUG - 2014-08-20 16:27:26 --> Config Class Initialized
DEBUG - 2014-08-20 16:27:26 --> Hooks Class Initialized
DEBUG - 2014-08-20 16:27:26 --> Utf8 Class Initialized
DEBUG - 2014-08-20 16:27:26 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 16:27:26 --> URI Class Initialized
DEBUG - 2014-08-20 16:27:26 --> Router Class Initialized
DEBUG - 2014-08-20 16:27:26 --> No URI present. Default controller set.
DEBUG - 2014-08-20 16:27:26 --> Output Class Initialized
DEBUG - 2014-08-20 16:27:26 --> Security Class Initialized
DEBUG - 2014-08-20 16:27:26 --> Input Class Initialized
DEBUG - 2014-08-20 16:27:26 --> XSS Filtering completed
DEBUG - 2014-08-20 16:27:26 --> XSS Filtering completed
DEBUG - 2014-08-20 16:27:26 --> XSS Filtering completed
DEBUG - 2014-08-20 16:27:26 --> XSS Filtering completed
DEBUG - 2014-08-20 16:27:26 --> XSS Filtering completed
DEBUG - 2014-08-20 16:27:26 --> XSS Filtering completed
DEBUG - 2014-08-20 16:27:26 --> CRSF cookie Set
DEBUG - 2014-08-20 16:27:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 16:27:26 --> Language Class Initialized
DEBUG - 2014-08-20 16:27:26 --> Loader Class Initialized
DEBUG - 2014-08-20 16:27:26 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 16:27:26 --> Helper loaded: url_helper
DEBUG - 2014-08-20 16:27:26 --> Database Driver Class Initialized
ERROR - 2014-08-20 16:27:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 16:27:26 --> Session Class Initialized
DEBUG - 2014-08-20 16:27:26 --> Helper loaded: string_helper
DEBUG - 2014-08-20 16:27:26 --> Session routines successfully run
DEBUG - 2014-08-20 16:27:26 --> Controller Class Initialized
DEBUG - 2014-08-20 16:27:26 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 16:27:26 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 16:27:26 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 16:27:26 --> Helper loaded: form_helper
DEBUG - 2014-08-20 16:27:26 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 16:27:26 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-20 16:27:26 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 16:27:26 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 16:27:26 --> Final output sent to browser
DEBUG - 2014-08-20 16:27:26 --> Total execution time: 0.1220
DEBUG - 2014-08-20 16:27:27 --> Config Class Initialized
DEBUG - 2014-08-20 16:27:27 --> Hooks Class Initialized
DEBUG - 2014-08-20 16:27:27 --> Utf8 Class Initialized
DEBUG - 2014-08-20 16:27:27 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 16:27:27 --> URI Class Initialized
DEBUG - 2014-08-20 16:27:27 --> Router Class Initialized
DEBUG - 2014-08-20 16:27:27 --> No URI present. Default controller set.
DEBUG - 2014-08-20 16:27:27 --> Output Class Initialized
DEBUG - 2014-08-20 16:27:27 --> Security Class Initialized
DEBUG - 2014-08-20 16:27:27 --> Input Class Initialized
DEBUG - 2014-08-20 16:27:27 --> XSS Filtering completed
DEBUG - 2014-08-20 16:27:27 --> XSS Filtering completed
DEBUG - 2014-08-20 16:27:27 --> XSS Filtering completed
DEBUG - 2014-08-20 16:27:27 --> XSS Filtering completed
DEBUG - 2014-08-20 16:27:27 --> XSS Filtering completed
DEBUG - 2014-08-20 16:27:27 --> XSS Filtering completed
DEBUG - 2014-08-20 16:27:27 --> CRSF cookie Set
DEBUG - 2014-08-20 16:27:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 16:27:27 --> Language Class Initialized
DEBUG - 2014-08-20 16:27:28 --> Loader Class Initialized
DEBUG - 2014-08-20 16:27:28 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 16:27:28 --> Helper loaded: url_helper
DEBUG - 2014-08-20 16:27:28 --> Database Driver Class Initialized
ERROR - 2014-08-20 16:27:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 16:27:28 --> Session Class Initialized
DEBUG - 2014-08-20 16:27:28 --> Helper loaded: string_helper
DEBUG - 2014-08-20 16:27:28 --> Session routines successfully run
DEBUG - 2014-08-20 16:27:28 --> Controller Class Initialized
DEBUG - 2014-08-20 16:27:28 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 16:27:28 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 16:27:28 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 16:27:28 --> Helper loaded: form_helper
DEBUG - 2014-08-20 16:27:28 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 16:27:28 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-20 16:27:28 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 16:27:28 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 16:27:28 --> Final output sent to browser
DEBUG - 2014-08-20 16:27:28 --> Total execution time: 0.1122
DEBUG - 2014-08-20 16:31:16 --> Config Class Initialized
DEBUG - 2014-08-20 16:31:16 --> Hooks Class Initialized
DEBUG - 2014-08-20 16:31:16 --> Utf8 Class Initialized
DEBUG - 2014-08-20 16:31:16 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 16:31:16 --> URI Class Initialized
DEBUG - 2014-08-20 16:31:16 --> Router Class Initialized
DEBUG - 2014-08-20 16:31:16 --> No URI present. Default controller set.
DEBUG - 2014-08-20 16:31:16 --> Output Class Initialized
DEBUG - 2014-08-20 16:31:16 --> Security Class Initialized
DEBUG - 2014-08-20 16:31:16 --> Input Class Initialized
DEBUG - 2014-08-20 16:31:16 --> XSS Filtering completed
DEBUG - 2014-08-20 16:31:16 --> XSS Filtering completed
DEBUG - 2014-08-20 16:31:16 --> XSS Filtering completed
DEBUG - 2014-08-20 16:31:16 --> XSS Filtering completed
DEBUG - 2014-08-20 16:31:16 --> XSS Filtering completed
DEBUG - 2014-08-20 16:31:16 --> XSS Filtering completed
DEBUG - 2014-08-20 16:31:16 --> CRSF cookie Set
DEBUG - 2014-08-20 16:31:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 16:31:16 --> Language Class Initialized
DEBUG - 2014-08-20 16:31:16 --> Loader Class Initialized
DEBUG - 2014-08-20 16:31:16 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 16:31:16 --> Helper loaded: url_helper
DEBUG - 2014-08-20 16:31:16 --> Database Driver Class Initialized
ERROR - 2014-08-20 16:31:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 16:31:16 --> Session Class Initialized
DEBUG - 2014-08-20 16:31:16 --> Helper loaded: string_helper
DEBUG - 2014-08-20 16:31:16 --> Session routines successfully run
DEBUG - 2014-08-20 16:31:16 --> Controller Class Initialized
DEBUG - 2014-08-20 16:31:16 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 16:31:16 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 16:31:16 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 16:31:16 --> Helper loaded: form_helper
DEBUG - 2014-08-20 16:31:16 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 16:31:16 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-20 16:31:16 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 16:31:16 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 16:31:16 --> Final output sent to browser
DEBUG - 2014-08-20 16:31:16 --> Total execution time: 0.1140
DEBUG - 2014-08-20 16:32:20 --> Config Class Initialized
DEBUG - 2014-08-20 16:32:20 --> Hooks Class Initialized
DEBUG - 2014-08-20 16:32:20 --> Utf8 Class Initialized
DEBUG - 2014-08-20 16:32:20 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 16:32:20 --> URI Class Initialized
DEBUG - 2014-08-20 16:32:20 --> Router Class Initialized
DEBUG - 2014-08-20 16:32:20 --> No URI present. Default controller set.
DEBUG - 2014-08-20 16:32:20 --> Output Class Initialized
DEBUG - 2014-08-20 16:32:20 --> Security Class Initialized
DEBUG - 2014-08-20 16:32:20 --> Input Class Initialized
DEBUG - 2014-08-20 16:32:20 --> XSS Filtering completed
DEBUG - 2014-08-20 16:32:20 --> XSS Filtering completed
DEBUG - 2014-08-20 16:32:20 --> XSS Filtering completed
DEBUG - 2014-08-20 16:32:20 --> XSS Filtering completed
DEBUG - 2014-08-20 16:32:20 --> XSS Filtering completed
DEBUG - 2014-08-20 16:32:20 --> XSS Filtering completed
DEBUG - 2014-08-20 16:32:20 --> CRSF cookie Set
DEBUG - 2014-08-20 16:32:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 16:32:20 --> Language Class Initialized
DEBUG - 2014-08-20 16:32:20 --> Loader Class Initialized
DEBUG - 2014-08-20 16:32:20 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 16:32:20 --> Helper loaded: url_helper
DEBUG - 2014-08-20 16:32:20 --> Database Driver Class Initialized
ERROR - 2014-08-20 16:32:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 16:32:20 --> Session Class Initialized
DEBUG - 2014-08-20 16:32:20 --> Helper loaded: string_helper
DEBUG - 2014-08-20 16:32:20 --> Session routines successfully run
DEBUG - 2014-08-20 16:32:20 --> Controller Class Initialized
DEBUG - 2014-08-20 16:32:20 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 16:32:20 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 16:32:20 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 16:32:20 --> Helper loaded: form_helper
DEBUG - 2014-08-20 16:32:20 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 16:32:20 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-20 16:32:20 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 16:32:20 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 16:32:20 --> Final output sent to browser
DEBUG - 2014-08-20 16:32:20 --> Total execution time: 0.1135
DEBUG - 2014-08-20 16:32:29 --> Config Class Initialized
DEBUG - 2014-08-20 16:32:29 --> Hooks Class Initialized
DEBUG - 2014-08-20 16:32:29 --> Utf8 Class Initialized
DEBUG - 2014-08-20 16:32:29 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 16:32:29 --> URI Class Initialized
DEBUG - 2014-08-20 16:32:29 --> Router Class Initialized
DEBUG - 2014-08-20 16:32:29 --> No URI present. Default controller set.
DEBUG - 2014-08-20 16:32:29 --> Output Class Initialized
DEBUG - 2014-08-20 16:32:29 --> Security Class Initialized
DEBUG - 2014-08-20 16:32:29 --> Input Class Initialized
DEBUG - 2014-08-20 16:32:29 --> XSS Filtering completed
DEBUG - 2014-08-20 16:32:29 --> XSS Filtering completed
DEBUG - 2014-08-20 16:32:29 --> XSS Filtering completed
DEBUG - 2014-08-20 16:32:29 --> XSS Filtering completed
DEBUG - 2014-08-20 16:32:29 --> XSS Filtering completed
DEBUG - 2014-08-20 16:32:29 --> XSS Filtering completed
DEBUG - 2014-08-20 16:32:29 --> CRSF cookie Set
DEBUG - 2014-08-20 16:32:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 16:32:29 --> Language Class Initialized
DEBUG - 2014-08-20 16:32:29 --> Loader Class Initialized
DEBUG - 2014-08-20 16:32:29 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 16:32:29 --> Helper loaded: url_helper
DEBUG - 2014-08-20 16:32:29 --> Database Driver Class Initialized
ERROR - 2014-08-20 16:32:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 16:32:29 --> Session Class Initialized
DEBUG - 2014-08-20 16:32:29 --> Helper loaded: string_helper
DEBUG - 2014-08-20 16:32:29 --> Session routines successfully run
DEBUG - 2014-08-20 16:32:29 --> Controller Class Initialized
DEBUG - 2014-08-20 16:32:29 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 16:32:29 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 16:32:29 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 16:32:29 --> Helper loaded: form_helper
DEBUG - 2014-08-20 16:32:29 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 16:32:29 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-20 16:32:29 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 16:32:29 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 16:32:29 --> Final output sent to browser
DEBUG - 2014-08-20 16:32:29 --> Total execution time: 0.1144
DEBUG - 2014-08-20 17:30:09 --> Config Class Initialized
DEBUG - 2014-08-20 17:30:09 --> Hooks Class Initialized
DEBUG - 2014-08-20 17:30:09 --> Utf8 Class Initialized
DEBUG - 2014-08-20 17:30:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 17:30:09 --> URI Class Initialized
DEBUG - 2014-08-20 17:30:09 --> Router Class Initialized
DEBUG - 2014-08-20 17:30:09 --> Output Class Initialized
DEBUG - 2014-08-20 17:30:09 --> Security Class Initialized
DEBUG - 2014-08-20 17:30:09 --> Input Class Initialized
DEBUG - 2014-08-20 17:30:09 --> XSS Filtering completed
DEBUG - 2014-08-20 17:30:09 --> XSS Filtering completed
DEBUG - 2014-08-20 17:30:09 --> XSS Filtering completed
DEBUG - 2014-08-20 17:30:09 --> XSS Filtering completed
DEBUG - 2014-08-20 17:30:09 --> XSS Filtering completed
DEBUG - 2014-08-20 17:30:09 --> CRSF cookie Set
DEBUG - 2014-08-20 17:30:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 17:30:09 --> Language Class Initialized
DEBUG - 2014-08-20 17:30:09 --> Loader Class Initialized
DEBUG - 2014-08-20 17:30:09 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 17:30:09 --> Helper loaded: url_helper
DEBUG - 2014-08-20 17:30:09 --> Database Driver Class Initialized
ERROR - 2014-08-20 17:30:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 17:30:09 --> Session Class Initialized
DEBUG - 2014-08-20 17:30:09 --> Helper loaded: string_helper
DEBUG - 2014-08-20 17:30:09 --> Session routines successfully run
DEBUG - 2014-08-20 17:30:09 --> Controller Class Initialized
DEBUG - 2014-08-20 17:30:09 --> Final output sent to browser
DEBUG - 2014-08-20 17:30:09 --> Total execution time: 0.0884
DEBUG - 2014-08-20 17:31:02 --> Config Class Initialized
DEBUG - 2014-08-20 17:31:02 --> Hooks Class Initialized
DEBUG - 2014-08-20 17:31:02 --> Utf8 Class Initialized
DEBUG - 2014-08-20 17:31:02 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 17:31:02 --> URI Class Initialized
DEBUG - 2014-08-20 17:31:02 --> Router Class Initialized
DEBUG - 2014-08-20 17:31:02 --> Output Class Initialized
DEBUG - 2014-08-20 17:31:02 --> Security Class Initialized
DEBUG - 2014-08-20 17:31:02 --> Input Class Initialized
DEBUG - 2014-08-20 17:31:02 --> XSS Filtering completed
DEBUG - 2014-08-20 17:31:02 --> XSS Filtering completed
DEBUG - 2014-08-20 17:31:02 --> XSS Filtering completed
DEBUG - 2014-08-20 17:31:02 --> XSS Filtering completed
DEBUG - 2014-08-20 17:31:02 --> XSS Filtering completed
DEBUG - 2014-08-20 17:31:02 --> CRSF cookie Set
DEBUG - 2014-08-20 17:31:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 17:31:02 --> Language Class Initialized
DEBUG - 2014-08-20 17:31:02 --> Loader Class Initialized
DEBUG - 2014-08-20 17:31:02 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 17:31:02 --> Helper loaded: url_helper
DEBUG - 2014-08-20 17:31:02 --> Database Driver Class Initialized
ERROR - 2014-08-20 17:31:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 17:31:02 --> Session Class Initialized
DEBUG - 2014-08-20 17:31:02 --> Helper loaded: string_helper
DEBUG - 2014-08-20 17:31:02 --> Session routines successfully run
DEBUG - 2014-08-20 17:31:02 --> Controller Class Initialized
DEBUG - 2014-08-20 17:31:02 --> Final output sent to browser
DEBUG - 2014-08-20 17:31:02 --> Total execution time: 0.0814
DEBUG - 2014-08-20 17:31:19 --> Config Class Initialized
DEBUG - 2014-08-20 17:31:19 --> Hooks Class Initialized
DEBUG - 2014-08-20 17:31:19 --> Utf8 Class Initialized
DEBUG - 2014-08-20 17:31:19 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 17:31:19 --> URI Class Initialized
DEBUG - 2014-08-20 17:31:19 --> Router Class Initialized
DEBUG - 2014-08-20 17:31:19 --> Output Class Initialized
DEBUG - 2014-08-20 17:31:19 --> Security Class Initialized
DEBUG - 2014-08-20 17:31:19 --> Input Class Initialized
DEBUG - 2014-08-20 17:31:19 --> XSS Filtering completed
DEBUG - 2014-08-20 17:31:19 --> XSS Filtering completed
DEBUG - 2014-08-20 17:31:19 --> XSS Filtering completed
DEBUG - 2014-08-20 17:31:19 --> XSS Filtering completed
DEBUG - 2014-08-20 17:31:19 --> XSS Filtering completed
DEBUG - 2014-08-20 17:31:19 --> CRSF cookie Set
DEBUG - 2014-08-20 17:31:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 17:31:19 --> Language Class Initialized
DEBUG - 2014-08-20 17:31:19 --> Loader Class Initialized
DEBUG - 2014-08-20 17:31:19 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 17:31:19 --> Helper loaded: url_helper
DEBUG - 2014-08-20 17:31:19 --> Database Driver Class Initialized
ERROR - 2014-08-20 17:31:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 17:31:19 --> Session Class Initialized
DEBUG - 2014-08-20 17:31:19 --> Helper loaded: string_helper
DEBUG - 2014-08-20 17:31:19 --> Session routines successfully run
DEBUG - 2014-08-20 17:31:19 --> Controller Class Initialized
DEBUG - 2014-08-20 17:31:19 --> Final output sent to browser
DEBUG - 2014-08-20 17:31:19 --> Total execution time: 0.0862
DEBUG - 2014-08-20 17:31:31 --> Config Class Initialized
DEBUG - 2014-08-20 17:31:31 --> Hooks Class Initialized
DEBUG - 2014-08-20 17:31:31 --> Utf8 Class Initialized
DEBUG - 2014-08-20 17:31:31 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 17:31:31 --> URI Class Initialized
DEBUG - 2014-08-20 17:31:31 --> Router Class Initialized
DEBUG - 2014-08-20 17:31:31 --> Output Class Initialized
DEBUG - 2014-08-20 17:31:31 --> Security Class Initialized
DEBUG - 2014-08-20 17:31:31 --> Input Class Initialized
DEBUG - 2014-08-20 17:31:31 --> XSS Filtering completed
DEBUG - 2014-08-20 17:31:31 --> XSS Filtering completed
DEBUG - 2014-08-20 17:31:31 --> XSS Filtering completed
DEBUG - 2014-08-20 17:31:31 --> XSS Filtering completed
DEBUG - 2014-08-20 17:31:31 --> XSS Filtering completed
DEBUG - 2014-08-20 17:31:31 --> CRSF cookie Set
DEBUG - 2014-08-20 17:31:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 17:31:31 --> Language Class Initialized
DEBUG - 2014-08-20 17:31:31 --> Loader Class Initialized
DEBUG - 2014-08-20 17:31:31 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 17:31:31 --> Helper loaded: url_helper
DEBUG - 2014-08-20 17:31:31 --> Database Driver Class Initialized
ERROR - 2014-08-20 17:31:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 17:31:31 --> Session Class Initialized
DEBUG - 2014-08-20 17:31:31 --> Helper loaded: string_helper
DEBUG - 2014-08-20 17:31:31 --> Session routines successfully run
DEBUG - 2014-08-20 17:31:31 --> Controller Class Initialized
DEBUG - 2014-08-20 17:31:31 --> Final output sent to browser
DEBUG - 2014-08-20 17:31:31 --> Total execution time: 0.0803
DEBUG - 2014-08-20 17:31:56 --> Config Class Initialized
DEBUG - 2014-08-20 17:31:56 --> Hooks Class Initialized
DEBUG - 2014-08-20 17:31:56 --> Utf8 Class Initialized
DEBUG - 2014-08-20 17:31:56 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 17:31:56 --> URI Class Initialized
DEBUG - 2014-08-20 17:31:56 --> Router Class Initialized
DEBUG - 2014-08-20 17:31:56 --> Output Class Initialized
DEBUG - 2014-08-20 17:31:56 --> Security Class Initialized
DEBUG - 2014-08-20 17:31:56 --> Input Class Initialized
DEBUG - 2014-08-20 17:31:56 --> XSS Filtering completed
DEBUG - 2014-08-20 17:31:56 --> XSS Filtering completed
DEBUG - 2014-08-20 17:31:56 --> XSS Filtering completed
DEBUG - 2014-08-20 17:31:56 --> XSS Filtering completed
DEBUG - 2014-08-20 17:31:56 --> XSS Filtering completed
DEBUG - 2014-08-20 17:31:56 --> CRSF cookie Set
DEBUG - 2014-08-20 17:31:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 17:31:56 --> Language Class Initialized
DEBUG - 2014-08-20 17:31:56 --> Loader Class Initialized
DEBUG - 2014-08-20 17:31:56 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 17:31:56 --> Helper loaded: url_helper
DEBUG - 2014-08-20 17:31:56 --> Database Driver Class Initialized
ERROR - 2014-08-20 17:31:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 17:31:56 --> Session Class Initialized
DEBUG - 2014-08-20 17:31:56 --> Helper loaded: string_helper
DEBUG - 2014-08-20 17:31:56 --> Session routines successfully run
DEBUG - 2014-08-20 17:31:56 --> Controller Class Initialized
DEBUG - 2014-08-20 17:31:56 --> Final output sent to browser
DEBUG - 2014-08-20 17:31:56 --> Total execution time: 0.0798
DEBUG - 2014-08-20 17:32:12 --> Config Class Initialized
DEBUG - 2014-08-20 17:32:12 --> Hooks Class Initialized
DEBUG - 2014-08-20 17:32:12 --> Utf8 Class Initialized
DEBUG - 2014-08-20 17:32:12 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 17:32:12 --> URI Class Initialized
DEBUG - 2014-08-20 17:32:12 --> Router Class Initialized
DEBUG - 2014-08-20 17:32:12 --> Output Class Initialized
DEBUG - 2014-08-20 17:32:12 --> Security Class Initialized
DEBUG - 2014-08-20 17:32:12 --> Input Class Initialized
DEBUG - 2014-08-20 17:32:12 --> XSS Filtering completed
DEBUG - 2014-08-20 17:32:12 --> XSS Filtering completed
DEBUG - 2014-08-20 17:32:12 --> XSS Filtering completed
DEBUG - 2014-08-20 17:32:12 --> XSS Filtering completed
DEBUG - 2014-08-20 17:32:12 --> XSS Filtering completed
DEBUG - 2014-08-20 17:32:12 --> CRSF cookie Set
DEBUG - 2014-08-20 17:32:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 17:32:12 --> Language Class Initialized
DEBUG - 2014-08-20 17:32:12 --> Loader Class Initialized
DEBUG - 2014-08-20 17:32:12 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 17:32:12 --> Helper loaded: url_helper
DEBUG - 2014-08-20 17:32:12 --> Database Driver Class Initialized
ERROR - 2014-08-20 17:32:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 17:32:12 --> Session Class Initialized
DEBUG - 2014-08-20 17:32:12 --> Helper loaded: string_helper
DEBUG - 2014-08-20 17:32:12 --> Session routines successfully run
DEBUG - 2014-08-20 17:32:12 --> Controller Class Initialized
DEBUG - 2014-08-20 17:32:12 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 17:32:12 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 17:32:12 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 17:32:12 --> Helper loaded: form_helper
DEBUG - 2014-08-20 17:32:12 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 17:32:12 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-20 17:32:12 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 17:32:12 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 17:32:12 --> Final output sent to browser
DEBUG - 2014-08-20 17:32:12 --> Total execution time: 0.1111
DEBUG - 2014-08-20 17:34:39 --> Config Class Initialized
DEBUG - 2014-08-20 17:34:39 --> Hooks Class Initialized
DEBUG - 2014-08-20 17:34:39 --> Utf8 Class Initialized
DEBUG - 2014-08-20 17:34:39 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 17:34:39 --> URI Class Initialized
DEBUG - 2014-08-20 17:34:39 --> Router Class Initialized
DEBUG - 2014-08-20 17:34:39 --> Output Class Initialized
DEBUG - 2014-08-20 17:34:39 --> Security Class Initialized
DEBUG - 2014-08-20 17:34:39 --> Input Class Initialized
DEBUG - 2014-08-20 17:34:39 --> CRSF cookie Set
DEBUG - 2014-08-20 17:34:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 17:34:39 --> Language Class Initialized
DEBUG - 2014-08-20 17:34:39 --> Loader Class Initialized
DEBUG - 2014-08-20 17:34:39 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 17:34:39 --> Helper loaded: url_helper
DEBUG - 2014-08-20 17:34:39 --> Database Driver Class Initialized
ERROR - 2014-08-20 17:34:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 17:34:39 --> Session Class Initialized
DEBUG - 2014-08-20 17:34:39 --> Helper loaded: string_helper
DEBUG - 2014-08-20 17:34:39 --> A session cookie was not found.
DEBUG - 2014-08-20 17:34:39 --> Session routines successfully run
DEBUG - 2014-08-20 17:34:39 --> Controller Class Initialized
DEBUG - 2014-08-20 17:34:39 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 17:34:39 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 17:34:39 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 17:34:39 --> Helper loaded: form_helper
DEBUG - 2014-08-20 17:34:39 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 17:34:39 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-20 17:34:39 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 17:34:39 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 17:34:39 --> Final output sent to browser
DEBUG - 2014-08-20 17:34:39 --> Total execution time: 0.0947
DEBUG - 2014-08-20 17:35:48 --> Config Class Initialized
DEBUG - 2014-08-20 17:35:48 --> Hooks Class Initialized
DEBUG - 2014-08-20 17:35:48 --> Utf8 Class Initialized
DEBUG - 2014-08-20 17:35:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 17:35:48 --> URI Class Initialized
DEBUG - 2014-08-20 17:35:48 --> Router Class Initialized
DEBUG - 2014-08-20 17:35:48 --> Output Class Initialized
DEBUG - 2014-08-20 17:35:48 --> Security Class Initialized
DEBUG - 2014-08-20 17:35:48 --> Input Class Initialized
DEBUG - 2014-08-20 17:35:48 --> XSS Filtering completed
DEBUG - 2014-08-20 17:35:48 --> XSS Filtering completed
DEBUG - 2014-08-20 17:35:48 --> CRSF cookie Set
DEBUG - 2014-08-20 17:35:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 17:35:48 --> Language Class Initialized
DEBUG - 2014-08-20 17:35:48 --> Loader Class Initialized
DEBUG - 2014-08-20 17:35:48 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 17:35:48 --> Helper loaded: url_helper
DEBUG - 2014-08-20 17:35:48 --> Database Driver Class Initialized
ERROR - 2014-08-20 17:35:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 17:35:48 --> Session Class Initialized
DEBUG - 2014-08-20 17:35:48 --> Helper loaded: string_helper
DEBUG - 2014-08-20 17:35:48 --> Session routines successfully run
DEBUG - 2014-08-20 17:35:48 --> Controller Class Initialized
DEBUG - 2014-08-20 17:35:48 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 17:35:48 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 17:35:48 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 17:35:48 --> Helper loaded: form_helper
DEBUG - 2014-08-20 17:35:48 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 17:35:48 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-20 17:35:48 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 17:35:48 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 17:35:48 --> Final output sent to browser
DEBUG - 2014-08-20 17:35:48 --> Total execution time: 0.0914
DEBUG - 2014-08-20 17:36:02 --> Config Class Initialized
DEBUG - 2014-08-20 17:36:02 --> Hooks Class Initialized
DEBUG - 2014-08-20 17:36:02 --> Utf8 Class Initialized
DEBUG - 2014-08-20 17:36:02 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 17:36:02 --> URI Class Initialized
DEBUG - 2014-08-20 17:36:02 --> Router Class Initialized
DEBUG - 2014-08-20 17:36:02 --> Output Class Initialized
DEBUG - 2014-08-20 17:36:02 --> Security Class Initialized
DEBUG - 2014-08-20 17:36:02 --> Input Class Initialized
DEBUG - 2014-08-20 17:36:02 --> XSS Filtering completed
DEBUG - 2014-08-20 17:36:02 --> XSS Filtering completed
DEBUG - 2014-08-20 17:36:02 --> XSS Filtering completed
DEBUG - 2014-08-20 17:36:02 --> XSS Filtering completed
DEBUG - 2014-08-20 17:36:02 --> XSS Filtering completed
DEBUG - 2014-08-20 17:36:02 --> CRSF cookie Set
DEBUG - 2014-08-20 17:36:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 17:36:02 --> Language Class Initialized
DEBUG - 2014-08-20 17:36:02 --> Loader Class Initialized
DEBUG - 2014-08-20 17:36:02 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 17:36:03 --> Helper loaded: url_helper
DEBUG - 2014-08-20 17:36:03 --> Database Driver Class Initialized
ERROR - 2014-08-20 17:36:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 17:36:03 --> Session Class Initialized
DEBUG - 2014-08-20 17:36:03 --> Helper loaded: string_helper
DEBUG - 2014-08-20 17:36:03 --> Session routines successfully run
DEBUG - 2014-08-20 17:36:03 --> Controller Class Initialized
DEBUG - 2014-08-20 17:36:03 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 17:36:03 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 17:36:03 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 17:36:03 --> Helper loaded: form_helper
DEBUG - 2014-08-20 17:36:03 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 17:36:03 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-20 17:36:03 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 17:36:03 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 17:36:03 --> Final output sent to browser
DEBUG - 2014-08-20 17:36:03 --> Total execution time: 0.1087
DEBUG - 2014-08-20 17:36:34 --> Config Class Initialized
DEBUG - 2014-08-20 17:36:34 --> Hooks Class Initialized
DEBUG - 2014-08-20 17:36:34 --> Utf8 Class Initialized
DEBUG - 2014-08-20 17:36:34 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 17:36:34 --> URI Class Initialized
DEBUG - 2014-08-20 17:36:34 --> Router Class Initialized
DEBUG - 2014-08-20 17:36:34 --> Output Class Initialized
DEBUG - 2014-08-20 17:36:34 --> Security Class Initialized
DEBUG - 2014-08-20 17:36:34 --> Input Class Initialized
DEBUG - 2014-08-20 17:36:34 --> XSS Filtering completed
DEBUG - 2014-08-20 17:36:34 --> XSS Filtering completed
DEBUG - 2014-08-20 17:36:34 --> XSS Filtering completed
DEBUG - 2014-08-20 17:36:34 --> XSS Filtering completed
DEBUG - 2014-08-20 17:36:34 --> XSS Filtering completed
DEBUG - 2014-08-20 17:36:34 --> CRSF cookie Set
DEBUG - 2014-08-20 17:36:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 17:36:34 --> Language Class Initialized
DEBUG - 2014-08-20 17:36:34 --> Loader Class Initialized
DEBUG - 2014-08-20 17:36:34 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 17:36:34 --> Helper loaded: url_helper
DEBUG - 2014-08-20 17:36:34 --> Database Driver Class Initialized
ERROR - 2014-08-20 17:36:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 17:36:34 --> Session Class Initialized
DEBUG - 2014-08-20 17:36:34 --> Helper loaded: string_helper
DEBUG - 2014-08-20 17:36:34 --> Session routines successfully run
DEBUG - 2014-08-20 17:36:34 --> Controller Class Initialized
ERROR - 2014-08-20 17:36:34 --> 404 Page Not Found --> placement/history
DEBUG - 2014-08-20 17:36:43 --> Config Class Initialized
DEBUG - 2014-08-20 17:36:43 --> Hooks Class Initialized
DEBUG - 2014-08-20 17:36:43 --> Utf8 Class Initialized
DEBUG - 2014-08-20 17:36:43 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 17:36:43 --> URI Class Initialized
DEBUG - 2014-08-20 17:36:43 --> Router Class Initialized
DEBUG - 2014-08-20 17:36:43 --> Output Class Initialized
DEBUG - 2014-08-20 17:36:43 --> Security Class Initialized
DEBUG - 2014-08-20 17:36:43 --> Input Class Initialized
DEBUG - 2014-08-20 17:36:43 --> XSS Filtering completed
DEBUG - 2014-08-20 17:36:43 --> XSS Filtering completed
DEBUG - 2014-08-20 17:36:43 --> XSS Filtering completed
DEBUG - 2014-08-20 17:36:43 --> XSS Filtering completed
DEBUG - 2014-08-20 17:36:43 --> XSS Filtering completed
DEBUG - 2014-08-20 17:36:43 --> CRSF cookie Set
DEBUG - 2014-08-20 17:36:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 17:36:43 --> Language Class Initialized
DEBUG - 2014-08-20 17:36:43 --> Loader Class Initialized
DEBUG - 2014-08-20 17:36:43 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 17:36:43 --> Helper loaded: url_helper
DEBUG - 2014-08-20 17:36:43 --> Database Driver Class Initialized
ERROR - 2014-08-20 17:36:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 17:36:43 --> Session Class Initialized
DEBUG - 2014-08-20 17:36:43 --> Helper loaded: string_helper
DEBUG - 2014-08-20 17:36:43 --> Session routines successfully run
DEBUG - 2014-08-20 17:36:43 --> Controller Class Initialized
ERROR - 2014-08-20 17:36:43 --> 404 Page Not Found --> placement/history
DEBUG - 2014-08-20 17:36:50 --> Config Class Initialized
DEBUG - 2014-08-20 17:36:50 --> Hooks Class Initialized
DEBUG - 2014-08-20 17:36:50 --> Utf8 Class Initialized
DEBUG - 2014-08-20 17:36:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 17:36:50 --> URI Class Initialized
DEBUG - 2014-08-20 17:36:50 --> Router Class Initialized
DEBUG - 2014-08-20 17:36:50 --> Output Class Initialized
DEBUG - 2014-08-20 17:36:50 --> Security Class Initialized
DEBUG - 2014-08-20 17:36:50 --> Input Class Initialized
DEBUG - 2014-08-20 17:36:50 --> XSS Filtering completed
DEBUG - 2014-08-20 17:36:50 --> XSS Filtering completed
DEBUG - 2014-08-20 17:36:50 --> XSS Filtering completed
DEBUG - 2014-08-20 17:36:50 --> XSS Filtering completed
DEBUG - 2014-08-20 17:36:50 --> XSS Filtering completed
DEBUG - 2014-08-20 17:36:50 --> CRSF cookie Set
DEBUG - 2014-08-20 17:36:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 17:36:50 --> Language Class Initialized
DEBUG - 2014-08-20 17:36:50 --> Loader Class Initialized
DEBUG - 2014-08-20 17:36:50 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 17:36:50 --> Helper loaded: url_helper
DEBUG - 2014-08-20 17:36:50 --> Database Driver Class Initialized
ERROR - 2014-08-20 17:36:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 17:36:50 --> Session Class Initialized
DEBUG - 2014-08-20 17:36:50 --> Helper loaded: string_helper
DEBUG - 2014-08-20 17:36:50 --> Session routines successfully run
DEBUG - 2014-08-20 17:36:50 --> Controller Class Initialized
ERROR - 2014-08-20 17:36:50 --> 404 Page Not Found --> placement/history
DEBUG - 2014-08-20 17:37:55 --> Config Class Initialized
DEBUG - 2014-08-20 17:37:55 --> Hooks Class Initialized
DEBUG - 2014-08-20 17:37:55 --> Utf8 Class Initialized
DEBUG - 2014-08-20 17:37:55 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 17:37:55 --> URI Class Initialized
DEBUG - 2014-08-20 17:37:55 --> Router Class Initialized
DEBUG - 2014-08-20 17:37:55 --> Output Class Initialized
DEBUG - 2014-08-20 17:37:55 --> Security Class Initialized
DEBUG - 2014-08-20 17:37:55 --> Input Class Initialized
DEBUG - 2014-08-20 17:37:55 --> XSS Filtering completed
DEBUG - 2014-08-20 17:37:55 --> XSS Filtering completed
DEBUG - 2014-08-20 17:37:55 --> XSS Filtering completed
DEBUG - 2014-08-20 17:37:55 --> XSS Filtering completed
DEBUG - 2014-08-20 17:37:55 --> XSS Filtering completed
DEBUG - 2014-08-20 17:37:55 --> CRSF cookie Set
DEBUG - 2014-08-20 17:37:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 17:37:55 --> Language Class Initialized
DEBUG - 2014-08-20 17:37:55 --> Loader Class Initialized
DEBUG - 2014-08-20 17:37:55 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 17:37:55 --> Helper loaded: url_helper
DEBUG - 2014-08-20 17:37:55 --> Database Driver Class Initialized
ERROR - 2014-08-20 17:37:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 17:37:55 --> Session Class Initialized
DEBUG - 2014-08-20 17:37:55 --> Helper loaded: string_helper
DEBUG - 2014-08-20 17:37:55 --> Session routines successfully run
DEBUG - 2014-08-20 17:37:55 --> Controller Class Initialized
DEBUG - 2014-08-20 17:37:55 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 17:37:55 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 17:37:55 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 17:37:55 --> Helper loaded: form_helper
DEBUG - 2014-08-20 17:37:55 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 17:37:55 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-20 17:37:55 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 17:37:55 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 17:37:55 --> Final output sent to browser
DEBUG - 2014-08-20 17:37:55 --> Total execution time: 0.0973
DEBUG - 2014-08-20 17:38:24 --> Config Class Initialized
DEBUG - 2014-08-20 17:38:24 --> Hooks Class Initialized
DEBUG - 2014-08-20 17:38:24 --> Utf8 Class Initialized
DEBUG - 2014-08-20 17:38:24 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 17:38:24 --> URI Class Initialized
DEBUG - 2014-08-20 17:38:24 --> Router Class Initialized
DEBUG - 2014-08-20 17:38:24 --> Output Class Initialized
DEBUG - 2014-08-20 17:38:24 --> Security Class Initialized
DEBUG - 2014-08-20 17:38:24 --> Input Class Initialized
DEBUG - 2014-08-20 17:38:24 --> XSS Filtering completed
DEBUG - 2014-08-20 17:38:24 --> XSS Filtering completed
DEBUG - 2014-08-20 17:38:24 --> XSS Filtering completed
DEBUG - 2014-08-20 17:38:24 --> XSS Filtering completed
DEBUG - 2014-08-20 17:38:24 --> XSS Filtering completed
DEBUG - 2014-08-20 17:38:24 --> CRSF cookie Set
DEBUG - 2014-08-20 17:38:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 17:38:24 --> Language Class Initialized
DEBUG - 2014-08-20 17:38:24 --> Loader Class Initialized
DEBUG - 2014-08-20 17:38:24 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 17:38:24 --> Helper loaded: url_helper
DEBUG - 2014-08-20 17:38:24 --> Database Driver Class Initialized
ERROR - 2014-08-20 17:38:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 17:38:24 --> Session Class Initialized
DEBUG - 2014-08-20 17:38:24 --> Helper loaded: string_helper
DEBUG - 2014-08-20 17:38:24 --> Session routines successfully run
DEBUG - 2014-08-20 17:38:24 --> Controller Class Initialized
DEBUG - 2014-08-20 17:38:24 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 17:38:24 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 17:38:24 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-20 17:38:24 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 17:38:24 --> Helper loaded: form_helper
DEBUG - 2014-08-20 17:38:24 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 17:38:24 --> File loaded: application/views/placement_contact.php
DEBUG - 2014-08-20 17:38:24 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 17:38:24 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 17:38:24 --> Final output sent to browser
DEBUG - 2014-08-20 17:38:24 --> Total execution time: 0.1488
DEBUG - 2014-08-20 17:56:32 --> Config Class Initialized
DEBUG - 2014-08-20 17:56:32 --> Hooks Class Initialized
DEBUG - 2014-08-20 17:56:32 --> Utf8 Class Initialized
DEBUG - 2014-08-20 17:56:32 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 17:56:32 --> URI Class Initialized
DEBUG - 2014-08-20 17:56:32 --> Router Class Initialized
DEBUG - 2014-08-20 17:56:32 --> No URI present. Default controller set.
DEBUG - 2014-08-20 17:56:32 --> Output Class Initialized
DEBUG - 2014-08-20 17:56:32 --> Security Class Initialized
DEBUG - 2014-08-20 17:56:32 --> Input Class Initialized
DEBUG - 2014-08-20 17:56:32 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:32 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:32 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:32 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:32 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:32 --> CRSF cookie Set
DEBUG - 2014-08-20 17:56:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 17:56:32 --> Language Class Initialized
DEBUG - 2014-08-20 17:56:32 --> Loader Class Initialized
DEBUG - 2014-08-20 17:56:32 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 17:56:32 --> Helper loaded: url_helper
DEBUG - 2014-08-20 17:56:32 --> Database Driver Class Initialized
ERROR - 2014-08-20 17:56:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 17:56:32 --> Session Class Initialized
DEBUG - 2014-08-20 17:56:32 --> Helper loaded: string_helper
DEBUG - 2014-08-20 17:56:32 --> Session routines successfully run
DEBUG - 2014-08-20 17:56:32 --> Controller Class Initialized
DEBUG - 2014-08-20 17:56:32 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 17:56:32 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 17:56:32 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 17:56:32 --> Helper loaded: form_helper
DEBUG - 2014-08-20 17:56:32 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 17:56:32 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-20 17:56:32 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 17:56:32 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 17:56:32 --> Final output sent to browser
DEBUG - 2014-08-20 17:56:32 --> Total execution time: 0.1251
DEBUG - 2014-08-20 17:56:33 --> Config Class Initialized
DEBUG - 2014-08-20 17:56:33 --> Hooks Class Initialized
DEBUG - 2014-08-20 17:56:33 --> Utf8 Class Initialized
DEBUG - 2014-08-20 17:56:33 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 17:56:33 --> URI Class Initialized
DEBUG - 2014-08-20 17:56:33 --> Router Class Initialized
DEBUG - 2014-08-20 17:56:33 --> No URI present. Default controller set.
DEBUG - 2014-08-20 17:56:33 --> Output Class Initialized
DEBUG - 2014-08-20 17:56:33 --> Security Class Initialized
DEBUG - 2014-08-20 17:56:33 --> Input Class Initialized
DEBUG - 2014-08-20 17:56:33 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:33 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:33 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:33 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:33 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:33 --> CRSF cookie Set
DEBUG - 2014-08-20 17:56:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 17:56:33 --> Language Class Initialized
DEBUG - 2014-08-20 17:56:33 --> Loader Class Initialized
DEBUG - 2014-08-20 17:56:33 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 17:56:33 --> Helper loaded: url_helper
DEBUG - 2014-08-20 17:56:33 --> Database Driver Class Initialized
ERROR - 2014-08-20 17:56:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 17:56:33 --> Session Class Initialized
DEBUG - 2014-08-20 17:56:33 --> Helper loaded: string_helper
DEBUG - 2014-08-20 17:56:33 --> Session routines successfully run
DEBUG - 2014-08-20 17:56:33 --> Controller Class Initialized
DEBUG - 2014-08-20 17:56:33 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 17:56:33 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 17:56:33 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 17:56:33 --> Helper loaded: form_helper
DEBUG - 2014-08-20 17:56:33 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 17:56:33 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-20 17:56:33 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 17:56:33 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 17:56:33 --> Final output sent to browser
DEBUG - 2014-08-20 17:56:33 --> Total execution time: 0.1034
DEBUG - 2014-08-20 17:56:35 --> Config Class Initialized
DEBUG - 2014-08-20 17:56:35 --> Hooks Class Initialized
DEBUG - 2014-08-20 17:56:36 --> Utf8 Class Initialized
DEBUG - 2014-08-20 17:56:36 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 17:56:36 --> URI Class Initialized
DEBUG - 2014-08-20 17:56:36 --> Router Class Initialized
DEBUG - 2014-08-20 17:56:36 --> Output Class Initialized
DEBUG - 2014-08-20 17:56:36 --> Security Class Initialized
DEBUG - 2014-08-20 17:56:36 --> Input Class Initialized
DEBUG - 2014-08-20 17:56:36 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:36 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:36 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:36 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:36 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:36 --> CRSF cookie Set
DEBUG - 2014-08-20 17:56:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 17:56:36 --> Language Class Initialized
DEBUG - 2014-08-20 17:56:36 --> Loader Class Initialized
DEBUG - 2014-08-20 17:56:36 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 17:56:36 --> Helper loaded: url_helper
DEBUG - 2014-08-20 17:56:36 --> Database Driver Class Initialized
ERROR - 2014-08-20 17:56:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 17:56:36 --> Session Class Initialized
DEBUG - 2014-08-20 17:56:36 --> Helper loaded: string_helper
DEBUG - 2014-08-20 17:56:36 --> Session routines successfully run
DEBUG - 2014-08-20 17:56:36 --> Controller Class Initialized
DEBUG - 2014-08-20 17:56:36 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 17:56:36 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 17:56:36 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-20 17:56:36 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 17:56:36 --> Helper loaded: form_helper
DEBUG - 2014-08-20 17:56:36 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 17:56:36 --> File loaded: application/views/placement_history.php
DEBUG - 2014-08-20 17:56:36 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 17:56:36 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 17:56:36 --> Final output sent to browser
DEBUG - 2014-08-20 17:56:36 --> Total execution time: 0.1083
DEBUG - 2014-08-20 17:56:38 --> Config Class Initialized
DEBUG - 2014-08-20 17:56:38 --> Hooks Class Initialized
DEBUG - 2014-08-20 17:56:38 --> Utf8 Class Initialized
DEBUG - 2014-08-20 17:56:38 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 17:56:38 --> URI Class Initialized
DEBUG - 2014-08-20 17:56:38 --> Router Class Initialized
DEBUG - 2014-08-20 17:56:38 --> Output Class Initialized
DEBUG - 2014-08-20 17:56:38 --> Security Class Initialized
DEBUG - 2014-08-20 17:56:38 --> Input Class Initialized
DEBUG - 2014-08-20 17:56:38 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:38 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:38 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:38 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:38 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:38 --> CRSF cookie Set
DEBUG - 2014-08-20 17:56:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 17:56:38 --> Language Class Initialized
DEBUG - 2014-08-20 17:56:38 --> Loader Class Initialized
DEBUG - 2014-08-20 17:56:38 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 17:56:38 --> Helper loaded: url_helper
DEBUG - 2014-08-20 17:56:38 --> Database Driver Class Initialized
ERROR - 2014-08-20 17:56:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 17:56:38 --> Session Class Initialized
DEBUG - 2014-08-20 17:56:38 --> Helper loaded: string_helper
DEBUG - 2014-08-20 17:56:38 --> Session routines successfully run
DEBUG - 2014-08-20 17:56:38 --> Controller Class Initialized
DEBUG - 2014-08-20 17:56:38 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 17:56:38 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 17:56:38 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-20 17:56:38 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 17:56:38 --> Helper loaded: form_helper
DEBUG - 2014-08-20 17:56:38 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 17:56:38 --> File loaded: application/views/placement_contact.php
DEBUG - 2014-08-20 17:56:38 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 17:56:38 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 17:56:38 --> Final output sent to browser
DEBUG - 2014-08-20 17:56:38 --> Total execution time: 0.1032
DEBUG - 2014-08-20 17:56:39 --> Config Class Initialized
DEBUG - 2014-08-20 17:56:39 --> Hooks Class Initialized
DEBUG - 2014-08-20 17:56:39 --> Utf8 Class Initialized
DEBUG - 2014-08-20 17:56:39 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 17:56:39 --> URI Class Initialized
DEBUG - 2014-08-20 17:56:39 --> Router Class Initialized
DEBUG - 2014-08-20 17:56:39 --> Output Class Initialized
DEBUG - 2014-08-20 17:56:39 --> Security Class Initialized
DEBUG - 2014-08-20 17:56:39 --> Input Class Initialized
DEBUG - 2014-08-20 17:56:39 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:39 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:39 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:39 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:39 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:39 --> CRSF cookie Set
DEBUG - 2014-08-20 17:56:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 17:56:39 --> Language Class Initialized
DEBUG - 2014-08-20 17:56:39 --> Loader Class Initialized
DEBUG - 2014-08-20 17:56:39 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 17:56:39 --> Helper loaded: url_helper
DEBUG - 2014-08-20 17:56:39 --> Database Driver Class Initialized
ERROR - 2014-08-20 17:56:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 17:56:39 --> Session Class Initialized
DEBUG - 2014-08-20 17:56:39 --> Helper loaded: string_helper
DEBUG - 2014-08-20 17:56:39 --> Session routines successfully run
DEBUG - 2014-08-20 17:56:39 --> Controller Class Initialized
DEBUG - 2014-08-20 17:56:39 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 17:56:39 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 17:56:39 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 17:56:39 --> Helper loaded: form_helper
DEBUG - 2014-08-20 17:56:39 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 17:56:39 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-20 17:56:39 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 17:56:39 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 17:56:39 --> Final output sent to browser
DEBUG - 2014-08-20 17:56:39 --> Total execution time: 0.1177
DEBUG - 2014-08-20 17:56:41 --> Config Class Initialized
DEBUG - 2014-08-20 17:56:41 --> Hooks Class Initialized
DEBUG - 2014-08-20 17:56:41 --> Utf8 Class Initialized
DEBUG - 2014-08-20 17:56:41 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 17:56:41 --> URI Class Initialized
DEBUG - 2014-08-20 17:56:41 --> Router Class Initialized
DEBUG - 2014-08-20 17:56:41 --> Output Class Initialized
DEBUG - 2014-08-20 17:56:41 --> Security Class Initialized
DEBUG - 2014-08-20 17:56:41 --> Input Class Initialized
DEBUG - 2014-08-20 17:56:41 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:41 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:41 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:41 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:41 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:41 --> CRSF cookie Set
DEBUG - 2014-08-20 17:56:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 17:56:41 --> Language Class Initialized
DEBUG - 2014-08-20 17:56:41 --> Loader Class Initialized
DEBUG - 2014-08-20 17:56:41 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 17:56:41 --> Helper loaded: url_helper
DEBUG - 2014-08-20 17:56:41 --> Database Driver Class Initialized
ERROR - 2014-08-20 17:56:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 17:56:41 --> Session Class Initialized
DEBUG - 2014-08-20 17:56:41 --> Helper loaded: string_helper
DEBUG - 2014-08-20 17:56:41 --> Session routines successfully run
DEBUG - 2014-08-20 17:56:41 --> Controller Class Initialized
DEBUG - 2014-08-20 17:56:41 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 17:56:41 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 17:56:41 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-20 17:56:41 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 17:56:41 --> Helper loaded: form_helper
DEBUG - 2014-08-20 17:56:41 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 17:56:41 --> File loaded: application/views/placement_history.php
DEBUG - 2014-08-20 17:56:41 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 17:56:41 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 17:56:41 --> Final output sent to browser
DEBUG - 2014-08-20 17:56:41 --> Total execution time: 0.1338
DEBUG - 2014-08-20 17:56:48 --> Config Class Initialized
DEBUG - 2014-08-20 17:56:48 --> Hooks Class Initialized
DEBUG - 2014-08-20 17:56:48 --> Utf8 Class Initialized
DEBUG - 2014-08-20 17:56:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 17:56:48 --> URI Class Initialized
DEBUG - 2014-08-20 17:56:48 --> Router Class Initialized
DEBUG - 2014-08-20 17:56:48 --> Output Class Initialized
DEBUG - 2014-08-20 17:56:48 --> Security Class Initialized
DEBUG - 2014-08-20 17:56:48 --> Input Class Initialized
DEBUG - 2014-08-20 17:56:48 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:48 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:48 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:48 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:48 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:48 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:48 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:48 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:48 --> CRSF cookie Set
DEBUG - 2014-08-20 17:56:48 --> CSRF token verified
DEBUG - 2014-08-20 17:56:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 17:56:48 --> Language Class Initialized
DEBUG - 2014-08-20 17:56:48 --> Loader Class Initialized
DEBUG - 2014-08-20 17:56:48 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 17:56:48 --> Helper loaded: url_helper
DEBUG - 2014-08-20 17:56:48 --> Database Driver Class Initialized
ERROR - 2014-08-20 17:56:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 17:56:48 --> Session Class Initialized
DEBUG - 2014-08-20 17:56:48 --> Helper loaded: string_helper
DEBUG - 2014-08-20 17:56:48 --> Session routines successfully run
DEBUG - 2014-08-20 17:56:48 --> Controller Class Initialized
DEBUG - 2014-08-20 17:56:49 --> Helper loaded: form_helper
DEBUG - 2014-08-20 17:56:49 --> Form Validation Class Initialized
DEBUG - 2014-08-20 17:56:49 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-20 17:56:49 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:49 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:49 --> Model Class Initialized
DEBUG - 2014-08-20 17:56:49 --> Model Class Initialized
DEBUG - 2014-08-20 17:56:49 --> Model Class Initialized
DEBUG - 2014-08-20 17:56:49 --> Model Class Initialized
DEBUG - 2014-08-20 17:56:49 --> Encrypt Class Initialized
DEBUG - 2014-08-20 17:56:49 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:49 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:49 --> Config Class Initialized
DEBUG - 2014-08-20 17:56:49 --> Hooks Class Initialized
DEBUG - 2014-08-20 17:56:49 --> Utf8 Class Initialized
DEBUG - 2014-08-20 17:56:49 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 17:56:49 --> URI Class Initialized
DEBUG - 2014-08-20 17:56:49 --> Router Class Initialized
DEBUG - 2014-08-20 17:56:49 --> Output Class Initialized
DEBUG - 2014-08-20 17:56:49 --> Security Class Initialized
DEBUG - 2014-08-20 17:56:49 --> Input Class Initialized
DEBUG - 2014-08-20 17:56:49 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:49 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:49 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:49 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:49 --> XSS Filtering completed
DEBUG - 2014-08-20 17:56:49 --> CRSF cookie Set
DEBUG - 2014-08-20 17:56:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 17:56:49 --> Language Class Initialized
DEBUG - 2014-08-20 17:56:49 --> Loader Class Initialized
DEBUG - 2014-08-20 17:56:49 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 17:56:49 --> Helper loaded: url_helper
DEBUG - 2014-08-20 17:56:49 --> Database Driver Class Initialized
ERROR - 2014-08-20 17:56:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 17:56:49 --> Session Class Initialized
DEBUG - 2014-08-20 17:56:49 --> Helper loaded: string_helper
DEBUG - 2014-08-20 17:56:49 --> Session routines successfully run
DEBUG - 2014-08-20 17:56:49 --> Controller Class Initialized
DEBUG - 2014-08-20 17:56:49 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 17:56:49 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-20 17:56:49 --> Encrypt Class Initialized
DEBUG - 2014-08-20 17:56:49 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-20 17:56:49 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 17:56:49 --> File loaded: application/views/placement_admin_home.php
DEBUG - 2014-08-20 17:56:49 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 17:56:49 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 17:56:49 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-20 17:56:49 --> Final output sent to browser
DEBUG - 2014-08-20 17:56:49 --> Total execution time: 0.1378
DEBUG - 2014-08-20 17:58:17 --> Config Class Initialized
DEBUG - 2014-08-20 17:58:17 --> Hooks Class Initialized
DEBUG - 2014-08-20 17:58:17 --> Utf8 Class Initialized
DEBUG - 2014-08-20 17:58:17 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 17:58:17 --> URI Class Initialized
DEBUG - 2014-08-20 17:58:17 --> Router Class Initialized
DEBUG - 2014-08-20 17:58:17 --> No URI present. Default controller set.
DEBUG - 2014-08-20 17:58:17 --> Output Class Initialized
DEBUG - 2014-08-20 17:58:17 --> Security Class Initialized
DEBUG - 2014-08-20 17:58:17 --> Input Class Initialized
DEBUG - 2014-08-20 17:58:17 --> XSS Filtering completed
DEBUG - 2014-08-20 17:58:17 --> XSS Filtering completed
DEBUG - 2014-08-20 17:58:17 --> XSS Filtering completed
DEBUG - 2014-08-20 17:58:17 --> XSS Filtering completed
DEBUG - 2014-08-20 17:58:17 --> XSS Filtering completed
DEBUG - 2014-08-20 17:58:17 --> CRSF cookie Set
DEBUG - 2014-08-20 17:58:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 17:58:17 --> Language Class Initialized
DEBUG - 2014-08-20 17:58:17 --> Loader Class Initialized
DEBUG - 2014-08-20 17:58:17 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 17:58:17 --> Helper loaded: url_helper
DEBUG - 2014-08-20 17:58:17 --> Database Driver Class Initialized
ERROR - 2014-08-20 17:58:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 17:58:17 --> Session Class Initialized
DEBUG - 2014-08-20 17:58:17 --> Helper loaded: string_helper
DEBUG - 2014-08-20 17:58:17 --> Session routines successfully run
DEBUG - 2014-08-20 17:58:17 --> Controller Class Initialized
DEBUG - 2014-08-20 17:58:17 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 17:58:17 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 17:58:17 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 17:58:17 --> Helper loaded: form_helper
DEBUG - 2014-08-20 17:58:17 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 17:58:17 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-20 17:58:17 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 17:58:17 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 17:58:17 --> Final output sent to browser
DEBUG - 2014-08-20 17:58:17 --> Total execution time: 0.1062
DEBUG - 2014-08-20 17:58:17 --> Config Class Initialized
DEBUG - 2014-08-20 17:58:17 --> Hooks Class Initialized
DEBUG - 2014-08-20 17:58:17 --> Utf8 Class Initialized
DEBUG - 2014-08-20 17:58:17 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 17:58:17 --> URI Class Initialized
DEBUG - 2014-08-20 17:58:17 --> Router Class Initialized
DEBUG - 2014-08-20 17:58:17 --> No URI present. Default controller set.
DEBUG - 2014-08-20 17:58:17 --> Output Class Initialized
DEBUG - 2014-08-20 17:58:17 --> Security Class Initialized
DEBUG - 2014-08-20 17:58:17 --> Input Class Initialized
DEBUG - 2014-08-20 17:58:17 --> XSS Filtering completed
DEBUG - 2014-08-20 17:58:17 --> XSS Filtering completed
DEBUG - 2014-08-20 17:58:17 --> XSS Filtering completed
DEBUG - 2014-08-20 17:58:17 --> XSS Filtering completed
DEBUG - 2014-08-20 17:58:17 --> XSS Filtering completed
DEBUG - 2014-08-20 17:58:17 --> CRSF cookie Set
DEBUG - 2014-08-20 17:58:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 17:58:17 --> Language Class Initialized
DEBUG - 2014-08-20 17:58:17 --> Loader Class Initialized
DEBUG - 2014-08-20 17:58:17 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 17:58:17 --> Helper loaded: url_helper
DEBUG - 2014-08-20 17:58:17 --> Database Driver Class Initialized
ERROR - 2014-08-20 17:58:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 17:58:17 --> Session Class Initialized
DEBUG - 2014-08-20 17:58:17 --> Helper loaded: string_helper
DEBUG - 2014-08-20 17:58:17 --> Session routines successfully run
DEBUG - 2014-08-20 17:58:17 --> Controller Class Initialized
DEBUG - 2014-08-20 17:58:17 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 17:58:17 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 17:58:17 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 17:58:17 --> Helper loaded: form_helper
DEBUG - 2014-08-20 17:58:17 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 17:58:17 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-20 17:58:17 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 17:58:17 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 17:58:17 --> Final output sent to browser
DEBUG - 2014-08-20 17:58:17 --> Total execution time: 0.1220
DEBUG - 2014-08-20 17:58:19 --> Config Class Initialized
DEBUG - 2014-08-20 17:58:19 --> Hooks Class Initialized
DEBUG - 2014-08-20 17:58:19 --> Utf8 Class Initialized
DEBUG - 2014-08-20 17:58:19 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 17:58:19 --> URI Class Initialized
DEBUG - 2014-08-20 17:58:19 --> Router Class Initialized
DEBUG - 2014-08-20 17:58:19 --> Output Class Initialized
DEBUG - 2014-08-20 17:58:19 --> Security Class Initialized
DEBUG - 2014-08-20 17:58:19 --> Input Class Initialized
DEBUG - 2014-08-20 17:58:19 --> XSS Filtering completed
DEBUG - 2014-08-20 17:58:19 --> XSS Filtering completed
DEBUG - 2014-08-20 17:58:19 --> XSS Filtering completed
DEBUG - 2014-08-20 17:58:19 --> XSS Filtering completed
DEBUG - 2014-08-20 17:58:19 --> XSS Filtering completed
DEBUG - 2014-08-20 17:58:19 --> CRSF cookie Set
DEBUG - 2014-08-20 17:58:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 17:58:19 --> Language Class Initialized
DEBUG - 2014-08-20 17:58:19 --> Loader Class Initialized
DEBUG - 2014-08-20 17:58:19 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 17:58:19 --> Helper loaded: url_helper
DEBUG - 2014-08-20 17:58:19 --> Database Driver Class Initialized
ERROR - 2014-08-20 17:58:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 17:58:19 --> Session Class Initialized
DEBUG - 2014-08-20 17:58:19 --> Helper loaded: string_helper
DEBUG - 2014-08-20 17:58:19 --> Session routines successfully run
DEBUG - 2014-08-20 17:58:19 --> Controller Class Initialized
DEBUG - 2014-08-20 17:58:19 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 17:58:19 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 17:58:19 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-20 17:58:19 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 17:58:19 --> Helper loaded: form_helper
DEBUG - 2014-08-20 17:58:19 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 17:58:19 --> File loaded: application/views/placement_contact.php
DEBUG - 2014-08-20 17:58:19 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 17:58:20 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 17:58:20 --> Final output sent to browser
DEBUG - 2014-08-20 17:58:20 --> Total execution time: 0.1077
DEBUG - 2014-08-20 17:58:21 --> Config Class Initialized
DEBUG - 2014-08-20 17:58:21 --> Hooks Class Initialized
DEBUG - 2014-08-20 17:58:21 --> Utf8 Class Initialized
DEBUG - 2014-08-20 17:58:21 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 17:58:21 --> URI Class Initialized
DEBUG - 2014-08-20 17:58:21 --> Router Class Initialized
DEBUG - 2014-08-20 17:58:21 --> Output Class Initialized
DEBUG - 2014-08-20 17:58:21 --> Security Class Initialized
DEBUG - 2014-08-20 17:58:21 --> Input Class Initialized
DEBUG - 2014-08-20 17:58:21 --> XSS Filtering completed
DEBUG - 2014-08-20 17:58:21 --> XSS Filtering completed
DEBUG - 2014-08-20 17:58:21 --> XSS Filtering completed
DEBUG - 2014-08-20 17:58:21 --> XSS Filtering completed
DEBUG - 2014-08-20 17:58:21 --> XSS Filtering completed
DEBUG - 2014-08-20 17:58:21 --> CRSF cookie Set
DEBUG - 2014-08-20 17:58:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 17:58:21 --> Language Class Initialized
DEBUG - 2014-08-20 17:58:21 --> Loader Class Initialized
DEBUG - 2014-08-20 17:58:21 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 17:58:21 --> Helper loaded: url_helper
DEBUG - 2014-08-20 17:58:21 --> Database Driver Class Initialized
ERROR - 2014-08-20 17:58:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 17:58:21 --> Session Class Initialized
DEBUG - 2014-08-20 17:58:21 --> Helper loaded: string_helper
DEBUG - 2014-08-20 17:58:21 --> Session routines successfully run
DEBUG - 2014-08-20 17:58:21 --> Controller Class Initialized
DEBUG - 2014-08-20 17:58:21 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 17:58:21 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 17:58:21 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-20 17:58:21 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 17:58:21 --> Helper loaded: form_helper
DEBUG - 2014-08-20 17:58:21 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 17:58:21 --> File loaded: application/views/placement_history.php
DEBUG - 2014-08-20 17:58:21 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 17:58:21 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 17:58:21 --> Final output sent to browser
DEBUG - 2014-08-20 17:58:21 --> Total execution time: 0.1244
DEBUG - 2014-08-20 17:58:23 --> Config Class Initialized
DEBUG - 2014-08-20 17:58:23 --> Hooks Class Initialized
DEBUG - 2014-08-20 17:58:23 --> Utf8 Class Initialized
DEBUG - 2014-08-20 17:58:23 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 17:58:23 --> URI Class Initialized
DEBUG - 2014-08-20 17:58:23 --> Router Class Initialized
DEBUG - 2014-08-20 17:58:23 --> Output Class Initialized
DEBUG - 2014-08-20 17:58:23 --> Security Class Initialized
DEBUG - 2014-08-20 17:58:23 --> Input Class Initialized
DEBUG - 2014-08-20 17:58:23 --> XSS Filtering completed
DEBUG - 2014-08-20 17:58:23 --> XSS Filtering completed
DEBUG - 2014-08-20 17:58:23 --> XSS Filtering completed
DEBUG - 2014-08-20 17:58:23 --> XSS Filtering completed
DEBUG - 2014-08-20 17:58:23 --> XSS Filtering completed
DEBUG - 2014-08-20 17:58:23 --> CRSF cookie Set
DEBUG - 2014-08-20 17:58:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 17:58:23 --> Language Class Initialized
DEBUG - 2014-08-20 17:58:23 --> Loader Class Initialized
DEBUG - 2014-08-20 17:58:23 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 17:58:23 --> Helper loaded: url_helper
DEBUG - 2014-08-20 17:58:23 --> Database Driver Class Initialized
ERROR - 2014-08-20 17:58:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 17:58:23 --> Session Class Initialized
DEBUG - 2014-08-20 17:58:23 --> Helper loaded: string_helper
DEBUG - 2014-08-20 17:58:23 --> Session routines successfully run
DEBUG - 2014-08-20 17:58:23 --> Controller Class Initialized
DEBUG - 2014-08-20 17:58:23 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 17:58:23 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 17:58:23 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 17:58:23 --> Helper loaded: form_helper
DEBUG - 2014-08-20 17:58:23 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 17:58:23 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-20 17:58:23 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 17:58:23 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 17:58:23 --> Final output sent to browser
DEBUG - 2014-08-20 17:58:23 --> Total execution time: 0.1062
DEBUG - 2014-08-20 17:58:24 --> Config Class Initialized
DEBUG - 2014-08-20 17:58:24 --> Hooks Class Initialized
DEBUG - 2014-08-20 17:58:24 --> Utf8 Class Initialized
DEBUG - 2014-08-20 17:58:24 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 17:58:24 --> URI Class Initialized
DEBUG - 2014-08-20 17:58:24 --> Router Class Initialized
DEBUG - 2014-08-20 17:58:24 --> Output Class Initialized
DEBUG - 2014-08-20 17:58:24 --> Security Class Initialized
DEBUG - 2014-08-20 17:58:24 --> Input Class Initialized
DEBUG - 2014-08-20 17:58:24 --> XSS Filtering completed
DEBUG - 2014-08-20 17:58:24 --> XSS Filtering completed
DEBUG - 2014-08-20 17:58:24 --> XSS Filtering completed
DEBUG - 2014-08-20 17:58:24 --> XSS Filtering completed
DEBUG - 2014-08-20 17:58:24 --> XSS Filtering completed
DEBUG - 2014-08-20 17:58:24 --> CRSF cookie Set
DEBUG - 2014-08-20 17:58:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 17:58:24 --> Language Class Initialized
DEBUG - 2014-08-20 17:58:24 --> Loader Class Initialized
DEBUG - 2014-08-20 17:58:24 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 17:58:24 --> Helper loaded: url_helper
DEBUG - 2014-08-20 17:58:24 --> Database Driver Class Initialized
ERROR - 2014-08-20 17:58:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 17:58:24 --> Session Class Initialized
DEBUG - 2014-08-20 17:58:24 --> Helper loaded: string_helper
DEBUG - 2014-08-20 17:58:24 --> Session routines successfully run
DEBUG - 2014-08-20 17:58:24 --> Controller Class Initialized
DEBUG - 2014-08-20 17:58:24 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 17:58:24 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 17:58:24 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-20 17:58:24 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 17:58:25 --> Helper loaded: form_helper
DEBUG - 2014-08-20 17:58:25 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 17:58:25 --> File loaded: application/views/placement_contact.php
DEBUG - 2014-08-20 17:58:25 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 17:58:25 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 17:58:25 --> Final output sent to browser
DEBUG - 2014-08-20 17:58:25 --> Total execution time: 0.1226
DEBUG - 2014-08-20 17:58:26 --> Config Class Initialized
DEBUG - 2014-08-20 17:58:26 --> Hooks Class Initialized
DEBUG - 2014-08-20 17:58:26 --> Utf8 Class Initialized
DEBUG - 2014-08-20 17:58:26 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 17:58:26 --> URI Class Initialized
DEBUG - 2014-08-20 17:58:26 --> Router Class Initialized
DEBUG - 2014-08-20 17:58:26 --> Output Class Initialized
DEBUG - 2014-08-20 17:58:26 --> Security Class Initialized
DEBUG - 2014-08-20 17:58:26 --> Input Class Initialized
DEBUG - 2014-08-20 17:58:26 --> XSS Filtering completed
DEBUG - 2014-08-20 17:58:26 --> XSS Filtering completed
DEBUG - 2014-08-20 17:58:26 --> XSS Filtering completed
DEBUG - 2014-08-20 17:58:26 --> XSS Filtering completed
DEBUG - 2014-08-20 17:58:26 --> XSS Filtering completed
DEBUG - 2014-08-20 17:58:26 --> CRSF cookie Set
DEBUG - 2014-08-20 17:58:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 17:58:26 --> Language Class Initialized
DEBUG - 2014-08-20 17:58:26 --> Loader Class Initialized
DEBUG - 2014-08-20 17:58:26 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 17:58:26 --> Helper loaded: url_helper
DEBUG - 2014-08-20 17:58:26 --> Database Driver Class Initialized
ERROR - 2014-08-20 17:58:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 17:58:26 --> Session Class Initialized
DEBUG - 2014-08-20 17:58:26 --> Helper loaded: string_helper
DEBUG - 2014-08-20 17:58:26 --> Session routines successfully run
DEBUG - 2014-08-20 17:58:26 --> Controller Class Initialized
DEBUG - 2014-08-20 17:58:26 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 17:58:26 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 17:58:26 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-20 17:58:26 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 17:58:26 --> Helper loaded: form_helper
DEBUG - 2014-08-20 17:58:26 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 17:58:26 --> File loaded: application/views/placement_history.php
DEBUG - 2014-08-20 17:58:26 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 17:58:26 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 17:58:26 --> Final output sent to browser
DEBUG - 2014-08-20 17:58:26 --> Total execution time: 0.1334
DEBUG - 2014-08-20 17:58:27 --> Config Class Initialized
DEBUG - 2014-08-20 17:58:27 --> Hooks Class Initialized
DEBUG - 2014-08-20 17:58:27 --> Utf8 Class Initialized
DEBUG - 2014-08-20 17:58:27 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 17:58:27 --> URI Class Initialized
DEBUG - 2014-08-20 17:58:27 --> Router Class Initialized
DEBUG - 2014-08-20 17:58:27 --> Output Class Initialized
DEBUG - 2014-08-20 17:58:27 --> Security Class Initialized
DEBUG - 2014-08-20 17:58:27 --> Input Class Initialized
DEBUG - 2014-08-20 17:58:27 --> XSS Filtering completed
DEBUG - 2014-08-20 17:58:27 --> XSS Filtering completed
DEBUG - 2014-08-20 17:58:27 --> XSS Filtering completed
DEBUG - 2014-08-20 17:58:27 --> XSS Filtering completed
DEBUG - 2014-08-20 17:58:27 --> XSS Filtering completed
DEBUG - 2014-08-20 17:58:27 --> CRSF cookie Set
DEBUG - 2014-08-20 17:58:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 17:58:27 --> Language Class Initialized
DEBUG - 2014-08-20 17:58:27 --> Loader Class Initialized
DEBUG - 2014-08-20 17:58:27 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 17:58:27 --> Helper loaded: url_helper
DEBUG - 2014-08-20 17:58:27 --> Database Driver Class Initialized
ERROR - 2014-08-20 17:58:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 17:58:27 --> Session Class Initialized
DEBUG - 2014-08-20 17:58:27 --> Helper loaded: string_helper
DEBUG - 2014-08-20 17:58:27 --> Session routines successfully run
DEBUG - 2014-08-20 17:58:27 --> Controller Class Initialized
DEBUG - 2014-08-20 17:58:27 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 17:58:27 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 17:58:27 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-20 17:58:27 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 17:58:27 --> Helper loaded: form_helper
DEBUG - 2014-08-20 17:58:27 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 17:58:27 --> File loaded: application/views/placement_history.php
DEBUG - 2014-08-20 17:58:27 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 17:58:27 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 17:58:27 --> Final output sent to browser
DEBUG - 2014-08-20 17:58:27 --> Total execution time: 0.1166
DEBUG - 2014-08-20 18:04:15 --> Config Class Initialized
DEBUG - 2014-08-20 18:04:15 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:04:15 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:04:15 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:04:15 --> URI Class Initialized
DEBUG - 2014-08-20 18:04:15 --> Router Class Initialized
DEBUG - 2014-08-20 18:04:15 --> Output Class Initialized
DEBUG - 2014-08-20 18:04:15 --> Security Class Initialized
DEBUG - 2014-08-20 18:04:15 --> Input Class Initialized
DEBUG - 2014-08-20 18:04:15 --> XSS Filtering completed
DEBUG - 2014-08-20 18:04:15 --> XSS Filtering completed
DEBUG - 2014-08-20 18:04:15 --> XSS Filtering completed
DEBUG - 2014-08-20 18:04:15 --> XSS Filtering completed
DEBUG - 2014-08-20 18:04:15 --> XSS Filtering completed
DEBUG - 2014-08-20 18:04:15 --> CRSF cookie Set
DEBUG - 2014-08-20 18:04:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:04:15 --> Language Class Initialized
DEBUG - 2014-08-20 18:04:15 --> Loader Class Initialized
DEBUG - 2014-08-20 18:04:15 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:04:15 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:04:15 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:04:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:04:15 --> Session Class Initialized
DEBUG - 2014-08-20 18:04:15 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:04:15 --> Session routines successfully run
DEBUG - 2014-08-20 18:04:15 --> Controller Class Initialized
DEBUG - 2014-08-20 18:04:15 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 18:04:15 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 18:04:15 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-20 18:04:15 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 18:04:15 --> Helper loaded: form_helper
DEBUG - 2014-08-20 18:04:15 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 18:04:15 --> File loaded: application/views/placement_contact.php
DEBUG - 2014-08-20 18:04:15 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 18:04:15 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 18:04:15 --> Final output sent to browser
DEBUG - 2014-08-20 18:04:15 --> Total execution time: 0.1115
DEBUG - 2014-08-20 18:04:17 --> Config Class Initialized
DEBUG - 2014-08-20 18:04:17 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:04:17 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:04:17 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:04:17 --> URI Class Initialized
DEBUG - 2014-08-20 18:04:17 --> Router Class Initialized
DEBUG - 2014-08-20 18:04:17 --> Output Class Initialized
DEBUG - 2014-08-20 18:04:17 --> Security Class Initialized
DEBUG - 2014-08-20 18:04:17 --> Input Class Initialized
DEBUG - 2014-08-20 18:04:17 --> XSS Filtering completed
DEBUG - 2014-08-20 18:04:17 --> XSS Filtering completed
DEBUG - 2014-08-20 18:04:17 --> XSS Filtering completed
DEBUG - 2014-08-20 18:04:17 --> XSS Filtering completed
DEBUG - 2014-08-20 18:04:17 --> XSS Filtering completed
DEBUG - 2014-08-20 18:04:17 --> CRSF cookie Set
DEBUG - 2014-08-20 18:04:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:04:17 --> Language Class Initialized
DEBUG - 2014-08-20 18:04:17 --> Loader Class Initialized
DEBUG - 2014-08-20 18:04:17 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:04:17 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:04:17 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:04:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:04:17 --> Session Class Initialized
DEBUG - 2014-08-20 18:04:17 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:04:17 --> Session routines successfully run
DEBUG - 2014-08-20 18:04:17 --> Controller Class Initialized
DEBUG - 2014-08-20 18:04:17 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 18:04:17 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 18:04:17 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 18:04:17 --> Helper loaded: form_helper
DEBUG - 2014-08-20 18:04:17 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 18:04:17 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-20 18:04:17 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 18:04:17 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 18:04:17 --> Final output sent to browser
DEBUG - 2014-08-20 18:04:17 --> Total execution time: 0.1087
DEBUG - 2014-08-20 18:04:19 --> Config Class Initialized
DEBUG - 2014-08-20 18:04:19 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:04:19 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:04:19 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:04:19 --> URI Class Initialized
DEBUG - 2014-08-20 18:04:19 --> Router Class Initialized
DEBUG - 2014-08-20 18:04:19 --> Output Class Initialized
DEBUG - 2014-08-20 18:04:19 --> Security Class Initialized
DEBUG - 2014-08-20 18:04:19 --> Input Class Initialized
DEBUG - 2014-08-20 18:04:19 --> XSS Filtering completed
DEBUG - 2014-08-20 18:04:19 --> XSS Filtering completed
DEBUG - 2014-08-20 18:04:19 --> XSS Filtering completed
DEBUG - 2014-08-20 18:04:19 --> XSS Filtering completed
DEBUG - 2014-08-20 18:04:19 --> XSS Filtering completed
DEBUG - 2014-08-20 18:04:19 --> CRSF cookie Set
DEBUG - 2014-08-20 18:04:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:04:19 --> Language Class Initialized
DEBUG - 2014-08-20 18:04:19 --> Loader Class Initialized
DEBUG - 2014-08-20 18:04:19 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:04:19 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:04:19 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:04:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:04:19 --> Session Class Initialized
DEBUG - 2014-08-20 18:04:19 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:04:19 --> Session routines successfully run
DEBUG - 2014-08-20 18:04:19 --> Controller Class Initialized
DEBUG - 2014-08-20 18:04:19 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 18:04:19 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 18:04:19 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-20 18:04:19 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 18:04:19 --> Helper loaded: form_helper
DEBUG - 2014-08-20 18:04:19 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 18:04:19 --> File loaded: application/views/placement_history.php
DEBUG - 2014-08-20 18:04:19 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 18:04:19 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 18:04:19 --> Final output sent to browser
DEBUG - 2014-08-20 18:04:19 --> Total execution time: 0.1130
DEBUG - 2014-08-20 18:04:20 --> Config Class Initialized
DEBUG - 2014-08-20 18:04:20 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:04:20 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:04:20 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:04:20 --> URI Class Initialized
DEBUG - 2014-08-20 18:04:20 --> Router Class Initialized
DEBUG - 2014-08-20 18:04:20 --> Output Class Initialized
DEBUG - 2014-08-20 18:04:20 --> Security Class Initialized
DEBUG - 2014-08-20 18:04:20 --> Input Class Initialized
DEBUG - 2014-08-20 18:04:20 --> XSS Filtering completed
DEBUG - 2014-08-20 18:04:20 --> XSS Filtering completed
DEBUG - 2014-08-20 18:04:20 --> XSS Filtering completed
DEBUG - 2014-08-20 18:04:20 --> XSS Filtering completed
DEBUG - 2014-08-20 18:04:20 --> XSS Filtering completed
DEBUG - 2014-08-20 18:04:20 --> CRSF cookie Set
DEBUG - 2014-08-20 18:04:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:04:20 --> Language Class Initialized
DEBUG - 2014-08-20 18:04:20 --> Loader Class Initialized
DEBUG - 2014-08-20 18:04:20 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:04:20 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:04:20 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:04:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:04:20 --> Session Class Initialized
DEBUG - 2014-08-20 18:04:20 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:04:20 --> Session routines successfully run
DEBUG - 2014-08-20 18:04:20 --> Controller Class Initialized
DEBUG - 2014-08-20 18:04:20 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 18:04:20 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 18:04:20 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 18:04:20 --> Helper loaded: form_helper
DEBUG - 2014-08-20 18:04:20 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 18:04:20 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-20 18:04:20 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 18:04:20 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 18:04:20 --> Final output sent to browser
DEBUG - 2014-08-20 18:04:20 --> Total execution time: 0.1325
DEBUG - 2014-08-20 18:04:46 --> Config Class Initialized
DEBUG - 2014-08-20 18:04:46 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:04:46 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:04:46 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:04:46 --> URI Class Initialized
DEBUG - 2014-08-20 18:04:46 --> Router Class Initialized
DEBUG - 2014-08-20 18:04:46 --> Output Class Initialized
DEBUG - 2014-08-20 18:04:46 --> Security Class Initialized
DEBUG - 2014-08-20 18:04:46 --> Input Class Initialized
DEBUG - 2014-08-20 18:04:46 --> XSS Filtering completed
DEBUG - 2014-08-20 18:04:46 --> XSS Filtering completed
DEBUG - 2014-08-20 18:04:46 --> XSS Filtering completed
DEBUG - 2014-08-20 18:04:46 --> XSS Filtering completed
DEBUG - 2014-08-20 18:04:46 --> XSS Filtering completed
DEBUG - 2014-08-20 18:04:46 --> CRSF cookie Set
DEBUG - 2014-08-20 18:04:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:04:46 --> Language Class Initialized
DEBUG - 2014-08-20 18:04:46 --> Loader Class Initialized
DEBUG - 2014-08-20 18:04:46 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:04:46 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:04:46 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:04:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:04:46 --> Session Class Initialized
DEBUG - 2014-08-20 18:04:46 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:04:46 --> Session routines successfully run
DEBUG - 2014-08-20 18:04:46 --> Controller Class Initialized
DEBUG - 2014-08-20 18:04:46 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 18:04:46 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 18:04:46 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-20 18:04:46 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 18:04:46 --> Helper loaded: form_helper
DEBUG - 2014-08-20 18:04:46 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 18:04:46 --> File loaded: application/views/placement_history.php
DEBUG - 2014-08-20 18:04:46 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 18:04:46 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 18:04:46 --> Final output sent to browser
DEBUG - 2014-08-20 18:04:46 --> Total execution time: 0.1212
DEBUG - 2014-08-20 18:04:48 --> Config Class Initialized
DEBUG - 2014-08-20 18:04:48 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:04:48 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:04:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:04:48 --> URI Class Initialized
DEBUG - 2014-08-20 18:04:48 --> Router Class Initialized
DEBUG - 2014-08-20 18:04:48 --> Output Class Initialized
DEBUG - 2014-08-20 18:04:48 --> Security Class Initialized
DEBUG - 2014-08-20 18:04:48 --> Input Class Initialized
DEBUG - 2014-08-20 18:04:48 --> XSS Filtering completed
DEBUG - 2014-08-20 18:04:48 --> XSS Filtering completed
DEBUG - 2014-08-20 18:04:48 --> XSS Filtering completed
DEBUG - 2014-08-20 18:04:48 --> XSS Filtering completed
DEBUG - 2014-08-20 18:04:48 --> XSS Filtering completed
DEBUG - 2014-08-20 18:04:48 --> CRSF cookie Set
DEBUG - 2014-08-20 18:04:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:04:48 --> Language Class Initialized
DEBUG - 2014-08-20 18:04:48 --> Loader Class Initialized
DEBUG - 2014-08-20 18:04:48 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:04:48 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:04:48 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:04:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:04:48 --> Session Class Initialized
DEBUG - 2014-08-20 18:04:48 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:04:48 --> Session routines successfully run
DEBUG - 2014-08-20 18:04:48 --> Controller Class Initialized
DEBUG - 2014-08-20 18:04:48 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 18:04:48 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 18:04:48 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-20 18:04:48 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 18:04:48 --> Helper loaded: form_helper
DEBUG - 2014-08-20 18:04:48 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 18:04:48 --> File loaded: application/views/placement_contact.php
DEBUG - 2014-08-20 18:04:48 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 18:04:48 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 18:04:48 --> Final output sent to browser
DEBUG - 2014-08-20 18:04:48 --> Total execution time: 0.1384
DEBUG - 2014-08-20 18:04:49 --> Config Class Initialized
DEBUG - 2014-08-20 18:04:49 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:04:49 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:04:49 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:04:49 --> URI Class Initialized
DEBUG - 2014-08-20 18:04:49 --> Router Class Initialized
DEBUG - 2014-08-20 18:04:49 --> Output Class Initialized
DEBUG - 2014-08-20 18:04:49 --> Security Class Initialized
DEBUG - 2014-08-20 18:04:49 --> Input Class Initialized
DEBUG - 2014-08-20 18:04:49 --> XSS Filtering completed
DEBUG - 2014-08-20 18:04:49 --> XSS Filtering completed
DEBUG - 2014-08-20 18:04:49 --> XSS Filtering completed
DEBUG - 2014-08-20 18:04:49 --> XSS Filtering completed
DEBUG - 2014-08-20 18:04:49 --> XSS Filtering completed
DEBUG - 2014-08-20 18:04:49 --> CRSF cookie Set
DEBUG - 2014-08-20 18:04:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:04:49 --> Language Class Initialized
DEBUG - 2014-08-20 18:04:49 --> Loader Class Initialized
DEBUG - 2014-08-20 18:04:49 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:04:49 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:04:49 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:04:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:04:49 --> Session Class Initialized
DEBUG - 2014-08-20 18:04:49 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:04:49 --> Session routines successfully run
DEBUG - 2014-08-20 18:04:49 --> Controller Class Initialized
DEBUG - 2014-08-20 18:04:49 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 18:04:49 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 18:04:49 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 18:04:49 --> Helper loaded: form_helper
DEBUG - 2014-08-20 18:04:49 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 18:04:49 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-20 18:04:49 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 18:04:49 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 18:04:49 --> Final output sent to browser
DEBUG - 2014-08-20 18:04:49 --> Total execution time: 0.1254
DEBUG - 2014-08-20 18:05:27 --> Config Class Initialized
DEBUG - 2014-08-20 18:05:27 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:05:27 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:05:27 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:05:27 --> URI Class Initialized
DEBUG - 2014-08-20 18:05:27 --> Router Class Initialized
DEBUG - 2014-08-20 18:05:27 --> Output Class Initialized
DEBUG - 2014-08-20 18:05:27 --> Security Class Initialized
DEBUG - 2014-08-20 18:05:27 --> Input Class Initialized
DEBUG - 2014-08-20 18:05:27 --> XSS Filtering completed
DEBUG - 2014-08-20 18:05:27 --> XSS Filtering completed
DEBUG - 2014-08-20 18:05:27 --> XSS Filtering completed
DEBUG - 2014-08-20 18:05:27 --> XSS Filtering completed
DEBUG - 2014-08-20 18:05:27 --> XSS Filtering completed
DEBUG - 2014-08-20 18:05:27 --> CRSF cookie Set
DEBUG - 2014-08-20 18:05:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:05:27 --> Language Class Initialized
DEBUG - 2014-08-20 18:05:27 --> Loader Class Initialized
DEBUG - 2014-08-20 18:05:27 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:05:27 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:05:27 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:05:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:05:27 --> Session Class Initialized
DEBUG - 2014-08-20 18:05:27 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:05:27 --> Session routines successfully run
DEBUG - 2014-08-20 18:05:27 --> Controller Class Initialized
DEBUG - 2014-08-20 18:05:27 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 18:05:27 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 18:05:27 --> Helper loaded: form_helper
DEBUG - 2014-08-20 18:05:27 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 18:05:27 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 18:05:27 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-20 18:05:27 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 18:05:27 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 18:05:27 --> Final output sent to browser
DEBUG - 2014-08-20 18:05:27 --> Total execution time: 0.1102
DEBUG - 2014-08-20 18:05:47 --> Config Class Initialized
DEBUG - 2014-08-20 18:05:47 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:05:47 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:05:47 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:05:47 --> URI Class Initialized
DEBUG - 2014-08-20 18:05:47 --> Router Class Initialized
DEBUG - 2014-08-20 18:05:47 --> Output Class Initialized
DEBUG - 2014-08-20 18:05:47 --> Security Class Initialized
DEBUG - 2014-08-20 18:05:47 --> Input Class Initialized
DEBUG - 2014-08-20 18:05:47 --> XSS Filtering completed
DEBUG - 2014-08-20 18:05:47 --> XSS Filtering completed
DEBUG - 2014-08-20 18:05:47 --> XSS Filtering completed
DEBUG - 2014-08-20 18:05:47 --> XSS Filtering completed
DEBUG - 2014-08-20 18:05:47 --> XSS Filtering completed
DEBUG - 2014-08-20 18:05:47 --> CRSF cookie Set
DEBUG - 2014-08-20 18:05:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:05:47 --> Language Class Initialized
DEBUG - 2014-08-20 18:05:47 --> Loader Class Initialized
DEBUG - 2014-08-20 18:05:47 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:05:47 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:05:47 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:05:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:05:47 --> Session Class Initialized
DEBUG - 2014-08-20 18:05:47 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:05:47 --> Session routines successfully run
DEBUG - 2014-08-20 18:05:47 --> Controller Class Initialized
DEBUG - 2014-08-20 18:05:47 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 18:05:47 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 18:05:47 --> Helper loaded: form_helper
DEBUG - 2014-08-20 18:05:47 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 18:05:47 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 18:05:47 --> File loaded: application/views/placement_students_register.php
DEBUG - 2014-08-20 18:05:47 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 18:05:47 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 18:05:47 --> Final output sent to browser
DEBUG - 2014-08-20 18:05:47 --> Total execution time: 0.1125
DEBUG - 2014-08-20 18:06:13 --> Config Class Initialized
DEBUG - 2014-08-20 18:06:13 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:06:13 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:06:13 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:06:13 --> URI Class Initialized
DEBUG - 2014-08-20 18:06:13 --> Router Class Initialized
DEBUG - 2014-08-20 18:06:13 --> Output Class Initialized
DEBUG - 2014-08-20 18:06:13 --> Security Class Initialized
DEBUG - 2014-08-20 18:06:13 --> Input Class Initialized
DEBUG - 2014-08-20 18:06:13 --> XSS Filtering completed
DEBUG - 2014-08-20 18:06:13 --> XSS Filtering completed
DEBUG - 2014-08-20 18:06:13 --> XSS Filtering completed
DEBUG - 2014-08-20 18:06:13 --> XSS Filtering completed
DEBUG - 2014-08-20 18:06:13 --> XSS Filtering completed
DEBUG - 2014-08-20 18:06:13 --> CRSF cookie Set
DEBUG - 2014-08-20 18:06:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:06:13 --> Language Class Initialized
DEBUG - 2014-08-20 18:06:13 --> Loader Class Initialized
DEBUG - 2014-08-20 18:06:13 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:06:13 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:06:13 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:06:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:06:13 --> Session Class Initialized
DEBUG - 2014-08-20 18:06:13 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:06:13 --> Session routines successfully run
DEBUG - 2014-08-20 18:06:13 --> Controller Class Initialized
DEBUG - 2014-08-20 18:06:13 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 18:06:13 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 18:06:13 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-20 18:06:13 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 18:06:13 --> Helper loaded: form_helper
DEBUG - 2014-08-20 18:06:13 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 18:06:13 --> File loaded: application/views/placement_history.php
DEBUG - 2014-08-20 18:06:13 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 18:06:13 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 18:06:13 --> Final output sent to browser
DEBUG - 2014-08-20 18:06:13 --> Total execution time: 0.1148
DEBUG - 2014-08-20 18:06:45 --> Config Class Initialized
DEBUG - 2014-08-20 18:06:45 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:06:46 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:06:46 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:06:46 --> URI Class Initialized
DEBUG - 2014-08-20 18:06:46 --> Router Class Initialized
DEBUG - 2014-08-20 18:06:46 --> Output Class Initialized
DEBUG - 2014-08-20 18:06:46 --> Security Class Initialized
DEBUG - 2014-08-20 18:06:46 --> Input Class Initialized
DEBUG - 2014-08-20 18:06:46 --> XSS Filtering completed
DEBUG - 2014-08-20 18:06:46 --> XSS Filtering completed
DEBUG - 2014-08-20 18:06:46 --> XSS Filtering completed
DEBUG - 2014-08-20 18:06:46 --> XSS Filtering completed
DEBUG - 2014-08-20 18:06:46 --> XSS Filtering completed
DEBUG - 2014-08-20 18:06:46 --> CRSF cookie Set
DEBUG - 2014-08-20 18:06:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:06:46 --> Language Class Initialized
DEBUG - 2014-08-20 18:06:46 --> Loader Class Initialized
DEBUG - 2014-08-20 18:06:46 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:06:46 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:06:46 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:06:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:06:46 --> Session Class Initialized
DEBUG - 2014-08-20 18:06:46 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:06:46 --> Session routines successfully run
DEBUG - 2014-08-20 18:06:46 --> Controller Class Initialized
DEBUG - 2014-08-20 18:06:46 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 18:06:46 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 18:06:46 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-20 18:06:46 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 18:06:46 --> Helper loaded: form_helper
DEBUG - 2014-08-20 18:06:46 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 18:06:46 --> File loaded: application/views/placement_history.php
DEBUG - 2014-08-20 18:06:46 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 18:06:46 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 18:06:46 --> Final output sent to browser
DEBUG - 2014-08-20 18:06:46 --> Total execution time: 0.1117
DEBUG - 2014-08-20 18:06:48 --> Config Class Initialized
DEBUG - 2014-08-20 18:06:48 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:06:48 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:06:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:06:48 --> URI Class Initialized
DEBUG - 2014-08-20 18:06:48 --> Router Class Initialized
DEBUG - 2014-08-20 18:06:48 --> Output Class Initialized
DEBUG - 2014-08-20 18:06:48 --> Security Class Initialized
DEBUG - 2014-08-20 18:06:48 --> Input Class Initialized
DEBUG - 2014-08-20 18:06:48 --> XSS Filtering completed
DEBUG - 2014-08-20 18:06:48 --> XSS Filtering completed
DEBUG - 2014-08-20 18:06:48 --> XSS Filtering completed
DEBUG - 2014-08-20 18:06:48 --> XSS Filtering completed
DEBUG - 2014-08-20 18:06:48 --> XSS Filtering completed
DEBUG - 2014-08-20 18:06:48 --> CRSF cookie Set
DEBUG - 2014-08-20 18:06:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:06:48 --> Language Class Initialized
DEBUG - 2014-08-20 18:06:48 --> Loader Class Initialized
DEBUG - 2014-08-20 18:06:48 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:06:48 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:06:48 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:06:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:06:48 --> Session Class Initialized
DEBUG - 2014-08-20 18:06:48 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:06:48 --> Session routines successfully run
DEBUG - 2014-08-20 18:06:48 --> Controller Class Initialized
DEBUG - 2014-08-20 18:06:48 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 18:06:48 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 18:06:48 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-20 18:06:48 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 18:06:48 --> Helper loaded: form_helper
DEBUG - 2014-08-20 18:06:48 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 18:06:48 --> File loaded: application/views/placement_contact.php
DEBUG - 2014-08-20 18:06:48 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 18:06:48 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 18:06:48 --> Final output sent to browser
DEBUG - 2014-08-20 18:06:48 --> Total execution time: 0.1154
DEBUG - 2014-08-20 18:06:50 --> Config Class Initialized
DEBUG - 2014-08-20 18:06:50 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:06:50 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:06:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:06:50 --> URI Class Initialized
DEBUG - 2014-08-20 18:06:50 --> Router Class Initialized
DEBUG - 2014-08-20 18:06:50 --> Output Class Initialized
DEBUG - 2014-08-20 18:06:50 --> Security Class Initialized
DEBUG - 2014-08-20 18:06:50 --> Input Class Initialized
DEBUG - 2014-08-20 18:06:50 --> XSS Filtering completed
DEBUG - 2014-08-20 18:06:50 --> XSS Filtering completed
DEBUG - 2014-08-20 18:06:50 --> XSS Filtering completed
DEBUG - 2014-08-20 18:06:50 --> XSS Filtering completed
DEBUG - 2014-08-20 18:06:50 --> XSS Filtering completed
DEBUG - 2014-08-20 18:06:50 --> CRSF cookie Set
DEBUG - 2014-08-20 18:06:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:06:50 --> Language Class Initialized
DEBUG - 2014-08-20 18:06:50 --> Loader Class Initialized
DEBUG - 2014-08-20 18:06:50 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:06:50 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:06:50 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:06:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:06:50 --> Session Class Initialized
DEBUG - 2014-08-20 18:06:50 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:06:50 --> Session routines successfully run
DEBUG - 2014-08-20 18:06:50 --> Controller Class Initialized
DEBUG - 2014-08-20 18:06:50 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 18:06:50 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 18:06:50 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 18:06:50 --> Helper loaded: form_helper
DEBUG - 2014-08-20 18:06:50 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 18:06:50 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-20 18:06:50 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 18:06:50 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 18:06:50 --> Final output sent to browser
DEBUG - 2014-08-20 18:06:50 --> Total execution time: 0.1090
DEBUG - 2014-08-20 18:07:29 --> Config Class Initialized
DEBUG - 2014-08-20 18:07:29 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:07:29 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:07:29 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:07:29 --> URI Class Initialized
DEBUG - 2014-08-20 18:07:29 --> Router Class Initialized
DEBUG - 2014-08-20 18:07:29 --> Output Class Initialized
DEBUG - 2014-08-20 18:07:29 --> Security Class Initialized
DEBUG - 2014-08-20 18:07:29 --> Input Class Initialized
DEBUG - 2014-08-20 18:07:29 --> XSS Filtering completed
DEBUG - 2014-08-20 18:07:29 --> XSS Filtering completed
DEBUG - 2014-08-20 18:07:29 --> XSS Filtering completed
DEBUG - 2014-08-20 18:07:29 --> XSS Filtering completed
DEBUG - 2014-08-20 18:07:29 --> XSS Filtering completed
DEBUG - 2014-08-20 18:07:29 --> CRSF cookie Set
DEBUG - 2014-08-20 18:07:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:07:29 --> Language Class Initialized
DEBUG - 2014-08-20 18:07:29 --> Loader Class Initialized
DEBUG - 2014-08-20 18:07:29 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:07:29 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:07:29 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:07:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:07:29 --> Session Class Initialized
DEBUG - 2014-08-20 18:07:29 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:07:29 --> Session routines successfully run
DEBUG - 2014-08-20 18:07:29 --> Controller Class Initialized
DEBUG - 2014-08-20 18:07:29 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 18:07:29 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 18:07:29 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-20 18:07:29 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 18:07:29 --> Helper loaded: form_helper
DEBUG - 2014-08-20 18:07:29 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 18:07:29 --> File loaded: application/views/placement_history.php
DEBUG - 2014-08-20 18:07:29 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 18:07:29 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 18:07:29 --> Final output sent to browser
DEBUG - 2014-08-20 18:07:29 --> Total execution time: 0.1124
DEBUG - 2014-08-20 18:09:25 --> Config Class Initialized
DEBUG - 2014-08-20 18:09:25 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:09:25 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:09:25 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:09:25 --> URI Class Initialized
DEBUG - 2014-08-20 18:09:25 --> Router Class Initialized
DEBUG - 2014-08-20 18:09:25 --> Output Class Initialized
DEBUG - 2014-08-20 18:09:25 --> Security Class Initialized
DEBUG - 2014-08-20 18:09:25 --> Input Class Initialized
DEBUG - 2014-08-20 18:09:25 --> XSS Filtering completed
DEBUG - 2014-08-20 18:09:25 --> XSS Filtering completed
DEBUG - 2014-08-20 18:09:25 --> XSS Filtering completed
DEBUG - 2014-08-20 18:09:25 --> XSS Filtering completed
DEBUG - 2014-08-20 18:09:25 --> XSS Filtering completed
DEBUG - 2014-08-20 18:09:25 --> CRSF cookie Set
DEBUG - 2014-08-20 18:09:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:09:25 --> Language Class Initialized
DEBUG - 2014-08-20 18:09:25 --> Loader Class Initialized
DEBUG - 2014-08-20 18:09:25 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:09:25 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:09:25 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:09:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:09:25 --> Session Class Initialized
DEBUG - 2014-08-20 18:09:25 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:09:25 --> Session routines successfully run
DEBUG - 2014-08-20 18:09:25 --> Controller Class Initialized
DEBUG - 2014-08-20 18:09:25 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 18:09:25 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 18:09:25 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-20 18:09:25 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 18:09:25 --> Helper loaded: form_helper
DEBUG - 2014-08-20 18:09:25 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 18:09:25 --> File loaded: application/views/placement_history.php
DEBUG - 2014-08-20 18:09:25 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 18:09:25 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 18:09:25 --> Final output sent to browser
DEBUG - 2014-08-20 18:09:25 --> Total execution time: 0.1103
DEBUG - 2014-08-20 18:09:34 --> Config Class Initialized
DEBUG - 2014-08-20 18:09:34 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:09:34 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:09:34 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:09:34 --> URI Class Initialized
DEBUG - 2014-08-20 18:09:34 --> Router Class Initialized
DEBUG - 2014-08-20 18:09:34 --> Output Class Initialized
DEBUG - 2014-08-20 18:09:34 --> Security Class Initialized
DEBUG - 2014-08-20 18:09:34 --> Input Class Initialized
DEBUG - 2014-08-20 18:09:34 --> XSS Filtering completed
DEBUG - 2014-08-20 18:09:34 --> XSS Filtering completed
DEBUG - 2014-08-20 18:09:34 --> XSS Filtering completed
DEBUG - 2014-08-20 18:09:34 --> XSS Filtering completed
DEBUG - 2014-08-20 18:09:34 --> XSS Filtering completed
DEBUG - 2014-08-20 18:09:34 --> CRSF cookie Set
DEBUG - 2014-08-20 18:09:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:09:34 --> Language Class Initialized
DEBUG - 2014-08-20 18:09:34 --> Loader Class Initialized
DEBUG - 2014-08-20 18:09:34 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:09:34 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:09:34 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:09:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:09:34 --> Session Class Initialized
DEBUG - 2014-08-20 18:09:34 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:09:34 --> Session routines successfully run
DEBUG - 2014-08-20 18:09:34 --> Controller Class Initialized
DEBUG - 2014-08-20 18:09:34 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 18:09:34 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 18:09:34 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-20 18:09:34 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 18:09:34 --> Helper loaded: form_helper
DEBUG - 2014-08-20 18:09:34 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 18:09:34 --> File loaded: application/views/placement_contact.php
DEBUG - 2014-08-20 18:09:34 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 18:09:34 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 18:09:34 --> Final output sent to browser
DEBUG - 2014-08-20 18:09:34 --> Total execution time: 0.0987
DEBUG - 2014-08-20 18:09:36 --> Config Class Initialized
DEBUG - 2014-08-20 18:09:36 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:09:36 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:09:36 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:09:36 --> URI Class Initialized
DEBUG - 2014-08-20 18:09:36 --> Router Class Initialized
DEBUG - 2014-08-20 18:09:36 --> Output Class Initialized
DEBUG - 2014-08-20 18:09:36 --> Security Class Initialized
DEBUG - 2014-08-20 18:09:36 --> Input Class Initialized
DEBUG - 2014-08-20 18:09:36 --> XSS Filtering completed
DEBUG - 2014-08-20 18:09:36 --> XSS Filtering completed
DEBUG - 2014-08-20 18:09:36 --> XSS Filtering completed
DEBUG - 2014-08-20 18:09:36 --> XSS Filtering completed
DEBUG - 2014-08-20 18:09:36 --> XSS Filtering completed
DEBUG - 2014-08-20 18:09:36 --> CRSF cookie Set
DEBUG - 2014-08-20 18:09:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:09:36 --> Language Class Initialized
DEBUG - 2014-08-20 18:09:36 --> Loader Class Initialized
DEBUG - 2014-08-20 18:09:36 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:09:36 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:09:36 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:09:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:09:36 --> Session Class Initialized
DEBUG - 2014-08-20 18:09:36 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:09:36 --> Session routines successfully run
DEBUG - 2014-08-20 18:09:36 --> Controller Class Initialized
DEBUG - 2014-08-20 18:09:36 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 18:09:36 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 18:09:36 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 18:09:36 --> Helper loaded: form_helper
DEBUG - 2014-08-20 18:09:36 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 18:09:36 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-20 18:09:36 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 18:09:36 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 18:09:36 --> Final output sent to browser
DEBUG - 2014-08-20 18:09:36 --> Total execution time: 0.1118
DEBUG - 2014-08-20 18:09:39 --> Config Class Initialized
DEBUG - 2014-08-20 18:09:39 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:09:39 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:09:39 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:09:39 --> URI Class Initialized
DEBUG - 2014-08-20 18:09:39 --> Router Class Initialized
DEBUG - 2014-08-20 18:09:39 --> Output Class Initialized
DEBUG - 2014-08-20 18:09:39 --> Security Class Initialized
DEBUG - 2014-08-20 18:09:39 --> Input Class Initialized
DEBUG - 2014-08-20 18:09:39 --> XSS Filtering completed
DEBUG - 2014-08-20 18:09:39 --> XSS Filtering completed
DEBUG - 2014-08-20 18:09:39 --> XSS Filtering completed
DEBUG - 2014-08-20 18:09:39 --> XSS Filtering completed
DEBUG - 2014-08-20 18:09:39 --> XSS Filtering completed
DEBUG - 2014-08-20 18:09:39 --> CRSF cookie Set
DEBUG - 2014-08-20 18:09:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:09:39 --> Language Class Initialized
DEBUG - 2014-08-20 18:09:39 --> Loader Class Initialized
DEBUG - 2014-08-20 18:09:39 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:09:39 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:09:39 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:09:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:09:39 --> Session Class Initialized
DEBUG - 2014-08-20 18:09:39 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:09:39 --> Session routines successfully run
DEBUG - 2014-08-20 18:09:39 --> Controller Class Initialized
DEBUG - 2014-08-20 18:09:39 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 18:09:39 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 18:09:39 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-20 18:09:39 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 18:09:39 --> Helper loaded: form_helper
DEBUG - 2014-08-20 18:09:39 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 18:09:39 --> File loaded: application/views/placement_history.php
DEBUG - 2014-08-20 18:09:39 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 18:09:39 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 18:09:39 --> Final output sent to browser
DEBUG - 2014-08-20 18:09:39 --> Total execution time: 0.1112
DEBUG - 2014-08-20 18:09:56 --> Config Class Initialized
DEBUG - 2014-08-20 18:09:56 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:09:56 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:09:56 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:09:56 --> URI Class Initialized
DEBUG - 2014-08-20 18:09:56 --> Router Class Initialized
DEBUG - 2014-08-20 18:09:56 --> Output Class Initialized
DEBUG - 2014-08-20 18:09:56 --> Security Class Initialized
DEBUG - 2014-08-20 18:09:56 --> Input Class Initialized
DEBUG - 2014-08-20 18:09:56 --> XSS Filtering completed
DEBUG - 2014-08-20 18:09:56 --> XSS Filtering completed
DEBUG - 2014-08-20 18:09:56 --> XSS Filtering completed
DEBUG - 2014-08-20 18:09:56 --> XSS Filtering completed
DEBUG - 2014-08-20 18:09:56 --> XSS Filtering completed
DEBUG - 2014-08-20 18:09:56 --> CRSF cookie Set
DEBUG - 2014-08-20 18:09:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:09:56 --> Language Class Initialized
DEBUG - 2014-08-20 18:09:56 --> Loader Class Initialized
DEBUG - 2014-08-20 18:09:56 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:09:56 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:09:56 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:09:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:09:56 --> Session Class Initialized
DEBUG - 2014-08-20 18:09:56 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:09:56 --> Session routines successfully run
DEBUG - 2014-08-20 18:09:56 --> Controller Class Initialized
DEBUG - 2014-08-20 18:09:56 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 18:09:56 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 18:09:56 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-20 18:09:56 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 18:09:56 --> Helper loaded: form_helper
DEBUG - 2014-08-20 18:09:56 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 18:09:56 --> File loaded: application/views/placement_contact.php
DEBUG - 2014-08-20 18:09:56 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 18:09:56 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 18:09:56 --> Final output sent to browser
DEBUG - 2014-08-20 18:09:56 --> Total execution time: 0.1154
DEBUG - 2014-08-20 18:15:49 --> Config Class Initialized
DEBUG - 2014-08-20 18:15:49 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:15:49 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:15:49 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:15:49 --> URI Class Initialized
DEBUG - 2014-08-20 18:15:49 --> Router Class Initialized
DEBUG - 2014-08-20 18:15:49 --> Output Class Initialized
DEBUG - 2014-08-20 18:15:49 --> Security Class Initialized
DEBUG - 2014-08-20 18:15:49 --> Input Class Initialized
DEBUG - 2014-08-20 18:15:49 --> XSS Filtering completed
DEBUG - 2014-08-20 18:15:49 --> XSS Filtering completed
DEBUG - 2014-08-20 18:15:49 --> XSS Filtering completed
DEBUG - 2014-08-20 18:15:49 --> XSS Filtering completed
DEBUG - 2014-08-20 18:15:49 --> XSS Filtering completed
DEBUG - 2014-08-20 18:15:49 --> XSS Filtering completed
DEBUG - 2014-08-20 18:15:49 --> XSS Filtering completed
DEBUG - 2014-08-20 18:15:49 --> XSS Filtering completed
DEBUG - 2014-08-20 18:15:49 --> CRSF cookie Set
DEBUG - 2014-08-20 18:15:49 --> CSRF token verified
DEBUG - 2014-08-20 18:15:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:15:49 --> Language Class Initialized
DEBUG - 2014-08-20 18:15:49 --> Loader Class Initialized
DEBUG - 2014-08-20 18:15:49 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:15:49 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:15:49 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:15:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:15:49 --> Session Class Initialized
DEBUG - 2014-08-20 18:15:49 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:15:49 --> Session routines successfully run
DEBUG - 2014-08-20 18:15:49 --> Controller Class Initialized
DEBUG - 2014-08-20 18:15:49 --> Helper loaded: form_helper
DEBUG - 2014-08-20 18:15:49 --> Form Validation Class Initialized
DEBUG - 2014-08-20 18:15:49 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-20 18:15:49 --> XSS Filtering completed
DEBUG - 2014-08-20 18:15:49 --> XSS Filtering completed
DEBUG - 2014-08-20 18:15:49 --> Model Class Initialized
DEBUG - 2014-08-20 18:15:49 --> Model Class Initialized
DEBUG - 2014-08-20 18:15:49 --> Model Class Initialized
DEBUG - 2014-08-20 18:15:49 --> Model Class Initialized
DEBUG - 2014-08-20 18:15:49 --> Encrypt Class Initialized
DEBUG - 2014-08-20 18:15:49 --> XSS Filtering completed
DEBUG - 2014-08-20 18:15:49 --> XSS Filtering completed
DEBUG - 2014-08-20 18:15:49 --> Config Class Initialized
DEBUG - 2014-08-20 18:15:49 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:15:49 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:15:49 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:15:49 --> URI Class Initialized
DEBUG - 2014-08-20 18:15:49 --> Router Class Initialized
DEBUG - 2014-08-20 18:15:49 --> Output Class Initialized
DEBUG - 2014-08-20 18:15:49 --> Security Class Initialized
DEBUG - 2014-08-20 18:15:49 --> Input Class Initialized
DEBUG - 2014-08-20 18:15:49 --> XSS Filtering completed
DEBUG - 2014-08-20 18:15:49 --> XSS Filtering completed
DEBUG - 2014-08-20 18:15:49 --> XSS Filtering completed
DEBUG - 2014-08-20 18:15:49 --> XSS Filtering completed
DEBUG - 2014-08-20 18:15:49 --> XSS Filtering completed
DEBUG - 2014-08-20 18:15:49 --> CRSF cookie Set
DEBUG - 2014-08-20 18:15:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:15:49 --> Language Class Initialized
DEBUG - 2014-08-20 18:15:49 --> Loader Class Initialized
DEBUG - 2014-08-20 18:15:49 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:15:49 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:15:49 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:15:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:15:49 --> Session Class Initialized
DEBUG - 2014-08-20 18:15:49 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:15:49 --> Session routines successfully run
DEBUG - 2014-08-20 18:15:49 --> Controller Class Initialized
DEBUG - 2014-08-20 18:15:49 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 18:15:49 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-20 18:15:49 --> Encrypt Class Initialized
DEBUG - 2014-08-20 18:15:49 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-20 18:15:49 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 18:15:49 --> File loaded: application/views/placement_admin_home.php
DEBUG - 2014-08-20 18:15:49 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 18:15:49 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 18:15:49 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-20 18:15:49 --> Final output sent to browser
DEBUG - 2014-08-20 18:15:49 --> Total execution time: 0.0577
DEBUG - 2014-08-20 18:15:52 --> Config Class Initialized
DEBUG - 2014-08-20 18:15:52 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:15:52 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:15:52 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:15:52 --> URI Class Initialized
DEBUG - 2014-08-20 18:15:52 --> Router Class Initialized
DEBUG - 2014-08-20 18:15:52 --> Output Class Initialized
DEBUG - 2014-08-20 18:15:52 --> Security Class Initialized
DEBUG - 2014-08-20 18:15:52 --> Input Class Initialized
DEBUG - 2014-08-20 18:15:52 --> XSS Filtering completed
DEBUG - 2014-08-20 18:15:52 --> XSS Filtering completed
DEBUG - 2014-08-20 18:15:52 --> XSS Filtering completed
DEBUG - 2014-08-20 18:15:52 --> XSS Filtering completed
DEBUG - 2014-08-20 18:15:52 --> XSS Filtering completed
DEBUG - 2014-08-20 18:15:52 --> CRSF cookie Set
DEBUG - 2014-08-20 18:15:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:15:52 --> Language Class Initialized
DEBUG - 2014-08-20 18:15:52 --> Loader Class Initialized
DEBUG - 2014-08-20 18:15:52 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:15:52 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:15:52 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:15:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:15:52 --> Session Class Initialized
DEBUG - 2014-08-20 18:15:52 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:15:52 --> Session routines successfully run
DEBUG - 2014-08-20 18:15:52 --> Controller Class Initialized
DEBUG - 2014-08-20 18:15:52 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 18:15:52 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-20 18:15:52 --> Encrypt Class Initialized
DEBUG - 2014-08-20 18:15:52 --> Model Class Initialized
DEBUG - 2014-08-20 18:15:52 --> Model Class Initialized
DEBUG - 2014-08-20 18:15:52 --> Model Class Initialized
DEBUG - 2014-08-20 18:15:52 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-20 18:15:52 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 18:15:52 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 18:15:52 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-20 18:15:52 --> Final output sent to browser
DEBUG - 2014-08-20 18:15:52 --> Total execution time: 0.0616
DEBUG - 2014-08-20 18:15:57 --> Config Class Initialized
DEBUG - 2014-08-20 18:15:57 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:15:57 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:15:57 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:15:57 --> URI Class Initialized
DEBUG - 2014-08-20 18:15:57 --> Router Class Initialized
DEBUG - 2014-08-20 18:15:57 --> Output Class Initialized
DEBUG - 2014-08-20 18:15:57 --> Security Class Initialized
DEBUG - 2014-08-20 18:15:57 --> Input Class Initialized
DEBUG - 2014-08-20 18:15:57 --> XSS Filtering completed
DEBUG - 2014-08-20 18:15:57 --> XSS Filtering completed
DEBUG - 2014-08-20 18:15:57 --> XSS Filtering completed
DEBUG - 2014-08-20 18:15:57 --> XSS Filtering completed
DEBUG - 2014-08-20 18:15:57 --> XSS Filtering completed
DEBUG - 2014-08-20 18:15:57 --> XSS Filtering completed
DEBUG - 2014-08-20 18:16:04 --> Config Class Initialized
DEBUG - 2014-08-20 18:16:04 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:16:04 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:16:04 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:16:04 --> URI Class Initialized
DEBUG - 2014-08-20 18:16:04 --> Router Class Initialized
DEBUG - 2014-08-20 18:16:04 --> Output Class Initialized
DEBUG - 2014-08-20 18:16:04 --> Security Class Initialized
DEBUG - 2014-08-20 18:16:04 --> Input Class Initialized
DEBUG - 2014-08-20 18:16:04 --> XSS Filtering completed
DEBUG - 2014-08-20 18:16:04 --> XSS Filtering completed
DEBUG - 2014-08-20 18:16:04 --> XSS Filtering completed
DEBUG - 2014-08-20 18:16:04 --> XSS Filtering completed
DEBUG - 2014-08-20 18:16:04 --> XSS Filtering completed
DEBUG - 2014-08-20 18:16:04 --> XSS Filtering completed
DEBUG - 2014-08-20 18:16:54 --> Config Class Initialized
DEBUG - 2014-08-20 18:16:54 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:16:54 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:16:54 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:16:54 --> URI Class Initialized
DEBUG - 2014-08-20 18:16:54 --> Router Class Initialized
DEBUG - 2014-08-20 18:16:54 --> Output Class Initialized
DEBUG - 2014-08-20 18:16:54 --> Security Class Initialized
DEBUG - 2014-08-20 18:16:54 --> Input Class Initialized
DEBUG - 2014-08-20 18:16:54 --> XSS Filtering completed
DEBUG - 2014-08-20 18:16:54 --> CRSF cookie Set
DEBUG - 2014-08-20 18:16:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:16:54 --> Language Class Initialized
DEBUG - 2014-08-20 18:16:54 --> Loader Class Initialized
DEBUG - 2014-08-20 18:16:54 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:16:54 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:16:54 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:16:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:16:54 --> Session Class Initialized
DEBUG - 2014-08-20 18:16:54 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:16:54 --> A session cookie was not found.
DEBUG - 2014-08-20 18:16:54 --> Session routines successfully run
DEBUG - 2014-08-20 18:16:54 --> Controller Class Initialized
DEBUG - 2014-08-20 18:16:54 --> File loaded: application/views/login_to_continue.php
DEBUG - 2014-08-20 18:16:54 --> Final output sent to browser
DEBUG - 2014-08-20 18:16:54 --> Total execution time: 0.0343
DEBUG - 2014-08-20 18:16:56 --> Config Class Initialized
DEBUG - 2014-08-20 18:16:56 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:16:56 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:16:56 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:16:56 --> URI Class Initialized
DEBUG - 2014-08-20 18:16:56 --> Router Class Initialized
DEBUG - 2014-08-20 18:16:56 --> No URI present. Default controller set.
DEBUG - 2014-08-20 18:16:56 --> Output Class Initialized
DEBUG - 2014-08-20 18:16:56 --> Security Class Initialized
DEBUG - 2014-08-20 18:16:56 --> Input Class Initialized
DEBUG - 2014-08-20 18:16:56 --> XSS Filtering completed
DEBUG - 2014-08-20 18:16:56 --> XSS Filtering completed
DEBUG - 2014-08-20 18:16:56 --> CRSF cookie Set
DEBUG - 2014-08-20 18:16:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:16:56 --> Language Class Initialized
DEBUG - 2014-08-20 18:16:56 --> Loader Class Initialized
DEBUG - 2014-08-20 18:16:56 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:16:56 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:16:56 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:16:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:16:56 --> Session Class Initialized
DEBUG - 2014-08-20 18:16:56 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:16:56 --> Session routines successfully run
DEBUG - 2014-08-20 18:16:56 --> Controller Class Initialized
DEBUG - 2014-08-20 18:16:56 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 18:16:56 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 18:16:56 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 18:16:56 --> Helper loaded: form_helper
DEBUG - 2014-08-20 18:16:56 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 18:16:56 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-20 18:16:56 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 18:16:56 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 18:16:56 --> Final output sent to browser
DEBUG - 2014-08-20 18:16:56 --> Total execution time: 0.0551
DEBUG - 2014-08-20 18:17:51 --> Config Class Initialized
DEBUG - 2014-08-20 18:17:51 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:17:51 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:17:51 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:17:51 --> URI Class Initialized
DEBUG - 2014-08-20 18:17:51 --> Router Class Initialized
DEBUG - 2014-08-20 18:17:51 --> Output Class Initialized
DEBUG - 2014-08-20 18:17:52 --> Security Class Initialized
DEBUG - 2014-08-20 18:17:52 --> Input Class Initialized
DEBUG - 2014-08-20 18:17:52 --> XSS Filtering completed
DEBUG - 2014-08-20 18:17:52 --> XSS Filtering completed
DEBUG - 2014-08-20 18:17:52 --> XSS Filtering completed
DEBUG - 2014-08-20 18:17:52 --> XSS Filtering completed
DEBUG - 2014-08-20 18:17:52 --> XSS Filtering completed
DEBUG - 2014-08-20 18:17:52 --> XSS Filtering completed
DEBUG - 2014-08-20 18:19:00 --> Config Class Initialized
DEBUG - 2014-08-20 18:19:00 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:19:00 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:19:00 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:19:00 --> URI Class Initialized
DEBUG - 2014-08-20 18:19:00 --> Router Class Initialized
DEBUG - 2014-08-20 18:19:00 --> Output Class Initialized
DEBUG - 2014-08-20 18:19:00 --> Security Class Initialized
DEBUG - 2014-08-20 18:19:00 --> Input Class Initialized
DEBUG - 2014-08-20 18:19:00 --> XSS Filtering completed
DEBUG - 2014-08-20 18:19:00 --> XSS Filtering completed
DEBUG - 2014-08-20 18:19:00 --> XSS Filtering completed
DEBUG - 2014-08-20 18:19:00 --> XSS Filtering completed
DEBUG - 2014-08-20 18:19:00 --> XSS Filtering completed
DEBUG - 2014-08-20 18:19:00 --> CRSF cookie Set
DEBUG - 2014-08-20 18:19:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:19:00 --> Language Class Initialized
DEBUG - 2014-08-20 18:19:00 --> Loader Class Initialized
DEBUG - 2014-08-20 18:19:00 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:19:00 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:19:00 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:19:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:19:00 --> Session Class Initialized
DEBUG - 2014-08-20 18:19:00 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:19:00 --> Session routines successfully run
DEBUG - 2014-08-20 18:19:00 --> Controller Class Initialized
DEBUG - 2014-08-20 18:19:00 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 18:19:00 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-20 18:19:00 --> Encrypt Class Initialized
DEBUG - 2014-08-20 18:19:00 --> Model Class Initialized
DEBUG - 2014-08-20 18:19:00 --> Model Class Initialized
DEBUG - 2014-08-20 18:19:00 --> Model Class Initialized
DEBUG - 2014-08-20 18:19:00 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-20 18:19:00 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 18:19:00 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 18:19:00 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-20 18:19:00 --> Final output sent to browser
DEBUG - 2014-08-20 18:19:00 --> Total execution time: 0.0644
DEBUG - 2014-08-20 18:19:27 --> Config Class Initialized
DEBUG - 2014-08-20 18:19:27 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:19:27 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:19:27 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:19:27 --> URI Class Initialized
DEBUG - 2014-08-20 18:19:27 --> Router Class Initialized
DEBUG - 2014-08-20 18:19:27 --> Output Class Initialized
DEBUG - 2014-08-20 18:19:27 --> Security Class Initialized
DEBUG - 2014-08-20 18:19:27 --> Input Class Initialized
DEBUG - 2014-08-20 18:19:27 --> XSS Filtering completed
DEBUG - 2014-08-20 18:19:27 --> XSS Filtering completed
DEBUG - 2014-08-20 18:19:27 --> XSS Filtering completed
DEBUG - 2014-08-20 18:19:27 --> XSS Filtering completed
DEBUG - 2014-08-20 18:19:27 --> XSS Filtering completed
DEBUG - 2014-08-20 18:19:27 --> CRSF cookie Set
DEBUG - 2014-08-20 18:19:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:19:27 --> Language Class Initialized
DEBUG - 2014-08-20 18:19:27 --> Loader Class Initialized
DEBUG - 2014-08-20 18:19:27 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:19:27 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:19:27 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:19:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:19:27 --> Session Class Initialized
DEBUG - 2014-08-20 18:19:27 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:19:27 --> Session routines successfully run
DEBUG - 2014-08-20 18:19:27 --> Controller Class Initialized
DEBUG - 2014-08-20 18:19:27 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 18:19:27 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-20 18:19:27 --> Encrypt Class Initialized
DEBUG - 2014-08-20 18:19:27 --> Model Class Initialized
DEBUG - 2014-08-20 18:19:27 --> Model Class Initialized
DEBUG - 2014-08-20 18:19:27 --> Model Class Initialized
DEBUG - 2014-08-20 18:19:27 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-20 18:19:27 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 18:19:27 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 18:19:27 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-20 18:19:27 --> Final output sent to browser
DEBUG - 2014-08-20 18:19:27 --> Total execution time: 0.0693
DEBUG - 2014-08-20 18:22:54 --> Config Class Initialized
DEBUG - 2014-08-20 18:22:54 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:22:54 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:22:54 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:22:54 --> URI Class Initialized
DEBUG - 2014-08-20 18:22:54 --> Router Class Initialized
DEBUG - 2014-08-20 18:22:54 --> Output Class Initialized
DEBUG - 2014-08-20 18:22:54 --> Security Class Initialized
DEBUG - 2014-08-20 18:22:54 --> Input Class Initialized
DEBUG - 2014-08-20 18:22:54 --> XSS Filtering completed
DEBUG - 2014-08-20 18:22:54 --> XSS Filtering completed
DEBUG - 2014-08-20 18:22:54 --> XSS Filtering completed
DEBUG - 2014-08-20 18:22:54 --> XSS Filtering completed
DEBUG - 2014-08-20 18:22:54 --> XSS Filtering completed
DEBUG - 2014-08-20 18:22:54 --> CRSF cookie Set
DEBUG - 2014-08-20 18:22:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:22:54 --> Language Class Initialized
DEBUG - 2014-08-20 18:22:54 --> Loader Class Initialized
DEBUG - 2014-08-20 18:22:54 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:22:54 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:22:54 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:22:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:22:54 --> Session Class Initialized
DEBUG - 2014-08-20 18:22:54 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:22:54 --> Session routines successfully run
DEBUG - 2014-08-20 18:22:54 --> Controller Class Initialized
DEBUG - 2014-08-20 18:22:54 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 18:22:54 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-20 18:22:54 --> Encrypt Class Initialized
DEBUG - 2014-08-20 18:22:54 --> Model Class Initialized
DEBUG - 2014-08-20 18:22:54 --> Model Class Initialized
DEBUG - 2014-08-20 18:22:54 --> Model Class Initialized
DEBUG - 2014-08-20 18:22:54 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-20 18:22:54 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 18:22:54 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 18:22:54 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-20 18:22:54 --> Final output sent to browser
DEBUG - 2014-08-20 18:22:54 --> Total execution time: 0.1572
DEBUG - 2014-08-20 18:23:48 --> Config Class Initialized
DEBUG - 2014-08-20 18:23:48 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:23:48 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:23:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:23:48 --> URI Class Initialized
DEBUG - 2014-08-20 18:23:48 --> Router Class Initialized
DEBUG - 2014-08-20 18:23:48 --> Output Class Initialized
DEBUG - 2014-08-20 18:23:48 --> Security Class Initialized
DEBUG - 2014-08-20 18:23:48 --> Input Class Initialized
DEBUG - 2014-08-20 18:23:48 --> XSS Filtering completed
DEBUG - 2014-08-20 18:23:48 --> XSS Filtering completed
DEBUG - 2014-08-20 18:23:48 --> XSS Filtering completed
DEBUG - 2014-08-20 18:23:48 --> XSS Filtering completed
DEBUG - 2014-08-20 18:23:48 --> XSS Filtering completed
DEBUG - 2014-08-20 18:23:48 --> CRSF cookie Set
DEBUG - 2014-08-20 18:23:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:23:48 --> Language Class Initialized
DEBUG - 2014-08-20 18:23:48 --> Loader Class Initialized
DEBUG - 2014-08-20 18:23:48 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:23:48 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:23:48 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:23:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:23:48 --> Session Class Initialized
DEBUG - 2014-08-20 18:23:48 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:23:48 --> Session routines successfully run
DEBUG - 2014-08-20 18:23:48 --> Controller Class Initialized
DEBUG - 2014-08-20 18:23:48 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 18:23:48 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-20 18:23:48 --> Encrypt Class Initialized
DEBUG - 2014-08-20 18:23:48 --> Model Class Initialized
DEBUG - 2014-08-20 18:23:48 --> Model Class Initialized
DEBUG - 2014-08-20 18:23:48 --> Model Class Initialized
DEBUG - 2014-08-20 18:23:48 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-20 18:23:48 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 18:23:48 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 18:23:48 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-20 18:23:48 --> Final output sent to browser
DEBUG - 2014-08-20 18:23:48 --> Total execution time: 0.1577
DEBUG - 2014-08-20 18:23:49 --> Config Class Initialized
DEBUG - 2014-08-20 18:23:49 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:23:49 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:23:49 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:23:49 --> URI Class Initialized
DEBUG - 2014-08-20 18:23:49 --> Router Class Initialized
DEBUG - 2014-08-20 18:23:49 --> Output Class Initialized
DEBUG - 2014-08-20 18:23:49 --> Security Class Initialized
DEBUG - 2014-08-20 18:23:49 --> Input Class Initialized
DEBUG - 2014-08-20 18:23:49 --> XSS Filtering completed
DEBUG - 2014-08-20 18:23:49 --> XSS Filtering completed
DEBUG - 2014-08-20 18:23:49 --> XSS Filtering completed
DEBUG - 2014-08-20 18:23:49 --> XSS Filtering completed
DEBUG - 2014-08-20 18:23:49 --> XSS Filtering completed
DEBUG - 2014-08-20 18:23:49 --> CRSF cookie Set
DEBUG - 2014-08-20 18:23:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:23:49 --> Language Class Initialized
DEBUG - 2014-08-20 18:23:49 --> Loader Class Initialized
DEBUG - 2014-08-20 18:23:49 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:23:49 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:23:49 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:23:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:23:49 --> Session Class Initialized
DEBUG - 2014-08-20 18:23:49 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:23:49 --> Session routines successfully run
DEBUG - 2014-08-20 18:23:49 --> Controller Class Initialized
DEBUG - 2014-08-20 18:23:49 --> Final output sent to browser
DEBUG - 2014-08-20 18:23:49 --> Total execution time: 0.1645
DEBUG - 2014-08-20 18:24:53 --> Config Class Initialized
DEBUG - 2014-08-20 18:24:53 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:24:53 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:24:53 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:24:53 --> URI Class Initialized
DEBUG - 2014-08-20 18:24:53 --> Router Class Initialized
DEBUG - 2014-08-20 18:24:53 --> Output Class Initialized
DEBUG - 2014-08-20 18:24:53 --> Security Class Initialized
DEBUG - 2014-08-20 18:24:53 --> Input Class Initialized
DEBUG - 2014-08-20 18:24:53 --> XSS Filtering completed
DEBUG - 2014-08-20 18:24:53 --> XSS Filtering completed
DEBUG - 2014-08-20 18:24:53 --> XSS Filtering completed
DEBUG - 2014-08-20 18:24:53 --> XSS Filtering completed
DEBUG - 2014-08-20 18:24:53 --> XSS Filtering completed
DEBUG - 2014-08-20 18:24:53 --> XSS Filtering completed
DEBUG - 2014-08-20 18:26:42 --> Config Class Initialized
DEBUG - 2014-08-20 18:26:42 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:26:42 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:26:42 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:26:42 --> URI Class Initialized
DEBUG - 2014-08-20 18:26:42 --> Router Class Initialized
DEBUG - 2014-08-20 18:26:42 --> Output Class Initialized
DEBUG - 2014-08-20 18:26:42 --> Security Class Initialized
DEBUG - 2014-08-20 18:26:42 --> Input Class Initialized
DEBUG - 2014-08-20 18:26:42 --> XSS Filtering completed
DEBUG - 2014-08-20 18:26:42 --> XSS Filtering completed
DEBUG - 2014-08-20 18:26:42 --> XSS Filtering completed
DEBUG - 2014-08-20 18:26:42 --> XSS Filtering completed
DEBUG - 2014-08-20 18:26:42 --> XSS Filtering completed
DEBUG - 2014-08-20 18:26:42 --> CRSF cookie Set
DEBUG - 2014-08-20 18:26:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:26:42 --> Language Class Initialized
DEBUG - 2014-08-20 18:26:42 --> Loader Class Initialized
DEBUG - 2014-08-20 18:26:42 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:26:42 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:26:42 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:26:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:26:42 --> Session Class Initialized
DEBUG - 2014-08-20 18:26:42 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:26:42 --> Session routines successfully run
DEBUG - 2014-08-20 18:26:42 --> Controller Class Initialized
DEBUG - 2014-08-20 18:26:42 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 18:26:42 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-20 18:26:42 --> Encrypt Class Initialized
DEBUG - 2014-08-20 18:26:42 --> Model Class Initialized
DEBUG - 2014-08-20 18:26:42 --> Model Class Initialized
DEBUG - 2014-08-20 18:26:42 --> Model Class Initialized
DEBUG - 2014-08-20 18:26:42 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-20 18:26:42 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 18:26:42 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 18:26:42 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-20 18:26:42 --> Final output sent to browser
DEBUG - 2014-08-20 18:26:42 --> Total execution time: 0.1681
DEBUG - 2014-08-20 18:26:43 --> Config Class Initialized
DEBUG - 2014-08-20 18:26:43 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:26:43 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:26:43 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:26:43 --> URI Class Initialized
DEBUG - 2014-08-20 18:26:43 --> Router Class Initialized
DEBUG - 2014-08-20 18:26:43 --> Output Class Initialized
DEBUG - 2014-08-20 18:26:43 --> Security Class Initialized
DEBUG - 2014-08-20 18:26:43 --> Input Class Initialized
DEBUG - 2014-08-20 18:26:43 --> XSS Filtering completed
DEBUG - 2014-08-20 18:26:43 --> XSS Filtering completed
DEBUG - 2014-08-20 18:26:43 --> XSS Filtering completed
DEBUG - 2014-08-20 18:26:43 --> XSS Filtering completed
DEBUG - 2014-08-20 18:26:43 --> XSS Filtering completed
DEBUG - 2014-08-20 18:26:43 --> CRSF cookie Set
DEBUG - 2014-08-20 18:26:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:26:43 --> Language Class Initialized
DEBUG - 2014-08-20 18:26:43 --> Loader Class Initialized
DEBUG - 2014-08-20 18:26:43 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:26:43 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:26:43 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:26:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:26:43 --> Session Class Initialized
DEBUG - 2014-08-20 18:26:43 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:26:43 --> Session routines successfully run
DEBUG - 2014-08-20 18:26:43 --> Controller Class Initialized
DEBUG - 2014-08-20 18:26:43 --> Final output sent to browser
DEBUG - 2014-08-20 18:26:43 --> Total execution time: 0.1170
DEBUG - 2014-08-20 18:26:51 --> Config Class Initialized
DEBUG - 2014-08-20 18:26:51 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:26:51 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:26:51 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:26:51 --> URI Class Initialized
DEBUG - 2014-08-20 18:26:51 --> Router Class Initialized
DEBUG - 2014-08-20 18:26:51 --> Output Class Initialized
DEBUG - 2014-08-20 18:26:51 --> Security Class Initialized
DEBUG - 2014-08-20 18:26:51 --> Input Class Initialized
DEBUG - 2014-08-20 18:26:51 --> XSS Filtering completed
DEBUG - 2014-08-20 18:26:51 --> XSS Filtering completed
DEBUG - 2014-08-20 18:26:51 --> XSS Filtering completed
DEBUG - 2014-08-20 18:26:51 --> XSS Filtering completed
DEBUG - 2014-08-20 18:26:51 --> XSS Filtering completed
DEBUG - 2014-08-20 18:26:51 --> XSS Filtering completed
DEBUG - 2014-08-20 18:30:54 --> Config Class Initialized
DEBUG - 2014-08-20 18:30:54 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:30:54 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:30:54 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:30:54 --> URI Class Initialized
DEBUG - 2014-08-20 18:30:54 --> Router Class Initialized
DEBUG - 2014-08-20 18:30:54 --> Output Class Initialized
DEBUG - 2014-08-20 18:30:54 --> Security Class Initialized
DEBUG - 2014-08-20 18:30:54 --> Input Class Initialized
DEBUG - 2014-08-20 18:30:54 --> XSS Filtering completed
DEBUG - 2014-08-20 18:30:54 --> XSS Filtering completed
DEBUG - 2014-08-20 18:30:54 --> XSS Filtering completed
DEBUG - 2014-08-20 18:30:54 --> XSS Filtering completed
DEBUG - 2014-08-20 18:30:54 --> XSS Filtering completed
DEBUG - 2014-08-20 18:30:54 --> CRSF cookie Set
DEBUG - 2014-08-20 18:30:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:30:54 --> Language Class Initialized
DEBUG - 2014-08-20 18:30:54 --> Loader Class Initialized
DEBUG - 2014-08-20 18:30:54 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:30:54 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:30:54 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:30:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:30:54 --> Session Class Initialized
DEBUG - 2014-08-20 18:30:54 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:30:54 --> Session routines successfully run
DEBUG - 2014-08-20 18:30:54 --> Controller Class Initialized
DEBUG - 2014-08-20 18:30:54 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 18:30:54 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-20 18:30:54 --> Encrypt Class Initialized
DEBUG - 2014-08-20 18:30:54 --> Model Class Initialized
DEBUG - 2014-08-20 18:30:54 --> Model Class Initialized
DEBUG - 2014-08-20 18:30:54 --> Model Class Initialized
DEBUG - 2014-08-20 18:30:54 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-20 18:30:54 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 18:30:54 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 18:30:54 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-20 18:30:54 --> Final output sent to browser
DEBUG - 2014-08-20 18:30:54 --> Total execution time: 0.1707
DEBUG - 2014-08-20 18:30:55 --> Config Class Initialized
DEBUG - 2014-08-20 18:30:55 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:30:55 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:30:55 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:30:55 --> URI Class Initialized
DEBUG - 2014-08-20 18:30:55 --> Router Class Initialized
DEBUG - 2014-08-20 18:30:55 --> Output Class Initialized
DEBUG - 2014-08-20 18:30:55 --> Security Class Initialized
DEBUG - 2014-08-20 18:30:55 --> Input Class Initialized
DEBUG - 2014-08-20 18:30:55 --> XSS Filtering completed
DEBUG - 2014-08-20 18:30:55 --> XSS Filtering completed
DEBUG - 2014-08-20 18:30:55 --> XSS Filtering completed
DEBUG - 2014-08-20 18:30:55 --> XSS Filtering completed
DEBUG - 2014-08-20 18:30:55 --> XSS Filtering completed
DEBUG - 2014-08-20 18:30:55 --> CRSF cookie Set
DEBUG - 2014-08-20 18:30:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:30:55 --> Language Class Initialized
DEBUG - 2014-08-20 18:30:55 --> Loader Class Initialized
DEBUG - 2014-08-20 18:30:55 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:30:55 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:30:55 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:30:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:30:55 --> Session Class Initialized
DEBUG - 2014-08-20 18:30:55 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:30:55 --> Session routines successfully run
DEBUG - 2014-08-20 18:30:55 --> Controller Class Initialized
DEBUG - 2014-08-20 18:30:55 --> Final output sent to browser
DEBUG - 2014-08-20 18:30:55 --> Total execution time: 0.1153
DEBUG - 2014-08-20 18:31:00 --> Config Class Initialized
DEBUG - 2014-08-20 18:31:00 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:31:00 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:31:00 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:31:00 --> URI Class Initialized
DEBUG - 2014-08-20 18:31:00 --> Router Class Initialized
DEBUG - 2014-08-20 18:31:00 --> Output Class Initialized
DEBUG - 2014-08-20 18:31:00 --> Security Class Initialized
DEBUG - 2014-08-20 18:31:00 --> Input Class Initialized
DEBUG - 2014-08-20 18:31:00 --> XSS Filtering completed
DEBUG - 2014-08-20 18:31:00 --> XSS Filtering completed
DEBUG - 2014-08-20 18:31:00 --> XSS Filtering completed
DEBUG - 2014-08-20 18:31:00 --> XSS Filtering completed
DEBUG - 2014-08-20 18:31:00 --> XSS Filtering completed
DEBUG - 2014-08-20 18:31:00 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:16 --> Config Class Initialized
DEBUG - 2014-08-20 18:32:16 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:32:16 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:32:16 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:32:16 --> URI Class Initialized
DEBUG - 2014-08-20 18:32:16 --> Router Class Initialized
DEBUG - 2014-08-20 18:32:16 --> Output Class Initialized
DEBUG - 2014-08-20 18:32:16 --> Security Class Initialized
DEBUG - 2014-08-20 18:32:16 --> Input Class Initialized
DEBUG - 2014-08-20 18:32:16 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:16 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:16 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:16 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:16 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:16 --> CRSF cookie Set
DEBUG - 2014-08-20 18:32:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:32:16 --> Language Class Initialized
DEBUG - 2014-08-20 18:32:16 --> Loader Class Initialized
DEBUG - 2014-08-20 18:32:16 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:32:16 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:32:16 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:32:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:32:16 --> Session Class Initialized
DEBUG - 2014-08-20 18:32:16 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:32:16 --> Session routines successfully run
DEBUG - 2014-08-20 18:32:16 --> Controller Class Initialized
DEBUG - 2014-08-20 18:32:16 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 18:32:16 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-20 18:32:16 --> Encrypt Class Initialized
DEBUG - 2014-08-20 18:32:16 --> Model Class Initialized
DEBUG - 2014-08-20 18:32:16 --> Model Class Initialized
DEBUG - 2014-08-20 18:32:16 --> Model Class Initialized
DEBUG - 2014-08-20 18:32:16 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-20 18:32:16 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 18:32:16 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 18:32:16 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-20 18:32:16 --> Final output sent to browser
DEBUG - 2014-08-20 18:32:16 --> Total execution time: 0.1635
DEBUG - 2014-08-20 18:32:17 --> Config Class Initialized
DEBUG - 2014-08-20 18:32:17 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:32:17 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:32:17 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:32:17 --> URI Class Initialized
DEBUG - 2014-08-20 18:32:17 --> Router Class Initialized
DEBUG - 2014-08-20 18:32:17 --> Output Class Initialized
DEBUG - 2014-08-20 18:32:17 --> Security Class Initialized
DEBUG - 2014-08-20 18:32:17 --> Input Class Initialized
DEBUG - 2014-08-20 18:32:17 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:17 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:17 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:17 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:17 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:17 --> CRSF cookie Set
DEBUG - 2014-08-20 18:32:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:32:17 --> Language Class Initialized
DEBUG - 2014-08-20 18:32:17 --> Loader Class Initialized
DEBUG - 2014-08-20 18:32:17 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:32:17 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:32:17 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:32:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:32:17 --> Session Class Initialized
DEBUG - 2014-08-20 18:32:17 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:32:17 --> Session routines successfully run
DEBUG - 2014-08-20 18:32:17 --> Controller Class Initialized
DEBUG - 2014-08-20 18:32:17 --> Final output sent to browser
DEBUG - 2014-08-20 18:32:17 --> Total execution time: 0.1072
DEBUG - 2014-08-20 18:32:19 --> Config Class Initialized
DEBUG - 2014-08-20 18:32:19 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:32:19 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:32:19 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:32:19 --> URI Class Initialized
DEBUG - 2014-08-20 18:32:19 --> Router Class Initialized
DEBUG - 2014-08-20 18:32:19 --> Output Class Initialized
DEBUG - 2014-08-20 18:32:19 --> Security Class Initialized
DEBUG - 2014-08-20 18:32:19 --> Input Class Initialized
DEBUG - 2014-08-20 18:32:19 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:19 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:19 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:19 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:19 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:19 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:31 --> Config Class Initialized
DEBUG - 2014-08-20 18:32:31 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:32:31 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:32:31 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:32:31 --> URI Class Initialized
DEBUG - 2014-08-20 18:32:31 --> Router Class Initialized
DEBUG - 2014-08-20 18:32:31 --> Output Class Initialized
DEBUG - 2014-08-20 18:32:31 --> Security Class Initialized
DEBUG - 2014-08-20 18:32:31 --> Input Class Initialized
DEBUG - 2014-08-20 18:32:31 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:31 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:31 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:31 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:31 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:31 --> CRSF cookie Set
DEBUG - 2014-08-20 18:32:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:32:31 --> Language Class Initialized
DEBUG - 2014-08-20 18:32:31 --> Loader Class Initialized
DEBUG - 2014-08-20 18:32:31 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:32:31 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:32:31 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:32:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:32:31 --> Session Class Initialized
DEBUG - 2014-08-20 18:32:31 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:32:31 --> Session routines successfully run
DEBUG - 2014-08-20 18:32:31 --> Controller Class Initialized
DEBUG - 2014-08-20 18:32:31 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 18:32:31 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-20 18:32:31 --> Encrypt Class Initialized
DEBUG - 2014-08-20 18:32:31 --> Model Class Initialized
DEBUG - 2014-08-20 18:32:31 --> Model Class Initialized
DEBUG - 2014-08-20 18:32:31 --> Model Class Initialized
DEBUG - 2014-08-20 18:32:32 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-20 18:32:32 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 18:32:32 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 18:32:32 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-20 18:32:32 --> Final output sent to browser
DEBUG - 2014-08-20 18:32:32 --> Total execution time: 0.1738
DEBUG - 2014-08-20 18:32:32 --> Config Class Initialized
DEBUG - 2014-08-20 18:32:32 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:32:32 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:32:32 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:32:32 --> URI Class Initialized
DEBUG - 2014-08-20 18:32:32 --> Router Class Initialized
DEBUG - 2014-08-20 18:32:32 --> Output Class Initialized
DEBUG - 2014-08-20 18:32:32 --> Security Class Initialized
DEBUG - 2014-08-20 18:32:32 --> Input Class Initialized
DEBUG - 2014-08-20 18:32:32 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:32 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:32 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:32 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:32 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:32 --> CRSF cookie Set
DEBUG - 2014-08-20 18:32:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:32:32 --> Language Class Initialized
DEBUG - 2014-08-20 18:32:32 --> Loader Class Initialized
DEBUG - 2014-08-20 18:32:32 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:32:32 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:32:32 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:32:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:32:32 --> Session Class Initialized
DEBUG - 2014-08-20 18:32:32 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:32:32 --> Session routines successfully run
DEBUG - 2014-08-20 18:32:32 --> Controller Class Initialized
DEBUG - 2014-08-20 18:32:32 --> Final output sent to browser
DEBUG - 2014-08-20 18:32:33 --> Total execution time: 0.1011
DEBUG - 2014-08-20 18:32:36 --> Config Class Initialized
DEBUG - 2014-08-20 18:32:36 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:32:36 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:32:36 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:32:36 --> URI Class Initialized
DEBUG - 2014-08-20 18:32:36 --> Router Class Initialized
DEBUG - 2014-08-20 18:32:36 --> Output Class Initialized
DEBUG - 2014-08-20 18:32:36 --> Security Class Initialized
DEBUG - 2014-08-20 18:32:36 --> Input Class Initialized
DEBUG - 2014-08-20 18:32:36 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:36 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:36 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:36 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:36 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:36 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:43 --> Config Class Initialized
DEBUG - 2014-08-20 18:32:43 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:32:43 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:32:43 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:32:43 --> URI Class Initialized
DEBUG - 2014-08-20 18:32:43 --> Router Class Initialized
DEBUG - 2014-08-20 18:32:43 --> Output Class Initialized
DEBUG - 2014-08-20 18:32:43 --> Security Class Initialized
DEBUG - 2014-08-20 18:32:43 --> Input Class Initialized
DEBUG - 2014-08-20 18:32:43 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:43 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:43 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:43 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:43 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:43 --> CRSF cookie Set
DEBUG - 2014-08-20 18:32:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:32:43 --> Language Class Initialized
DEBUG - 2014-08-20 18:32:43 --> Loader Class Initialized
DEBUG - 2014-08-20 18:32:43 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:32:43 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:32:43 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:32:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:32:43 --> Session Class Initialized
DEBUG - 2014-08-20 18:32:43 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:32:43 --> Session routines successfully run
DEBUG - 2014-08-20 18:32:43 --> Controller Class Initialized
DEBUG - 2014-08-20 18:32:43 --> Final output sent to browser
DEBUG - 2014-08-20 18:32:43 --> Total execution time: 0.0963
DEBUG - 2014-08-20 18:32:53 --> Config Class Initialized
DEBUG - 2014-08-20 18:32:53 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:32:53 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:32:53 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:32:53 --> URI Class Initialized
DEBUG - 2014-08-20 18:32:53 --> Router Class Initialized
DEBUG - 2014-08-20 18:32:53 --> Output Class Initialized
DEBUG - 2014-08-20 18:32:53 --> Security Class Initialized
DEBUG - 2014-08-20 18:32:53 --> Input Class Initialized
DEBUG - 2014-08-20 18:32:53 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:53 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:53 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:53 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:53 --> XSS Filtering completed
DEBUG - 2014-08-20 18:32:53 --> CRSF cookie Set
DEBUG - 2014-08-20 18:32:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:32:53 --> Language Class Initialized
DEBUG - 2014-08-20 18:32:53 --> Loader Class Initialized
DEBUG - 2014-08-20 18:32:53 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:32:53 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:32:53 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:32:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:32:53 --> Session Class Initialized
DEBUG - 2014-08-20 18:32:53 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:32:53 --> Session routines successfully run
DEBUG - 2014-08-20 18:32:53 --> Controller Class Initialized
DEBUG - 2014-08-20 18:32:53 --> Final output sent to browser
DEBUG - 2014-08-20 18:32:53 --> Total execution time: 0.0785
DEBUG - 2014-08-20 18:33:03 --> Config Class Initialized
DEBUG - 2014-08-20 18:33:03 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:33:03 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:33:03 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:33:03 --> URI Class Initialized
DEBUG - 2014-08-20 18:33:03 --> Router Class Initialized
DEBUG - 2014-08-20 18:33:03 --> Output Class Initialized
DEBUG - 2014-08-20 18:33:03 --> Security Class Initialized
DEBUG - 2014-08-20 18:33:03 --> Input Class Initialized
DEBUG - 2014-08-20 18:33:03 --> XSS Filtering completed
DEBUG - 2014-08-20 18:33:03 --> XSS Filtering completed
DEBUG - 2014-08-20 18:33:03 --> XSS Filtering completed
DEBUG - 2014-08-20 18:33:03 --> XSS Filtering completed
DEBUG - 2014-08-20 18:33:03 --> XSS Filtering completed
DEBUG - 2014-08-20 18:33:03 --> XSS Filtering completed
DEBUG - 2014-08-20 18:33:06 --> Config Class Initialized
DEBUG - 2014-08-20 18:33:06 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:33:06 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:33:06 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:33:06 --> URI Class Initialized
DEBUG - 2014-08-20 18:33:06 --> Router Class Initialized
DEBUG - 2014-08-20 18:33:06 --> Output Class Initialized
DEBUG - 2014-08-20 18:33:06 --> Security Class Initialized
DEBUG - 2014-08-20 18:33:06 --> Input Class Initialized
DEBUG - 2014-08-20 18:33:06 --> XSS Filtering completed
DEBUG - 2014-08-20 18:33:06 --> XSS Filtering completed
DEBUG - 2014-08-20 18:33:06 --> XSS Filtering completed
DEBUG - 2014-08-20 18:33:06 --> XSS Filtering completed
DEBUG - 2014-08-20 18:33:06 --> XSS Filtering completed
DEBUG - 2014-08-20 18:33:06 --> XSS Filtering completed
DEBUG - 2014-08-20 18:33:08 --> Config Class Initialized
DEBUG - 2014-08-20 18:33:08 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:33:08 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:33:08 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:33:08 --> URI Class Initialized
DEBUG - 2014-08-20 18:33:08 --> Router Class Initialized
DEBUG - 2014-08-20 18:33:08 --> Output Class Initialized
DEBUG - 2014-08-20 18:33:08 --> Security Class Initialized
DEBUG - 2014-08-20 18:33:08 --> Input Class Initialized
DEBUG - 2014-08-20 18:33:08 --> XSS Filtering completed
DEBUG - 2014-08-20 18:33:08 --> XSS Filtering completed
DEBUG - 2014-08-20 18:33:08 --> XSS Filtering completed
DEBUG - 2014-08-20 18:33:08 --> XSS Filtering completed
DEBUG - 2014-08-20 18:33:08 --> XSS Filtering completed
DEBUG - 2014-08-20 18:33:08 --> XSS Filtering completed
DEBUG - 2014-08-20 18:33:09 --> Config Class Initialized
DEBUG - 2014-08-20 18:33:09 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:33:09 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:33:09 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:33:09 --> URI Class Initialized
DEBUG - 2014-08-20 18:33:09 --> Router Class Initialized
DEBUG - 2014-08-20 18:33:09 --> Output Class Initialized
DEBUG - 2014-08-20 18:33:09 --> Security Class Initialized
DEBUG - 2014-08-20 18:33:09 --> Input Class Initialized
DEBUG - 2014-08-20 18:33:09 --> XSS Filtering completed
DEBUG - 2014-08-20 18:33:09 --> XSS Filtering completed
DEBUG - 2014-08-20 18:33:09 --> XSS Filtering completed
DEBUG - 2014-08-20 18:33:09 --> XSS Filtering completed
DEBUG - 2014-08-20 18:33:09 --> XSS Filtering completed
DEBUG - 2014-08-20 18:33:09 --> XSS Filtering completed
DEBUG - 2014-08-20 18:33:22 --> Config Class Initialized
DEBUG - 2014-08-20 18:33:22 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:33:22 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:33:22 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:33:22 --> URI Class Initialized
DEBUG - 2014-08-20 18:33:22 --> Router Class Initialized
DEBUG - 2014-08-20 18:33:22 --> Output Class Initialized
DEBUG - 2014-08-20 18:33:22 --> Security Class Initialized
DEBUG - 2014-08-20 18:33:22 --> Input Class Initialized
DEBUG - 2014-08-20 18:33:22 --> XSS Filtering completed
DEBUG - 2014-08-20 18:33:22 --> XSS Filtering completed
DEBUG - 2014-08-20 18:33:22 --> XSS Filtering completed
DEBUG - 2014-08-20 18:33:22 --> XSS Filtering completed
DEBUG - 2014-08-20 18:33:22 --> XSS Filtering completed
DEBUG - 2014-08-20 18:33:22 --> XSS Filtering completed
DEBUG - 2014-08-20 18:42:29 --> Config Class Initialized
DEBUG - 2014-08-20 18:42:29 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:42:29 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:42:29 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:42:29 --> URI Class Initialized
DEBUG - 2014-08-20 18:42:29 --> Router Class Initialized
DEBUG - 2014-08-20 18:42:29 --> Output Class Initialized
DEBUG - 2014-08-20 18:42:29 --> Security Class Initialized
DEBUG - 2014-08-20 18:42:29 --> Input Class Initialized
DEBUG - 2014-08-20 18:42:29 --> XSS Filtering completed
DEBUG - 2014-08-20 18:42:29 --> XSS Filtering completed
DEBUG - 2014-08-20 18:42:29 --> XSS Filtering completed
DEBUG - 2014-08-20 18:42:29 --> XSS Filtering completed
DEBUG - 2014-08-20 18:42:29 --> XSS Filtering completed
DEBUG - 2014-08-20 18:42:29 --> XSS Filtering completed
DEBUG - 2014-08-20 18:48:27 --> Config Class Initialized
DEBUG - 2014-08-20 18:48:27 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:48:27 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:48:27 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:48:27 --> URI Class Initialized
DEBUG - 2014-08-20 18:48:27 --> Router Class Initialized
DEBUG - 2014-08-20 18:48:27 --> Output Class Initialized
DEBUG - 2014-08-20 18:48:27 --> Security Class Initialized
DEBUG - 2014-08-20 18:48:27 --> Input Class Initialized
DEBUG - 2014-08-20 18:48:27 --> XSS Filtering completed
DEBUG - 2014-08-20 18:48:27 --> XSS Filtering completed
DEBUG - 2014-08-20 18:48:27 --> XSS Filtering completed
DEBUG - 2014-08-20 18:48:27 --> XSS Filtering completed
DEBUG - 2014-08-20 18:48:27 --> XSS Filtering completed
DEBUG - 2014-08-20 18:48:27 --> CRSF cookie Set
DEBUG - 2014-08-20 18:48:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:48:27 --> Language Class Initialized
DEBUG - 2014-08-20 18:48:27 --> Loader Class Initialized
DEBUG - 2014-08-20 18:48:27 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:48:27 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:48:27 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:48:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:48:27 --> Session Class Initialized
DEBUG - 2014-08-20 18:48:27 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:48:27 --> Session routines successfully run
DEBUG - 2014-08-20 18:48:27 --> Controller Class Initialized
DEBUG - 2014-08-20 18:48:27 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 18:48:27 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-20 18:48:27 --> Encrypt Class Initialized
DEBUG - 2014-08-20 18:48:27 --> Model Class Initialized
DEBUG - 2014-08-20 18:48:27 --> Model Class Initialized
DEBUG - 2014-08-20 18:48:27 --> Model Class Initialized
DEBUG - 2014-08-20 18:48:27 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-20 18:48:27 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 18:48:27 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 18:48:27 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-20 18:48:27 --> Final output sent to browser
DEBUG - 2014-08-20 18:48:27 --> Total execution time: 0.1517
DEBUG - 2014-08-20 18:48:28 --> Config Class Initialized
DEBUG - 2014-08-20 18:48:28 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:48:28 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:48:28 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:48:28 --> URI Class Initialized
DEBUG - 2014-08-20 18:48:28 --> Router Class Initialized
DEBUG - 2014-08-20 18:48:28 --> Output Class Initialized
DEBUG - 2014-08-20 18:48:28 --> Security Class Initialized
DEBUG - 2014-08-20 18:48:28 --> Input Class Initialized
DEBUG - 2014-08-20 18:48:28 --> XSS Filtering completed
DEBUG - 2014-08-20 18:48:28 --> XSS Filtering completed
DEBUG - 2014-08-20 18:48:28 --> XSS Filtering completed
DEBUG - 2014-08-20 18:48:28 --> XSS Filtering completed
DEBUG - 2014-08-20 18:48:28 --> XSS Filtering completed
DEBUG - 2014-08-20 18:48:28 --> CRSF cookie Set
DEBUG - 2014-08-20 18:48:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:48:28 --> Language Class Initialized
DEBUG - 2014-08-20 18:48:28 --> Loader Class Initialized
DEBUG - 2014-08-20 18:48:28 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:48:28 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:48:28 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:48:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:48:28 --> Session Class Initialized
DEBUG - 2014-08-20 18:48:28 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:48:28 --> Session routines successfully run
DEBUG - 2014-08-20 18:48:28 --> Controller Class Initialized
DEBUG - 2014-08-20 18:48:28 --> Final output sent to browser
DEBUG - 2014-08-20 18:48:28 --> Total execution time: 0.1325
DEBUG - 2014-08-20 18:48:30 --> Config Class Initialized
DEBUG - 2014-08-20 18:48:30 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:48:30 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:48:30 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:48:30 --> URI Class Initialized
DEBUG - 2014-08-20 18:48:30 --> Router Class Initialized
DEBUG - 2014-08-20 18:48:30 --> Output Class Initialized
DEBUG - 2014-08-20 18:48:30 --> Security Class Initialized
DEBUG - 2014-08-20 18:48:30 --> Input Class Initialized
DEBUG - 2014-08-20 18:48:30 --> XSS Filtering completed
DEBUG - 2014-08-20 18:48:30 --> XSS Filtering completed
DEBUG - 2014-08-20 18:48:30 --> XSS Filtering completed
DEBUG - 2014-08-20 18:48:30 --> XSS Filtering completed
DEBUG - 2014-08-20 18:48:30 --> XSS Filtering completed
DEBUG - 2014-08-20 18:48:30 --> XSS Filtering completed
DEBUG - 2014-08-20 18:49:57 --> Config Class Initialized
DEBUG - 2014-08-20 18:49:57 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:49:57 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:49:57 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:49:57 --> URI Class Initialized
DEBUG - 2014-08-20 18:49:57 --> Router Class Initialized
DEBUG - 2014-08-20 18:49:57 --> Output Class Initialized
DEBUG - 2014-08-20 18:49:57 --> Security Class Initialized
DEBUG - 2014-08-20 18:49:57 --> Input Class Initialized
DEBUG - 2014-08-20 18:49:57 --> XSS Filtering completed
DEBUG - 2014-08-20 18:49:57 --> XSS Filtering completed
DEBUG - 2014-08-20 18:49:57 --> XSS Filtering completed
DEBUG - 2014-08-20 18:49:57 --> XSS Filtering completed
DEBUG - 2014-08-20 18:49:57 --> XSS Filtering completed
DEBUG - 2014-08-20 18:49:57 --> CRSF cookie Set
DEBUG - 2014-08-20 18:49:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:49:57 --> Language Class Initialized
DEBUG - 2014-08-20 18:49:57 --> Loader Class Initialized
DEBUG - 2014-08-20 18:49:57 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:49:57 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:49:57 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:49:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:49:57 --> Session Class Initialized
DEBUG - 2014-08-20 18:49:57 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:49:57 --> Session routines successfully run
DEBUG - 2014-08-20 18:49:57 --> Controller Class Initialized
DEBUG - 2014-08-20 18:49:57 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 18:49:57 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-20 18:49:57 --> Encrypt Class Initialized
DEBUG - 2014-08-20 18:49:57 --> Model Class Initialized
DEBUG - 2014-08-20 18:49:57 --> Model Class Initialized
DEBUG - 2014-08-20 18:49:57 --> Model Class Initialized
DEBUG - 2014-08-20 18:49:57 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-20 18:49:57 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 18:49:57 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 18:49:57 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-20 18:49:57 --> Final output sent to browser
DEBUG - 2014-08-20 18:49:57 --> Total execution time: 0.1671
DEBUG - 2014-08-20 18:49:58 --> Config Class Initialized
DEBUG - 2014-08-20 18:49:58 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:49:58 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:49:58 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:49:58 --> URI Class Initialized
DEBUG - 2014-08-20 18:49:58 --> Router Class Initialized
DEBUG - 2014-08-20 18:49:58 --> Output Class Initialized
DEBUG - 2014-08-20 18:49:58 --> Security Class Initialized
DEBUG - 2014-08-20 18:49:58 --> Input Class Initialized
DEBUG - 2014-08-20 18:49:58 --> XSS Filtering completed
DEBUG - 2014-08-20 18:49:58 --> XSS Filtering completed
DEBUG - 2014-08-20 18:49:58 --> XSS Filtering completed
DEBUG - 2014-08-20 18:49:58 --> XSS Filtering completed
DEBUG - 2014-08-20 18:49:58 --> XSS Filtering completed
DEBUG - 2014-08-20 18:49:58 --> XSS Filtering completed
DEBUG - 2014-08-20 18:49:58 --> CRSF cookie Set
DEBUG - 2014-08-20 18:49:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:49:58 --> Language Class Initialized
DEBUG - 2014-08-20 18:49:58 --> Loader Class Initialized
DEBUG - 2014-08-20 18:49:58 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:49:58 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:49:58 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:49:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:49:58 --> Session Class Initialized
DEBUG - 2014-08-20 18:49:58 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:49:58 --> Session routines successfully run
DEBUG - 2014-08-20 18:49:58 --> Controller Class Initialized
DEBUG - 2014-08-20 18:49:58 --> Final output sent to browser
DEBUG - 2014-08-20 18:49:58 --> Total execution time: 0.1220
DEBUG - 2014-08-20 18:50:00 --> Config Class Initialized
DEBUG - 2014-08-20 18:50:00 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:50:00 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:50:00 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:50:00 --> URI Class Initialized
DEBUG - 2014-08-20 18:50:00 --> Router Class Initialized
DEBUG - 2014-08-20 18:50:00 --> Output Class Initialized
DEBUG - 2014-08-20 18:50:00 --> Security Class Initialized
DEBUG - 2014-08-20 18:50:00 --> Input Class Initialized
DEBUG - 2014-08-20 18:50:00 --> XSS Filtering completed
DEBUG - 2014-08-20 18:50:00 --> XSS Filtering completed
DEBUG - 2014-08-20 18:50:00 --> XSS Filtering completed
DEBUG - 2014-08-20 18:50:00 --> XSS Filtering completed
DEBUG - 2014-08-20 18:50:00 --> XSS Filtering completed
DEBUG - 2014-08-20 18:50:00 --> XSS Filtering completed
DEBUG - 2014-08-20 18:50:00 --> XSS Filtering completed
DEBUG - 2014-08-20 18:50:19 --> Config Class Initialized
DEBUG - 2014-08-20 18:50:19 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:50:19 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:50:19 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:50:19 --> URI Class Initialized
DEBUG - 2014-08-20 18:50:19 --> Router Class Initialized
DEBUG - 2014-08-20 18:50:19 --> Output Class Initialized
DEBUG - 2014-08-20 18:50:19 --> Security Class Initialized
DEBUG - 2014-08-20 18:50:19 --> Input Class Initialized
DEBUG - 2014-08-20 18:50:19 --> XSS Filtering completed
DEBUG - 2014-08-20 18:50:19 --> XSS Filtering completed
DEBUG - 2014-08-20 18:50:19 --> XSS Filtering completed
DEBUG - 2014-08-20 18:50:19 --> XSS Filtering completed
DEBUG - 2014-08-20 18:50:19 --> XSS Filtering completed
DEBUG - 2014-08-20 18:50:19 --> XSS Filtering completed
DEBUG - 2014-08-20 18:50:19 --> XSS Filtering completed
DEBUG - 2014-08-20 18:51:14 --> Config Class Initialized
DEBUG - 2014-08-20 18:51:14 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:51:14 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:51:14 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:51:14 --> URI Class Initialized
DEBUG - 2014-08-20 18:51:14 --> Router Class Initialized
DEBUG - 2014-08-20 18:51:14 --> Output Class Initialized
DEBUG - 2014-08-20 18:51:14 --> Security Class Initialized
DEBUG - 2014-08-20 18:51:14 --> Input Class Initialized
DEBUG - 2014-08-20 18:51:14 --> XSS Filtering completed
DEBUG - 2014-08-20 18:51:14 --> XSS Filtering completed
DEBUG - 2014-08-20 18:51:14 --> XSS Filtering completed
DEBUG - 2014-08-20 18:51:14 --> XSS Filtering completed
DEBUG - 2014-08-20 18:51:14 --> XSS Filtering completed
DEBUG - 2014-08-20 18:51:14 --> XSS Filtering completed
DEBUG - 2014-08-20 18:51:14 --> CRSF cookie Set
DEBUG - 2014-08-20 18:51:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:51:14 --> Language Class Initialized
DEBUG - 2014-08-20 18:51:14 --> Loader Class Initialized
DEBUG - 2014-08-20 18:51:14 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:51:14 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:51:14 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:51:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:51:14 --> Session Class Initialized
DEBUG - 2014-08-20 18:51:14 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:51:14 --> Session routines successfully run
DEBUG - 2014-08-20 18:51:14 --> Controller Class Initialized
DEBUG - 2014-08-20 18:51:14 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 18:51:14 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-20 18:51:14 --> Encrypt Class Initialized
DEBUG - 2014-08-20 18:51:14 --> Model Class Initialized
DEBUG - 2014-08-20 18:51:14 --> Model Class Initialized
DEBUG - 2014-08-20 18:51:14 --> Model Class Initialized
DEBUG - 2014-08-20 18:51:14 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-20 18:51:14 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 18:51:14 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 18:51:14 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-20 18:51:14 --> Final output sent to browser
DEBUG - 2014-08-20 18:51:14 --> Total execution time: 0.1513
DEBUG - 2014-08-20 18:51:15 --> Config Class Initialized
DEBUG - 2014-08-20 18:51:15 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:51:15 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:51:15 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:51:15 --> URI Class Initialized
DEBUG - 2014-08-20 18:51:15 --> Router Class Initialized
DEBUG - 2014-08-20 18:51:15 --> Output Class Initialized
DEBUG - 2014-08-20 18:51:15 --> Security Class Initialized
DEBUG - 2014-08-20 18:51:15 --> Input Class Initialized
DEBUG - 2014-08-20 18:51:15 --> XSS Filtering completed
DEBUG - 2014-08-20 18:51:15 --> XSS Filtering completed
DEBUG - 2014-08-20 18:51:15 --> XSS Filtering completed
DEBUG - 2014-08-20 18:51:15 --> XSS Filtering completed
DEBUG - 2014-08-20 18:51:15 --> XSS Filtering completed
DEBUG - 2014-08-20 18:51:15 --> XSS Filtering completed
DEBUG - 2014-08-20 18:51:15 --> CRSF cookie Set
DEBUG - 2014-08-20 18:51:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:51:15 --> Language Class Initialized
DEBUG - 2014-08-20 18:51:15 --> Loader Class Initialized
DEBUG - 2014-08-20 18:51:15 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:51:15 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:51:15 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:51:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:51:15 --> Session Class Initialized
DEBUG - 2014-08-20 18:51:15 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:51:15 --> Session routines successfully run
DEBUG - 2014-08-20 18:51:15 --> Controller Class Initialized
DEBUG - 2014-08-20 18:51:15 --> Final output sent to browser
DEBUG - 2014-08-20 18:51:15 --> Total execution time: 0.1218
DEBUG - 2014-08-20 18:51:18 --> Config Class Initialized
DEBUG - 2014-08-20 18:51:18 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:51:18 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:51:18 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:51:18 --> URI Class Initialized
DEBUG - 2014-08-20 18:51:18 --> Router Class Initialized
DEBUG - 2014-08-20 18:51:18 --> Output Class Initialized
DEBUG - 2014-08-20 18:51:18 --> Security Class Initialized
DEBUG - 2014-08-20 18:51:18 --> Input Class Initialized
DEBUG - 2014-08-20 18:51:18 --> XSS Filtering completed
DEBUG - 2014-08-20 18:51:18 --> XSS Filtering completed
DEBUG - 2014-08-20 18:51:18 --> XSS Filtering completed
DEBUG - 2014-08-20 18:51:18 --> XSS Filtering completed
DEBUG - 2014-08-20 18:51:18 --> XSS Filtering completed
DEBUG - 2014-08-20 18:51:18 --> XSS Filtering completed
DEBUG - 2014-08-20 18:51:18 --> XSS Filtering completed
DEBUG - 2014-08-20 18:52:07 --> Config Class Initialized
DEBUG - 2014-08-20 18:52:07 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:52:07 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:52:07 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:52:07 --> URI Class Initialized
DEBUG - 2014-08-20 18:52:07 --> Router Class Initialized
DEBUG - 2014-08-20 18:52:07 --> Output Class Initialized
DEBUG - 2014-08-20 18:52:07 --> Security Class Initialized
DEBUG - 2014-08-20 18:52:07 --> Input Class Initialized
DEBUG - 2014-08-20 18:52:07 --> XSS Filtering completed
DEBUG - 2014-08-20 18:52:07 --> XSS Filtering completed
DEBUG - 2014-08-20 18:52:07 --> XSS Filtering completed
DEBUG - 2014-08-20 18:52:07 --> XSS Filtering completed
DEBUG - 2014-08-20 18:52:07 --> XSS Filtering completed
DEBUG - 2014-08-20 18:52:07 --> XSS Filtering completed
DEBUG - 2014-08-20 18:52:07 --> CRSF cookie Set
DEBUG - 2014-08-20 18:52:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:52:07 --> Language Class Initialized
DEBUG - 2014-08-20 18:52:07 --> Loader Class Initialized
DEBUG - 2014-08-20 18:52:07 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:52:07 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:52:07 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:52:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:52:07 --> Session Class Initialized
DEBUG - 2014-08-20 18:52:07 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:52:07 --> Session routines successfully run
DEBUG - 2014-08-20 18:52:07 --> Controller Class Initialized
DEBUG - 2014-08-20 18:52:07 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 18:52:07 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-20 18:52:07 --> Encrypt Class Initialized
DEBUG - 2014-08-20 18:52:07 --> Model Class Initialized
DEBUG - 2014-08-20 18:52:07 --> Model Class Initialized
DEBUG - 2014-08-20 18:52:07 --> Model Class Initialized
DEBUG - 2014-08-20 18:52:07 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-20 18:52:07 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 18:52:07 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 18:52:07 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-20 18:52:07 --> Final output sent to browser
DEBUG - 2014-08-20 18:52:07 --> Total execution time: 0.1642
DEBUG - 2014-08-20 18:52:08 --> Config Class Initialized
DEBUG - 2014-08-20 18:52:08 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:52:08 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:52:08 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:52:08 --> URI Class Initialized
DEBUG - 2014-08-20 18:52:08 --> Router Class Initialized
DEBUG - 2014-08-20 18:52:08 --> Output Class Initialized
DEBUG - 2014-08-20 18:52:08 --> Security Class Initialized
DEBUG - 2014-08-20 18:52:08 --> Input Class Initialized
DEBUG - 2014-08-20 18:52:08 --> XSS Filtering completed
DEBUG - 2014-08-20 18:52:08 --> XSS Filtering completed
DEBUG - 2014-08-20 18:52:08 --> XSS Filtering completed
DEBUG - 2014-08-20 18:52:08 --> XSS Filtering completed
DEBUG - 2014-08-20 18:52:08 --> XSS Filtering completed
DEBUG - 2014-08-20 18:52:08 --> XSS Filtering completed
DEBUG - 2014-08-20 18:52:08 --> XSS Filtering completed
DEBUG - 2014-08-20 18:52:08 --> CRSF cookie Set
DEBUG - 2014-08-20 18:52:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:52:08 --> Language Class Initialized
DEBUG - 2014-08-20 18:52:08 --> Loader Class Initialized
DEBUG - 2014-08-20 18:52:08 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:52:08 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:52:08 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:52:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:52:08 --> Session Class Initialized
DEBUG - 2014-08-20 18:52:08 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:52:08 --> Session routines successfully run
DEBUG - 2014-08-20 18:52:08 --> Controller Class Initialized
DEBUG - 2014-08-20 18:52:08 --> Final output sent to browser
DEBUG - 2014-08-20 18:52:08 --> Total execution time: 0.1221
DEBUG - 2014-08-20 18:53:16 --> Config Class Initialized
DEBUG - 2014-08-20 18:53:16 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:53:16 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:53:16 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:53:16 --> URI Class Initialized
DEBUG - 2014-08-20 18:53:16 --> Router Class Initialized
DEBUG - 2014-08-20 18:53:16 --> Output Class Initialized
DEBUG - 2014-08-20 18:53:16 --> Security Class Initialized
DEBUG - 2014-08-20 18:53:16 --> Input Class Initialized
DEBUG - 2014-08-20 18:53:16 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:16 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:16 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:16 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:16 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:16 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:16 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:16 --> CRSF cookie Set
DEBUG - 2014-08-20 18:53:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:53:16 --> Language Class Initialized
DEBUG - 2014-08-20 18:53:16 --> Loader Class Initialized
DEBUG - 2014-08-20 18:53:16 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:53:16 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:53:16 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:53:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:53:16 --> Session Class Initialized
DEBUG - 2014-08-20 18:53:16 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:53:16 --> Session routines successfully run
DEBUG - 2014-08-20 18:53:16 --> Controller Class Initialized
DEBUG - 2014-08-20 18:53:16 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 18:53:16 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-20 18:53:16 --> Encrypt Class Initialized
DEBUG - 2014-08-20 18:53:16 --> Model Class Initialized
DEBUG - 2014-08-20 18:53:16 --> Model Class Initialized
DEBUG - 2014-08-20 18:53:16 --> Model Class Initialized
DEBUG - 2014-08-20 18:53:16 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-20 18:53:16 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 18:53:16 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 18:53:16 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-20 18:53:16 --> Final output sent to browser
DEBUG - 2014-08-20 18:53:16 --> Total execution time: 0.1674
DEBUG - 2014-08-20 18:53:17 --> Config Class Initialized
DEBUG - 2014-08-20 18:53:17 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:53:17 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:53:17 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:53:17 --> URI Class Initialized
DEBUG - 2014-08-20 18:53:17 --> Router Class Initialized
DEBUG - 2014-08-20 18:53:17 --> Output Class Initialized
DEBUG - 2014-08-20 18:53:17 --> Security Class Initialized
DEBUG - 2014-08-20 18:53:17 --> Input Class Initialized
DEBUG - 2014-08-20 18:53:17 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:17 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:17 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:17 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:17 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:17 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:17 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:17 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:17 --> CRSF cookie Set
DEBUG - 2014-08-20 18:53:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:53:17 --> Language Class Initialized
DEBUG - 2014-08-20 18:53:17 --> Loader Class Initialized
DEBUG - 2014-08-20 18:53:17 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:53:17 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:53:17 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:53:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:53:17 --> Session Class Initialized
DEBUG - 2014-08-20 18:53:17 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:53:17 --> Session routines successfully run
DEBUG - 2014-08-20 18:53:17 --> Controller Class Initialized
DEBUG - 2014-08-20 18:53:17 --> Final output sent to browser
DEBUG - 2014-08-20 18:53:17 --> Total execution time: 0.1270
DEBUG - 2014-08-20 18:53:22 --> Config Class Initialized
DEBUG - 2014-08-20 18:53:22 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:53:22 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:53:22 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:53:22 --> URI Class Initialized
DEBUG - 2014-08-20 18:53:22 --> Router Class Initialized
DEBUG - 2014-08-20 18:53:22 --> Output Class Initialized
DEBUG - 2014-08-20 18:53:22 --> Security Class Initialized
DEBUG - 2014-08-20 18:53:22 --> Input Class Initialized
DEBUG - 2014-08-20 18:53:22 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:22 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:22 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:22 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:22 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:22 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:22 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:22 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:22 --> CRSF cookie Set
DEBUG - 2014-08-20 18:53:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:53:22 --> Language Class Initialized
DEBUG - 2014-08-20 18:53:22 --> Loader Class Initialized
DEBUG - 2014-08-20 18:53:22 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:53:22 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:53:22 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:53:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:53:22 --> Session Class Initialized
DEBUG - 2014-08-20 18:53:22 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:53:22 --> Session routines successfully run
DEBUG - 2014-08-20 18:53:22 --> Controller Class Initialized
DEBUG - 2014-08-20 18:53:22 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 18:53:22 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-20 18:53:22 --> Encrypt Class Initialized
DEBUG - 2014-08-20 18:53:22 --> Model Class Initialized
DEBUG - 2014-08-20 18:53:22 --> Model Class Initialized
DEBUG - 2014-08-20 18:53:22 --> Model Class Initialized
DEBUG - 2014-08-20 18:53:22 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-20 18:53:22 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 18:53:22 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 18:53:22 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-20 18:53:22 --> Final output sent to browser
DEBUG - 2014-08-20 18:53:22 --> Total execution time: 0.1628
DEBUG - 2014-08-20 18:53:23 --> Config Class Initialized
DEBUG - 2014-08-20 18:53:23 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:53:23 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:53:23 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:53:23 --> URI Class Initialized
DEBUG - 2014-08-20 18:53:23 --> Router Class Initialized
DEBUG - 2014-08-20 18:53:23 --> Output Class Initialized
DEBUG - 2014-08-20 18:53:23 --> Security Class Initialized
DEBUG - 2014-08-20 18:53:23 --> Input Class Initialized
DEBUG - 2014-08-20 18:53:23 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:23 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:23 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:23 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:23 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:23 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:23 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:23 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:23 --> CRSF cookie Set
DEBUG - 2014-08-20 18:53:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:53:23 --> Language Class Initialized
DEBUG - 2014-08-20 18:53:23 --> Loader Class Initialized
DEBUG - 2014-08-20 18:53:23 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:53:23 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:53:23 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:53:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:53:23 --> Session Class Initialized
DEBUG - 2014-08-20 18:53:23 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:53:23 --> Session routines successfully run
DEBUG - 2014-08-20 18:53:23 --> Controller Class Initialized
DEBUG - 2014-08-20 18:53:23 --> Final output sent to browser
DEBUG - 2014-08-20 18:53:23 --> Total execution time: 0.1301
DEBUG - 2014-08-20 18:53:42 --> Config Class Initialized
DEBUG - 2014-08-20 18:53:42 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:53:42 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:53:42 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:53:42 --> URI Class Initialized
DEBUG - 2014-08-20 18:53:42 --> Router Class Initialized
DEBUG - 2014-08-20 18:53:42 --> Output Class Initialized
DEBUG - 2014-08-20 18:53:42 --> Security Class Initialized
DEBUG - 2014-08-20 18:53:42 --> Input Class Initialized
DEBUG - 2014-08-20 18:53:42 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:42 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:42 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:42 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:42 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:42 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:42 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:42 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:42 --> CRSF cookie Set
DEBUG - 2014-08-20 18:53:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:53:42 --> Language Class Initialized
DEBUG - 2014-08-20 18:53:42 --> Loader Class Initialized
DEBUG - 2014-08-20 18:53:42 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:53:42 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:53:42 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:53:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:53:42 --> Session Class Initialized
DEBUG - 2014-08-20 18:53:42 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:53:42 --> Session routines successfully run
DEBUG - 2014-08-20 18:53:42 --> Controller Class Initialized
DEBUG - 2014-08-20 18:53:42 --> File loaded: application/views/logout.php
DEBUG - 2014-08-20 18:53:42 --> Final output sent to browser
DEBUG - 2014-08-20 18:53:42 --> Total execution time: 0.0935
DEBUG - 2014-08-20 18:53:42 --> Config Class Initialized
DEBUG - 2014-08-20 18:53:42 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:53:42 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:53:42 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:53:42 --> URI Class Initialized
DEBUG - 2014-08-20 18:53:42 --> Router Class Initialized
DEBUG - 2014-08-20 18:53:42 --> No URI present. Default controller set.
DEBUG - 2014-08-20 18:53:42 --> Output Class Initialized
DEBUG - 2014-08-20 18:53:42 --> Security Class Initialized
DEBUG - 2014-08-20 18:53:42 --> Input Class Initialized
DEBUG - 2014-08-20 18:53:42 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:42 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:42 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:42 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:42 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:42 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:42 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:42 --> CRSF cookie Set
DEBUG - 2014-08-20 18:53:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:53:42 --> Language Class Initialized
DEBUG - 2014-08-20 18:53:42 --> Loader Class Initialized
DEBUG - 2014-08-20 18:53:42 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:53:42 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:53:42 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:53:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:53:42 --> Session Class Initialized
DEBUG - 2014-08-20 18:53:42 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:53:42 --> A session cookie was not found.
DEBUG - 2014-08-20 18:53:42 --> Session routines successfully run
DEBUG - 2014-08-20 18:53:42 --> Controller Class Initialized
DEBUG - 2014-08-20 18:53:42 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 18:53:42 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 18:53:42 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 18:53:42 --> Helper loaded: form_helper
DEBUG - 2014-08-20 18:53:42 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 18:53:42 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-20 18:53:42 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 18:53:42 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 18:53:42 --> Final output sent to browser
DEBUG - 2014-08-20 18:53:42 --> Total execution time: 0.1335
DEBUG - 2014-08-20 18:53:52 --> Config Class Initialized
DEBUG - 2014-08-20 18:53:52 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:53:52 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:53:52 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:53:52 --> URI Class Initialized
DEBUG - 2014-08-20 18:53:52 --> Router Class Initialized
DEBUG - 2014-08-20 18:53:52 --> Output Class Initialized
DEBUG - 2014-08-20 18:53:52 --> Security Class Initialized
DEBUG - 2014-08-20 18:53:52 --> Input Class Initialized
DEBUG - 2014-08-20 18:53:52 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:52 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:52 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:52 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:52 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:52 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:52 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:52 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:52 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:52 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:52 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:52 --> CRSF cookie Set
DEBUG - 2014-08-20 18:53:52 --> CSRF token verified
DEBUG - 2014-08-20 18:53:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:53:52 --> Language Class Initialized
DEBUG - 2014-08-20 18:53:52 --> Loader Class Initialized
DEBUG - 2014-08-20 18:53:52 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:53:52 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:53:52 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:53:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:53:52 --> Session Class Initialized
DEBUG - 2014-08-20 18:53:52 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:53:52 --> Session routines successfully run
DEBUG - 2014-08-20 18:53:52 --> Controller Class Initialized
DEBUG - 2014-08-20 18:53:52 --> Helper loaded: form_helper
DEBUG - 2014-08-20 18:53:52 --> Form Validation Class Initialized
DEBUG - 2014-08-20 18:53:52 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-20 18:53:52 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:52 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:52 --> Model Class Initialized
DEBUG - 2014-08-20 18:53:52 --> Model Class Initialized
DEBUG - 2014-08-20 18:53:52 --> Model Class Initialized
DEBUG - 2014-08-20 18:53:52 --> Model Class Initialized
DEBUG - 2014-08-20 18:53:52 --> Encrypt Class Initialized
DEBUG - 2014-08-20 18:53:52 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:52 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:52 --> Config Class Initialized
DEBUG - 2014-08-20 18:53:52 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:53:52 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:53:52 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:53:52 --> URI Class Initialized
DEBUG - 2014-08-20 18:53:52 --> Router Class Initialized
DEBUG - 2014-08-20 18:53:52 --> Output Class Initialized
DEBUG - 2014-08-20 18:53:52 --> Security Class Initialized
DEBUG - 2014-08-20 18:53:52 --> Input Class Initialized
DEBUG - 2014-08-20 18:53:52 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:52 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:52 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:52 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:52 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:52 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:52 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:52 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:52 --> CRSF cookie Set
DEBUG - 2014-08-20 18:53:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:53:52 --> Language Class Initialized
DEBUG - 2014-08-20 18:53:52 --> Loader Class Initialized
DEBUG - 2014-08-20 18:53:52 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:53:52 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:53:52 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:53:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:53:52 --> Session Class Initialized
DEBUG - 2014-08-20 18:53:52 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:53:52 --> Session routines successfully run
DEBUG - 2014-08-20 18:53:52 --> Controller Class Initialized
DEBUG - 2014-08-20 18:53:52 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 18:53:52 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-20 18:53:52 --> Encrypt Class Initialized
DEBUG - 2014-08-20 18:53:52 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-20 18:53:52 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 18:53:52 --> File loaded: application/views/placement_admin_home.php
DEBUG - 2014-08-20 18:53:52 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 18:53:52 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 18:53:52 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-20 18:53:52 --> Final output sent to browser
DEBUG - 2014-08-20 18:53:52 --> Total execution time: 0.1550
DEBUG - 2014-08-20 18:53:53 --> Config Class Initialized
DEBUG - 2014-08-20 18:53:53 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:53:53 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:53:53 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:53:53 --> URI Class Initialized
DEBUG - 2014-08-20 18:53:53 --> Router Class Initialized
DEBUG - 2014-08-20 18:53:53 --> Output Class Initialized
DEBUG - 2014-08-20 18:53:53 --> Security Class Initialized
DEBUG - 2014-08-20 18:53:53 --> Input Class Initialized
DEBUG - 2014-08-20 18:53:53 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:53 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:53 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:53 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:53 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:53 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:53 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:53 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:53 --> CRSF cookie Set
DEBUG - 2014-08-20 18:53:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:53:53 --> Language Class Initialized
DEBUG - 2014-08-20 18:53:53 --> Loader Class Initialized
DEBUG - 2014-08-20 18:53:53 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:53:53 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:53:53 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:53:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:53:53 --> Session Class Initialized
DEBUG - 2014-08-20 18:53:53 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:53:53 --> Session routines successfully run
DEBUG - 2014-08-20 18:53:53 --> Controller Class Initialized
DEBUG - 2014-08-20 18:53:53 --> Final output sent to browser
DEBUG - 2014-08-20 18:53:53 --> Total execution time: 0.1279
DEBUG - 2014-08-20 18:53:56 --> Config Class Initialized
DEBUG - 2014-08-20 18:53:56 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:53:56 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:53:56 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:53:56 --> URI Class Initialized
DEBUG - 2014-08-20 18:53:56 --> Router Class Initialized
DEBUG - 2014-08-20 18:53:56 --> Output Class Initialized
DEBUG - 2014-08-20 18:53:56 --> Security Class Initialized
DEBUG - 2014-08-20 18:53:56 --> Input Class Initialized
DEBUG - 2014-08-20 18:53:56 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:56 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:56 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:56 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:56 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:56 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:56 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:56 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:56 --> CRSF cookie Set
DEBUG - 2014-08-20 18:53:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:53:56 --> Language Class Initialized
DEBUG - 2014-08-20 18:53:56 --> Loader Class Initialized
DEBUG - 2014-08-20 18:53:56 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:53:56 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:53:56 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:53:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:53:56 --> Session Class Initialized
DEBUG - 2014-08-20 18:53:56 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:53:56 --> Session routines successfully run
DEBUG - 2014-08-20 18:53:56 --> Controller Class Initialized
DEBUG - 2014-08-20 18:53:56 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 18:53:56 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-20 18:53:56 --> Encrypt Class Initialized
DEBUG - 2014-08-20 18:53:56 --> Model Class Initialized
DEBUG - 2014-08-20 18:53:56 --> Model Class Initialized
DEBUG - 2014-08-20 18:53:56 --> Model Class Initialized
DEBUG - 2014-08-20 18:53:56 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-20 18:53:56 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 18:53:56 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 18:53:56 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-20 18:53:56 --> Final output sent to browser
DEBUG - 2014-08-20 18:53:56 --> Total execution time: 0.1584
DEBUG - 2014-08-20 18:53:57 --> Config Class Initialized
DEBUG - 2014-08-20 18:53:57 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:53:57 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:53:57 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:53:57 --> URI Class Initialized
DEBUG - 2014-08-20 18:53:57 --> Router Class Initialized
DEBUG - 2014-08-20 18:53:57 --> Output Class Initialized
DEBUG - 2014-08-20 18:53:57 --> Security Class Initialized
DEBUG - 2014-08-20 18:53:57 --> Input Class Initialized
DEBUG - 2014-08-20 18:53:57 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:57 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:57 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:57 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:57 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:57 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:57 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:57 --> XSS Filtering completed
DEBUG - 2014-08-20 18:53:57 --> CRSF cookie Set
DEBUG - 2014-08-20 18:53:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:53:57 --> Language Class Initialized
DEBUG - 2014-08-20 18:53:57 --> Loader Class Initialized
DEBUG - 2014-08-20 18:53:57 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:53:57 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:53:57 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:53:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:53:57 --> Session Class Initialized
DEBUG - 2014-08-20 18:53:57 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:53:57 --> Session routines successfully run
DEBUG - 2014-08-20 18:53:57 --> Controller Class Initialized
DEBUG - 2014-08-20 18:53:57 --> Final output sent to browser
DEBUG - 2014-08-20 18:53:57 --> Total execution time: 0.1368
DEBUG - 2014-08-20 18:54:11 --> Config Class Initialized
DEBUG - 2014-08-20 18:54:11 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:54:11 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:54:11 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:54:11 --> URI Class Initialized
DEBUG - 2014-08-20 18:54:11 --> Router Class Initialized
DEBUG - 2014-08-20 18:54:11 --> Output Class Initialized
DEBUG - 2014-08-20 18:54:11 --> Security Class Initialized
DEBUG - 2014-08-20 18:54:11 --> Input Class Initialized
DEBUG - 2014-08-20 18:54:11 --> XSS Filtering completed
DEBUG - 2014-08-20 18:54:11 --> XSS Filtering completed
DEBUG - 2014-08-20 18:54:11 --> XSS Filtering completed
DEBUG - 2014-08-20 18:54:11 --> XSS Filtering completed
DEBUG - 2014-08-20 18:54:11 --> XSS Filtering completed
DEBUG - 2014-08-20 18:54:11 --> XSS Filtering completed
DEBUG - 2014-08-20 18:54:11 --> XSS Filtering completed
DEBUG - 2014-08-20 18:54:11 --> XSS Filtering completed
DEBUG - 2014-08-20 18:54:11 --> XSS Filtering completed
DEBUG - 2014-08-20 18:58:42 --> Config Class Initialized
DEBUG - 2014-08-20 18:58:42 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:58:42 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:58:42 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:58:42 --> URI Class Initialized
DEBUG - 2014-08-20 18:58:42 --> Router Class Initialized
DEBUG - 2014-08-20 18:58:42 --> Output Class Initialized
DEBUG - 2014-08-20 18:58:42 --> Security Class Initialized
DEBUG - 2014-08-20 18:58:42 --> Input Class Initialized
DEBUG - 2014-08-20 18:58:42 --> XSS Filtering completed
DEBUG - 2014-08-20 18:58:42 --> XSS Filtering completed
DEBUG - 2014-08-20 18:58:42 --> XSS Filtering completed
DEBUG - 2014-08-20 18:58:42 --> XSS Filtering completed
DEBUG - 2014-08-20 18:58:42 --> XSS Filtering completed
DEBUG - 2014-08-20 18:58:42 --> XSS Filtering completed
DEBUG - 2014-08-20 18:58:42 --> XSS Filtering completed
DEBUG - 2014-08-20 18:58:42 --> XSS Filtering completed
DEBUG - 2014-08-20 18:58:42 --> CRSF cookie Set
DEBUG - 2014-08-20 18:58:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:58:42 --> Language Class Initialized
DEBUG - 2014-08-20 18:58:42 --> Loader Class Initialized
DEBUG - 2014-08-20 18:58:42 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:58:42 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:58:42 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:58:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:58:42 --> Session Class Initialized
DEBUG - 2014-08-20 18:58:42 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:58:42 --> Session routines successfully run
DEBUG - 2014-08-20 18:58:42 --> Controller Class Initialized
DEBUG - 2014-08-20 18:58:42 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 18:58:42 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-20 18:58:42 --> Encrypt Class Initialized
DEBUG - 2014-08-20 18:58:42 --> Model Class Initialized
DEBUG - 2014-08-20 18:58:42 --> Model Class Initialized
DEBUG - 2014-08-20 18:58:42 --> Model Class Initialized
DEBUG - 2014-08-20 18:58:42 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-20 18:58:42 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 18:58:42 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 18:58:42 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-20 18:58:42 --> Final output sent to browser
DEBUG - 2014-08-20 18:58:42 --> Total execution time: 0.1723
DEBUG - 2014-08-20 18:58:43 --> Config Class Initialized
DEBUG - 2014-08-20 18:58:43 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:58:43 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:58:43 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:58:43 --> URI Class Initialized
DEBUG - 2014-08-20 18:58:43 --> Router Class Initialized
DEBUG - 2014-08-20 18:58:43 --> Output Class Initialized
DEBUG - 2014-08-20 18:58:43 --> Security Class Initialized
DEBUG - 2014-08-20 18:58:43 --> Input Class Initialized
DEBUG - 2014-08-20 18:58:43 --> XSS Filtering completed
DEBUG - 2014-08-20 18:58:43 --> XSS Filtering completed
DEBUG - 2014-08-20 18:58:43 --> XSS Filtering completed
DEBUG - 2014-08-20 18:58:43 --> XSS Filtering completed
DEBUG - 2014-08-20 18:58:43 --> XSS Filtering completed
DEBUG - 2014-08-20 18:58:43 --> XSS Filtering completed
DEBUG - 2014-08-20 18:58:43 --> XSS Filtering completed
DEBUG - 2014-08-20 18:58:43 --> XSS Filtering completed
DEBUG - 2014-08-20 18:58:43 --> CRSF cookie Set
DEBUG - 2014-08-20 18:58:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:58:43 --> Language Class Initialized
DEBUG - 2014-08-20 18:58:43 --> Loader Class Initialized
DEBUG - 2014-08-20 18:58:43 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:58:43 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:58:43 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:58:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:58:43 --> Session Class Initialized
DEBUG - 2014-08-20 18:58:43 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:58:43 --> Session routines successfully run
DEBUG - 2014-08-20 18:58:43 --> Controller Class Initialized
DEBUG - 2014-08-20 18:58:43 --> Final output sent to browser
DEBUG - 2014-08-20 18:58:43 --> Total execution time: 0.1363
DEBUG - 2014-08-20 18:58:46 --> Config Class Initialized
DEBUG - 2014-08-20 18:58:46 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:58:46 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:58:46 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:58:46 --> URI Class Initialized
DEBUG - 2014-08-20 18:58:46 --> Router Class Initialized
DEBUG - 2014-08-20 18:58:46 --> Output Class Initialized
DEBUG - 2014-08-20 18:58:46 --> Security Class Initialized
DEBUG - 2014-08-20 18:58:46 --> Input Class Initialized
DEBUG - 2014-08-20 18:58:46 --> XSS Filtering completed
DEBUG - 2014-08-20 18:58:46 --> XSS Filtering completed
DEBUG - 2014-08-20 18:58:46 --> XSS Filtering completed
DEBUG - 2014-08-20 18:58:46 --> XSS Filtering completed
DEBUG - 2014-08-20 18:58:46 --> XSS Filtering completed
DEBUG - 2014-08-20 18:58:46 --> XSS Filtering completed
DEBUG - 2014-08-20 18:58:46 --> XSS Filtering completed
DEBUG - 2014-08-20 18:58:46 --> XSS Filtering completed
DEBUG - 2014-08-20 18:59:14 --> Config Class Initialized
DEBUG - 2014-08-20 18:59:14 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:59:14 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:59:14 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:59:14 --> URI Class Initialized
DEBUG - 2014-08-20 18:59:14 --> Router Class Initialized
DEBUG - 2014-08-20 18:59:14 --> Output Class Initialized
DEBUG - 2014-08-20 18:59:14 --> Security Class Initialized
DEBUG - 2014-08-20 18:59:14 --> Input Class Initialized
DEBUG - 2014-08-20 18:59:14 --> XSS Filtering completed
DEBUG - 2014-08-20 18:59:14 --> XSS Filtering completed
DEBUG - 2014-08-20 18:59:14 --> XSS Filtering completed
DEBUG - 2014-08-20 18:59:14 --> XSS Filtering completed
DEBUG - 2014-08-20 18:59:14 --> XSS Filtering completed
DEBUG - 2014-08-20 18:59:14 --> XSS Filtering completed
DEBUG - 2014-08-20 18:59:14 --> XSS Filtering completed
DEBUG - 2014-08-20 18:59:14 --> XSS Filtering completed
DEBUG - 2014-08-20 18:59:14 --> CRSF cookie Set
DEBUG - 2014-08-20 18:59:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:59:14 --> Language Class Initialized
DEBUG - 2014-08-20 18:59:14 --> Loader Class Initialized
DEBUG - 2014-08-20 18:59:14 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:59:14 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:59:14 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:59:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:59:14 --> Session Class Initialized
DEBUG - 2014-08-20 18:59:14 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:59:14 --> Session routines successfully run
DEBUG - 2014-08-20 18:59:14 --> Controller Class Initialized
DEBUG - 2014-08-20 18:59:14 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 18:59:14 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-20 18:59:14 --> Encrypt Class Initialized
DEBUG - 2014-08-20 18:59:14 --> Model Class Initialized
DEBUG - 2014-08-20 18:59:14 --> Model Class Initialized
DEBUG - 2014-08-20 18:59:14 --> Model Class Initialized
DEBUG - 2014-08-20 18:59:14 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-20 18:59:14 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 18:59:14 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 18:59:14 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-20 18:59:14 --> Final output sent to browser
DEBUG - 2014-08-20 18:59:14 --> Total execution time: 0.1602
DEBUG - 2014-08-20 18:59:15 --> Config Class Initialized
DEBUG - 2014-08-20 18:59:15 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:59:15 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:59:15 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:59:15 --> URI Class Initialized
DEBUG - 2014-08-20 18:59:15 --> Router Class Initialized
DEBUG - 2014-08-20 18:59:15 --> Output Class Initialized
DEBUG - 2014-08-20 18:59:15 --> Security Class Initialized
DEBUG - 2014-08-20 18:59:15 --> Input Class Initialized
DEBUG - 2014-08-20 18:59:15 --> XSS Filtering completed
DEBUG - 2014-08-20 18:59:15 --> XSS Filtering completed
DEBUG - 2014-08-20 18:59:15 --> XSS Filtering completed
DEBUG - 2014-08-20 18:59:15 --> XSS Filtering completed
DEBUG - 2014-08-20 18:59:15 --> XSS Filtering completed
DEBUG - 2014-08-20 18:59:15 --> XSS Filtering completed
DEBUG - 2014-08-20 18:59:15 --> XSS Filtering completed
DEBUG - 2014-08-20 18:59:15 --> XSS Filtering completed
DEBUG - 2014-08-20 18:59:15 --> CRSF cookie Set
DEBUG - 2014-08-20 18:59:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:59:15 --> Language Class Initialized
DEBUG - 2014-08-20 18:59:15 --> Loader Class Initialized
DEBUG - 2014-08-20 18:59:15 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:59:15 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:59:15 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:59:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:59:15 --> Session Class Initialized
DEBUG - 2014-08-20 18:59:15 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:59:15 --> Session routines successfully run
DEBUG - 2014-08-20 18:59:15 --> Controller Class Initialized
DEBUG - 2014-08-20 18:59:15 --> Final output sent to browser
DEBUG - 2014-08-20 18:59:15 --> Total execution time: 0.1302
DEBUG - 2014-08-20 18:59:20 --> Config Class Initialized
DEBUG - 2014-08-20 18:59:20 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:59:20 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:59:20 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:59:20 --> URI Class Initialized
DEBUG - 2014-08-20 18:59:20 --> Router Class Initialized
DEBUG - 2014-08-20 18:59:20 --> Output Class Initialized
DEBUG - 2014-08-20 18:59:20 --> Security Class Initialized
DEBUG - 2014-08-20 18:59:20 --> Input Class Initialized
DEBUG - 2014-08-20 18:59:20 --> XSS Filtering completed
DEBUG - 2014-08-20 18:59:20 --> XSS Filtering completed
DEBUG - 2014-08-20 18:59:20 --> XSS Filtering completed
DEBUG - 2014-08-20 18:59:20 --> XSS Filtering completed
DEBUG - 2014-08-20 18:59:20 --> XSS Filtering completed
DEBUG - 2014-08-20 18:59:20 --> XSS Filtering completed
DEBUG - 2014-08-20 18:59:20 --> XSS Filtering completed
DEBUG - 2014-08-20 18:59:20 --> XSS Filtering completed
DEBUG - 2014-08-20 18:59:20 --> CRSF cookie Set
DEBUG - 2014-08-20 18:59:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:59:20 --> Language Class Initialized
DEBUG - 2014-08-20 18:59:20 --> Loader Class Initialized
DEBUG - 2014-08-20 18:59:20 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:59:20 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:59:20 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:59:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:59:20 --> Session Class Initialized
DEBUG - 2014-08-20 18:59:20 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:59:20 --> Session routines successfully run
DEBUG - 2014-08-20 18:59:20 --> Controller Class Initialized
DEBUG - 2014-08-20 18:59:20 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 18:59:20 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-20 18:59:20 --> Encrypt Class Initialized
DEBUG - 2014-08-20 18:59:20 --> Model Class Initialized
DEBUG - 2014-08-20 18:59:20 --> Model Class Initialized
DEBUG - 2014-08-20 18:59:20 --> Model Class Initialized
DEBUG - 2014-08-20 18:59:20 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-20 18:59:20 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 18:59:20 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 18:59:20 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-20 18:59:20 --> Final output sent to browser
DEBUG - 2014-08-20 18:59:20 --> Total execution time: 0.1664
DEBUG - 2014-08-20 18:59:21 --> Config Class Initialized
DEBUG - 2014-08-20 18:59:21 --> Hooks Class Initialized
DEBUG - 2014-08-20 18:59:21 --> Utf8 Class Initialized
DEBUG - 2014-08-20 18:59:21 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 18:59:21 --> URI Class Initialized
DEBUG - 2014-08-20 18:59:21 --> Router Class Initialized
DEBUG - 2014-08-20 18:59:21 --> Output Class Initialized
DEBUG - 2014-08-20 18:59:21 --> Security Class Initialized
DEBUG - 2014-08-20 18:59:21 --> Input Class Initialized
DEBUG - 2014-08-20 18:59:21 --> XSS Filtering completed
DEBUG - 2014-08-20 18:59:21 --> XSS Filtering completed
DEBUG - 2014-08-20 18:59:21 --> XSS Filtering completed
DEBUG - 2014-08-20 18:59:21 --> XSS Filtering completed
DEBUG - 2014-08-20 18:59:21 --> XSS Filtering completed
DEBUG - 2014-08-20 18:59:21 --> XSS Filtering completed
DEBUG - 2014-08-20 18:59:21 --> XSS Filtering completed
DEBUG - 2014-08-20 18:59:21 --> XSS Filtering completed
DEBUG - 2014-08-20 18:59:21 --> CRSF cookie Set
DEBUG - 2014-08-20 18:59:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 18:59:21 --> Language Class Initialized
DEBUG - 2014-08-20 18:59:21 --> Loader Class Initialized
DEBUG - 2014-08-20 18:59:21 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 18:59:21 --> Helper loaded: url_helper
DEBUG - 2014-08-20 18:59:21 --> Database Driver Class Initialized
ERROR - 2014-08-20 18:59:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 18:59:21 --> Session Class Initialized
DEBUG - 2014-08-20 18:59:21 --> Helper loaded: string_helper
DEBUG - 2014-08-20 18:59:21 --> Session routines successfully run
DEBUG - 2014-08-20 18:59:21 --> Controller Class Initialized
DEBUG - 2014-08-20 18:59:21 --> Final output sent to browser
DEBUG - 2014-08-20 18:59:21 --> Total execution time: 0.1104
DEBUG - 2014-08-20 19:00:15 --> Config Class Initialized
DEBUG - 2014-08-20 19:00:15 --> Hooks Class Initialized
DEBUG - 2014-08-20 19:00:15 --> Utf8 Class Initialized
DEBUG - 2014-08-20 19:00:15 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 19:00:15 --> URI Class Initialized
DEBUG - 2014-08-20 19:00:15 --> Router Class Initialized
DEBUG - 2014-08-20 19:00:15 --> Output Class Initialized
DEBUG - 2014-08-20 19:00:15 --> Security Class Initialized
DEBUG - 2014-08-20 19:00:15 --> Input Class Initialized
DEBUG - 2014-08-20 19:00:15 --> XSS Filtering completed
DEBUG - 2014-08-20 19:00:15 --> XSS Filtering completed
DEBUG - 2014-08-20 19:00:15 --> XSS Filtering completed
DEBUG - 2014-08-20 19:00:15 --> CRSF cookie Set
DEBUG - 2014-08-20 19:00:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 19:00:15 --> Language Class Initialized
DEBUG - 2014-08-20 19:00:15 --> Loader Class Initialized
DEBUG - 2014-08-20 19:00:15 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 19:00:15 --> Helper loaded: url_helper
DEBUG - 2014-08-20 19:00:15 --> Database Driver Class Initialized
ERROR - 2014-08-20 19:00:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 19:00:15 --> Session Class Initialized
DEBUG - 2014-08-20 19:00:15 --> Helper loaded: string_helper
DEBUG - 2014-08-20 19:00:15 --> A session cookie was not found.
DEBUG - 2014-08-20 19:00:15 --> Session routines successfully run
DEBUG - 2014-08-20 19:00:15 --> Controller Class Initialized
DEBUG - 2014-08-20 19:00:15 --> File loaded: application/views/logout.php
DEBUG - 2014-08-20 19:00:15 --> Final output sent to browser
DEBUG - 2014-08-20 19:00:15 --> Total execution time: 0.0788
DEBUG - 2014-08-20 19:00:15 --> Config Class Initialized
DEBUG - 2014-08-20 19:00:15 --> Hooks Class Initialized
DEBUG - 2014-08-20 19:00:15 --> Utf8 Class Initialized
DEBUG - 2014-08-20 19:00:15 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 19:00:15 --> URI Class Initialized
DEBUG - 2014-08-20 19:00:15 --> Router Class Initialized
DEBUG - 2014-08-20 19:00:15 --> No URI present. Default controller set.
DEBUG - 2014-08-20 19:00:15 --> Output Class Initialized
DEBUG - 2014-08-20 19:00:15 --> Security Class Initialized
DEBUG - 2014-08-20 19:00:15 --> Input Class Initialized
DEBUG - 2014-08-20 19:00:15 --> XSS Filtering completed
DEBUG - 2014-08-20 19:00:15 --> XSS Filtering completed
DEBUG - 2014-08-20 19:00:15 --> XSS Filtering completed
DEBUG - 2014-08-20 19:00:15 --> XSS Filtering completed
DEBUG - 2014-08-20 19:00:15 --> CRSF cookie Set
DEBUG - 2014-08-20 19:00:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 19:00:15 --> Language Class Initialized
DEBUG - 2014-08-20 19:00:15 --> Loader Class Initialized
DEBUG - 2014-08-20 19:00:15 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 19:00:15 --> Helper loaded: url_helper
DEBUG - 2014-08-20 19:00:15 --> Database Driver Class Initialized
ERROR - 2014-08-20 19:00:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 19:00:16 --> Session Class Initialized
DEBUG - 2014-08-20 19:00:16 --> Helper loaded: string_helper
DEBUG - 2014-08-20 19:00:16 --> A session cookie was not found.
DEBUG - 2014-08-20 19:00:16 --> Session routines successfully run
DEBUG - 2014-08-20 19:00:16 --> Controller Class Initialized
DEBUG - 2014-08-20 19:00:16 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 19:00:16 --> File loaded: application/views/bootstrap/placement_nav.php
DEBUG - 2014-08-20 19:00:16 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 19:00:16 --> Helper loaded: form_helper
DEBUG - 2014-08-20 19:00:16 --> File loaded: application/views/placement_login_sidebar.php
DEBUG - 2014-08-20 19:00:16 --> File loaded: application/views/home_body_placement.php
DEBUG - 2014-08-20 19:00:16 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 19:00:16 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 19:00:16 --> Final output sent to browser
DEBUG - 2014-08-20 19:00:16 --> Total execution time: 0.1443
DEBUG - 2014-08-20 19:00:43 --> Config Class Initialized
DEBUG - 2014-08-20 19:00:43 --> Hooks Class Initialized
DEBUG - 2014-08-20 19:00:43 --> Utf8 Class Initialized
DEBUG - 2014-08-20 19:00:43 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 19:00:43 --> URI Class Initialized
DEBUG - 2014-08-20 19:00:43 --> Router Class Initialized
DEBUG - 2014-08-20 19:00:43 --> Output Class Initialized
DEBUG - 2014-08-20 19:00:43 --> Security Class Initialized
DEBUG - 2014-08-20 19:00:43 --> Input Class Initialized
DEBUG - 2014-08-20 19:00:43 --> XSS Filtering completed
DEBUG - 2014-08-20 19:00:43 --> XSS Filtering completed
DEBUG - 2014-08-20 19:00:43 --> XSS Filtering completed
DEBUG - 2014-08-20 19:00:43 --> XSS Filtering completed
DEBUG - 2014-08-20 19:00:43 --> XSS Filtering completed
DEBUG - 2014-08-20 19:00:43 --> XSS Filtering completed
DEBUG - 2014-08-20 19:00:43 --> XSS Filtering completed
DEBUG - 2014-08-20 19:00:43 --> XSS Filtering completed
DEBUG - 2014-08-20 19:00:43 --> CRSF cookie Set
DEBUG - 2014-08-20 19:00:43 --> CSRF token verified
DEBUG - 2014-08-20 19:00:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 19:00:43 --> Language Class Initialized
DEBUG - 2014-08-20 19:00:43 --> Loader Class Initialized
DEBUG - 2014-08-20 19:00:43 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 19:00:43 --> Helper loaded: url_helper
DEBUG - 2014-08-20 19:00:43 --> Database Driver Class Initialized
ERROR - 2014-08-20 19:00:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 19:00:44 --> Session Class Initialized
DEBUG - 2014-08-20 19:00:44 --> Helper loaded: string_helper
DEBUG - 2014-08-20 19:00:44 --> Session routines successfully run
DEBUG - 2014-08-20 19:00:44 --> Controller Class Initialized
DEBUG - 2014-08-20 19:00:44 --> Helper loaded: form_helper
DEBUG - 2014-08-20 19:00:44 --> Form Validation Class Initialized
DEBUG - 2014-08-20 19:00:44 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2014-08-20 19:00:44 --> XSS Filtering completed
DEBUG - 2014-08-20 19:00:44 --> XSS Filtering completed
DEBUG - 2014-08-20 19:00:44 --> Model Class Initialized
DEBUG - 2014-08-20 19:00:44 --> Model Class Initialized
DEBUG - 2014-08-20 19:00:44 --> Model Class Initialized
DEBUG - 2014-08-20 19:00:44 --> Model Class Initialized
DEBUG - 2014-08-20 19:00:44 --> Encrypt Class Initialized
DEBUG - 2014-08-20 19:00:44 --> XSS Filtering completed
DEBUG - 2014-08-20 19:00:44 --> XSS Filtering completed
DEBUG - 2014-08-20 19:00:44 --> Config Class Initialized
DEBUG - 2014-08-20 19:00:44 --> Hooks Class Initialized
DEBUG - 2014-08-20 19:00:44 --> Utf8 Class Initialized
DEBUG - 2014-08-20 19:00:44 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 19:00:44 --> URI Class Initialized
DEBUG - 2014-08-20 19:00:44 --> Router Class Initialized
DEBUG - 2014-08-20 19:00:44 --> Output Class Initialized
DEBUG - 2014-08-20 19:00:44 --> Security Class Initialized
DEBUG - 2014-08-20 19:00:44 --> Input Class Initialized
DEBUG - 2014-08-20 19:00:44 --> XSS Filtering completed
DEBUG - 2014-08-20 19:00:44 --> XSS Filtering completed
DEBUG - 2014-08-20 19:00:44 --> XSS Filtering completed
DEBUG - 2014-08-20 19:00:44 --> XSS Filtering completed
DEBUG - 2014-08-20 19:00:44 --> XSS Filtering completed
DEBUG - 2014-08-20 19:00:44 --> CRSF cookie Set
DEBUG - 2014-08-20 19:00:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 19:00:44 --> Language Class Initialized
DEBUG - 2014-08-20 19:00:44 --> Loader Class Initialized
DEBUG - 2014-08-20 19:00:44 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 19:00:44 --> Helper loaded: url_helper
DEBUG - 2014-08-20 19:00:44 --> Database Driver Class Initialized
ERROR - 2014-08-20 19:00:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 19:00:44 --> Session Class Initialized
DEBUG - 2014-08-20 19:00:44 --> Helper loaded: string_helper
DEBUG - 2014-08-20 19:00:44 --> Session routines successfully run
DEBUG - 2014-08-20 19:00:44 --> Controller Class Initialized
DEBUG - 2014-08-20 19:00:44 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 19:00:44 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-20 19:00:44 --> Encrypt Class Initialized
DEBUG - 2014-08-20 19:00:44 --> File loaded: application/views/under_construction.php
DEBUG - 2014-08-20 19:00:44 --> File loaded: application/views/placement_events.php
DEBUG - 2014-08-20 19:00:44 --> File loaded: application/views/placement_admin_home.php
DEBUG - 2014-08-20 19:00:44 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 19:00:44 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 19:00:44 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-20 19:00:44 --> Final output sent to browser
DEBUG - 2014-08-20 19:00:44 --> Total execution time: 0.0682
DEBUG - 2014-08-20 19:00:44 --> Config Class Initialized
DEBUG - 2014-08-20 19:00:44 --> Hooks Class Initialized
DEBUG - 2014-08-20 19:00:44 --> Utf8 Class Initialized
DEBUG - 2014-08-20 19:00:44 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 19:00:44 --> URI Class Initialized
DEBUG - 2014-08-20 19:00:44 --> Router Class Initialized
DEBUG - 2014-08-20 19:00:44 --> Output Class Initialized
DEBUG - 2014-08-20 19:00:44 --> Security Class Initialized
DEBUG - 2014-08-20 19:00:44 --> Input Class Initialized
DEBUG - 2014-08-20 19:00:44 --> XSS Filtering completed
DEBUG - 2014-08-20 19:00:44 --> XSS Filtering completed
DEBUG - 2014-08-20 19:00:44 --> XSS Filtering completed
DEBUG - 2014-08-20 19:00:44 --> XSS Filtering completed
DEBUG - 2014-08-20 19:00:44 --> XSS Filtering completed
DEBUG - 2014-08-20 19:00:44 --> CRSF cookie Set
DEBUG - 2014-08-20 19:00:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 19:00:44 --> Language Class Initialized
DEBUG - 2014-08-20 19:00:44 --> Loader Class Initialized
DEBUG - 2014-08-20 19:00:44 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 19:00:44 --> Helper loaded: url_helper
DEBUG - 2014-08-20 19:00:44 --> Database Driver Class Initialized
ERROR - 2014-08-20 19:00:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 19:00:44 --> Session Class Initialized
DEBUG - 2014-08-20 19:00:44 --> Helper loaded: string_helper
DEBUG - 2014-08-20 19:00:44 --> Session routines successfully run
DEBUG - 2014-08-20 19:00:44 --> Controller Class Initialized
DEBUG - 2014-08-20 19:00:44 --> Final output sent to browser
DEBUG - 2014-08-20 19:00:44 --> Total execution time: 0.0516
DEBUG - 2014-08-20 19:00:54 --> Config Class Initialized
DEBUG - 2014-08-20 19:00:54 --> Hooks Class Initialized
DEBUG - 2014-08-20 19:00:54 --> Utf8 Class Initialized
DEBUG - 2014-08-20 19:00:54 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 19:00:54 --> URI Class Initialized
DEBUG - 2014-08-20 19:00:54 --> Router Class Initialized
DEBUG - 2014-08-20 19:00:54 --> Output Class Initialized
DEBUG - 2014-08-20 19:00:54 --> Security Class Initialized
DEBUG - 2014-08-20 19:00:54 --> Input Class Initialized
DEBUG - 2014-08-20 19:00:54 --> XSS Filtering completed
DEBUG - 2014-08-20 19:00:54 --> XSS Filtering completed
DEBUG - 2014-08-20 19:00:54 --> XSS Filtering completed
DEBUG - 2014-08-20 19:00:54 --> XSS Filtering completed
DEBUG - 2014-08-20 19:00:54 --> XSS Filtering completed
DEBUG - 2014-08-20 19:00:54 --> CRSF cookie Set
DEBUG - 2014-08-20 19:00:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 19:00:54 --> Language Class Initialized
DEBUG - 2014-08-20 19:00:54 --> Loader Class Initialized
DEBUG - 2014-08-20 19:00:54 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 19:00:54 --> Helper loaded: url_helper
DEBUG - 2014-08-20 19:00:54 --> Database Driver Class Initialized
ERROR - 2014-08-20 19:00:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 19:00:54 --> Session Class Initialized
DEBUG - 2014-08-20 19:00:54 --> Helper loaded: string_helper
DEBUG - 2014-08-20 19:00:54 --> Session routines successfully run
DEBUG - 2014-08-20 19:00:54 --> Controller Class Initialized
DEBUG - 2014-08-20 19:00:54 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 19:00:54 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-20 19:00:54 --> Encrypt Class Initialized
DEBUG - 2014-08-20 19:00:54 --> Model Class Initialized
DEBUG - 2014-08-20 19:00:54 --> Model Class Initialized
DEBUG - 2014-08-20 19:00:54 --> Model Class Initialized
DEBUG - 2014-08-20 19:00:54 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-20 19:00:54 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 19:00:54 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 19:00:54 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-20 19:00:54 --> Final output sent to browser
DEBUG - 2014-08-20 19:00:54 --> Total execution time: 0.0615
DEBUG - 2014-08-20 19:00:54 --> Config Class Initialized
DEBUG - 2014-08-20 19:00:54 --> Hooks Class Initialized
DEBUG - 2014-08-20 19:00:54 --> Utf8 Class Initialized
DEBUG - 2014-08-20 19:00:54 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 19:00:54 --> URI Class Initialized
DEBUG - 2014-08-20 19:00:54 --> Router Class Initialized
DEBUG - 2014-08-20 19:00:54 --> Output Class Initialized
DEBUG - 2014-08-20 19:00:54 --> Security Class Initialized
DEBUG - 2014-08-20 19:00:54 --> Input Class Initialized
DEBUG - 2014-08-20 19:00:54 --> XSS Filtering completed
DEBUG - 2014-08-20 19:00:54 --> XSS Filtering completed
DEBUG - 2014-08-20 19:00:54 --> XSS Filtering completed
DEBUG - 2014-08-20 19:00:54 --> XSS Filtering completed
DEBUG - 2014-08-20 19:00:54 --> XSS Filtering completed
DEBUG - 2014-08-20 19:00:54 --> CRSF cookie Set
DEBUG - 2014-08-20 19:00:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 19:00:54 --> Language Class Initialized
DEBUG - 2014-08-20 19:00:54 --> Loader Class Initialized
DEBUG - 2014-08-20 19:00:54 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 19:00:54 --> Helper loaded: url_helper
DEBUG - 2014-08-20 19:00:54 --> Database Driver Class Initialized
ERROR - 2014-08-20 19:00:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 19:00:54 --> Session Class Initialized
DEBUG - 2014-08-20 19:00:54 --> Helper loaded: string_helper
DEBUG - 2014-08-20 19:00:54 --> Session routines successfully run
DEBUG - 2014-08-20 19:00:54 --> Controller Class Initialized
DEBUG - 2014-08-20 19:00:54 --> Final output sent to browser
DEBUG - 2014-08-20 19:00:54 --> Total execution time: 0.0583
DEBUG - 2014-08-20 19:01:10 --> Config Class Initialized
DEBUG - 2014-08-20 19:01:10 --> Hooks Class Initialized
DEBUG - 2014-08-20 19:01:10 --> Utf8 Class Initialized
DEBUG - 2014-08-20 19:01:10 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 19:01:10 --> URI Class Initialized
DEBUG - 2014-08-20 19:01:10 --> Router Class Initialized
DEBUG - 2014-08-20 19:01:10 --> Output Class Initialized
DEBUG - 2014-08-20 19:01:10 --> Security Class Initialized
DEBUG - 2014-08-20 19:01:10 --> Input Class Initialized
DEBUG - 2014-08-20 19:01:10 --> XSS Filtering completed
DEBUG - 2014-08-20 19:01:10 --> XSS Filtering completed
DEBUG - 2014-08-20 19:01:10 --> XSS Filtering completed
DEBUG - 2014-08-20 19:01:10 --> XSS Filtering completed
DEBUG - 2014-08-20 19:01:10 --> XSS Filtering completed
DEBUG - 2014-08-20 19:02:40 --> Config Class Initialized
DEBUG - 2014-08-20 19:02:40 --> Hooks Class Initialized
DEBUG - 2014-08-20 19:02:40 --> Utf8 Class Initialized
DEBUG - 2014-08-20 19:02:40 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 19:02:40 --> URI Class Initialized
DEBUG - 2014-08-20 19:02:40 --> Router Class Initialized
DEBUG - 2014-08-20 19:02:40 --> Output Class Initialized
DEBUG - 2014-08-20 19:02:40 --> Security Class Initialized
DEBUG - 2014-08-20 19:02:40 --> Input Class Initialized
DEBUG - 2014-08-20 19:02:40 --> XSS Filtering completed
DEBUG - 2014-08-20 19:02:40 --> XSS Filtering completed
DEBUG - 2014-08-20 19:02:40 --> XSS Filtering completed
DEBUG - 2014-08-20 19:02:40 --> XSS Filtering completed
DEBUG - 2014-08-20 19:02:40 --> XSS Filtering completed
DEBUG - 2014-08-20 19:02:40 --> CRSF cookie Set
DEBUG - 2014-08-20 19:02:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 19:02:40 --> Language Class Initialized
DEBUG - 2014-08-20 19:02:40 --> Loader Class Initialized
DEBUG - 2014-08-20 19:02:40 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 19:02:40 --> Helper loaded: url_helper
DEBUG - 2014-08-20 19:02:40 --> Database Driver Class Initialized
ERROR - 2014-08-20 19:02:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 19:02:40 --> Session Class Initialized
DEBUG - 2014-08-20 19:02:40 --> Helper loaded: string_helper
DEBUG - 2014-08-20 19:02:40 --> Session routines successfully run
DEBUG - 2014-08-20 19:02:40 --> Controller Class Initialized
DEBUG - 2014-08-20 19:02:40 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 19:02:40 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-20 19:02:40 --> Encrypt Class Initialized
DEBUG - 2014-08-20 19:02:40 --> Model Class Initialized
DEBUG - 2014-08-20 19:02:40 --> Model Class Initialized
DEBUG - 2014-08-20 19:02:40 --> Model Class Initialized
DEBUG - 2014-08-20 19:02:40 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-20 19:02:40 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 19:02:40 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 19:02:40 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-20 19:02:40 --> Final output sent to browser
DEBUG - 2014-08-20 19:02:40 --> Total execution time: 0.0713
DEBUG - 2014-08-20 19:02:40 --> Config Class Initialized
DEBUG - 2014-08-20 19:02:40 --> Hooks Class Initialized
DEBUG - 2014-08-20 19:02:40 --> Utf8 Class Initialized
DEBUG - 2014-08-20 19:02:40 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 19:02:40 --> URI Class Initialized
DEBUG - 2014-08-20 19:02:40 --> Router Class Initialized
DEBUG - 2014-08-20 19:02:40 --> Output Class Initialized
DEBUG - 2014-08-20 19:02:40 --> Security Class Initialized
DEBUG - 2014-08-20 19:02:40 --> Input Class Initialized
DEBUG - 2014-08-20 19:02:40 --> XSS Filtering completed
DEBUG - 2014-08-20 19:02:40 --> XSS Filtering completed
DEBUG - 2014-08-20 19:02:40 --> XSS Filtering completed
DEBUG - 2014-08-20 19:02:40 --> XSS Filtering completed
DEBUG - 2014-08-20 19:02:40 --> XSS Filtering completed
DEBUG - 2014-08-20 19:02:40 --> CRSF cookie Set
DEBUG - 2014-08-20 19:02:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 19:02:40 --> Language Class Initialized
DEBUG - 2014-08-20 19:02:40 --> Loader Class Initialized
DEBUG - 2014-08-20 19:02:40 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 19:02:40 --> Helper loaded: url_helper
DEBUG - 2014-08-20 19:02:40 --> Database Driver Class Initialized
ERROR - 2014-08-20 19:02:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 19:02:40 --> Session Class Initialized
DEBUG - 2014-08-20 19:02:40 --> Helper loaded: string_helper
DEBUG - 2014-08-20 19:02:40 --> Session routines successfully run
DEBUG - 2014-08-20 19:02:40 --> Controller Class Initialized
DEBUG - 2014-08-20 19:02:40 --> Final output sent to browser
DEBUG - 2014-08-20 19:02:40 --> Total execution time: 0.0578
DEBUG - 2014-08-20 19:02:42 --> Config Class Initialized
DEBUG - 2014-08-20 19:02:42 --> Hooks Class Initialized
DEBUG - 2014-08-20 19:02:42 --> Utf8 Class Initialized
DEBUG - 2014-08-20 19:02:42 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 19:02:42 --> URI Class Initialized
DEBUG - 2014-08-20 19:02:42 --> Router Class Initialized
DEBUG - 2014-08-20 19:02:42 --> Output Class Initialized
DEBUG - 2014-08-20 19:02:42 --> Security Class Initialized
DEBUG - 2014-08-20 19:02:42 --> Input Class Initialized
DEBUG - 2014-08-20 19:02:42 --> XSS Filtering completed
DEBUG - 2014-08-20 19:02:42 --> XSS Filtering completed
DEBUG - 2014-08-20 19:02:42 --> XSS Filtering completed
DEBUG - 2014-08-20 19:02:42 --> XSS Filtering completed
DEBUG - 2014-08-20 19:02:42 --> XSS Filtering completed
DEBUG - 2014-08-20 19:02:42 --> CRSF cookie Set
DEBUG - 2014-08-20 19:02:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 19:02:42 --> Language Class Initialized
DEBUG - 2014-08-20 19:02:42 --> Loader Class Initialized
DEBUG - 2014-08-20 19:02:42 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 19:02:42 --> Helper loaded: url_helper
DEBUG - 2014-08-20 19:02:42 --> Database Driver Class Initialized
ERROR - 2014-08-20 19:02:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 19:02:42 --> Session Class Initialized
DEBUG - 2014-08-20 19:02:42 --> Helper loaded: string_helper
DEBUG - 2014-08-20 19:02:42 --> Session routines successfully run
DEBUG - 2014-08-20 19:02:42 --> Controller Class Initialized
DEBUG - 2014-08-20 19:02:42 --> Final output sent to browser
DEBUG - 2014-08-20 19:02:42 --> Total execution time: 0.0339
DEBUG - 2014-08-20 19:02:48 --> Config Class Initialized
DEBUG - 2014-08-20 19:02:48 --> Hooks Class Initialized
DEBUG - 2014-08-20 19:02:48 --> Utf8 Class Initialized
DEBUG - 2014-08-20 19:02:48 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 19:02:48 --> URI Class Initialized
DEBUG - 2014-08-20 19:02:48 --> Router Class Initialized
DEBUG - 2014-08-20 19:02:48 --> Output Class Initialized
DEBUG - 2014-08-20 19:02:48 --> Security Class Initialized
DEBUG - 2014-08-20 19:02:48 --> Input Class Initialized
DEBUG - 2014-08-20 19:02:48 --> XSS Filtering completed
DEBUG - 2014-08-20 19:02:48 --> XSS Filtering completed
DEBUG - 2014-08-20 19:02:48 --> XSS Filtering completed
DEBUG - 2014-08-20 19:02:48 --> XSS Filtering completed
DEBUG - 2014-08-20 19:02:48 --> XSS Filtering completed
DEBUG - 2014-08-20 19:02:48 --> CRSF cookie Set
DEBUG - 2014-08-20 19:02:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 19:02:48 --> Language Class Initialized
DEBUG - 2014-08-20 19:02:48 --> Loader Class Initialized
DEBUG - 2014-08-20 19:02:48 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 19:02:48 --> Helper loaded: url_helper
DEBUG - 2014-08-20 19:02:48 --> Database Driver Class Initialized
ERROR - 2014-08-20 19:02:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 19:02:48 --> Session Class Initialized
DEBUG - 2014-08-20 19:02:48 --> Helper loaded: string_helper
DEBUG - 2014-08-20 19:02:48 --> Session routines successfully run
DEBUG - 2014-08-20 19:02:48 --> Controller Class Initialized
DEBUG - 2014-08-20 19:02:48 --> Final output sent to browser
DEBUG - 2014-08-20 19:02:48 --> Total execution time: 0.0366
DEBUG - 2014-08-20 19:04:01 --> Config Class Initialized
DEBUG - 2014-08-20 19:04:01 --> Hooks Class Initialized
DEBUG - 2014-08-20 19:04:01 --> Utf8 Class Initialized
DEBUG - 2014-08-20 19:04:01 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 19:04:01 --> URI Class Initialized
DEBUG - 2014-08-20 19:04:01 --> Router Class Initialized
DEBUG - 2014-08-20 19:04:01 --> Output Class Initialized
DEBUG - 2014-08-20 19:04:01 --> Security Class Initialized
DEBUG - 2014-08-20 19:04:01 --> Input Class Initialized
DEBUG - 2014-08-20 19:04:01 --> XSS Filtering completed
DEBUG - 2014-08-20 19:04:01 --> XSS Filtering completed
DEBUG - 2014-08-20 19:04:01 --> XSS Filtering completed
DEBUG - 2014-08-20 19:04:01 --> XSS Filtering completed
DEBUG - 2014-08-20 19:04:01 --> XSS Filtering completed
DEBUG - 2014-08-20 19:04:01 --> CRSF cookie Set
DEBUG - 2014-08-20 19:04:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 19:04:01 --> Language Class Initialized
DEBUG - 2014-08-20 19:04:01 --> Loader Class Initialized
DEBUG - 2014-08-20 19:04:01 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 19:04:01 --> Helper loaded: url_helper
DEBUG - 2014-08-20 19:04:01 --> Database Driver Class Initialized
ERROR - 2014-08-20 19:04:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 19:04:01 --> Session Class Initialized
DEBUG - 2014-08-20 19:04:01 --> Helper loaded: string_helper
DEBUG - 2014-08-20 19:04:01 --> Session routines successfully run
DEBUG - 2014-08-20 19:04:01 --> Controller Class Initialized
DEBUG - 2014-08-20 19:04:01 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 19:04:01 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-20 19:04:01 --> Encrypt Class Initialized
DEBUG - 2014-08-20 19:04:01 --> Model Class Initialized
DEBUG - 2014-08-20 19:04:01 --> Model Class Initialized
DEBUG - 2014-08-20 19:04:01 --> Model Class Initialized
DEBUG - 2014-08-20 19:04:01 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-20 19:04:01 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 19:04:01 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 19:04:01 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-20 19:04:01 --> Final output sent to browser
DEBUG - 2014-08-20 19:04:01 --> Total execution time: 0.0670
DEBUG - 2014-08-20 19:04:01 --> Config Class Initialized
DEBUG - 2014-08-20 19:04:01 --> Hooks Class Initialized
DEBUG - 2014-08-20 19:04:01 --> Utf8 Class Initialized
DEBUG - 2014-08-20 19:04:01 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 19:04:01 --> URI Class Initialized
DEBUG - 2014-08-20 19:04:01 --> Router Class Initialized
DEBUG - 2014-08-20 19:04:01 --> Output Class Initialized
DEBUG - 2014-08-20 19:04:01 --> Security Class Initialized
DEBUG - 2014-08-20 19:04:01 --> Input Class Initialized
DEBUG - 2014-08-20 19:04:01 --> XSS Filtering completed
DEBUG - 2014-08-20 19:04:01 --> XSS Filtering completed
DEBUG - 2014-08-20 19:04:01 --> XSS Filtering completed
DEBUG - 2014-08-20 19:04:01 --> XSS Filtering completed
DEBUG - 2014-08-20 19:04:01 --> XSS Filtering completed
DEBUG - 2014-08-20 19:04:01 --> CRSF cookie Set
DEBUG - 2014-08-20 19:04:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 19:04:01 --> Language Class Initialized
DEBUG - 2014-08-20 19:04:01 --> Loader Class Initialized
DEBUG - 2014-08-20 19:04:01 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 19:04:01 --> Helper loaded: url_helper
DEBUG - 2014-08-20 19:04:01 --> Database Driver Class Initialized
ERROR - 2014-08-20 19:04:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 19:04:01 --> Session Class Initialized
DEBUG - 2014-08-20 19:04:01 --> Helper loaded: string_helper
DEBUG - 2014-08-20 19:04:01 --> Session routines successfully run
DEBUG - 2014-08-20 19:04:01 --> Controller Class Initialized
DEBUG - 2014-08-20 19:04:01 --> Final output sent to browser
DEBUG - 2014-08-20 19:04:01 --> Total execution time: 0.0409
DEBUG - 2014-08-20 19:04:03 --> Config Class Initialized
DEBUG - 2014-08-20 19:04:03 --> Hooks Class Initialized
DEBUG - 2014-08-20 19:04:03 --> Utf8 Class Initialized
DEBUG - 2014-08-20 19:04:03 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 19:04:03 --> URI Class Initialized
DEBUG - 2014-08-20 19:04:03 --> Router Class Initialized
DEBUG - 2014-08-20 19:04:03 --> Output Class Initialized
DEBUG - 2014-08-20 19:04:03 --> Security Class Initialized
DEBUG - 2014-08-20 19:04:03 --> Input Class Initialized
DEBUG - 2014-08-20 19:04:03 --> XSS Filtering completed
DEBUG - 2014-08-20 19:04:03 --> XSS Filtering completed
DEBUG - 2014-08-20 19:04:03 --> XSS Filtering completed
DEBUG - 2014-08-20 19:04:03 --> XSS Filtering completed
DEBUG - 2014-08-20 19:04:03 --> XSS Filtering completed
DEBUG - 2014-08-20 19:04:03 --> XSS Filtering completed
DEBUG - 2014-08-20 19:05:39 --> Config Class Initialized
DEBUG - 2014-08-20 19:05:39 --> Hooks Class Initialized
DEBUG - 2014-08-20 19:05:39 --> Utf8 Class Initialized
DEBUG - 2014-08-20 19:05:39 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 19:05:39 --> URI Class Initialized
DEBUG - 2014-08-20 19:05:39 --> Router Class Initialized
DEBUG - 2014-08-20 19:05:39 --> Output Class Initialized
DEBUG - 2014-08-20 19:05:39 --> Security Class Initialized
DEBUG - 2014-08-20 19:05:39 --> Input Class Initialized
DEBUG - 2014-08-20 19:05:39 --> XSS Filtering completed
DEBUG - 2014-08-20 19:05:39 --> XSS Filtering completed
DEBUG - 2014-08-20 19:05:39 --> XSS Filtering completed
DEBUG - 2014-08-20 19:05:39 --> XSS Filtering completed
DEBUG - 2014-08-20 19:05:39 --> XSS Filtering completed
DEBUG - 2014-08-20 19:05:39 --> CRSF cookie Set
DEBUG - 2014-08-20 19:05:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 19:05:39 --> Language Class Initialized
DEBUG - 2014-08-20 19:05:39 --> Loader Class Initialized
DEBUG - 2014-08-20 19:05:39 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 19:05:39 --> Helper loaded: url_helper
DEBUG - 2014-08-20 19:05:39 --> Database Driver Class Initialized
ERROR - 2014-08-20 19:05:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 19:05:39 --> Session Class Initialized
DEBUG - 2014-08-20 19:05:39 --> Helper loaded: string_helper
DEBUG - 2014-08-20 19:05:39 --> Session routines successfully run
DEBUG - 2014-08-20 19:05:39 --> Controller Class Initialized
DEBUG - 2014-08-20 19:05:39 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 19:05:39 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-20 19:05:39 --> Encrypt Class Initialized
DEBUG - 2014-08-20 19:05:39 --> Model Class Initialized
DEBUG - 2014-08-20 19:05:39 --> Model Class Initialized
DEBUG - 2014-08-20 19:05:39 --> Model Class Initialized
DEBUG - 2014-08-20 19:05:39 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-20 19:05:39 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 19:05:39 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 19:05:39 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-20 19:05:39 --> Final output sent to browser
DEBUG - 2014-08-20 19:05:39 --> Total execution time: 0.0672
DEBUG - 2014-08-20 19:05:39 --> Config Class Initialized
DEBUG - 2014-08-20 19:05:39 --> Hooks Class Initialized
DEBUG - 2014-08-20 19:05:39 --> Utf8 Class Initialized
DEBUG - 2014-08-20 19:05:39 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 19:05:39 --> URI Class Initialized
DEBUG - 2014-08-20 19:05:39 --> Router Class Initialized
DEBUG - 2014-08-20 19:05:39 --> Output Class Initialized
DEBUG - 2014-08-20 19:05:39 --> Security Class Initialized
DEBUG - 2014-08-20 19:05:39 --> Input Class Initialized
DEBUG - 2014-08-20 19:05:39 --> XSS Filtering completed
DEBUG - 2014-08-20 19:05:39 --> XSS Filtering completed
DEBUG - 2014-08-20 19:05:39 --> XSS Filtering completed
DEBUG - 2014-08-20 19:05:39 --> XSS Filtering completed
DEBUG - 2014-08-20 19:05:39 --> XSS Filtering completed
DEBUG - 2014-08-20 19:05:39 --> CRSF cookie Set
DEBUG - 2014-08-20 19:05:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 19:05:39 --> Language Class Initialized
DEBUG - 2014-08-20 19:05:39 --> Loader Class Initialized
DEBUG - 2014-08-20 19:05:39 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 19:05:39 --> Helper loaded: url_helper
DEBUG - 2014-08-20 19:05:39 --> Database Driver Class Initialized
ERROR - 2014-08-20 19:05:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 19:05:39 --> Session Class Initialized
DEBUG - 2014-08-20 19:05:39 --> Helper loaded: string_helper
DEBUG - 2014-08-20 19:05:39 --> Session routines successfully run
DEBUG - 2014-08-20 19:05:39 --> Controller Class Initialized
DEBUG - 2014-08-20 19:05:39 --> Final output sent to browser
DEBUG - 2014-08-20 19:05:39 --> Total execution time: 0.0505
DEBUG - 2014-08-20 19:05:41 --> Config Class Initialized
DEBUG - 2014-08-20 19:05:41 --> Hooks Class Initialized
DEBUG - 2014-08-20 19:05:41 --> Utf8 Class Initialized
DEBUG - 2014-08-20 19:05:41 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 19:05:41 --> URI Class Initialized
DEBUG - 2014-08-20 19:05:41 --> Router Class Initialized
DEBUG - 2014-08-20 19:05:41 --> Output Class Initialized
DEBUG - 2014-08-20 19:05:41 --> Security Class Initialized
DEBUG - 2014-08-20 19:05:41 --> Input Class Initialized
DEBUG - 2014-08-20 19:05:41 --> XSS Filtering completed
DEBUG - 2014-08-20 19:05:41 --> XSS Filtering completed
DEBUG - 2014-08-20 19:05:41 --> XSS Filtering completed
DEBUG - 2014-08-20 19:05:41 --> XSS Filtering completed
DEBUG - 2014-08-20 19:05:41 --> XSS Filtering completed
DEBUG - 2014-08-20 19:05:41 --> XSS Filtering completed
DEBUG - 2014-08-20 19:05:47 --> Config Class Initialized
DEBUG - 2014-08-20 19:05:47 --> Hooks Class Initialized
DEBUG - 2014-08-20 19:05:47 --> Utf8 Class Initialized
DEBUG - 2014-08-20 19:05:47 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 19:05:47 --> URI Class Initialized
DEBUG - 2014-08-20 19:05:47 --> Router Class Initialized
DEBUG - 2014-08-20 19:05:47 --> Output Class Initialized
DEBUG - 2014-08-20 19:05:47 --> Security Class Initialized
DEBUG - 2014-08-20 19:05:47 --> Input Class Initialized
DEBUG - 2014-08-20 19:05:47 --> XSS Filtering completed
DEBUG - 2014-08-20 19:05:47 --> XSS Filtering completed
DEBUG - 2014-08-20 19:05:47 --> XSS Filtering completed
DEBUG - 2014-08-20 19:05:47 --> XSS Filtering completed
DEBUG - 2014-08-20 19:05:47 --> XSS Filtering completed
DEBUG - 2014-08-20 19:05:47 --> XSS Filtering completed
DEBUG - 2014-08-20 19:05:49 --> Config Class Initialized
DEBUG - 2014-08-20 19:05:49 --> Hooks Class Initialized
DEBUG - 2014-08-20 19:05:49 --> Utf8 Class Initialized
DEBUG - 2014-08-20 19:05:49 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 19:05:49 --> URI Class Initialized
DEBUG - 2014-08-20 19:05:49 --> Router Class Initialized
DEBUG - 2014-08-20 19:05:49 --> Output Class Initialized
DEBUG - 2014-08-20 19:05:49 --> Security Class Initialized
DEBUG - 2014-08-20 19:05:49 --> Input Class Initialized
DEBUG - 2014-08-20 19:05:49 --> XSS Filtering completed
DEBUG - 2014-08-20 19:05:49 --> XSS Filtering completed
DEBUG - 2014-08-20 19:05:49 --> XSS Filtering completed
DEBUG - 2014-08-20 19:05:49 --> XSS Filtering completed
DEBUG - 2014-08-20 19:05:49 --> XSS Filtering completed
DEBUG - 2014-08-20 19:05:49 --> XSS Filtering completed
DEBUG - 2014-08-20 19:05:50 --> Config Class Initialized
DEBUG - 2014-08-20 19:05:50 --> Hooks Class Initialized
DEBUG - 2014-08-20 19:05:50 --> Utf8 Class Initialized
DEBUG - 2014-08-20 19:05:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 19:05:50 --> URI Class Initialized
DEBUG - 2014-08-20 19:05:50 --> Router Class Initialized
DEBUG - 2014-08-20 19:05:50 --> Output Class Initialized
DEBUG - 2014-08-20 19:05:50 --> Security Class Initialized
DEBUG - 2014-08-20 19:05:50 --> Input Class Initialized
DEBUG - 2014-08-20 19:05:50 --> XSS Filtering completed
DEBUG - 2014-08-20 19:05:50 --> XSS Filtering completed
DEBUG - 2014-08-20 19:05:50 --> XSS Filtering completed
DEBUG - 2014-08-20 19:05:50 --> XSS Filtering completed
DEBUG - 2014-08-20 19:05:50 --> XSS Filtering completed
DEBUG - 2014-08-20 19:05:50 --> XSS Filtering completed
DEBUG - 2014-08-20 19:06:28 --> Config Class Initialized
DEBUG - 2014-08-20 19:06:28 --> Hooks Class Initialized
DEBUG - 2014-08-20 19:06:28 --> Utf8 Class Initialized
DEBUG - 2014-08-20 19:06:28 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 19:06:28 --> URI Class Initialized
DEBUG - 2014-08-20 19:06:28 --> Router Class Initialized
DEBUG - 2014-08-20 19:06:28 --> Output Class Initialized
DEBUG - 2014-08-20 19:06:28 --> Security Class Initialized
DEBUG - 2014-08-20 19:06:28 --> Input Class Initialized
DEBUG - 2014-08-20 19:06:28 --> XSS Filtering completed
DEBUG - 2014-08-20 19:06:28 --> XSS Filtering completed
DEBUG - 2014-08-20 19:06:28 --> XSS Filtering completed
DEBUG - 2014-08-20 19:06:28 --> XSS Filtering completed
DEBUG - 2014-08-20 19:06:28 --> XSS Filtering completed
DEBUG - 2014-08-20 19:06:28 --> CRSF cookie Set
DEBUG - 2014-08-20 19:06:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 19:06:28 --> Language Class Initialized
DEBUG - 2014-08-20 19:06:28 --> Loader Class Initialized
DEBUG - 2014-08-20 19:06:28 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 19:06:28 --> Helper loaded: url_helper
DEBUG - 2014-08-20 19:06:28 --> Database Driver Class Initialized
ERROR - 2014-08-20 19:06:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 19:06:28 --> Session Class Initialized
DEBUG - 2014-08-20 19:06:28 --> Helper loaded: string_helper
DEBUG - 2014-08-20 19:06:28 --> Session routines successfully run
DEBUG - 2014-08-20 19:06:28 --> Controller Class Initialized
DEBUG - 2014-08-20 19:06:28 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 19:06:28 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-20 19:06:28 --> Encrypt Class Initialized
DEBUG - 2014-08-20 19:06:28 --> Model Class Initialized
DEBUG - 2014-08-20 19:06:28 --> Model Class Initialized
DEBUG - 2014-08-20 19:06:28 --> Model Class Initialized
DEBUG - 2014-08-20 19:06:28 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-20 19:06:28 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 19:06:28 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 19:06:28 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-20 19:06:28 --> Final output sent to browser
DEBUG - 2014-08-20 19:06:28 --> Total execution time: 0.0831
DEBUG - 2014-08-20 19:06:28 --> Config Class Initialized
DEBUG - 2014-08-20 19:06:28 --> Hooks Class Initialized
DEBUG - 2014-08-20 19:06:28 --> Utf8 Class Initialized
DEBUG - 2014-08-20 19:06:28 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 19:06:28 --> URI Class Initialized
DEBUG - 2014-08-20 19:06:28 --> Router Class Initialized
DEBUG - 2014-08-20 19:06:28 --> Output Class Initialized
DEBUG - 2014-08-20 19:06:28 --> Security Class Initialized
DEBUG - 2014-08-20 19:06:28 --> Input Class Initialized
DEBUG - 2014-08-20 19:06:28 --> XSS Filtering completed
DEBUG - 2014-08-20 19:06:28 --> XSS Filtering completed
DEBUG - 2014-08-20 19:06:28 --> XSS Filtering completed
DEBUG - 2014-08-20 19:06:28 --> XSS Filtering completed
DEBUG - 2014-08-20 19:06:28 --> XSS Filtering completed
DEBUG - 2014-08-20 19:06:28 --> CRSF cookie Set
DEBUG - 2014-08-20 19:06:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 19:06:28 --> Language Class Initialized
DEBUG - 2014-08-20 19:06:28 --> Loader Class Initialized
DEBUG - 2014-08-20 19:06:28 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 19:06:28 --> Helper loaded: url_helper
DEBUG - 2014-08-20 19:06:28 --> Database Driver Class Initialized
ERROR - 2014-08-20 19:06:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 19:06:28 --> Session Class Initialized
DEBUG - 2014-08-20 19:06:28 --> Helper loaded: string_helper
DEBUG - 2014-08-20 19:06:28 --> Session routines successfully run
DEBUG - 2014-08-20 19:06:28 --> Controller Class Initialized
DEBUG - 2014-08-20 19:06:28 --> Final output sent to browser
DEBUG - 2014-08-20 19:06:28 --> Total execution time: 0.0467
DEBUG - 2014-08-20 19:06:30 --> Config Class Initialized
DEBUG - 2014-08-20 19:06:30 --> Hooks Class Initialized
DEBUG - 2014-08-20 19:06:30 --> Utf8 Class Initialized
DEBUG - 2014-08-20 19:06:30 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 19:06:30 --> URI Class Initialized
DEBUG - 2014-08-20 19:06:30 --> Router Class Initialized
DEBUG - 2014-08-20 19:06:30 --> Output Class Initialized
DEBUG - 2014-08-20 19:06:30 --> Security Class Initialized
DEBUG - 2014-08-20 19:06:30 --> Input Class Initialized
DEBUG - 2014-08-20 19:06:30 --> XSS Filtering completed
DEBUG - 2014-08-20 19:06:30 --> XSS Filtering completed
DEBUG - 2014-08-20 19:06:30 --> XSS Filtering completed
DEBUG - 2014-08-20 19:06:30 --> XSS Filtering completed
DEBUG - 2014-08-20 19:06:30 --> XSS Filtering completed
DEBUG - 2014-08-20 19:06:30 --> XSS Filtering completed
DEBUG - 2014-08-20 19:06:30 --> XSS Filtering completed
DEBUG - 2014-08-20 19:06:30 --> XSS Filtering completed
DEBUG - 2014-08-20 19:06:30 --> CRSF cookie Set
DEBUG - 2014-08-20 19:06:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 19:06:30 --> Language Class Initialized
DEBUG - 2014-08-20 19:06:30 --> Loader Class Initialized
DEBUG - 2014-08-20 19:06:30 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 19:06:30 --> Helper loaded: url_helper
DEBUG - 2014-08-20 19:06:30 --> Database Driver Class Initialized
ERROR - 2014-08-20 19:06:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 19:06:30 --> Session Class Initialized
DEBUG - 2014-08-20 19:06:30 --> Helper loaded: string_helper
DEBUG - 2014-08-20 19:06:30 --> Session routines successfully run
DEBUG - 2014-08-20 19:06:30 --> Controller Class Initialized
DEBUG - 2014-08-20 19:06:30 --> Final output sent to browser
DEBUG - 2014-08-20 19:06:30 --> Total execution time: 0.0356
DEBUG - 2014-08-20 19:07:58 --> Config Class Initialized
DEBUG - 2014-08-20 19:07:58 --> Hooks Class Initialized
DEBUG - 2014-08-20 19:07:58 --> Utf8 Class Initialized
DEBUG - 2014-08-20 19:07:58 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 19:07:58 --> URI Class Initialized
DEBUG - 2014-08-20 19:07:58 --> Router Class Initialized
DEBUG - 2014-08-20 19:07:58 --> Output Class Initialized
DEBUG - 2014-08-20 19:07:58 --> Security Class Initialized
DEBUG - 2014-08-20 19:07:58 --> Input Class Initialized
DEBUG - 2014-08-20 19:07:58 --> XSS Filtering completed
DEBUG - 2014-08-20 19:07:58 --> XSS Filtering completed
DEBUG - 2014-08-20 19:07:58 --> XSS Filtering completed
DEBUG - 2014-08-20 19:07:58 --> XSS Filtering completed
DEBUG - 2014-08-20 19:07:58 --> XSS Filtering completed
DEBUG - 2014-08-20 19:07:58 --> CRSF cookie Set
DEBUG - 2014-08-20 19:07:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 19:07:58 --> Language Class Initialized
DEBUG - 2014-08-20 19:07:58 --> Loader Class Initialized
DEBUG - 2014-08-20 19:07:58 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 19:07:58 --> Helper loaded: url_helper
DEBUG - 2014-08-20 19:07:58 --> Database Driver Class Initialized
ERROR - 2014-08-20 19:07:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 19:07:58 --> Session Class Initialized
DEBUG - 2014-08-20 19:07:58 --> Helper loaded: string_helper
DEBUG - 2014-08-20 19:07:58 --> Session routines successfully run
DEBUG - 2014-08-20 19:07:58 --> Controller Class Initialized
DEBUG - 2014-08-20 19:07:58 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 19:07:58 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-20 19:07:58 --> Encrypt Class Initialized
DEBUG - 2014-08-20 19:07:58 --> Model Class Initialized
DEBUG - 2014-08-20 19:07:58 --> Model Class Initialized
DEBUG - 2014-08-20 19:07:58 --> Model Class Initialized
DEBUG - 2014-08-20 19:07:58 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-20 19:07:58 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 19:07:58 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 19:07:58 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-20 19:07:58 --> Final output sent to browser
DEBUG - 2014-08-20 19:07:58 --> Total execution time: 0.0704
DEBUG - 2014-08-20 19:07:58 --> Config Class Initialized
DEBUG - 2014-08-20 19:07:58 --> Hooks Class Initialized
DEBUG - 2014-08-20 19:07:58 --> Utf8 Class Initialized
DEBUG - 2014-08-20 19:07:58 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 19:07:58 --> URI Class Initialized
DEBUG - 2014-08-20 19:07:58 --> Router Class Initialized
DEBUG - 2014-08-20 19:07:58 --> Output Class Initialized
DEBUG - 2014-08-20 19:07:58 --> Security Class Initialized
DEBUG - 2014-08-20 19:07:58 --> Input Class Initialized
DEBUG - 2014-08-20 19:07:58 --> XSS Filtering completed
DEBUG - 2014-08-20 19:07:58 --> XSS Filtering completed
DEBUG - 2014-08-20 19:07:58 --> XSS Filtering completed
DEBUG - 2014-08-20 19:07:58 --> XSS Filtering completed
DEBUG - 2014-08-20 19:07:58 --> XSS Filtering completed
DEBUG - 2014-08-20 19:07:58 --> CRSF cookie Set
DEBUG - 2014-08-20 19:07:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 19:07:58 --> Language Class Initialized
DEBUG - 2014-08-20 19:07:58 --> Loader Class Initialized
DEBUG - 2014-08-20 19:07:58 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 19:07:58 --> Helper loaded: url_helper
DEBUG - 2014-08-20 19:07:58 --> Database Driver Class Initialized
ERROR - 2014-08-20 19:07:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 19:07:58 --> Session Class Initialized
DEBUG - 2014-08-20 19:07:58 --> Helper loaded: string_helper
DEBUG - 2014-08-20 19:07:58 --> Session routines successfully run
DEBUG - 2014-08-20 19:07:58 --> Controller Class Initialized
DEBUG - 2014-08-20 19:07:58 --> Final output sent to browser
DEBUG - 2014-08-20 19:07:58 --> Total execution time: 0.0564
DEBUG - 2014-08-20 19:14:25 --> Config Class Initialized
DEBUG - 2014-08-20 19:14:25 --> Hooks Class Initialized
DEBUG - 2014-08-20 19:14:25 --> Utf8 Class Initialized
DEBUG - 2014-08-20 19:14:25 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 19:14:25 --> URI Class Initialized
DEBUG - 2014-08-20 19:14:25 --> Router Class Initialized
DEBUG - 2014-08-20 19:14:25 --> Output Class Initialized
DEBUG - 2014-08-20 19:14:25 --> Security Class Initialized
DEBUG - 2014-08-20 19:14:25 --> Input Class Initialized
DEBUG - 2014-08-20 19:14:25 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:25 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:25 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:25 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:25 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:25 --> CRSF cookie Set
DEBUG - 2014-08-20 19:14:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 19:14:25 --> Language Class Initialized
DEBUG - 2014-08-20 19:14:25 --> Loader Class Initialized
DEBUG - 2014-08-20 19:14:25 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 19:14:25 --> Helper loaded: url_helper
DEBUG - 2014-08-20 19:14:25 --> Database Driver Class Initialized
ERROR - 2014-08-20 19:14:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 19:14:25 --> Session Class Initialized
DEBUG - 2014-08-20 19:14:25 --> Helper loaded: string_helper
DEBUG - 2014-08-20 19:14:25 --> Session routines successfully run
DEBUG - 2014-08-20 19:14:25 --> Controller Class Initialized
DEBUG - 2014-08-20 19:14:25 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 19:14:25 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-20 19:14:25 --> Encrypt Class Initialized
DEBUG - 2014-08-20 19:14:25 --> Model Class Initialized
DEBUG - 2014-08-20 19:14:25 --> Model Class Initialized
DEBUG - 2014-08-20 19:14:25 --> Model Class Initialized
DEBUG - 2014-08-20 19:14:25 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-20 19:14:25 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 19:14:25 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 19:14:25 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-20 19:14:25 --> Final output sent to browser
DEBUG - 2014-08-20 19:14:25 --> Total execution time: 0.0862
DEBUG - 2014-08-20 19:14:25 --> Config Class Initialized
DEBUG - 2014-08-20 19:14:25 --> Hooks Class Initialized
DEBUG - 2014-08-20 19:14:25 --> Utf8 Class Initialized
DEBUG - 2014-08-20 19:14:25 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 19:14:25 --> URI Class Initialized
DEBUG - 2014-08-20 19:14:25 --> Router Class Initialized
DEBUG - 2014-08-20 19:14:25 --> Output Class Initialized
DEBUG - 2014-08-20 19:14:25 --> Security Class Initialized
DEBUG - 2014-08-20 19:14:25 --> Input Class Initialized
DEBUG - 2014-08-20 19:14:25 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:25 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:25 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:25 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:25 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:25 --> CRSF cookie Set
DEBUG - 2014-08-20 19:14:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 19:14:25 --> Language Class Initialized
DEBUG - 2014-08-20 19:14:25 --> Loader Class Initialized
DEBUG - 2014-08-20 19:14:25 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 19:14:25 --> Helper loaded: url_helper
DEBUG - 2014-08-20 19:14:25 --> Database Driver Class Initialized
ERROR - 2014-08-20 19:14:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 19:14:25 --> Session Class Initialized
DEBUG - 2014-08-20 19:14:25 --> Helper loaded: string_helper
DEBUG - 2014-08-20 19:14:25 --> Session routines successfully run
DEBUG - 2014-08-20 19:14:25 --> Controller Class Initialized
DEBUG - 2014-08-20 19:14:25 --> Final output sent to browser
DEBUG - 2014-08-20 19:14:25 --> Total execution time: 0.0532
DEBUG - 2014-08-20 19:14:27 --> Config Class Initialized
DEBUG - 2014-08-20 19:14:27 --> Hooks Class Initialized
DEBUG - 2014-08-20 19:14:27 --> Utf8 Class Initialized
DEBUG - 2014-08-20 19:14:27 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 19:14:27 --> URI Class Initialized
DEBUG - 2014-08-20 19:14:27 --> Router Class Initialized
DEBUG - 2014-08-20 19:14:27 --> Output Class Initialized
DEBUG - 2014-08-20 19:14:27 --> Security Class Initialized
DEBUG - 2014-08-20 19:14:27 --> Input Class Initialized
DEBUG - 2014-08-20 19:14:27 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:27 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:27 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:27 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:27 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:27 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:27 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:27 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:27 --> CRSF cookie Set
DEBUG - 2014-08-20 19:14:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 19:14:27 --> Language Class Initialized
DEBUG - 2014-08-20 19:14:27 --> Loader Class Initialized
DEBUG - 2014-08-20 19:14:27 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 19:14:27 --> Helper loaded: url_helper
DEBUG - 2014-08-20 19:14:27 --> Database Driver Class Initialized
ERROR - 2014-08-20 19:14:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 19:14:27 --> Session Class Initialized
DEBUG - 2014-08-20 19:14:27 --> Helper loaded: string_helper
DEBUG - 2014-08-20 19:14:27 --> Session routines successfully run
DEBUG - 2014-08-20 19:14:27 --> Controller Class Initialized
DEBUG - 2014-08-20 19:14:27 --> Final output sent to browser
DEBUG - 2014-08-20 19:14:27 --> Total execution time: 0.0365
DEBUG - 2014-08-20 19:14:29 --> Config Class Initialized
DEBUG - 2014-08-20 19:14:29 --> Hooks Class Initialized
DEBUG - 2014-08-20 19:14:29 --> Utf8 Class Initialized
DEBUG - 2014-08-20 19:14:29 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 19:14:29 --> URI Class Initialized
DEBUG - 2014-08-20 19:14:29 --> Router Class Initialized
DEBUG - 2014-08-20 19:14:29 --> Output Class Initialized
DEBUG - 2014-08-20 19:14:29 --> Security Class Initialized
DEBUG - 2014-08-20 19:14:29 --> Input Class Initialized
DEBUG - 2014-08-20 19:14:29 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:29 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:29 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:29 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:29 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:29 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:29 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:29 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:29 --> CRSF cookie Set
DEBUG - 2014-08-20 19:14:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 19:14:29 --> Language Class Initialized
DEBUG - 2014-08-20 19:14:29 --> Loader Class Initialized
DEBUG - 2014-08-20 19:14:29 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 19:14:29 --> Helper loaded: url_helper
DEBUG - 2014-08-20 19:14:29 --> Database Driver Class Initialized
ERROR - 2014-08-20 19:14:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 19:14:29 --> Session Class Initialized
DEBUG - 2014-08-20 19:14:29 --> Helper loaded: string_helper
DEBUG - 2014-08-20 19:14:29 --> Session routines successfully run
DEBUG - 2014-08-20 19:14:29 --> Controller Class Initialized
DEBUG - 2014-08-20 19:14:29 --> Final output sent to browser
DEBUG - 2014-08-20 19:14:29 --> Total execution time: 0.0402
DEBUG - 2014-08-20 19:14:50 --> Config Class Initialized
DEBUG - 2014-08-20 19:14:50 --> Hooks Class Initialized
DEBUG - 2014-08-20 19:14:50 --> Utf8 Class Initialized
DEBUG - 2014-08-20 19:14:50 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 19:14:50 --> URI Class Initialized
DEBUG - 2014-08-20 19:14:50 --> Router Class Initialized
DEBUG - 2014-08-20 19:14:50 --> Output Class Initialized
DEBUG - 2014-08-20 19:14:50 --> Security Class Initialized
DEBUG - 2014-08-20 19:14:50 --> Input Class Initialized
DEBUG - 2014-08-20 19:14:50 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:50 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:50 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:50 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:50 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:50 --> CRSF cookie Set
DEBUG - 2014-08-20 19:14:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 19:14:50 --> Language Class Initialized
DEBUG - 2014-08-20 19:14:50 --> Loader Class Initialized
DEBUG - 2014-08-20 19:14:50 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 19:14:50 --> Helper loaded: url_helper
DEBUG - 2014-08-20 19:14:50 --> Database Driver Class Initialized
ERROR - 2014-08-20 19:14:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 19:14:50 --> Session Class Initialized
DEBUG - 2014-08-20 19:14:50 --> Helper loaded: string_helper
DEBUG - 2014-08-20 19:14:50 --> Session routines successfully run
DEBUG - 2014-08-20 19:14:50 --> Controller Class Initialized
DEBUG - 2014-08-20 19:14:50 --> File loaded: application/views/bootstrap/placement_header.php
DEBUG - 2014-08-20 19:14:50 --> File loaded: application/views/bootstrap/placement_admin_nav.php
DEBUG - 2014-08-20 19:14:50 --> Encrypt Class Initialized
DEBUG - 2014-08-20 19:14:50 --> Model Class Initialized
DEBUG - 2014-08-20 19:14:50 --> Model Class Initialized
DEBUG - 2014-08-20 19:14:50 --> Model Class Initialized
DEBUG - 2014-08-20 19:14:50 --> File loaded: application/views/placement_admin_verify.php
DEBUG - 2014-08-20 19:14:50 --> File loaded: application/views/bootstrap/placement_secondary.php
DEBUG - 2014-08-20 19:14:50 --> File loaded: application/views/bootstrap/placement_footer.php
DEBUG - 2014-08-20 19:14:50 --> File loaded: application/views/security_check.php
DEBUG - 2014-08-20 19:14:50 --> Final output sent to browser
DEBUG - 2014-08-20 19:14:50 --> Total execution time: 0.0665
DEBUG - 2014-08-20 19:14:51 --> Config Class Initialized
DEBUG - 2014-08-20 19:14:51 --> Hooks Class Initialized
DEBUG - 2014-08-20 19:14:51 --> Utf8 Class Initialized
DEBUG - 2014-08-20 19:14:51 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 19:14:51 --> URI Class Initialized
DEBUG - 2014-08-20 19:14:51 --> Router Class Initialized
DEBUG - 2014-08-20 19:14:51 --> Output Class Initialized
DEBUG - 2014-08-20 19:14:51 --> Security Class Initialized
DEBUG - 2014-08-20 19:14:51 --> Input Class Initialized
DEBUG - 2014-08-20 19:14:51 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:51 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:51 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:51 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:51 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:51 --> CRSF cookie Set
DEBUG - 2014-08-20 19:14:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 19:14:51 --> Language Class Initialized
DEBUG - 2014-08-20 19:14:51 --> Loader Class Initialized
DEBUG - 2014-08-20 19:14:51 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 19:14:51 --> Helper loaded: url_helper
DEBUG - 2014-08-20 19:14:51 --> Database Driver Class Initialized
ERROR - 2014-08-20 19:14:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 19:14:51 --> Session Class Initialized
DEBUG - 2014-08-20 19:14:51 --> Helper loaded: string_helper
DEBUG - 2014-08-20 19:14:51 --> Session routines successfully run
DEBUG - 2014-08-20 19:14:51 --> Controller Class Initialized
DEBUG - 2014-08-20 19:14:51 --> Final output sent to browser
DEBUG - 2014-08-20 19:14:51 --> Total execution time: 0.0568
DEBUG - 2014-08-20 19:14:53 --> Config Class Initialized
DEBUG - 2014-08-20 19:14:53 --> Hooks Class Initialized
DEBUG - 2014-08-20 19:14:53 --> Utf8 Class Initialized
DEBUG - 2014-08-20 19:14:53 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 19:14:53 --> URI Class Initialized
DEBUG - 2014-08-20 19:14:53 --> Router Class Initialized
DEBUG - 2014-08-20 19:14:53 --> Output Class Initialized
DEBUG - 2014-08-20 19:14:53 --> Security Class Initialized
DEBUG - 2014-08-20 19:14:53 --> Input Class Initialized
DEBUG - 2014-08-20 19:14:53 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:53 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:53 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:53 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:53 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:53 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:53 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:53 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:53 --> CRSF cookie Set
DEBUG - 2014-08-20 19:14:53 --> CSRF token verified
DEBUG - 2014-08-20 19:14:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 19:14:53 --> Language Class Initialized
DEBUG - 2014-08-20 19:14:53 --> Loader Class Initialized
DEBUG - 2014-08-20 19:14:53 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 19:14:53 --> Helper loaded: url_helper
DEBUG - 2014-08-20 19:14:53 --> Database Driver Class Initialized
ERROR - 2014-08-20 19:14:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 19:14:53 --> Session Class Initialized
DEBUG - 2014-08-20 19:14:53 --> Helper loaded: string_helper
DEBUG - 2014-08-20 19:14:53 --> Session routines successfully run
DEBUG - 2014-08-20 19:14:53 --> Controller Class Initialized
DEBUG - 2014-08-20 19:14:53 --> Final output sent to browser
DEBUG - 2014-08-20 19:14:53 --> Total execution time: 0.0415
DEBUG - 2014-08-20 19:14:55 --> Config Class Initialized
DEBUG - 2014-08-20 19:14:55 --> Hooks Class Initialized
DEBUG - 2014-08-20 19:14:55 --> Utf8 Class Initialized
DEBUG - 2014-08-20 19:14:55 --> UTF-8 Support Enabled
DEBUG - 2014-08-20 19:14:55 --> URI Class Initialized
DEBUG - 2014-08-20 19:14:55 --> Router Class Initialized
DEBUG - 2014-08-20 19:14:55 --> Output Class Initialized
DEBUG - 2014-08-20 19:14:55 --> Security Class Initialized
DEBUG - 2014-08-20 19:14:55 --> Input Class Initialized
DEBUG - 2014-08-20 19:14:55 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:55 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:55 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:55 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:55 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:55 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:55 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:55 --> XSS Filtering completed
DEBUG - 2014-08-20 19:14:55 --> CRSF cookie Set
DEBUG - 2014-08-20 19:14:55 --> CSRF token verified
DEBUG - 2014-08-20 19:14:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-08-20 19:14:55 --> Language Class Initialized
DEBUG - 2014-08-20 19:14:55 --> Loader Class Initialized
DEBUG - 2014-08-20 19:14:55 --> Helper loaded: functions_helper
DEBUG - 2014-08-20 19:14:55 --> Helper loaded: url_helper
DEBUG - 2014-08-20 19:14:55 --> Database Driver Class Initialized
ERROR - 2014-08-20 19:14:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\wamp\www\cep\placement\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-08-20 19:14:55 --> Session Class Initialized
DEBUG - 2014-08-20 19:14:55 --> Helper loaded: string_helper
DEBUG - 2014-08-20 19:14:55 --> Session routines successfully run
DEBUG - 2014-08-20 19:14:55 --> Controller Class Initialized
DEBUG - 2014-08-20 19:14:55 --> Final output sent to browser
DEBUG - 2014-08-20 19:14:55 --> Total execution time: 0.0378
