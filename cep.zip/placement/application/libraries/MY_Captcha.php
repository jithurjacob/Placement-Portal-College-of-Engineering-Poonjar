<?php
 
class MY_Captcha extends CI_Captcha
{
   
}
 
?>