<?php

/**
* 
*/
class Placement_events extends MY_Model
{	

	const DB_TABLE = 'placement_events';
	const DB_TABLE_PK = 'event_id';
	/**
	 *  id
	 *@var int 
	 */
	
	public $event_id;
	/**
	 * title
	 * @var title
	 */
	public $event_title;
	/**
	 * details
	 * @var details
	 */
	public $event_details;
}

?>