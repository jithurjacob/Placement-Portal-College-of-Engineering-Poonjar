<?php

/**
* 
*/
class Placement_company extends CI_Model
{	

    public function validate($valid="r")
    {   
        $this->load->library('encrypt');
        $user=$this->encrypt->decode($this->input->post('userid'));
        $val=($valid=="a"?"1":"-1");
        $data = array('valid' => $val);
        
        $query = $this->db->where('username' , $user);
        return $this->db->update('company', $data);
    }
    public function verify_newreg()
    {
        $query = $this->db->get('company');
        $query = $this->db->get_where('company', array('valid' => 0));
        return $query->result_array();
    }
    public function register() {
         $this->load->library('encrypt');
        $companyname = $this->input->post('companyname');
        $username = $this->input->post('username');
        $email = $this->input->post('email');
        $password = $this->encrypt->sha1($this->input->post('password'). "jithu$&");
        $website = $this->input->post('website');
        $mobno = $this->input->post('mobno');
        

        $data = array('name'=>$companyname,'username'=>$username,'email'=>$email,'password'=>$password,'website'=>$website,'mobno'=>$mobno);
        return $this->db->insert('company', $data);
    }



	public function check_username_exists(){
$username = $this->security->xss_clean($this->input->post('username'));
        $this->db->where('username', $username);
        $query = $this->db->get('company');
        if($query->num_rows != 0)
        {
            return true;
        }else{
            return false;
        }
    }


	public function check_login(){
        $this->load->library('encrypt');
        // grab user input
        $username = $this->security->xss_clean($this->input->post('username'));
        $password = $this->security->xss_clean($this->input->post('password'));
        
        // Prep the query
        $this->db->where('username', $username);
       //  $this->db->where('valid', 1);
        $this->db->where('password', $this->encrypt->sha1($password."jithu$&"));
        
        // Run the query
        $query = $this->db->get('company');
        // Let's check if there are any results
        if($query->num_rows == 1)
        {
            // If there is a user, then create session data
            $row = $query->row();
            if($row->valid ==0)
                return "PENDING";
            if($row->valid == -1)
                return "REJECT";
            $data = array(
                    'username' => $row->username,
                    'admin' => false,
                    'validated' => true
                    );
            $this->session->set_userdata($data);
            return "true";
        }
        // If the previous process did not validate
        // then return false.
        return "false";
    }
}

?>