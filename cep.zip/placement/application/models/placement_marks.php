<?php

/**
 *
 */
class Placement_marks extends CI_Model {

	public function get_marksdetails_students() {
		//$query = $this->db->get('students');
		//$user  = $this->session->userdata('username');
		$regno  = $this->session->userdata('regno');
		//$year_pass  = $this->session->userdata('year_pass');
		$query = $this->db->get_where('marks', array('regno' => $regno));
		return $query->result_array();

	}
	
	


	// back stds
	public function get_details() {
		//$query = $this->db->get('students');
		$user  = $this->session->userdata('username');
		$query = $this->db->get_where('students', array('username' => $user));
		return $query->result_array();

	}

	public function register() {
		$this->load->library('encrypt');
		$name      = $this->input->post('name');
		$username  = $this->input->post('username');
		$email     = $this->input->post('email');
		$password  = $this->encrypt->sha1($this->input->post('password')."jithu$&");
		$admnno    = $this->input->post('admnno');
		$regno     = $this->input->post('regno');
		$year_pass = $this->input->post('year_pass');

		$data = array('name' => $name, 'username' => $username, 'email' => $email, 'password' => $password, 'admnno' => $admnno, 'regno' => $regno, 'year_pass' => $year_pass);
		return $this->db->insert('students', $data);
	}

    public function update() {
        $name      = $this->input->post('name');
        $gender  = $this->input->post('gender');
        $branch  = $this->input->post('branch');
        $semester  = $this->input->post('semester');
        $dob    = $this->input->post('dob');
        $perm_addr  = $this->input->post('perm_addr');
        $temp_addr   = $this->input->post('temp_addr');
        $mobno    = $this->input->post('mobno');
        $contactno = $this->input->post('contactno');
        $tenth  = $this->input->post('tenth');
        $twelth  = $this->input->post('twelth');
        $entrance_rank  = $this->input->post('entrance_rank');
        $year_pass  = $this->input->post('year_pass');
        $data = array('name' => $name, 'gender' => $gender, 'branch' => $branch, 'semester' => $semester,
         'dob' => $dob, 'perm_addr' => $perm_addr, 'temp_addr' => $temp_addr,'mobno'=>$mobno,
         'contactno'=>$contactno,'tenth'=>$tenth,'twelth'=>$twelth,'entrance_rank'=>$entrance_rank,'year_pass'=>$year_pass);
        
        $user  = $this->session->userdata('username');
        $query = $this->db->where('username' , $user);
        return $this->db->update('students', $data);
    }
}
?>