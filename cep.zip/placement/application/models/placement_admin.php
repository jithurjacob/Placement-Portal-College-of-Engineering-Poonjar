<?php

/**
* 
*/
class Placement_admin extends CI_Model
{	

    public function check_username_exists(){
$username = $this->security->xss_clean($this->input->post('username'));
        $this->db->where('username', $username);
        $query = $this->db->get('admin');
        if($query->num_rows != 0)
        {
            return true;
        }else{
            return false;
        }
    }

	const DB_TABLE = 'admin';
	const DB_TABLE_PK = 'username';
	
	
	public $admin_id;
	
	public $username;
	
	public $password;

	public function check_login(){
        $this->load->library('encrypt');
        // grab user input
        $username = $this->security->xss_clean($this->input->post('username'));
        $password = $this->security->xss_clean($this->input->post('password'));
        
        // Prep the query
        $this->db->where('username', $username);
        $this->db->where('password', $this->encrypt->sha1($password."jithu$&"));
        
        // Run the query
        $query = $this->db->get('admin');
        // Let's check if there are any results
        if($query->num_rows == 1)
        {
            // If there is a user, then create session data
            $row = $query->row();
            if($row->valid ==0)
                return "PENDING";
            if($row->valid == -1)
                return "REJECT";
            $data = array(
                    'username' => $row->username,
                    'admin' => true,
                    'validated' => true
                    );
            $this->session->set_userdata($data);
            return "true";
        }
        // If the previous process did not validate
        // then return false.
        return "false";
    }
}

?>