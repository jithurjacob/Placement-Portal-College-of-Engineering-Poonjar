<?php
if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class Placement extends CI_Controller
{
    
    /** * Index Page for this controller. * * Maps to the following URL * http://example.com/index.php/welcome * - or - * http://example.com/index.php/welcome/index * - or - * Since this controller is set as the default controller in * config/routes.php, it 's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * see http://codeigniter.com/user_guide/general/urls.html
     */
    
    public function validate_reg_ajax( $valid = '') {
        if ($this->input->is_ajax_request()) {
            $this->check_isvalidated();
            if ($this->input->post('type') == "student") {
                $this->load->model('placement_students');
                if ($this->placement_students->validate($valid)) echo "ok";
                else echo "not ok";
            } else if ($this->input->post('type') == "company") {
                $this->load->model('placement_company');
                if ($this->placement_company->validate($valid)) echo "ok";
                else echo "not ok";
            } else {
                echo "error";
                //error
                ;
            }
        }
    }
    
    public function students_update_verify() {
        
        $this->load->library('form_validation', array(), 'update_form');
        $data['error'] = FALSE;
        
        $this->update_form->set_rules('name', 'Name', 'trim|alpha_space|required|xss_clean');
        $this->update_form->set_rules('gender', 'Gender', 'trim|required|xss_clean');
        $this->update_form->set_rules('branch', 'Branch', 'trim|required|xss_clean');
        $this->update_form->set_rules('semester', 'Semester', 'trim|required|xss_clean');
        $this->update_form->set_rules('dob', 'Date of Birth', 'trim|required|valid_dob|xss_clean');
        $this->update_form->set_rules('mobno', 'Mobile Number', 'trim|exact_length[10]|is_natural_no_zero|required|xss_clean');
        $this->update_form->set_rules('contactno', 'Contact Number', 'trim|is_natural_no_zero|xss_clean');
        $this->update_form->set_rules('tenth', 'Tenth', 'trim|required|is_natural_no_zero|less_than[100]|xss_clean');
        $this->update_form->set_rules('twelth', 'Twelth', 'trim|required|is_natural_no_zero|less_than[100]|xss_clean');
        $this->update_form->set_rules('entrance_rank', 'Entrance Rank', 'trim|required|is_natural_no_zero|xss_clean');
        $this->update_form->set_rules('perm_addr', 'Permanent Address', 'trim|required|alpha_numeric|xss_clean');
        $this->update_form->set_rules('temp_addr', 'Current Address', 'trim|alpha_numeric|xss_clean');
        $this->update_form->set_rules('year_pass', 'Year of Passing', 'trim|required|is_natural_no_zero|greater_than[2000]|xss_clean');
        
        if (!$this->update_form->run()) {
            
            // $this->load->view('placement_students_update', $data);
            $data['error'] = TRUE;
            $data['update_form_error_msg'] = validation_errors();
            $this->students("update", $data);
        } else {
            
            $this->load->model('placement_students');
            
            if ($this->placement_students->update()) {
                $this->update_form->clear_field_data();
                $data['update_form_success_msg'] = "Profile updated successfully";
                $this->students("update", $data);
            } else {
                $data['update_form_error_msg'] = "Updation failed report this immediately to admin";
                $this->students("update", $data);
            }
        }
    }
    
    public function students_register_verify() {
        
        $this->load->library('form_validation', array(), 'register_form');
        $this->register_form->set_rules('captcha', 'Captcha', 'trim|required|callback_captcha_check|xss_clean');
        $this->register_form->set_rules('name', 'Name', 'trim|alpha_space|required|xss_clean');
        $this->register_form->set_rules('username', 'Username', 'trim|min_length[5]|required|is_unique[students.username]|is_unique[company.username]|is_unique[admin.username]|valid_username|xss_clean');
        $this->register_form->set_rules('email', 'Email', 'trim|required|valid_email|is_unique[students.email]|is_unique[company.email]|xss_clean');
        $this->register_form->set_rules('password', 'Password', 'trim|required|min_length[8]|matches[r_password]|xss_clean');
        $this->register_form->set_rules('r_password', 'RetypePassword', 'trim|required|min_length[8]|xss_clean');
        $this->register_form->set_rules('admnno', 'Admission Number', 'trim|required|numeric|is_natural_no_zero|valid_admnno|xss_clean');
        $this->register_form->set_rules('regno', 'Registration Number', 'trim|required|numeric|greater_than[0]|valid_regno|xss_clean');
        $this->register_form->set_rules('year_pass', 'Year of Passing', 'trim|required|numeric|greater_than[2000]|xss_clean');
        
        $this->register_form->set_message('captcha_check', 'Incorrect Captcha');
        
        if (!$this->register_form->run()) {
            
            // $this->load->view('placement_students_register', $data);
            
            $data['register_form_error_msg'] = validation_errors();
            $this->students("register", $data);
        } else {
            
            $this->load->model('placement_students');
            
            if ($this->placement_students->register()) {
                $this->register_form->clear_field_data();
                $data['register_form_success_msg'] = "Registerd successfully wait for confirmation mail to login";
                $this->students("register", $data);
            } else {
                $data['register_form_error_msg'] = "Registration failed report this immediately to admin";
                $this->students("register", $data);
            }
        }
    }
    
    public function company_register_verify() {
        $this->load->library('form_validation', array(), 'company_form');
        $this->company_form->set_rules('companyname', 'Company Name', 'trim|alpha_space|required|xss_clean');
        $this->company_form->set_rules('username', 'Username', 'trim|min_length[5]|required|is_unique[students.username]|is_unique[company.username]|is_unique[admin.username]|valid_username|xss_clean');
        
        $this->company_form->set_rules('email', 'Email', 'trim|required|valid_email|is_unique[students.email]|is_unique[company.email]|xss_clean');
        $this->company_form->set_rules('password', 'Password', 'trim|required|min_length[8]|matches[r_password]|xss_clean');
        $this->company_form->set_rules('r_password', 'RetypePassword', 'trim|required|min_length[8]|xss_clean');
        $this->company_form->set_rules('mobno', 'Mobile Number', 'trim|exact_length[10]|is_natural_no_zero|required|xss_clean');
        $this->company_form->set_rules('website', 'Website', 'trim|required|prep_url|valid_url|xss_clean');
        
        if (!$this->company_form->run()) {
            
            // $this->load->view('placement_students_register', $data);
            
            $data['register_form_error_msg'] = validation_errors();
            $this->company("register", $data);
        } else {
            
            $this->load->model('placement_company');
            
            if ($this->placement_company->register()) {
                $this->company_form->clear_field_data();
                $data['register_form_success_msg'] = "Registerd successfully wait for confirmation mail to login";
                $this->company("register", $data);
            } else {
                $data['register_form_error_msg'] = "Registration failed report this immediately to admin";
                $this->company("register", $data);
            }
        }
    }
    
    public function loginverify() {
        
        $this->load->library('form_validation');
        
        $this->form_validation->set_rules('username', 'Username', 'required|xss_clean');
        $this->form_validation->set_rules('password', 'Password', 'required|xss_clean');
        if ($this->form_validation->run() != FALSE) {
            
            // Load the model
            $this->load->model('placement_admin');
            $this->load->model('placement_students');
            $this->load->model('placement_company');
            
            // Validate the user can login
            $result = $this->placement_admin->check_login();
            
            // Now we verify the result
            if ($result == "false") {
                
                // admin check failed
                $result = $this->placement_students->check_login();
                
                if ($result == "false") {
                    
                    // students check failed try company
                    $result = $this->placement_company->check_login();
                    if ($result == "false") {
                        
                        // If user did not validate, then show them login page again
                        $data['login_form_error_msg'] = 'Invalid username and/or password.';
                        $this->home("home", $data);
                    } else if ($result == "true") {
                        redirect('placement/company/home', 'refresh');
                    } else if ($result == "PENDING") {
                        $data['login_form_error_msg'] = 'Account verification pending.';
                        $this->home("home", $data);
                    } else if ($result == "REJECT") {
                        $data['login_form_error_msg'] = 'Account has been suspended.';
                        $this->home("home", $data);
                    }
                } else if ($result == "true") {
                    
                    // If user did validate,
                    // Send them to students area
                    //echo "here";
                    redirect('placement/students/home', 'refresh');
                } else if ($result == "PENDING") {
                    $data['login_form_error_msg'] = 'Account verification pending.';
                    $this->home("home", $data);
                } else if ($result == "REJECT") {
                    $data['login_form_error_msg'] = 'Account has been suspended.';
                    $this->home("home", $data);
                }
            } else if ($result == "true") {
                redirect('placement/admin/home', 'refresh');
                
                //redirect to admin page
                
                
            } else if ($result == "PENDING") {
                $data['login_form_error_msg'] = 'Account verification pending.';
                $this->home("home", $data);
            } else if ($result == "REJECT") {
                $data['login_form_error_msg'] = 'Account has been suspended.';
                $this->home("home", $data);
            }
        } else {
            $data['login_form_error_msg'] = validation_errors();
            $this->home("home", $data);
        }
    }
    public function check_isvalidated() {
        if (!$this->session->userdata('validated')) {
            
            //print_r($this->session->userdata);
            // redirect('placement/home');
            
            $this->load->view('login_to_continue');
        }
    }
    
    public function events($page = 'events') {
        
        $data = array();
        $this->load->model('Events');
        $events = new Events();
        $events->load(1);
        $data['events'] = $events;
        
        //$this->Events->msg='k'; //insert
        //$this->Events->save();
        echo '<div>' . var_export($this->Events, TRUE) . '</div>';
    }
    
    public function logout() {
        $this->session->sess_destroy();
        $this->load->view('logout');
        
        //redirect('placement/home');
        
        
    }
    
    public function headers($page = "", $type = "") {
        
        if ($page != "") {
            $data['active'] = $page;
        } else {
            
            $data['active'] = "home";
        }
        
        $this->load->view('bootstrap/placement_header');
        if ($type == "admin") {
            $this->load->view('bootstrap/placement_admin_nav', $data);
        } else if ($type == "students") {
            $this->load->view('bootstrap/placement_students_nav', $data);
        } else if ($type == "company") {
            $this->load->view('bootstrap/placement_company_nav', $data);
        } else {
            $this->load->view('bootstrap/placement_nav', $data);
        }
    }
    
    public function footers($type = "") {
        $this->load->view('bootstrap/placement_secondary');
        $this->load->view('bootstrap/placement_footer');
        if ($type == "admin" || $type == "students" || $type == "company") {
            $this->load->view('security_check');
        }
    }
    
    public function index($page = "home") {
        $this->headers();
        if ($page == "home") {
            $this->load->view('home_body_placement');
        } else {
            $this->load->view('404');
        }
        $this->footers();
    }
    
    public function home($page = "home", $data = "") {
        
        // @msg is used to pass error msgs from login validation
        // @page is for page requested
        // @ active is for setting selecte at nav bar
        $this->headers($page);
        
        if ($page == "home") {
            $data['active'] = "home";
            $this->load->view('home_body_placement', $data);
        } else if ($page == "history") {
            $data['active'] = "history";
            $this->load->view('placement_history', $data);
        } else if ($page == "contact") {
            $data['active'] = "contact";
            $this->load->view('placement_contact', $data);
        } else {
            $data['active'] = "home";
            $this->load->view('404');
        }
        
        $this->footers();
    }
    
    public function admin($page = "home", $data = "") {
        $this->check_isvalidated();
        
        // @page is for page requested
        // @ active is for setting selecte at nav bar
        $this->headers($page, "admin");
        $this->load->library('encrypt');
        if ($page == "home") {
            $data['active'] = "home";
            $this->load->view('placement_admin_home', $data);
        } else if ($page == "history") {
            $data['active'] = "history";
            $this->load->view('placement_admin_history', $data);
        } else if ($page == "verify") {
            $this->load->model('placement_students');
            $this->load->model('placement_company');
            $data['students_newreg'] = $this->placement_students->verify_newreg();
            $data['company_newreg'] = $this->placement_company->verify_newreg();
            $this->placement_students->verify_newreg();
            $data['active'] = "verify";
            $this->load->view('placement_admin_verify', $data);
        } else {
            $data['active'] = "home";
            $this->load->view('404');
        }
        
        $this->footers("admin");
    }
    
    public function students($page, $data = "") {
        
        if (($page != "register")) {
            $this->check_isvalidated();
            $this->headers($page, "students");
            $this->load->model('placement_students');
            $this->load->model('placement_branches');
            $this->load->model('placement_semesters');
            $data['student_details'] = $this->placement_students->get_details();
            $data['branch_details'] = $this->placement_branches->get_branches();
            $data['semester_details'] = $this->placement_semesters->get_semesters();
        } else {
            $this->headers($page, "home");
        }
        
        if ($page == "home") {
            $this->load->view('placement_students_home', $data);
        } else if ($page == "register") {
            $this->load->view('placement_students_register', $data);
        } else if ($page == "update") {
            $this->load->view('placement_students_update', $data);
        } else if ($page == "marks") {
            $this->load->model('placement_marks');
            $data['mark_details'] = $this->placement_marks->get_marksdetails_students();
            $this->load->view('placement_students_marks', $data);
        } else if ($page == "performance") {
            $this->load->view('placement_under_construction_in', $data);
        } else if ($page == "resume") {
            $this->load->view('placement_under_construction_in', $data);
        } else if ($page == "offers") {
            $this->load->view('placement_under_construction_in', $data);
        } else if ($page == "placements") {
            $this->load->view('placement_under_construction_in', $data);
        } else if ($page == "settings") {
            $this->load->view('placement_under_construction_in', $data);
        } else if ($page == "help") {
            $this->load->view('placement_under_construction_in', $data);
        } else {
            $this->load->view('404');
        }
        
        if (!$page = "register") {
            $this->footers("students");
        } else {
            $this->footers("home");
        }
    }
    
    public function company($page, $data = "") {
        
        if (($page != "register")) {
            $this->check_isvalidated();
            $this->headers($page, "company");
        } else {
            $this->headers($page, "home");
        }
        if ($page == "home") {
            $this->load->view('placement_company_home', $data);
        } else if ($page == "register") {
            
            $this->load->view('placement_company_register', $data);
        } else {
            $this->load->view('404');
        }
        if (!$page = "register") {
            $this->footers("company");
        } else {
            $this->footers("home");
        }
    }
    
    public function upload_profile_pic_student() {
        $config['upload_path'] = 'profile_pics/';
        $config['allowed_types'] = 'jpeg|jpg';
        $config['max_size'] = '500';
        $config['max_width'] = '800';
        $config['max_height'] = '800';
        $config['file_name'] = rand(0, 999999999);
        $this->load->library('upload', $config);
        
        if (!$this->upload->do_upload()) {
            $data['error'] = $this->upload->display_errors();
            
            $this->students('home', $data);
        } else {
            
            //$data['upload_data']= $this->upload->data();
            $this->load->model('placement_students');
            $this->placement_students->profile_pic_update($config['file_name']);
            $this->students('home');
        }
    }
    
    public function captcha_check($value = '') {
        
        // First, delete old captchas
        $expiration = time() - 7200;
        
        // Two hour limit
        $this->db->query("DELETE FROM captcha WHERE captcha_time < " . $expiration);
        
        // Then see if a captcha exists:
        $sql = "SELECT COUNT(*) AS count FROM captcha WHERE word = ? AND ip_address = ? AND captcha_time > ?";
        $binds = array($_POST['captcha'], $this->input->ip_address(), $expiration);
        $query = $this->db->query($sql, $binds);
        $row = $query->row();
        
        if ($row->count == 0) {
            return FALSE;
        }
        return TRUE;
    }
} ?>
